function browserOrigin() {
  return typeof window !== 'undefined' ? window.location.origin : 'http://localhost:5000';
}

function browserHostname() {
  return typeof window !== 'undefined' ? window.location.hostname : 'localhost';
}

function isLocalHostname(hostname: string) {
  return ['localhost', '127.0.0.1', '0.0.0.0', '::1'].includes(hostname);
}

function isLocalConfiguredUrl(value: string) {
  try {
    const parsed = new URL(value);
    return isLocalHostname(parsed.hostname);
  } catch {
    return false;
  }
}

function resolveApiUrl() {
  const configured = process.env.NEXT_PUBLIC_API_URL || '';
  const origin = browserOrigin();
  if (!configured) return `${origin}/api/v1`;
  if (configured.startsWith('/')) return configured;
  if (typeof window !== 'undefined' && isLocalConfiguredUrl(configured) && !isLocalHostname(browserHostname())) return `${origin}/api/v1`;
  return configured.replace(/\/$/, '');
}

function resolveSocketUrl() {
  const configured = process.env.NEXT_PUBLIC_SOCKET_URL || '';
  const origin = browserOrigin();
  if (!configured) return origin;
  if (configured.startsWith('/')) return origin;
  if (typeof window !== 'undefined' && isLocalConfiguredUrl(configured) && !isLocalHostname(browserHostname())) return origin;
  return configured.replace(/\/$/, '');
}

export const API_URL = resolveApiUrl();
export const SOCKET_URL = resolveSocketUrl();

export type Admin = {
  id: string;
  email: string;
  displayName: string;
  status: string;
  role: 'super_admin' | 'admin' | 'meeting_admin';
  permissions?: string[] | null;
  effectivePermissions?: string[];
  disabledAt?: string | null;
  mustChangePassword: boolean;
  lastLoginAt?: string | null;
  passwordChangedAt?: string | null;
  createdAt?: string | null;
};

export type AdminSession = {
  id: string;
  ipAddress?: string | null;
  userAgent?: string | null;
  expiresAt: string;
  lastSeenAt: string;
  revokedAt?: string | null;
  revokedReason?: string | null;
  active: boolean;
  createdAt: string;
};

export type CsrfResponse = { csrfToken?: string };

export type AdminDevice = { id: string; adminId: string; label?: string | null; firstIp?: string | null; lastIp?: string | null; userAgent?: string | null; lastSeenAt?: string | null; trusted: boolean; revokedAt?: string | null; active: boolean; createdAt?: string | null };
export type IPBlock = { id: string; ipAddress: string; reason?: string | null; expiresAt?: string | null; revokedAt?: string | null; active: boolean; createdAt?: string | null };
export type E2EESetting = { enabled: boolean; requirePassphrase: boolean; mode: 'off' | 'optional' | 'required' };
export type ApiKey = { id: string; name: string; keyPrefix: string; scopes: string[]; expiresAt?: string | null; lastUsedAt?: string | null; revokedAt?: string | null; active: boolean; createdAt?: string | null };
export type WebhookSubscription = { id: string; targetUrl: string; events: string[]; enabled: boolean; description?: string | null; lastSuccessAt?: string | null; lastFailureAt?: string | null; createdAt?: string | null; updatedAt?: string | null; signingSecret?: string };
export type WebhookDelivery = { id: string; subscriptionId: string; eventType: string; payload: Record<string, unknown>; status: 'pending' | 'delivered' | 'failed'; attempts: number; lastAttemptAt?: string | null; nextRetryAt?: string | null; responseStatus?: number | null; responseBody?: string | null; errorMessage?: string | null; signature?: string | null; createdAt?: string | null };

export type AuditLog = {
  id: string;
  action: string;
  entityType?: string | null;
  entityId?: string | null;
  ipAddress?: string | null;
  metadata: Record<string, unknown>;
  createdAt: string;
};

export type Meeting = {
  id: string;
  meetingId: string;
  title: string;
  description?: string | null;
  scheduledStartAt: string;
  scheduledEndAt: string;
  timezone: string;
  status: string;
  hasPassword: boolean;
  linkExpiresAt?: string | null;
  reminderMinutes: number;
  waitingRoomEnabled: boolean;
  maxParticipants?: number | null;
  isLocked: boolean;
  allowParticipantAudio: boolean;
  allowParticipantVideo: boolean;
  allowChat: boolean;
  allowScreenShare: boolean;
  allowWhiteboard: boolean;
  screenSharePolicy: 'host' | 'cohosts' | 'all';
  activeScreenShareParticipantId?: string | null;
  presenterLayout: 'presenter' | 'side_by_side' | 'gallery';
  sharedCursorEnabled: boolean;
  endedAt?: string | null;
  advancedSettings?: Record<string, any>;
  participantCount: number;
  livekitRoomName?: string | null;
  invitationUrl?: string | null;
  invitationToken?: string | null;
  createdAt: string;
  updatedAt: string;
};

export type MeetingInvitation = {
  id?: string;
  meetingId?: string;
  token?: string;
  url: string;
  regeneratedAt?: string | null;
  createdAt?: string | null;
};

export type ChatFile = {
  id: string;
  meetingId: string;
  filename: string;
  contentType: string;
  sizeBytes: number;
  sha256: string;
  uploaderName: string;
  createdAt: string;
};

export type ChatMessage = {
  id: string;
  meetingId: string;
  senderAdminId?: string | null;
  senderParticipantId?: string | null;
  senderDisplayName: string;
  body?: string | null;
  messageType: 'text' | 'file';
  file?: ChatFile | null;
  replyToId?: string | null;
  threadRootId?: string | null;
  pinned?: boolean;
  metadata?: { reactions?: Record<string, string[]>; savedBy?: string[]; mentions?: string[]; markdown?: boolean; [key: string]: any };
  createdAt: string;
};

export type MediaRegion = { id: string; code: string; name: string; livekitUrl: string; turnUrl?: string | null; priority: number; enabled: boolean; createdAt?: string | null; updatedAt?: string | null };
export type NetworkDiagnostic = { id: string; meetingId: string; participantId: string; participantName?: string | null; quality?: string | null; rttMs?: number | null; jitterMs?: number | null; packetLoss?: number | null; downlinkMbps?: number | null; effectiveType?: string | null; saveData?: boolean | null; online?: boolean | null; iceState?: string | null; roomState?: string | null; selectedRegion?: string | null; raw: Record<string, unknown>; createdAt: string };

export type PollOption = { id: string; pollId: string; text: string; position: number };
export type PollResultOption = PollOption & { votes: number; percent: number; voters: string[] };
export type Poll = {
  id: string;
  meetingId: string;
  title: string;
  anonymous: boolean;
  multipleChoice: boolean;
  status: 'open' | 'closed';
  isOpen: boolean;
  closesAt?: string | null;
  closedAt?: string | null;
  options: PollOption[];
  results: { totalVotes: number; options: PollResultOption[] };
  createdAt: string;
};
export type Question = {
  id: string;
  meetingId: string;
  authorDisplayName: string;
  text: string;
  status: 'open' | 'answered' | 'dismissed';
  answerText?: string | null;
  answeredByDisplayName?: string | null;
  answeredAt?: string | null;
  upvotes: number;
  createdAt: string;
  updatedAt: string;
};

export type BreakoutAssignment = {
  id: string;
  meetingId: string;
  roomId: string;
  participantId: string;
  participant?: Participant | null;
  status: 'assigned' | 'active' | 'returned';
  movedAt?: string | null;
  returnedAt?: string | null;
  createdAt: string;
};

export type BreakoutRoom = {
  id: string;
  meetingId: string;
  name: string;
  livekitRoomName: string;
  status: 'open' | 'closed';
  timerEndsAt?: string | null;
  closedAt?: string | null;
  assignments: BreakoutAssignment[];
  activeCount: number;
  assignedCount: number;
  createdAt: string;
};

export type WhiteboardElement = {
  id: string;
  meetingId: string;
  actorAdminId?: string | null;
  actorParticipantId?: string | null;
  actorDisplayName: string;
  elementType: 'pen' | 'highlighter' | 'line' | 'rect' | 'ellipse' | 'text' | 'sticky' | 'image' | 'flow_rect' | 'flow_diamond' | 'uml_class' | 'mind_node';
  payload: Record<string, any>;
  zIndex: number;
  active: boolean;
  deletedAt?: string | null;
  createdAt: string;
  updatedAt: string;
};

export type Recording = {
  id: string;
  meetingId: string;
  adminId: string;
  title: string;
  status: 'recording' | 'processing' | 'ready' | 'archived' | 'failed';
  startedAt: string;
  endedAt?: string | null;
  durationSeconds: number;
  filename?: string | null;
  contentType?: string | null;
  sizeBytes: number;
  sha256?: string | null;
  errorMessage?: string | null;
  metadata: Record<string, unknown>;
  category?: string | null;
  expiresAt?: string | null;
  transcriptText?: string | null;
  summaryText?: string | null;
  shareCount?: number;
  playbackCount?: number;
  downloadCount?: number;
  createdAt: string;
  updatedAt: string;
};

export type RecordingShare = {
  id: string;
  recordingId: string;
  url?: string;
  expiresAt?: string | null;
  allowDownload: boolean;
  watermarkText?: string | null;
  clipStartSeconds?: number | null;
  clipEndSeconds?: number | null;
  passwordRequired: boolean;
  revokedAt?: string | null;
  lastAccessedAt?: string | null;
  active: boolean;
  accessCount: number;
  createdAt: string;
};

export type ParticipantHostControls = {
  handRaised?: boolean;
  handRaisedAt?: string | null;
  unmuteRequestedAt?: string | null;
  screenShareGranted?: boolean;
  screenShareRevoked?: boolean;
  whiteboardGranted?: boolean;
  whiteboardRevoked?: boolean;
  cohostPermissions?: string[];
  presenter?: boolean;
  pinned?: boolean;
  spotlighted?: boolean;
};

export type Participant = {
  id: string;
  meetingId: string;
  displayName: string;
  role: 'host' | 'participant' | 'cohost' | 'moderator' | 'presenter' | 'guest';
  status: 'waiting' | 'admitted' | 'rejected' | 'left';
  deviceInfo: Record<string, unknown>;
  hostControls?: ParticipantHostControls;
  muted: boolean;
  cameraEnabled: boolean;
  audioDisabled: boolean;
  videoDisabled: boolean;
  screenShareDisabled: boolean;
  screenSharing: boolean;
  screenSharePaused: boolean;
  screenShareSource?: string | null;
  lowBandwidthMode: boolean;
  audioOnlyMode: boolean;
  preferredLayout: 'auto' | 'mobile' | 'gallery' | 'speaker';
  mobileClient: boolean;
  networkType?: string | null;
  lastQualityReport: Record<string, unknown>;
  removedReason?: string | null;
  joinedAt?: string | null;
  admittedAt?: string | null;
  rejectedAt?: string | null;
  leftAt?: string | null;
  createdAt?: string | null;
  ipAddress?: string | null;
  userAgent?: string | null;
};

export function getAccessToken() {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem('defensiq.accessToken');
}

export function getRefreshToken() {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem('defensiq.refreshToken');
}

export function getCsrfToken() {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem('defensiq.csrfToken');
}

export function getDeviceId() {
  if (typeof window === 'undefined') return '';
  let id = localStorage.getItem('defensiq.deviceId');
  if (!id) {
    id = crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`;
    localStorage.setItem('defensiq.deviceId', id);
  }
  return id;
}

export function saveAuth(accessToken: string, refreshToken: string, admin: Admin, csrfToken?: string) {
  localStorage.setItem('defensiq.accessToken', accessToken);
  localStorage.setItem('defensiq.refreshToken', refreshToken);
  localStorage.setItem('defensiq.admin', JSON.stringify(admin));
  document.cookie = `defensiq_admin_present=1; Path=/; SameSite=Strict; Max-Age=${60 * 60 * 24 * 30}`;
  if (csrfToken) localStorage.setItem('defensiq.csrfToken', csrfToken);
}

export function clearAuth() {
  localStorage.removeItem('defensiq.accessToken');
  localStorage.removeItem('defensiq.refreshToken');
  localStorage.removeItem('defensiq.admin');
  localStorage.removeItem('defensiq.csrfToken');
  document.cookie = 'defensiq_admin_present=; Path=/; SameSite=Strict; Max-Age=0';
}

export function cachedAdmin(): Admin | null {
  if (typeof window === 'undefined') return null;
  const raw = localStorage.getItem('defensiq.admin');
  if (!raw) return null;
  try { return JSON.parse(raw) as Admin; } catch { return null; }
}

type Options = RequestInit & { auth?: boolean; retry?: boolean };

export async function api<T>(path: string, options: Options = {}): Promise<T> {
  const headers = new Headers(options.headers || {});
  if (!(options.body instanceof FormData) && !headers.has('Content-Type')) headers.set('Content-Type', 'application/json');
  headers.set('X-Device-Id', getDeviceId());
  if (options.auth !== false) {
    const token = getAccessToken();
    if (token) headers.set('Authorization', `Bearer ${token}`);
    if (['POST', 'PUT', 'PATCH', 'DELETE'].includes((options.method || 'GET').toUpperCase())) {
      const csrf = getCsrfToken();
      if (csrf) headers.set('X-CSRF-Token', csrf);
    }
  }
  const response = await fetch(`${API_URL}${path}`, { ...options, headers, cache: 'no-store' });
  if (response.status === 401 && options.auth !== false && options.retry !== false) {
    const ok = await refreshAccessToken();
    if (ok) return api<T>(path, { ...options, retry: false });
  }
  if (!response.ok) {
    let message = `Request failed (${response.status})`;
    let code = 'request_failed';
    try {
      const body = await response.json();
      message = body.error?.message || message;
      code = body.error?.code || code;
    } catch {}
    const err = new Error(message) as Error & { code?: string };
    err.code = code;
    throw err;
  }
  return response.json() as Promise<T>;
}

async function refreshAccessToken() {
  const refreshToken = getRefreshToken();
  if (!refreshToken) return false;
  try {
    const response = await fetch(`${API_URL}/auth/refresh`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Device-Id': getDeviceId() }, body: JSON.stringify({ refreshToken })
    });
    if (!response.ok) return false;
    const data = await response.json();
    saveAuth(data.accessToken, data.refreshToken, data.admin, data.csrfToken);
    return true;
  } catch {
    return false;
  }
}
