import { io, Socket } from 'socket.io-client';
import { getAccessToken, SOCKET_URL } from './api';

let socket: Socket | null = null;
let activeToken = '';

export function getSocket(token?: string) {
  const selected = token || getAccessToken() || '';
  if (!socket || socket.disconnected || activeToken !== selected) {
    socket?.disconnect();
    activeToken = selected;
    socket = io(SOCKET_URL, { path: '/socket.io/', transports: ['polling', 'websocket'], upgrade: true, auth: { token: selected }, reconnection: true, reconnectionAttempts: Infinity, reconnectionDelay: 500, reconnectionDelayMax: 5000, randomizationFactor: 0.35, timeout: 10000 });
  }
  return socket;
}

export function closeSocket() {
  socket?.disconnect();
  socket = null;
  activeToken = '';
}
