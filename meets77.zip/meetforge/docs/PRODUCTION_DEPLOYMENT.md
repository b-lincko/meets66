# Defensiq Meet Production Deployment Guide

This guide covers production deployment for the current Defensiq Meet application.

Current verified stack:

- Flask backend with Gunicorn gevent WebSocket worker
- PostgreSQL database
- Redis for rate-limit storage and Socket.IO message queue
- LiveKit media server
- Next.js `15.5.18` frontend
- Nginx reverse proxy
- Docker Compose orchestration

## Required production environment

Set these values before running with `FLASK_ENV=production`:

```env
FLASK_ENV=production
PUBLIC_APP_URL=https://meets.dpdns.org
SECRET_KEY=<64+ random chars>
JWT_SECRET=<64+ random chars>
DEFAULT_ADMIN_EMAIL=<admin email>
DEFAULT_ADMIN_PASSWORD=<temporary strong password changed on first login>
DATABASE_URL=postgresql+psycopg://...
REDIS_URL=redis://...
RATELIMIT_STORAGE_URI=redis://...
SOCKETIO_MESSAGE_QUEUE=redis://...
LIVEKIT_URL=wss://meets.dpdns.org/livekit
LIVEKIT_INTERNAL_URL=ws://livekit:7880
LIVEKIT_API_KEY=<livekit key>
LIVEKIT_API_SECRET=<32+ random chars>
LIVEKIT_ROOM_PREFIX=defensiq
CORS_ORIGINS=https://meets.dpdns.org
CSRF_ENFORCED=true
STUN_SERVERS=stun:stun.l.google.com:19302
TURN_URLS=turns:turn.example.com:5349
TURN_USERNAME=<turn username>
TURN_CREDENTIAL=<turn credential>
MAX_CHAT_FILE_MB=25
MAX_RECORDING_UPLOAD_MB=1024
NEXT_PUBLIC_API_URL=https://meets.dpdns.org/api/v1
NEXT_PUBLIC_SOCKET_URL=https://meets.dpdns.org
NEXT_PUBLIC_LIVEKIT_URL=wss://meets.dpdns.org/livekit
```

The backend validates production configuration with:

```bash
flask validate-config
```

The Docker backend command also runs this validation before starting.

## HTTPS reverse proxy

Use `nginx/nginx.prod.conf` for HTTPS deployments. Mount certificates at:

```text
/etc/nginx/certs/fullchain.pem
/etc/nginx/certs/privkey.pem
```

The production Nginx config includes:

- HTTP to HTTPS redirect
- TLS 1.2/1.3
- HSTS
- Secure headers
- WebSocket proxying for Socket.IO
- WebSocket proxying for LiveKit when configured behind Nginx
- Large upload limit for recording uploads

## WebRTC network requirements

For reliable enterprise use:

- Configure TURN with `turns:` URLs for restrictive networks.
- Keep at least one STUN server configured.
- Expose LiveKit TCP and UDP ports required by the selected LiveKit deployment mode.
- Confirm firewall/NAT rules for LiveKit and TURN before user rollout.
- Configure media regions if multiple LiveKit endpoints are deployed.

## Health checks

Backend:

```text
GET /api/v1/health/live
GET /api/v1/health/ready
GET /api/v1/health/metrics
GET /api/v1/health/config
```

Docker Compose includes health checks for backend, frontend, Nginx, and PostgreSQL.

Readiness check:

```bash
curl -fsS https://meets.dpdns.org/api/v1/health/ready
```

## Backups

Linux/macOS:

```bash
scripts/backup_postgres.sh
scripts/restore_postgres.sh backups/<file>.sql
```

Windows:

```bat
scripts\backup_postgres.bat
scripts\restore_postgres.bat backups\<file>.sql
```

Backups are written to `backups/` and include SHA-256 checksum files.

Operational requirements:

- Store backup copies outside the Docker host.
- Test restore regularly in a non-production environment.
- Protect backup files because they contain meeting metadata, recordings, audit logs, and admin data.

## Monitoring

Prometheus-compatible metrics are exposed at:

```text
/api/v1/health/metrics
```

The endpoint reports:

- API up/down
- Database up/down
- Backend process RSS memory
- Host memory percentage
- Host disk percentage

Also monitor:

- PostgreSQL disk usage
- Redis memory
- LiveKit health and participant counts
- Nginx 4xx/5xx rates
- Recording upload and transcoding failures
- Webhook delivery failures
- Admin audit-log activity

## Production verification commands

Backend:

```bash
python -m py_compile $(find backend/app -name '*.py')
cd backend && pytest -q
```

Frontend:

```bash
cd frontend
npm install
npm run typecheck
npm run build
npm audit --audit-level=moderate
```

Compose YAML:

```bash
python - <<'PY'
from pathlib import Path
import yaml
yaml.safe_load(Path('docker-compose.yml').read_text())
print('docker-compose.yml valid YAML')
PY
```

Latest known verification:

```text
Backend: 123 passed, 1 warning
Frontend: typecheck passed, build passed, audit 0 vulnerabilities
Compose: valid YAML
```

## Operational checklist

1. Set production secrets and URLs.
2. Configure PostgreSQL and Redis persistence.
3. Configure LiveKit public/internal URLs.
4. Configure STUN/TURN.
5. Run `flask validate-config`.
6. Run Docker Compose YAML validation.
7. Run `docker compose up --build -d`.
8. Confirm `/api/v1/health/ready` returns ready.
9. Confirm `/api/v1/health/metrics` is scraped by monitoring.
10. Confirm admin must change the temporary password.
11. Create named admin accounts and disable unused accounts.
12. Review role/permission assignments.
13. Confirm participants can join, be admitted, and publish audio/video.
14. Confirm host participant controls, join requests, recordings, whiteboard, chat, and screen share work in production browsers.
15. Configure scheduled backups.
16. Test restore.
17. Review audit logs after first production login.
