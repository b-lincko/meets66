# Defensiq Meet

Private, self-hosted enterprise video conferencing platform for Defensiq Security.

Defensiq Meet is a production-oriented Flask + Next.js + LiveKit application with PostgreSQL, Redis, Socket.IO, Docker Compose, role-based administration, real WebRTC audio/video, secure meeting links, recordings, whiteboard, breakouts, polls, analytics, integrations, and operational deployment tooling.

AI captions/transcription are intentionally not included because AI features were skipped by request.

## Current status

The application is implemented end-to-end and the exposed UI is connected to working backend/database/WebSocket/LiveKit flows. The latest reliability pass added the upgraded meeting people-management interface, professional clean-canvas recording mode, and updated frontend security dependencies.

Latest verified build state:

```text
Backend: 123 tests passed, Python compile passed
Frontend: TypeScript passed, production build passed
Frontend audit: 0 vulnerabilities
Docker Compose: YAML parsed successfully
```

## Latest update

### Meeting interface

- Collapsible right-side meeting panel with smooth layout resizing.
- Panel visibility persists for the current meeting session.
- Dedicated toolbar buttons for:
  - Participants
  - Join Requests
  - Hide/Show Panel
  - Raise/Lower Hand
- Participants panel shows:
  - total participant count
  - display name
  - role
  - camera status
  - microphone status
  - connection quality
  - hand-raised indicator
  - presenter/pinned/spotlight labels
- Join Requests panel shows waiting-room users in real time with:
  - name
  - join/request time
  - meeting title/code
  - device/browser information when available
  - approve/reject/ban controls
- Join request badge updates without refresh through WebSockets.
- Host controls are integrated into the participant list instead of floating over the meeting view.
- Whiteboard text/sticky-note entry now uses an in-app dialog instead of browser `prompt()`.

### Host and co-host controls

Admins/hosts can manage participants from the Participants panel:

- Mute participant
- Ask participant to unmute
- Disable/enable microphone
- Disable/enable camera
- Grant/revoke screen sharing permission
- Grant/revoke whiteboard permission
- Promote to co-host
- Remove co-host role
- Grant/revoke co-host management controls
- Change presenter
- Pin/unpin participant
- Spotlight/clear spotlight
- Rename participant
- Remove participant
- Move participant to waiting room
- Ban participant
- View connection quality

Permission enforcement is server-side:

- Hosts can access all participant management controls.
- Co-hosts see and execute participant management only after the host grants explicit management permission.
- Regular participants do not see or access host controls.
- Unauthorized participant-token control calls return permission errors.

### Professional recording mode

- Recording no longer captures the meeting interface.
- Output is composed on a private offscreen canvas.
- Default output includes only the shared screen/presentation and active presenter camera in Picture-in-Picture.
- Automatic presenter switching follows the active screen-sharing participant.
- Recording modes include presenter + screen, screen only, presenter camera only, and gallery.
- Host can change PiP position, PiP size, recording mode, presenter camera inclusion, resolution, and watermark setting.
- Pause, resume, and stop recording controls are functional.
- Recording audio mixes meeting microphone tracks and the presenter's screen-share audio when available.
- Recording metadata stores presenter name, mode, PiP position, resolution, clean-recording flags, and thumbnail data.
- Participants see an informational recording indicator; this indicator is not included in the exported video.
- LiveKit participant-not-found races during permission updates are handled as safe no-ops instead of noisy backend tracebacks.
- Dashboard meeting history includes a functional delete action for past/non-running meetings.
- A production Create Meeting page is available at `/meetings/new` with live summary, backend draft auto-save, conflict detection, templates, advanced meeting policies, invite emails, preview, duplicate, reset, and full backend validation/persistence.
- During screen sharing, participant thumbnails are hidden and the shared content expands to the full stage with presenter PiP only.
- Viewer zoom and pan controls for screen sharing are available with floating toolbar, Ctrl+wheel, keyboard shortcuts, drag-to-pan, double-tap zoom, and fullscreen mode.
- Intelligent layout engine improvements include dynamic video-grid sizing, drag-to-reorder gallery tiles, local layout persistence, control auto-hide, keyboard shortcuts, and push-to-talk Spacebar behavior.
- Presenter mode includes private presenter notes, presentation timer, laser pointer, and synced shared-screen annotations.
- Participant management now supports role grouping, sorting by speaking/hand/join time/name, and bulk mute/request-unmute/remove/move-to-waiting actions.
- Whiteboard now supports flowchart shapes, UML class boxes, mind-map nodes, SVG export, and version history for inactive/active elements.
- Chat now supports replies, threads, emoji reactions, markdown/code-block rendering, @mentions, pinned messages, saved messages, and authenticated image/file previews.
- Meeting Roles & Permissions page added for per-meeting Meeting Admin, Co-host, Moderator, and Presenter assignments with granular permission editor, role candidate search, realtime role sync, attendance CSV export, and live meeting administration dashboard.
- Co-hosts with waiting-room permissions can now see pending requests and approve/reject/ban joiners immediately without page refresh.
- Recording control fixes: Record now starts immediately without requiring a prior screen share, co-hosts with recording permissions can start/upload recordings through participant-token endpoints, and co-host meeting controls can lock/end/change layout when explicitly granted.
- Screen share capture now respects the browser picker source exactly; choosing Entire Screen records desktop/app switching, while choosing Window or Tab records only that source. The app no longer forces browser-tab capture.
- Web security pass added middleware-backed 404 protection for private routes, stricter public join input validation, safe admin next-URL handling, origin enforcement for unsafe API requests, and stronger frontend CSP/Permissions-Policy headers.
- Domain deployment fix: frontend API/Socket clients now fall back to same-origin `/api/v1` and current origin sockets when localhost values are accidentally present on a real domain; CSP also allows Cloudflare Insights when Cloudflare injects its beacon.
- Client-side performance pass added camera subscription throttling during screen share, reduced quality-report writes, virtualized participant list rendering, client-side MP4 recording upload when supported, throttled recording canvas FPS, live FPS/memory diagnostics, and extra performance indexes.
- Range-based recording playback/download now supports HTTP byte ranges for smoother seeking and lower transfer pressure.
- Pre-join now remembers preferred camera/microphone/start states and includes a lightweight device test with low-resolution preview to reduce client load before joining.
- Second performance pass added Next.js standalone runtime, Docker build-context pruning, MALLOC_ARENA_MAX memory tuning, static asset immutable caching, gzip compression, gallery camera subscription caps, large-gallery render caps, active-speaker video quality prioritization, and screen-share capture constraints.
- An additional 2 vCPU/2 GB optimization pass reduced gallery rendering to prioritized visible tiles, capped remote camera subscriptions more aggressively, uses active-speaker camera quality boosting, optimizes participant counts in meeting list APIs, and limits recording gallery composition to active/visible participants.
- Recording library now includes automatic chapters, timeline events, transcript segments, searchable/clickable public playback transcript, thumbnail preview metadata, clip-share start/end times, and password-protected clip playback.

### Security/dependency updates

- Next.js upgraded to `15.5.18`.
- PostCSS pinned/overridden to `8.5.10`.
- `npm audit --audit-level=moderate` reports zero vulnerabilities.
- Dynamic Next.js route pages updated for Next 15 async route params.

## Main capabilities

### Authentication and enterprise administration

- Private admin console at `/admin`.
- Forced first-login password change.
- JWT access tokens and rotating refresh sessions.
- Session revocation and idle timeout enforcement.
- Account lockout after repeated failed logins.
- Database-backed audit logs.
- Super admin, admin, and meeting admin roles.
- Granular permissions for admins, settings, meetings, recordings, security, integrations, and analytics.
- Admin management UI for creating, disabling, soft-deleting, resetting passwords, and assigning permissions.
- Enterprise settings UI for user management, meetings, security, storage, email, and branding.

### Meeting scheduling and joining

- Admin-only meeting creation and scheduling.
- Secure generated meeting IDs.
- Optional meeting passwords with hashing.
- Secure invitation links with expiration and regeneration.
- Public invitation validation page.
- Pre-join device preview.
- Camera and microphone selection.
- Waiting room with real-time host approval.
- Meeting lock, capacity enforcement, and host-only-start support.

### WebRTC meeting room

- LiveKit-backed audio/video rooms.
- Camera and microphone controls.
- Screen/window/browser-tab sharing.
- Screen-share audio capture request where supported.
- Pause/resume/switch sharing.
- Presenter, side-by-side, and gallery layouts.
- Adaptive streaming and dynacast.
- Local audio-start prompt for browser autoplay rules.
- Client-side enforcement of host mute/camera/screen/remove/end controls.

### Chat and files

- Real-time Socket.IO chat.
- Database-persisted message history.
- Typing indicators.
- File attachments and authenticated downloads.
- Host chat policy enforcement.

### Recording and recording library

- Host-only recording controls.
- Recording captures meeting content without chat/participants/controls overlays.
- Screen share plus host camera composition for presentation recordings.
- Browser MediaRecorder capture.
- Backend upload and FFmpeg MP4 conversion.
- MP4 playback and download.
- Recording metadata, archive/restore, deletion, categories, summary, transcript search text, and expiration.
- Secure recording share links.
- Password-protected shares.
- Share expiration, revocation, download permission, watermark overlay, and analytics.

### Whiteboard

- Real-time collaborative whiteboard.
- Pen, highlighter, lines, rectangles, ellipses, text, sticky notes, images, and laser pointer.
- Undo/redo per user.
- Database persistence for every element.
- Host policy and per-participant whiteboard grants/revokes.
- PNG and PDF export.

### Breakout rooms

- Create named breakout rooms.
- Timers.
- Auto assignment.
- Manual assignment.
- Move participants to rooms.
- Return everyone to the main room.
- Close rooms.
- Broadcast messages to breakout rooms.
- LiveKit room switching for moved participants.

### Polls and Q&A

- Live polls with single or multiple-choice voting.
- Anonymous and timed polls.
- Host/co-host close actions.
- Results with counts and percentages.
- CSV exports.
- Q&A submission, upvoting, moderation, answer tracking, and export.

### Calendar integration

- ICS calendar files.
- Public and admin calendar downloads.
- Google Calendar links.
- Outlook / Office 365 links.
- Yahoo links.
- Recurring event RRULE support.
- Calendar reminders.

### Mobile and network optimization

- Mobile detection during join.
- Low-bandwidth and audio-only modes.
- Participant preferred layout persistence.
- Network Information API quality reports when supported.
- STUN/TURN configuration through environment variables.
- Media region configuration.
- Admin network diagnostics and CSV export.
- Meeting-room Network panel.

### Security hardening

- CSRF protection on unsafe admin requests.
- Per-device admin tracking.
- Device trust/revoke workflow.
- IP block management with expiration/revocation.
- Self-IP block prevention unless forced.
- Optional E2EE policy endpoints.
- Security headers.
- Audit logging for sensitive operations.

### APIs, webhooks, and integrations

- OpenAPI JSON endpoint.
- Built-in API documentation endpoint.
- Hashed API keys with scopes.
- External API endpoints for meetings and recordings.
- Webhook subscriptions.
- HMAC SHA-256 signed webhook deliveries.
- Delivery logging and retry.
- Integrations UI.

### Analytics and operations

- Admin dashboard with live database-backed analytics.
- Meeting, participant, recording, chat, storage, and auth-event metrics.
- CSV exports.
- Performance Center with process and host metrics.
- Production health, readiness, config, and metrics endpoints.
- Docker Compose healthchecks.
- Production Nginx HTTPS/WebSocket config.
- PostgreSQL backup/restore scripts for Linux/macOS and Windows.

## Tech stack

- Backend: Flask 3, Flask-SQLAlchemy, Flask-SocketIO, Flask-Limiter
- Database: PostgreSQL through `psycopg`
- Cache/queues/rate-limit storage: Redis
- Realtime: Socket.IO
- Media: LiveKit
- Frontend: Next.js 15, React 18, Tailwind CSS, LiveKit React components
- Deployment: Docker Compose, Nginx, Gunicorn gevent WebSocket worker

## Repository layout

```text
backend/                 Flask API and tests
frontend/                Next.js web app
nginx/                   Development and production Nginx configs
scripts/                 PostgreSQL backup/restore scripts

docker-compose.yml       Full local stack
.env.example             Environment template
run.sh                   Linux/macOS launcher
run.bat                  Windows launcher
README.md                Current project documentation
docs/PRODUCTION_DEPLOYMENT.md
FINAL_PROJECT_STATUS.md
```

Generated test/build/cache artifacts and phase-verification markdown files are not required for runtime and have been removed from the root workspace.

## Environment

Create a local environment file:

```bash
cp .env.example .env
```

Important variables:

```env
APP_NAME=Defensiq Meet
PUBLIC_APP_URL=https://meets.dpdns.org
DATABASE_URL=postgresql+psycopg://meetforge:meetforge@postgres:5432/meetforge
REDIS_URL=redis://redis:6379/0
RATELIMIT_STORAGE_URI=redis://redis:6379/1
SOCKETIO_MESSAGE_QUEUE=redis://redis:6379/2
LIVEKIT_URL=wss://meets.dpdns.org/livekit
LIVEKIT_INTERNAL_URL=ws://livekit:7880
LIVEKIT_API_KEY=devkey
LIVEKIT_API_SECRET=secret
CSRF_ENFORCED=true
STUN_SERVERS=stun:stun.l.google.com:19302
TURN_URLS=
TURN_USERNAME=
TURN_CREDENTIAL=
NEXT_PUBLIC_API_URL=https://meets.dpdns.org/api/v1
NEXT_PUBLIC_SOCKET_URL=https://meets.dpdns.org
NEXT_PUBLIC_LIVEKIT_URL=wss://meets.dpdns.org/livekit
```

The default local administrator is seeded from `.env` values and must change the password on first login. Use a strong unique password in production.

## Run locally

Linux/macOS:

```bash
chmod +x run.sh
./run.sh
```

Windows:

```bat
run.bat
```

Manual Docker run:

```bash
docker compose up --build -d
```

Open locally on the server:

- Frontend process: <http://localhost:3000> (bound to server loopback in Docker Compose)
- API health: <http://localhost:5000/api/v1/health> (bound to server loopback in Docker Compose)
- Nginx gateway: <http://localhost:8080>

Open publicly through your production domain:

- Join page: <https://meets.dpdns.org>
- Admin login: <https://meets.dpdns.org/admin>
- API health: <https://meets.dpdns.org/api/v1/health>
- LiveKit WebSocket: `wss://meets.dpdns.org/livekit`

## Production run

```bash
cp .env.example .env
# edit .env with production secrets, URLs, LiveKit, TURN, database, and Redis values
docker compose up --build -d
```

Production validation:

```bash
docker compose exec backend flask validate-config
```

Readiness check:

```bash
curl https://meets.dpdns.org/api/v1/health/ready
```

Use `nginx/nginx.prod.conf` with HTTPS certificates for production WebSocket/TLS termination.

## Reset administrator password

```bash
docker compose exec backend flask reset-admin
```

## Verification commands

Install dependencies if the workspace was cleaned:

```bash
pip install -r backend/requirements.txt
cd frontend && npm install
```

Backend:

```bash
python -m py_compile $(find backend/app -name '*.py')
cd backend && pytest -q
```

Frontend:

```bash
cd frontend
npm run typecheck
npm run build
npm audit --audit-level=moderate
```

Docker Compose YAML validation:

```bash
python - <<'PY'
from pathlib import Path
import yaml
yaml.safe_load(Path('docker-compose.yml').read_text())
print('docker-compose.yml valid YAML')
PY
```

## Key API groups

- `/api/v1/auth/*` — admin authentication, refresh, sessions, logout, password change, audit logs
- `/api/v1/meetings/*` — meeting scheduling, invitations, host token, controls, participants, preferences, screen share
- `/api/v1/meetings/invitations/*` — public invitation, participant join/status, participant token actions, chat, whiteboard, polls, Q&A, diagnostics
- `/api/v1/recordings/*` — recording lifecycle, playback, download, metadata, shares, analytics
- `/api/v1/recording-shares/*` — public secure recording-share access
- `/api/v1/admin/*` — dashboard, analytics, exports, admins, settings, integrations, performance, network diagnostics
- `/api/v1/security/*` — devices, IP blocks, E2EE policy
- `/api/v1/network/*` — ICE servers and media regions
- `/api/v1/external/*` — scoped API-key access
- `/api/v1/health/*` — live, ready, config, metrics

## Database tables

Core tables include:

- `admin_accounts`
- `admin_sessions`
- `audit_logs`
- `app_settings`
- `meetings`
- `meeting_invitations`
- `meeting_participants`
- `chat_messages`
- `meeting_files`
- `recordings`
- `recording_shares`
- `recording_access_events`
- `whiteboard_elements`
- `breakout_rooms`
- `breakout_assignments`
- `polls`
- `poll_options`
- `poll_votes`
- `questions`
- `question_upvotes`
- `media_regions`
- `network_diagnostics`
- `admin_devices`
- `ip_blocks`
- `api_keys`
- `webhook_subscriptions`
- `webhook_deliveries`

## Production notes

- Replace all default secrets before production.
- Use HTTPS.
- Configure TURN for restrictive client networks.
- Keep Redis configured for Socket.IO message queue and rate-limit storage.
- Run backup scripts from `scripts/` on a schedule.
- Review audit logs after admin and meeting-management changes.
- Keep `frontend/package-lock.json` committed after dependency updates.
