/** @type {import('next').NextConfig} */
function originFrom(value, fallback) {
  if (!value) return fallback;
  if (value.startsWith('/')) return fallback;
  try { return new URL(value).origin; } catch { return fallback; }
}

const apiUrl = process.env.NEXT_PUBLIC_API_URL || '/api/v1';
const socketUrl = process.env.NEXT_PUBLIC_SOCKET_URL || '';
const livekitUrl = process.env.NEXT_PUBLIC_LIVEKIT_URL || 'ws://localhost:7880';
const apiOrigin = originFrom(apiUrl, "'self'");
const socketOrigin = originFrom(socketUrl, "'self'");
const socketWsOrigin = socketOrigin === "'self'" ? "'self'" : socketOrigin.replace(/^http/, 'ws');
const livekitOrigin = livekitUrl.replace(/^ws:/, 'http:').replace(/^wss:/, 'https:');
const livekitWs = livekitUrl;

const csp = [
  "default-src 'self'",
  "base-uri 'self'",
  "frame-ancestors 'none'",
  "object-src 'none'",
  "img-src 'self' data: blob:",
  "media-src 'self' blob: data:",
  "font-src 'self' data:",
  "style-src 'self' 'unsafe-inline'",
  "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://static.cloudflareinsights.com",
  "script-src-elem 'self' 'unsafe-inline' https://static.cloudflareinsights.com",
  `connect-src 'self' ${apiOrigin} ${socketOrigin} ${socketWsOrigin} ${livekitOrigin} ${livekitWs} https://static.cloudflareinsights.com https://cloudflareinsights.com blob: data:`,
  "form-action 'self'",
].join('; ');

const nextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  compress: true,
  output: 'standalone',
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
          { key: 'X-Frame-Options', value: 'DENY' },
          { key: 'Cross-Origin-Opener-Policy', value: 'same-origin' },
          { key: 'Cross-Origin-Resource-Policy', value: 'same-site' },
          { key: 'Permissions-Policy', value: 'camera=(self), microphone=(self), display-capture=(self), fullscreen=(self), geolocation=(), payment=(), usb=()' },
          { key: 'Content-Security-Policy', value: csp },
        ]
      }
    ];
  }
};
export default nextConfig;
