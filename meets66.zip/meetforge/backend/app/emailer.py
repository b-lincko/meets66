from __future__ import annotations

import smtplib
from email.message import EmailMessage
from typing import Iterable

from flask import current_app

from .models import AppSetting, Meeting


def email_settings() -> dict:
    row = AppSetting.query.get("email_settings")
    value = row.value if row else {}
    return {
        "smtpHost": value.get("smtpHost") or current_app.config.get("SMTP_HOST"),
        "smtpPort": int(value.get("smtpPort") or current_app.config.get("SMTP_PORT") or 587),
        "smtpUseTls": bool(value.get("smtpUseTls", current_app.config.get("SMTP_USE_TLS", True))),
        "smtpUsername": value.get("smtpUsername") or current_app.config.get("SMTP_USERNAME"),
        "smtpPassword": value.get("smtpPassword") or current_app.config.get("SMTP_PASSWORD"),
        "smtpFrom": value.get("smtpFrom") or current_app.config.get("SMTP_FROM"),
        "meetingInvitationsEnabled": bool(value.get("meetingInvitationsEnabled", bool(current_app.config.get("SMTP_HOST")))),
    }


def require_smtp_ready() -> dict:
    settings = email_settings()
    if not settings["meetingInvitationsEnabled"]:
        raise RuntimeError("Meeting invitation emails are disabled in email settings")
    if not settings["smtpHost"]:
        raise RuntimeError("SMTP host is not configured")
    if not settings["smtpFrom"]:
        raise RuntimeError("SMTP sender address is not configured")
    return settings


def send_email(*, to_email: str, subject: str, text: str, html: str | None = None, ics: str | None = None, ics_filename: str = "invite.ics") -> None:
    settings = require_smtp_ready()
    message = EmailMessage()
    message["From"] = settings["smtpFrom"]
    message["To"] = to_email
    message["Subject"] = subject
    message.set_content(text)
    if html:
        message.add_alternative(html, subtype="html")
    if ics:
        message.add_attachment(ics.encode("utf-8"), maintype="text", subtype="calendar", filename=ics_filename, params={"method": "PUBLISH"})

    with smtplib.SMTP(settings["smtpHost"], settings["smtpPort"], timeout=20) as smtp:
        if settings["smtpUseTls"]:
            smtp.starttls()
        if settings["smtpUsername"]:
            smtp.login(settings["smtpUsername"], settings["smtpPassword"] or "")
        smtp.send_message(message)


def send_meeting_invite_email(*, meeting: Meeting, to_email: str, ics: str, extra_message: str | None = None) -> None:
    join_url = meeting.invitation.url if meeting.invitation else ""
    starts = meeting.scheduled_start_at.isoformat() if meeting.scheduled_start_at else ""
    text = f"You are invited to {meeting.title}.\n\nStarts: {starts}\nMeeting ID: {meeting.meeting_id}\nJoin: {join_url}\n"
    if extra_message:
        text += f"\nMessage from host:\n{extra_message}\n"
    html = f"""
    <div style="font-family:Arial,sans-serif;line-height:1.6">
      <h2>{meeting.title}</h2>
      <p><strong>Starts:</strong> {starts}</p>
      <p><strong>Meeting ID:</strong> {meeting.meeting_id}</p>
      <p><a href="{join_url}" style="background:#1f68eb;color:#fff;padding:12px 18px;border-radius:8px;text-decoration:none">Join meeting</a></p>
      {f'<p>{extra_message}</p>' if extra_message else ''}
    </div>
    """
    send_email(to_email=to_email, subject=f"Meeting invitation: {meeting.title}", text=text, html=html, ics=ics, ics_filename=f"{meeting.meeting_id}.ics")
