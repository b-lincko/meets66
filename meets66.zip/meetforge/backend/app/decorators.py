from __future__ import annotations

from functools import wraps
from typing import Callable

import jwt
from datetime import timedelta

from flask import current_app, g, jsonify, request

from .extensions import db
from .models import AdminAccount, AdminSession, utcnow
from .permissions import has_permission
from .security import aware, decode_access_token, verify_csrf_token


def error(message: str, status: int = 400, code: str | None = None):
    return jsonify({"error": {"message": message, "code": code or message.lower().replace(" ", "_")}}), status


def bearer_token() -> str | None:
    header = request.headers.get("Authorization", "")
    if header.startswith("Bearer "):
        return header.removeprefix("Bearer ").strip()
    return None


def require_admin(fn: Callable | None = None, *, allow_password_change_required: bool = False, permission: str | None = None):
    def decorator(handler: Callable):
        @wraps(handler)
        def wrapper(*args, **kwargs):
            raw = bearer_token()
            if not raw:
                return error("Authentication required", 401, "auth_required")
            try:
                claims = decode_access_token(raw)
                if claims.get("type") != "access" or claims.get("role") != "admin":
                    raise jwt.InvalidTokenError("Invalid token claims")
            except jwt.ExpiredSignatureError:
                return error("Access token expired", 401, "token_expired")
            except jwt.InvalidTokenError:
                return error("Invalid access token", 401, "invalid_token")

            admin = db.session.get(AdminAccount, claims["sub"])
            session = db.session.get(AdminSession, claims["sid"])
            if not admin or admin.status != "active":
                return error("Administrator account is inactive", 403, "admin_inactive")
            if not session or session.admin_id != admin.id or session.revoked_at is not None or aware(session.expires_at) <= utcnow():
                return error("Session is no longer active", 401, "session_inactive")
            last_seen = aware(session.last_seen_at)
            if last_seen and last_seen + timedelta(minutes=current_app.config["SESSION_IDLE_TIMEOUT_MINUTES"]) <= utcnow():
                session.revoked_at = utcnow()
                session.revoked_reason = "idle_timeout"
                db.session.commit()
                return error("Session expired due to inactivity", 401, "session_idle_timeout")
            if session.access_jti != claims.get("jti"):
                return error("Access token was superseded", 401, "token_superseded")
            if admin.must_change_password and not allow_password_change_required:
                return error("Password change required before using the admin console", 403, "password_change_required")
            if permission and not has_permission(admin, permission):
                return error("Insufficient permissions", 403, "insufficient_permissions")
            if current_app.config.get("CSRF_ENFORCED") and request.method in {"POST", "PUT", "PATCH", "DELETE"}:
                if not verify_csrf_token(session, request.headers.get("X-CSRF-Token")):
                    return error("CSRF token is missing or invalid", 403, "csrf_invalid")

            session.last_seen_at = utcnow()
            db.session.flush()
            g.current_admin = admin
            g.current_session = session
            g.jwt_claims = claims
            return handler(*args, **kwargs)

        return wrapper

    if fn is not None:
        return decorator(fn)
    return decorator


def paginate(query, default_per_page: int = 20, max_per_page: int = 100):
    page = max(int(request.args.get("page", 1)), 1)
    per_page = min(max(int(request.args.get("perPage", default_per_page)), 1), max_per_page)
    return query.paginate(page=page, per_page=per_page, error_out=False)
