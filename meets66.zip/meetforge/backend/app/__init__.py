from __future__ import annotations

from flask import Flask, jsonify, request
from werkzeug.middleware.proxy_fix import ProxyFix

from .config import Config
from .config_validation import validate_config
from .extensions import cors, db, limiter, socketio
from sqlalchemy import inspect, text

from .models import AdminAccount, AppSetting, IPBlock, MediaRegion
from .permissions import ALL_PERMISSIONS
from .security import normalize_email, validate_password_strength


def create_app(config_object: type[Config] | None = None) -> Flask:
    app = Flask(__name__)
    app.config.from_object(config_object or Config)
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_port=1)

    db.init_app(app)
    cors.init_app(app, resources={r"/api/*": {"origins": app.config["CORS_ORIGINS"]}}, supports_credentials=True)
    limiter.init_app(app)
    socketio.init_app(app, cors_allowed_origins=app.config["CORS_ORIGINS"], message_queue=app.config.get("SOCKETIO_MESSAGE_QUEUE"), async_mode="gevent")

    register_routes(app)
    register_security_checks(app)
    register_errors(app)
    register_headers(app)
    register_cli(app)
    return app


def register_routes(app: Flask) -> None:
    from .routes.auth import bp as auth_bp
    from .routes.health import bp as health_bp
    from .routes.meetings import bp as meetings_bp
    from .routes.chat import bp as chat_bp
    from .routes.recordings import bp as recordings_bp
    from .routes.whiteboard import bp as whiteboard_bp
    from .routes.breakouts import bp as breakouts_bp
    from .routes.polls import bp as polls_bp
    from .routes.network import bp as network_bp
    from .routes.admin import bp as admin_bp
    from .routes.security import bp as security_bp
    from .routes.admin_accounts import bp as admin_accounts_bp
    from .routes.settings import bp as settings_bp
    from .routes.integrations import bp as integrations_bp
    from .routes.external_api import bp as external_api_bp
    from .routes.docs import bp as docs_bp

    from . import socket_handlers  # noqa: F401
    if app.config.get("TESTING"):
        socket_handlers.SID_ADMINS.clear()
        socket_handlers.SID_PARTICIPANTS.clear()
        socket_handlers.SID_MEETINGS.clear()

    app.register_blueprint(health_bp, url_prefix="/api/v1/health")
    app.register_blueprint(auth_bp, url_prefix="/api/v1/auth")
    app.register_blueprint(meetings_bp, url_prefix="/api/v1/meetings")
    app.register_blueprint(chat_bp, url_prefix="/api/v1/meetings")
    app.register_blueprint(recordings_bp, url_prefix="/api/v1")
    app.register_blueprint(whiteboard_bp, url_prefix="/api/v1/meetings")
    app.register_blueprint(breakouts_bp, url_prefix="/api/v1/meetings")
    app.register_blueprint(polls_bp, url_prefix="/api/v1/meetings")
    app.register_blueprint(network_bp, url_prefix="/api/v1")
    app.register_blueprint(admin_bp, url_prefix="/api/v1/admin")
    app.register_blueprint(security_bp, url_prefix="/api/v1/security")
    app.register_blueprint(admin_accounts_bp, url_prefix="/api/v1/admin")
    app.register_blueprint(settings_bp, url_prefix="/api/v1/admin")
    app.register_blueprint(integrations_bp, url_prefix="/api/v1/admin")
    app.register_blueprint(external_api_bp, url_prefix="/api/v1/external")
    app.register_blueprint(docs_bp, url_prefix="/api/v1")


def register_security_checks(app: Flask) -> None:
    @app.before_request
    def block_listed_ips():
        from .security import aware, client_ip, utcnow
        if not app.config.get("SQLALCHEMY_DATABASE_URI"):
            return None
        try:
            blocked = IPBlock.query.filter_by(ip_address=client_ip()).first()
            if blocked and blocked.revoked_at is None and (blocked.expires_at is None or aware(blocked.expires_at) > utcnow()):
                return jsonify({"error": {"message": "IP address is blocked", "code": "ip_blocked"}}), 403
        except Exception:
            db.session.rollback()
            return None
        return None

    @app.before_request
    def enforce_browser_origin_on_unsafe_requests():
        if request.method not in {"POST", "PUT", "PATCH", "DELETE"}:
            return None
        origin = request.headers.get("Origin")
        if not origin:
            return None
        allowed = set(app.config.get("CORS_ORIGINS") or [])
        public = str(app.config.get("PUBLIC_APP_URL") or "").rstrip("/")
        if public:
            allowed.add(public)
        if origin.rstrip("/") not in {item.rstrip("/") for item in allowed}:
            return jsonify({"error": {"message": "Request origin is not allowed", "code": "origin_not_allowed"}}), 403
        return None


def register_errors(app: Flask) -> None:
    @app.errorhandler(404)
    def not_found(_):
        return jsonify({"error": {"message": "Resource not found", "code": "not_found"}}), 404

    @app.errorhandler(429)
    def rate_limited(e):
        return jsonify({"error": {"message": "Too many requests", "code": "rate_limited", "detail": str(e.description)}}), 429

    @app.errorhandler(Exception)
    def unhandled(exc):
        app.logger.exception("Unhandled server error")
        return jsonify({"error": {"message": "Internal server error", "code": "server_error"}}), 500


def register_headers(app: Flask) -> None:
    @app.after_request
    def headers(response):
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("X-XSS-Protection", "0")
        response.headers.setdefault("Cross-Origin-Opener-Policy", "same-origin")
        response.headers.setdefault("Cross-Origin-Resource-Policy", "same-site")
        response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        response.headers.setdefault("Permissions-Policy", "camera=(self), microphone=(self), display-capture=(self), fullscreen=(self)")
        response.headers.setdefault("Content-Security-Policy", "default-src 'none'; frame-ancestors 'none'; base-uri 'none'")
        if request.headers.get("X-Forwarded-Proto") == "https" or request.is_secure:
            response.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
        response.headers.setdefault("Cache-Control", "no-store")
        return response


def patch_schema(app: Flask) -> None:
    """Apply lightweight additive schema patches for existing self-hosted installs.

    Earlier phased builds created a smaller schema. SQLAlchemy's create_all() does
    not alter existing tables, so we add missing columns here before the app
    accepts traffic. These patches are intentionally additive and idempotent.
    """
    inspector = inspect(db.engine)
    tables = set(inspector.get_table_names())
    dialect = db.engine.dialect.name
    binary_type = "BYTEA" if dialect == "postgresql" else "BLOB"
    json_type = "JSON"

    def add_column(table: str, column: str, definition: str) -> None:
        if table not in tables:
            return
        try:
            existing = {item["name"] for item in inspector.get_columns(table)}
            if column not in existing:
                db.session.execute(text(f"ALTER TABLE {table} ADD COLUMN {column} {definition}"))
                db.session.commit()
        except Exception:
            db.session.rollback()
            app.logger.exception("Schema patch failed for %s.%s", table, column)

    # Phase 1 auth/session/audit schema. Fixes older audit_logs tables that had
    # different column names such as actor_id/meta and caused login commits to fail.
    if "admin_accounts" in tables:
        add_column("admin_accounts", "display_name", "VARCHAR(160) DEFAULT 'Defensiq Administrator'")
        add_column("admin_accounts", "personal_meeting_id", "VARCHAR(32)")
        add_column("admin_accounts", "role", "VARCHAR(40) DEFAULT 'admin'")
        add_column("admin_accounts", "permissions_json", json_type)
        add_column("admin_accounts", "disabled_at", "TIMESTAMP")
        add_column("admin_accounts", "must_change_password", "BOOLEAN DEFAULT TRUE")
        add_column("admin_accounts", "failed_login_count", "INTEGER DEFAULT 0")
        add_column("admin_accounts", "lock_until", "TIMESTAMP")
        add_column("admin_accounts", "last_login_at", "TIMESTAMP")
        add_column("admin_accounts", "password_changed_at", "TIMESTAMP")
    if "admin_devices" in tables:
        add_column("admin_devices", "admin_id", "VARCHAR(36)")
        add_column("admin_devices", "fingerprint_hash", "VARCHAR(128)")
        add_column("admin_devices", "label", "VARCHAR(160)")
        add_column("admin_devices", "first_ip", "VARCHAR(64)")
        add_column("admin_devices", "last_ip", "VARCHAR(64)")
        add_column("admin_devices", "user_agent", "TEXT")
        add_column("admin_devices", "last_seen_at", "TIMESTAMP")
        add_column("admin_devices", "trusted", "BOOLEAN DEFAULT FALSE")
        add_column("admin_devices", "revoked_at", "TIMESTAMP")
    if "admin_sessions" in tables:
        add_column("admin_sessions", "refresh_token_hash", "VARCHAR(128)")
        add_column("admin_sessions", "access_jti", "VARCHAR(64)")
        add_column("admin_sessions", "ip_address", "VARCHAR(64)")
        add_column("admin_sessions", "user_agent", "TEXT")
        add_column("admin_sessions", "expires_at", "TIMESTAMP")
        add_column("admin_sessions", "last_seen_at", "TIMESTAMP")
        add_column("admin_sessions", "revoked_at", "TIMESTAMP")
        add_column("admin_sessions", "revoked_reason", "VARCHAR(160)")
        add_column("admin_sessions", "csrf_token_hash", "VARCHAR(128)")
        add_column("admin_sessions", "device_id", "VARCHAR(36)")
    if "ip_blocks" in tables:
        add_column("ip_blocks", "ip_address", "VARCHAR(64)")
        add_column("ip_blocks", "reason", "VARCHAR(255)")
        add_column("ip_blocks", "created_by_admin_id", "VARCHAR(36)")
        add_column("ip_blocks", "expires_at", "TIMESTAMP")
        add_column("ip_blocks", "revoked_at", "TIMESTAMP")
    if "api_keys" in tables:
        add_column("api_keys", "admin_id", "VARCHAR(36)")
        add_column("api_keys", "name", "VARCHAR(160)")
        add_column("api_keys", "key_hash", "VARCHAR(128)")
        add_column("api_keys", "key_prefix", "VARCHAR(24)")
        add_column("api_keys", "scopes", json_type)
        add_column("api_keys", "expires_at", "TIMESTAMP")
        add_column("api_keys", "last_used_at", "TIMESTAMP")
        add_column("api_keys", "revoked_at", "TIMESTAMP")
    if "webhook_subscriptions" in tables:
        add_column("webhook_subscriptions", "admin_id", "VARCHAR(36)")
        add_column("webhook_subscriptions", "target_url", "VARCHAR(1000)")
        add_column("webhook_subscriptions", "events", json_type)
        add_column("webhook_subscriptions", "enabled", "BOOLEAN DEFAULT TRUE")
        add_column("webhook_subscriptions", "description", "VARCHAR(255)")
        add_column("webhook_subscriptions", "secret_hash", "VARCHAR(128)")
        add_column("webhook_subscriptions", "last_success_at", "TIMESTAMP")
        add_column("webhook_subscriptions", "last_failure_at", "TIMESTAMP")
    if "webhook_deliveries" in tables:
        add_column("webhook_deliveries", "subscription_id", "VARCHAR(36)")
        add_column("webhook_deliveries", "event_type", "VARCHAR(120)")
        add_column("webhook_deliveries", "payload_json", json_type)
        add_column("webhook_deliveries", "status", "VARCHAR(40) DEFAULT 'pending'")
        add_column("webhook_deliveries", "attempts", "INTEGER DEFAULT 0")
        add_column("webhook_deliveries", "last_attempt_at", "TIMESTAMP")
        add_column("webhook_deliveries", "next_retry_at", "TIMESTAMP")
        add_column("webhook_deliveries", "response_status", "INTEGER")
        add_column("webhook_deliveries", "response_body", "TEXT")
        add_column("webhook_deliveries", "error_message", "TEXT")
        add_column("webhook_deliveries", "signature", "VARCHAR(128)")
        add_column("webhook_deliveries", "created_at", "TIMESTAMP")
    tables = set(inspect(db.engine).get_table_names())
    if "api_keys" in tables:
        add_column("api_keys", "admin_id", "VARCHAR(36)")
        add_column("api_keys", "name", "VARCHAR(160)")
        add_column("api_keys", "key_hash", "VARCHAR(128)")
        add_column("api_keys", "key_prefix", "VARCHAR(24)")
        add_column("api_keys", "scopes", json_type)
        add_column("api_keys", "expires_at", "TIMESTAMP")
        add_column("api_keys", "last_used_at", "TIMESTAMP")
        add_column("api_keys", "revoked_at", "TIMESTAMP")
    if "webhook_subscriptions" in tables:
        add_column("webhook_subscriptions", "admin_id", "VARCHAR(36)")
        add_column("webhook_subscriptions", "target_url", "VARCHAR(1000)")
        add_column("webhook_subscriptions", "events", json_type)
        add_column("webhook_subscriptions", "enabled", "BOOLEAN DEFAULT TRUE")
        add_column("webhook_subscriptions", "description", "VARCHAR(255)")
        add_column("webhook_subscriptions", "secret_hash", "VARCHAR(128)")
        add_column("webhook_subscriptions", "last_success_at", "TIMESTAMP")
        add_column("webhook_subscriptions", "last_failure_at", "TIMESTAMP")
    if "webhook_deliveries" in tables:
        add_column("webhook_deliveries", "subscription_id", "VARCHAR(36)")
        add_column("webhook_deliveries", "event_type", "VARCHAR(120)")
        add_column("webhook_deliveries", "payload_json", json_type)
        add_column("webhook_deliveries", "status", "VARCHAR(40) DEFAULT 'pending'")
        add_column("webhook_deliveries", "attempts", "INTEGER DEFAULT 0")
        add_column("webhook_deliveries", "last_attempt_at", "TIMESTAMP")
        add_column("webhook_deliveries", "next_retry_at", "TIMESTAMP")
        add_column("webhook_deliveries", "response_status", "INTEGER")
        add_column("webhook_deliveries", "response_body", "TEXT")
        add_column("webhook_deliveries", "error_message", "TEXT")
        add_column("webhook_deliveries", "signature", "VARCHAR(128)")
        add_column("webhook_deliveries", "created_at", "TIMESTAMP")
    if "audit_logs" in tables:
        add_column("audit_logs", "actor_admin_id", "VARCHAR(36)")
        add_column("audit_logs", "session_id", "VARCHAR(36)")
        add_column("audit_logs", "entity_type", "VARCHAR(120)")
        add_column("audit_logs", "entity_id", "VARCHAR(120)")
        add_column("audit_logs", "ip_address", "VARCHAR(64)")
        add_column("audit_logs", "user_agent", "TEXT")
        add_column("audit_logs", "metadata_json", json_type)
        add_column("audit_logs", "created_at", "TIMESTAMP")

    # Phase 2-8 meeting/media/chat/recording schema.
    if "meetings" in tables:
        add_column("meetings", "admin_id", "VARCHAR(36)")
        add_column("meetings", "meeting_id", "VARCHAR(32)")
        add_column("meetings", "scheduled_start_at", "TIMESTAMP")
        add_column("meetings", "scheduled_end_at", "TIMESTAMP")
        add_column("meetings", "timezone", "VARCHAR(80) DEFAULT 'UTC'")
        add_column("meetings", "password_hash", "VARCHAR(255)")
        add_column("meetings", "link_expires_at", "TIMESTAMP")
        add_column("meetings", "reminder_minutes", "INTEGER DEFAULT 10")
        add_column("meetings", "waiting_room_enabled", "BOOLEAN DEFAULT TRUE")
        add_column("meetings", "max_participants", "INTEGER")
        add_column("meetings", "livekit_room_name", "VARCHAR(160)")
        add_column("meetings", "is_locked", "BOOLEAN DEFAULT FALSE")
        add_column("meetings", "allow_participant_audio", "BOOLEAN DEFAULT TRUE")
        add_column("meetings", "allow_participant_video", "BOOLEAN DEFAULT TRUE")
        add_column("meetings", "allow_chat", "BOOLEAN DEFAULT TRUE")
        add_column("meetings", "allow_screen_share", "BOOLEAN DEFAULT TRUE")
        add_column("meetings", "allow_whiteboard", "BOOLEAN DEFAULT TRUE")
        add_column("meetings", "screen_share_policy", "VARCHAR(40) DEFAULT 'all'")
        add_column("meetings", "active_screen_share_participant_id", "VARCHAR(36)")
        add_column("meetings", "presenter_layout", "VARCHAR(40) DEFAULT 'presenter'")
        add_column("meetings", "shared_cursor_enabled", "BOOLEAN DEFAULT TRUE")
        add_column("meetings", "join_before_host", "BOOLEAN DEFAULT FALSE")
        add_column("meetings", "host_only_start", "BOOLEAN DEFAULT FALSE")
        add_column("meetings", "personal_meeting", "BOOLEAN DEFAULT FALSE")
        add_column("meetings", "recurrence_type", "VARCHAR(40) DEFAULT 'none'")
        add_column("meetings", "recurrence_count", "INTEGER DEFAULT 1")
        add_column("meetings", "recurrence_group_id", "VARCHAR(36)")
        add_column("meetings", "template_id", "VARCHAR(36)")
        add_column("meetings", "ended_at", "TIMESTAMP")
        add_column("meetings", "advanced_settings", json_type)
    if "meeting_invitations" in tables:
        add_column("meeting_invitations", "token", "VARCHAR(128)")
        add_column("meeting_invitations", "url", "VARCHAR(600)")
        add_column("meeting_invitations", "regenerated_at", "TIMESTAMP")
    if "meeting_participants" in tables:
        add_column("meeting_participants", "display_name", "VARCHAR(120)")
        add_column("meeting_participants", "participant_token_hash", "VARCHAR(128)")
        add_column("meeting_participants", "device_info", json_type)
        add_column("meeting_participants", "muted", "BOOLEAN DEFAULT FALSE")
        add_column("meeting_participants", "camera_enabled", "BOOLEAN DEFAULT TRUE")
        add_column("meeting_participants", "audio_disabled", "BOOLEAN DEFAULT FALSE")
        add_column("meeting_participants", "video_disabled", "BOOLEAN DEFAULT FALSE")
        add_column("meeting_participants", "screen_share_disabled", "BOOLEAN DEFAULT FALSE")
        add_column("meeting_participants", "screen_sharing", "BOOLEAN DEFAULT FALSE")
        add_column("meeting_participants", "screen_share_paused", "BOOLEAN DEFAULT FALSE")
        add_column("meeting_participants", "screen_share_source", "VARCHAR(40)")
        add_column("meeting_participants", "low_bandwidth_mode", "BOOLEAN DEFAULT FALSE")
        add_column("meeting_participants", "audio_only_mode", "BOOLEAN DEFAULT FALSE")
        add_column("meeting_participants", "preferred_layout", "VARCHAR(40) DEFAULT 'auto'")
        add_column("meeting_participants", "mobile_client", "BOOLEAN DEFAULT FALSE")
        add_column("meeting_participants", "network_type", "VARCHAR(80)")
        add_column("meeting_participants", "last_quality_report", json_type)
        add_column("meeting_participants", "removed_reason", "VARCHAR(160)")
        add_column("meeting_participants", "admitted_at", "TIMESTAMP")
        add_column("meeting_participants", "rejected_at", "TIMESTAMP")
    if "chat_messages" in tables:
        add_column("chat_messages", "sender_admin_id", "VARCHAR(36)")
        add_column("chat_messages", "sender_participant_id", "VARCHAR(36)")
        add_column("chat_messages", "sender_display_name", "VARCHAR(160)")
        add_column("chat_messages", "body", "TEXT")
        add_column("chat_messages", "message_type", "VARCHAR(40) DEFAULT 'text'")
        add_column("chat_messages", "file_id", "VARCHAR(36)")
        add_column("chat_messages", "reply_to_id", "VARCHAR(36)")
        add_column("chat_messages", "thread_root_id", "VARCHAR(36)")
        add_column("chat_messages", "pinned", "BOOLEAN DEFAULT FALSE")
        add_column("chat_messages", "metadata_json", json_type)
    if "meeting_files" in tables:
        add_column("meeting_files", "uploader_admin_id", "VARCHAR(36)")
        add_column("meeting_files", "uploader_participant_id", "VARCHAR(36)")
        add_column("meeting_files", "content_type", "VARCHAR(160)")
        add_column("meeting_files", "size_bytes", "INTEGER")
        add_column("meeting_files", "sha256", "VARCHAR(64)")
        add_column("meeting_files", "data", binary_type)
    if "polls" in tables:
        add_column("polls", "meeting_id", "VARCHAR(36)")
        add_column("polls", "creator_admin_id", "VARCHAR(36)")
        add_column("polls", "creator_participant_id", "VARCHAR(36)")
        add_column("polls", "title", "VARCHAR(240)")
        add_column("polls", "anonymous", "BOOLEAN DEFAULT FALSE")
        add_column("polls", "multiple_choice", "BOOLEAN DEFAULT FALSE")
        add_column("polls", "status", "VARCHAR(40) DEFAULT 'open'")
        add_column("polls", "closes_at", "TIMESTAMP")
        add_column("polls", "closed_at", "TIMESTAMP")
    if "poll_options" in tables:
        add_column("poll_options", "poll_id", "VARCHAR(36)")
        add_column("poll_options", "text", "VARCHAR(500)")
        add_column("poll_options", "position", "INTEGER DEFAULT 0")
    if "poll_votes" in tables:
        add_column("poll_votes", "poll_id", "VARCHAR(36)")
        add_column("poll_votes", "option_id", "VARCHAR(36)")
        add_column("poll_votes", "voter_admin_id", "VARCHAR(36)")
        add_column("poll_votes", "voter_participant_id", "VARCHAR(36)")
        add_column("poll_votes", "voter_display_name", "VARCHAR(160)")
    if "questions" in tables:
        add_column("questions", "meeting_id", "VARCHAR(36)")
        add_column("questions", "author_admin_id", "VARCHAR(36)")
        add_column("questions", "author_participant_id", "VARCHAR(36)")
        add_column("questions", "author_display_name", "VARCHAR(160)")
        add_column("questions", "text", "TEXT")
        add_column("questions", "status", "VARCHAR(40) DEFAULT 'open'")
        add_column("questions", "answer_text", "TEXT")
        add_column("questions", "answered_by_admin_id", "VARCHAR(36)")
        add_column("questions", "answered_by_participant_id", "VARCHAR(36)")
        add_column("questions", "answered_by_display_name", "VARCHAR(160)")
        add_column("questions", "answered_at", "TIMESTAMP")
    if "question_upvotes" in tables:
        add_column("question_upvotes", "question_id", "VARCHAR(36)")
        add_column("question_upvotes", "voter_admin_id", "VARCHAR(36)")
        add_column("question_upvotes", "voter_participant_id", "VARCHAR(36)")
        add_column("question_upvotes", "voter_display_name", "VARCHAR(160)")
    if "media_regions" in tables:
        add_column("media_regions", "code", "VARCHAR(40)")
        add_column("media_regions", "name", "VARCHAR(120)")
        add_column("media_regions", "livekit_url", "VARCHAR(300)")
        add_column("media_regions", "turn_url", "VARCHAR(300)")
        add_column("media_regions", "priority", "INTEGER DEFAULT 100")
        add_column("media_regions", "enabled", "BOOLEAN DEFAULT TRUE")
    if "network_diagnostics" in tables:
        add_column("network_diagnostics", "meeting_id", "VARCHAR(36)")
        add_column("network_diagnostics", "participant_id", "VARCHAR(36)")
        add_column("network_diagnostics", "quality", "VARCHAR(40)")
        add_column("network_diagnostics", "rtt_ms", "FLOAT")
        add_column("network_diagnostics", "jitter_ms", "FLOAT")
        add_column("network_diagnostics", "packet_loss", "FLOAT")
        add_column("network_diagnostics", "downlink_mbps", "FLOAT")
        add_column("network_diagnostics", "effective_type", "VARCHAR(40)")
        add_column("network_diagnostics", "save_data", "BOOLEAN")
        add_column("network_diagnostics", "online", "BOOLEAN")
        add_column("network_diagnostics", "ice_state", "VARCHAR(80)")
        add_column("network_diagnostics", "room_state", "VARCHAR(80)")
        add_column("network_diagnostics", "selected_region", "VARCHAR(40)")
        add_column("network_diagnostics", "raw_json", json_type)
        add_column("network_diagnostics", "created_at", "TIMESTAMP")
    if "breakout_rooms" in tables:
        add_column("breakout_rooms", "meeting_id", "VARCHAR(36)")
        add_column("breakout_rooms", "name", "VARCHAR(160)")
        add_column("breakout_rooms", "livekit_room_name", "VARCHAR(180)")
        add_column("breakout_rooms", "status", "VARCHAR(40) DEFAULT 'open'")
        add_column("breakout_rooms", "timer_ends_at", "TIMESTAMP")
        add_column("breakout_rooms", "created_by_admin_id", "VARCHAR(36)")
        add_column("breakout_rooms", "created_by_participant_id", "VARCHAR(36)")
        add_column("breakout_rooms", "closed_at", "TIMESTAMP")
    if "breakout_assignments" in tables:
        add_column("breakout_assignments", "meeting_id", "VARCHAR(36)")
        add_column("breakout_assignments", "room_id", "VARCHAR(36)")
        add_column("breakout_assignments", "participant_id", "VARCHAR(36)")
        add_column("breakout_assignments", "assigned_by_admin_id", "VARCHAR(36)")
        add_column("breakout_assignments", "assigned_by_participant_id", "VARCHAR(36)")
        add_column("breakout_assignments", "status", "VARCHAR(40) DEFAULT 'assigned'")
        add_column("breakout_assignments", "moved_at", "TIMESTAMP")
        add_column("breakout_assignments", "returned_at", "TIMESTAMP")
    if "whiteboard_elements" in tables:
        add_column("whiteboard_elements", "meeting_id", "VARCHAR(36)")
        add_column("whiteboard_elements", "actor_admin_id", "VARCHAR(36)")
        add_column("whiteboard_elements", "actor_participant_id", "VARCHAR(36)")
        add_column("whiteboard_elements", "actor_display_name", "VARCHAR(160)")
        add_column("whiteboard_elements", "element_type", "VARCHAR(40)")
        add_column("whiteboard_elements", "payload", json_type)
        add_column("whiteboard_elements", "z_index", "INTEGER DEFAULT 0")
        add_column("whiteboard_elements", "active", "BOOLEAN DEFAULT TRUE")
        add_column("whiteboard_elements", "deleted_at", "TIMESTAMP")
    if "recordings" in tables:
        add_column("recordings", "admin_id", "VARCHAR(36)")
        add_column("recordings", "status", "VARCHAR(40) DEFAULT 'recording'")
        add_column("recordings", "started_at", "TIMESTAMP")
        add_column("recordings", "ended_at", "TIMESTAMP")
        add_column("recordings", "duration_seconds", "INTEGER DEFAULT 0")
        add_column("recordings", "filename", "VARCHAR(255)")
        add_column("recordings", "content_type", "VARCHAR(120) DEFAULT 'video/mp4'")
        add_column("recordings", "size_bytes", "INTEGER DEFAULT 0")
        add_column("recordings", "sha256", "VARCHAR(64)")
        add_column("recordings", "data", binary_type)
        add_column("recordings", "error_message", "TEXT")
        add_column("recordings", "metadata_json", json_type)
        add_column("recordings", "category", "VARCHAR(120)")
        add_column("recordings", "expires_at", "TIMESTAMP")
        add_column("recordings", "transcript_text", "TEXT")
        add_column("recordings", "summary_text", "TEXT")
    tables = set(inspect(db.engine).get_table_names())
    if "recording_shares" in tables:
        add_column("recording_shares", "recording_id", "VARCHAR(36)")
        add_column("recording_shares", "created_by_admin_id", "VARCHAR(36)")
        add_column("recording_shares", "token_hash", "VARCHAR(128)")
        add_column("recording_shares", "password_hash", "VARCHAR(255)")
        add_column("recording_shares", "expires_at", "TIMESTAMP")
        add_column("recording_shares", "allow_download", "BOOLEAN DEFAULT FALSE")
        add_column("recording_shares", "watermark_text", "VARCHAR(160)")
        add_column("recording_shares", "clip_start_seconds", "INTEGER")
        add_column("recording_shares", "clip_end_seconds", "INTEGER")
        add_column("recording_shares", "revoked_at", "TIMESTAMP")
        add_column("recording_shares", "last_accessed_at", "TIMESTAMP")
    if "recording_access_events" in tables:
        add_column("recording_access_events", "recording_id", "VARCHAR(36)")
        add_column("recording_access_events", "share_id", "VARCHAR(36)")
        add_column("recording_access_events", "admin_id", "VARCHAR(36)")
        add_column("recording_access_events", "action", "VARCHAR(40)")
        add_column("recording_access_events", "ip_address", "VARCHAR(64)")
        add_column("recording_access_events", "user_agent", "TEXT")
        add_column("recording_access_events", "created_at", "TIMESTAMP")


def create_performance_indexes(app: Flask) -> None:
    statements = [
        "CREATE INDEX IF NOT EXISTS ix_meetings_admin_status_start ON meetings (admin_id, status, scheduled_start_at)",
        "CREATE INDEX IF NOT EXISTS ix_meetings_admin_created ON meetings (admin_id, created_at)",
        "CREATE INDEX IF NOT EXISTS ix_participants_meeting_status_role ON meeting_participants (meeting_id, status, role)",
        "CREATE INDEX IF NOT EXISTS ix_recordings_admin_status_created ON recordings (admin_id, status, created_at)",
        "CREATE INDEX IF NOT EXISTS ix_chat_messages_meeting_created ON chat_messages (meeting_id, created_at)",
        "CREATE INDEX IF NOT EXISTS ix_chat_messages_thread_created ON chat_messages (meeting_id, thread_root_id, created_at)",
        "CREATE INDEX IF NOT EXISTS ix_chat_messages_pinned_created ON chat_messages (meeting_id, pinned, created_at)",
        "CREATE INDEX IF NOT EXISTS ix_meeting_roles_meeting_active_role ON meeting_role_assignments (meeting_id, active, role)",
        "CREATE INDEX IF NOT EXISTS ix_meeting_files_meeting_created ON meeting_files (meeting_id, created_at)",
        "CREATE INDEX IF NOT EXISTS ix_audit_logs_action_created ON audit_logs (action, created_at)",
        "CREATE INDEX IF NOT EXISTS ix_network_diag_meeting_created ON network_diagnostics (meeting_id, created_at)",
        "CREATE INDEX IF NOT EXISTS ix_webhook_deliveries_status_retry ON webhook_deliveries (status, next_retry_at)",
        "CREATE INDEX IF NOT EXISTS ix_whiteboard_meeting_z_active ON whiteboard_elements (meeting_id, active, z_index)",
        "CREATE INDEX IF NOT EXISTS ix_poll_votes_poll_voter ON poll_votes (poll_id, voter_admin_id, voter_participant_id)",
        "CREATE INDEX IF NOT EXISTS ix_questions_meeting_status_created ON questions (meeting_id, status, created_at)",
    ]
    for statement in statements:
        try:
            db.session.execute(text(statement))
            db.session.commit()
        except Exception:
            db.session.rollback()
            app.logger.exception("Performance index creation failed: %s", statement)


def seed_database(app: Flask) -> str:
    db.create_all()
    patch_schema(app)
    create_performance_indexes(app)
    try:
        from .routes.settings import SETTING_DEFAULTS
    except Exception:
        SETTING_DEFAULTS = {}
    for key, default_value in SETTING_DEFAULTS.items():
        if not db.session.get(AppSetting, key):
            value = dict(default_value)
            if key == "branding":
                value["brandName"] = app.config["APP_NAME"]
            db.session.add(AppSetting(key=key, value=value))
    if not db.session.get(AppSetting, "branding"):
        db.session.add(AppSetting(key="branding", value={"brandName": app.config["APP_NAME"]}))
    for item in app.config.get("MEDIA_REGIONS", []):
        parts = item.split("|")
        if len(parts) >= 3:
            code, name, livekit_url = parts[0].strip(), parts[1].strip(), parts[2].strip()
            priority = int(parts[3]) if len(parts) > 3 and parts[3].strip().isdigit() else 100
            if code and livekit_url and not MediaRegion.query.filter_by(code=code).first():
                db.session.add(MediaRegion(code=code, name=name or code, livekit_url=livekit_url, priority=priority, enabled=True))
    admin_email = normalize_email(app.config["DEFAULT_ADMIN_EMAIL"])
    admin = AdminAccount.query.filter_by(email=admin_email).first()
    if not admin:
        validate_password_strength(app.config["DEFAULT_ADMIN_PASSWORD"])
        admin = AdminAccount(email=admin_email, display_name="Defensiq Administrator", status="active", role="super_admin", permissions_json=ALL_PERMISSIONS, must_change_password=True)
        admin.set_password(app.config["DEFAULT_ADMIN_PASSWORD"])
        db.session.add(admin)
    else:
        admin.status = "active"
        admin.role = admin.role or "super_admin"
        if admin.email == admin_email and admin.role != "super_admin":
            admin.role = "super_admin"
            admin.permissions_json = ALL_PERMISSIONS
        if admin.check_password(app.config["DEFAULT_ADMIN_PASSWORD"]):
            admin.must_change_password = True
    db.session.commit()
    return admin_email


def register_cli(app: Flask) -> None:
    @app.cli.command("init-db")
    def init_db_command():
        admin_email = seed_database(app)
        print(f"Database initialized. Admin account: {admin_email}")

    @app.cli.command("validate-config")
    def validate_config_command():
        import json
        import sys
        result = validate_config(app.config)
        print(json.dumps(result, indent=2, sort_keys=True))
        if not result["valid"]:
            sys.exit(1)

    @app.cli.command("reset-admin")
    def reset_admin_command():
        import click

        email = normalize_email(app.config["DEFAULT_ADMIN_EMAIL"])
        password = click.prompt("New admin password", hide_input=True, confirmation_prompt=True)
        validate_password_strength(password)
        admin = AdminAccount.query.filter_by(email=email).first()
        if not admin:
            admin = AdminAccount(email=email, display_name="Defensiq Administrator", status="active")
            db.session.add(admin)
        admin.set_password(password)
        admin.status = "active"
        admin.must_change_password = True
        db.session.commit()
        print(f"Admin password reset: {email}")
