from __future__ import annotations

import hmac
import json
import secrets
from datetime import timedelta
from hashlib import sha256
from typing import Any

import requests
from flask import current_app

from .extensions import db
from .models import WebhookDelivery, WebhookSubscription, utcnow
from .security import token_hash

ALL_WEBHOOK_EVENTS = [
    "meeting.created",
    "meeting.started",
    "participant.joined",
    "participant.left",
    "recording.started",
    "recording.completed",
    "chat.message",
    "file.uploaded",
    "poll.created",
    "poll.voted",
    "poll.closed",
]


def generate_webhook_secret(subscription_id: str) -> str:
    digest = hmac.new(current_app.config["JWT_SECRET"].encode(), subscription_id.encode(), sha256).hexdigest()
    return f"whsec_{digest}"


def sign_payload(secret: str, body: str, timestamp: int) -> str:
    signed = f"{timestamp}.{body}".encode()
    return hmac.new(secret.encode(), signed, sha256).hexdigest()


def create_delivery(subscription: WebhookSubscription, event_type: str, payload: dict[str, Any]) -> WebhookDelivery:
    delivery = WebhookDelivery(subscription_id=subscription.id, event_type=event_type, payload_json=payload, status="pending")
    db.session.add(delivery)
    db.session.flush()
    return delivery


def attempt_delivery(delivery: WebhookDelivery, timeout: int = 5) -> WebhookDelivery:
    subscription = delivery.subscription
    body = json.dumps({"id": delivery.id, "event": delivery.event_type, "payload": delivery.payload_json, "createdAt": delivery.created_at.isoformat() if delivery.created_at else None}, separators=(",", ":"), sort_keys=True)
    timestamp = int(utcnow().timestamp())
    secret = generate_webhook_secret(subscription.id)
    signature = sign_payload(secret, body, timestamp)
    delivery.signature = signature
    delivery.attempts += 1
    delivery.last_attempt_at = utcnow()
    headers = {
        "Content-Type": "application/json",
        "User-Agent": "DefensiqMeet-Webhooks/1.0",
        "X-Defensiq-Event": delivery.event_type,
        "X-Defensiq-Delivery": delivery.id,
        "X-Defensiq-Timestamp": str(timestamp),
        "X-Defensiq-Signature": f"sha256={signature}",
    }
    try:
        response = requests.post(subscription.target_url, data=body, headers=headers, timeout=timeout)
        delivery.response_status = response.status_code
        delivery.response_body = response.text[:2000]
        if 200 <= response.status_code < 300:
            delivery.status = "delivered"
            delivery.next_retry_at = None
            delivery.error_message = None
            subscription.last_success_at = utcnow()
        else:
            delivery.status = "failed"
            delivery.error_message = f"HTTP {response.status_code}"
            delivery.next_retry_at = utcnow() + timedelta(minutes=min(60, 2 ** min(delivery.attempts, 6)))
            subscription.last_failure_at = utcnow()
    except Exception as exc:
        delivery.status = "failed"
        delivery.error_message = str(exc)[:2000]
        delivery.next_retry_at = utcnow() + timedelta(minutes=min(60, 2 ** min(delivery.attempts, 6)))
        subscription.last_failure_at = utcnow()
    db.session.flush()
    return delivery


def dispatch_webhook(event_type: str, payload: dict[str, Any]) -> list[WebhookDelivery]:
    subscriptions = WebhookSubscription.query.filter_by(enabled=True).all()
    deliveries: list[WebhookDelivery] = []
    for subscription in subscriptions:
        events = subscription.events or []
        if "*" not in events and event_type not in events:
            continue
        delivery = create_delivery(subscription, event_type, payload)
        attempt_delivery(delivery)
        deliveries.append(delivery)
    return deliveries


def new_api_key() -> str:
    return f"dfq_{secrets.token_urlsafe(32)}"


def hash_api_key(raw: str) -> str:
    return token_hash(raw)
