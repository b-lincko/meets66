from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any

from sqlalchemy.orm import object_session
from werkzeug.security import check_password_hash, generate_password_hash

from .extensions import db


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def new_id() -> str:
    return str(uuid.uuid4())


class TimestampMixin:
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow, index=True)
    updated_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow, onupdate=utcnow)


class AdminAccount(db.Model, TimestampMixin):
    __tablename__ = "admin_accounts"

    id = db.Column(db.String(36), primary_key=True, default=new_id)
    email = db.Column(db.String(255), nullable=False, unique=True, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    display_name = db.Column(db.String(160), nullable=False, default="Defensiq Administrator")
    status = db.Column(db.String(40), nullable=False, default="active", index=True)
    role = db.Column(db.String(40), nullable=False, default="admin", index=True)
    permissions_json = db.Column(db.JSON)
    disabled_at = db.Column(db.DateTime(timezone=True))
    must_change_password = db.Column(db.Boolean, nullable=False, default=True)
    failed_login_count = db.Column(db.Integer, nullable=False, default=0)
    lock_until = db.Column(db.DateTime(timezone=True))
    last_login_at = db.Column(db.DateTime(timezone=True))
    password_changed_at = db.Column(db.DateTime(timezone=True))
    personal_meeting_id = db.Column(db.String(32), unique=True, index=True)

    sessions = db.relationship("AdminSession", back_populates="admin", cascade="all, delete-orphan")

    def set_password(self, password: str) -> None:
        self.password_hash = generate_password_hash(password, method="pbkdf2:sha256", salt_length=16)

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "email": self.email,
            "displayName": self.display_name,
            "status": self.status,
            "role": self.role,
            "permissions": self.permissions_json,
            "disabledAt": self.disabled_at.isoformat() if self.disabled_at else None,
            "mustChangePassword": self.must_change_password,
            "lastLoginAt": self.last_login_at.isoformat() if self.last_login_at else None,
            "passwordChangedAt": self.password_changed_at.isoformat() if self.password_changed_at else None,
            "personalMeetingId": self.personal_meeting_id,
            "createdAt": self.created_at.isoformat() if self.created_at else None,
        }


class AdminSession(db.Model, TimestampMixin):
    __tablename__ = "admin_sessions"

    id = db.Column(db.String(36), primary_key=True, default=new_id)
    admin_id = db.Column(db.String(36), db.ForeignKey("admin_accounts.id"), nullable=False, index=True)
    refresh_token_hash = db.Column(db.String(128), nullable=False, unique=True, index=True)
    access_jti = db.Column(db.String(64), nullable=False, index=True)
    ip_address = db.Column(db.String(64))
    user_agent = db.Column(db.Text)
    expires_at = db.Column(db.DateTime(timezone=True), nullable=False, index=True)
    last_seen_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)
    revoked_at = db.Column(db.DateTime(timezone=True), index=True)
    revoked_reason = db.Column(db.String(160))
    csrf_token_hash = db.Column(db.String(128), index=True)
    device_id = db.Column(db.String(36), db.ForeignKey("admin_devices.id"), index=True)

    admin = db.relationship("AdminAccount", back_populates="sessions")
    device = db.relationship("AdminDevice")

    @property
    def active(self) -> bool:
        expires = self.expires_at
        if expires and expires.tzinfo is None:
            expires = expires.replace(tzinfo=timezone.utc)
        return self.revoked_at is None and bool(expires and expires > utcnow())

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "ipAddress": self.ip_address,
            "userAgent": self.user_agent,
            "expiresAt": self.expires_at.isoformat() if self.expires_at else None,
            "lastSeenAt": self.last_seen_at.isoformat() if self.last_seen_at else None,
            "revokedAt": self.revoked_at.isoformat() if self.revoked_at else None,
            "revokedReason": self.revoked_reason,
            "deviceId": self.device_id,
            "device": self.device.to_dict() if self.device else None,
            "active": self.active,
            "createdAt": self.created_at.isoformat() if self.created_at else None,
        }


class AdminDevice(db.Model, TimestampMixin):
    __tablename__ = "admin_devices"

    id = db.Column(db.String(36), primary_key=True, default=new_id)
    admin_id = db.Column(db.String(36), db.ForeignKey("admin_accounts.id"), nullable=False, index=True)
    fingerprint_hash = db.Column(db.String(128), nullable=False, index=True)
    label = db.Column(db.String(160))
    first_ip = db.Column(db.String(64))
    last_ip = db.Column(db.String(64))
    user_agent = db.Column(db.Text)
    last_seen_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)
    trusted = db.Column(db.Boolean, nullable=False, default=False)
    revoked_at = db.Column(db.DateTime(timezone=True), index=True)

    admin = db.relationship("AdminAccount")

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "adminId": self.admin_id,
            "label": self.label,
            "firstIp": self.first_ip,
            "lastIp": self.last_ip,
            "userAgent": self.user_agent,
            "lastSeenAt": self.last_seen_at.isoformat() if self.last_seen_at else None,
            "trusted": self.trusted,
            "revokedAt": self.revoked_at.isoformat() if self.revoked_at else None,
            "active": self.revoked_at is None,
            "createdAt": self.created_at.isoformat() if self.created_at else None,
        }


class IPBlock(db.Model, TimestampMixin):
    __tablename__ = "ip_blocks"

    id = db.Column(db.String(36), primary_key=True, default=new_id)
    ip_address = db.Column(db.String(64), nullable=False, unique=True, index=True)
    reason = db.Column(db.String(255))
    created_by_admin_id = db.Column(db.String(36), db.ForeignKey("admin_accounts.id"), index=True)
    expires_at = db.Column(db.DateTime(timezone=True), index=True)
    revoked_at = db.Column(db.DateTime(timezone=True), index=True)

    created_by_admin = db.relationship("AdminAccount")

    @property
    def active(self) -> bool:
        expires = self.expires_at
        if expires and expires.tzinfo is None:
            expires = expires.replace(tzinfo=timezone.utc)
        return self.revoked_at is None and (expires is None or expires > utcnow())

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "ipAddress": self.ip_address,
            "reason": self.reason,
            "expiresAt": self.expires_at.isoformat() if self.expires_at else None,
            "revokedAt": self.revoked_at.isoformat() if self.revoked_at else None,
            "active": self.active,
            "createdAt": self.created_at.isoformat() if self.created_at else None,
        }


class AuditLog(db.Model):
    __tablename__ = "audit_logs"

    id = db.Column(db.String(36), primary_key=True, default=new_id)
    actor_admin_id = db.Column(db.String(36), db.ForeignKey("admin_accounts.id"), index=True)
    session_id = db.Column(db.String(36), db.ForeignKey("admin_sessions.id"), index=True)
    action = db.Column(db.String(120), nullable=False, index=True)
    entity_type = db.Column(db.String(120), index=True)
    entity_id = db.Column(db.String(120), index=True)
    ip_address = db.Column(db.String(64))
    user_agent = db.Column(db.Text)
    metadata_json = db.Column(db.JSON, nullable=False, default=dict)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow, index=True)

    actor = db.relationship("AdminAccount", foreign_keys=[actor_admin_id])
    session = db.relationship("AdminSession", foreign_keys=[session_id])

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "actor": self.actor.to_dict() if self.actor else None,
            "sessionId": self.session_id,
            "action": self.action,
            "entityType": self.entity_type,
            "entityId": self.entity_id,
            "ipAddress": self.ip_address,
            "userAgent": self.user_agent,
            "metadata": self.metadata_json or {},
            "createdAt": self.created_at.isoformat() if self.created_at else None,
        }


class MeetingTemplate(db.Model, TimestampMixin):
    __tablename__ = "meeting_templates"

    id = db.Column(db.String(36), primary_key=True, default=new_id)
    admin_id = db.Column(db.String(36), db.ForeignKey("admin_accounts.id"), nullable=False, index=True)
    name = db.Column(db.String(160), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    duration_minutes = db.Column(db.Integer, nullable=False, default=60)
    timezone = db.Column(db.String(80), nullable=False, default="UTC")
    waiting_room_enabled = db.Column(db.Boolean, nullable=False, default=True)
    join_before_host = db.Column(db.Boolean, nullable=False, default=False)
    host_only_start = db.Column(db.Boolean, nullable=False, default=False)
    allow_participant_audio = db.Column(db.Boolean, nullable=False, default=True)
    allow_participant_video = db.Column(db.Boolean, nullable=False, default=True)
    allow_chat = db.Column(db.Boolean, nullable=False, default=True)
    allow_screen_share = db.Column(db.Boolean, nullable=False, default=True)

    admin = db.relationship("AdminAccount")

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "title": self.title,
            "description": self.description,
            "durationMinutes": self.duration_minutes,
            "timezone": self.timezone,
            "waitingRoomEnabled": self.waiting_room_enabled,
            "joinBeforeHost": self.join_before_host,
            "hostOnlyStart": self.host_only_start,
            "allowParticipantAudio": self.allow_participant_audio,
            "allowParticipantVideo": self.allow_participant_video,
            "allowChat": self.allow_chat,
            "allowScreenShare": self.allow_screen_share,
            "createdAt": self.created_at.isoformat() if self.created_at else None,
            "updatedAt": self.updated_at.isoformat() if self.updated_at else None,
        }


class Meeting(db.Model, TimestampMixin):
    __tablename__ = "meetings"

    id = db.Column(db.String(36), primary_key=True, default=new_id)
    admin_id = db.Column(db.String(36), db.ForeignKey("admin_accounts.id"), nullable=False, index=True)
    meeting_id = db.Column(db.String(32), nullable=False, unique=True, index=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    scheduled_start_at = db.Column(db.DateTime(timezone=True), nullable=False, index=True)
    scheduled_end_at = db.Column(db.DateTime(timezone=True), nullable=False)
    timezone = db.Column(db.String(80), nullable=False, default="UTC")
    status = db.Column(db.String(40), nullable=False, default="scheduled", index=True)
    password_hash = db.Column(db.String(255))
    link_expires_at = db.Column(db.DateTime(timezone=True), index=True)
    reminder_minutes = db.Column(db.Integer, nullable=False, default=10)
    waiting_room_enabled = db.Column(db.Boolean, nullable=False, default=True)
    max_participants = db.Column(db.Integer)
    livekit_room_name = db.Column(db.String(160), nullable=False, unique=True, index=True)
    is_locked = db.Column(db.Boolean, nullable=False, default=False)
    allow_participant_audio = db.Column(db.Boolean, nullable=False, default=True)
    allow_participant_video = db.Column(db.Boolean, nullable=False, default=True)
    allow_chat = db.Column(db.Boolean, nullable=False, default=True)
    allow_screen_share = db.Column(db.Boolean, nullable=False, default=True)
    allow_whiteboard = db.Column(db.Boolean, nullable=False, default=True)
    screen_share_policy = db.Column(db.String(40), nullable=False, default="all")
    active_screen_share_participant_id = db.Column(db.String(36))
    presenter_layout = db.Column(db.String(40), nullable=False, default="presenter")
    shared_cursor_enabled = db.Column(db.Boolean, nullable=False, default=True)
    join_before_host = db.Column(db.Boolean, nullable=False, default=False)
    host_only_start = db.Column(db.Boolean, nullable=False, default=False)
    personal_meeting = db.Column(db.Boolean, nullable=False, default=False, index=True)
    recurrence_type = db.Column(db.String(40), nullable=False, default="none")
    recurrence_count = db.Column(db.Integer, nullable=False, default=1)
    recurrence_group_id = db.Column(db.String(36), index=True)
    template_id = db.Column(db.String(36), db.ForeignKey("meeting_templates.id"), index=True)
    ended_at = db.Column(db.DateTime(timezone=True))
    advanced_settings = db.Column(db.JSON, nullable=False, default=dict)

    admin = db.relationship("AdminAccount")
    invitation = db.relationship("MeetingInvitation", back_populates="meeting", uselist=False, cascade="all, delete-orphan")
    participants = db.relationship("MeetingParticipant", back_populates="meeting", cascade="all, delete-orphan")
    messages = db.relationship("ChatMessage", back_populates="meeting", cascade="all, delete-orphan")
    files = db.relationship("MeetingFile", back_populates="meeting", cascade="all, delete-orphan")
    recordings = db.relationship("Recording", back_populates="meeting", cascade="all, delete-orphan")
    whiteboard_elements = db.relationship("WhiteboardElement", back_populates="meeting", cascade="all, delete-orphan")
    breakout_rooms = db.relationship("BreakoutRoom", back_populates="meeting", cascade="all, delete-orphan")
    network_diagnostics = db.relationship("NetworkDiagnostic", back_populates="meeting", cascade="all, delete-orphan")
    polls = db.relationship("Poll", back_populates="meeting", cascade="all, delete-orphan")
    questions = db.relationship("Question", back_populates="meeting", cascade="all, delete-orphan")
    role_assignments = db.relationship("MeetingRoleAssignment", back_populates="meeting", cascade="all, delete-orphan")

    def set_password(self, password: str | None) -> None:
        self.password_hash = generate_password_hash(password, method="pbkdf2:sha256", salt_length=16) if password else None

    def check_password(self, password: str | None) -> bool:
        if not self.password_hash:
            return True
        if not password:
            return False
        return check_password_hash(self.password_hash, password)

    @property
    def has_password(self) -> bool:
        return bool(self.password_hash)

    def participant_count(self) -> int:
        override = getattr(self, "_participant_count_override", None)
        if override is not None:
            return int(override)
        session = object_session(self)
        if session is None or not self.id:
            return len(self.participants or [])
        return int(session.query(MeetingParticipant.id).filter_by(meeting_id=self.id).count())

    def to_dict(self, include_private: bool = False) -> dict[str, Any]:
        data = {
            "id": self.id,
            "meetingId": self.meeting_id,
            "title": self.title,
            "description": self.description,
            "scheduledStartAt": self.scheduled_start_at.isoformat() if self.scheduled_start_at else None,
            "scheduledEndAt": self.scheduled_end_at.isoformat() if self.scheduled_end_at else None,
            "timezone": self.timezone,
            "status": self.status,
            "hasPassword": self.has_password,
            "linkExpiresAt": self.link_expires_at.isoformat() if self.link_expires_at else None,
            "reminderMinutes": self.reminder_minutes,
            "waitingRoomEnabled": self.waiting_room_enabled,
            "maxParticipants": self.max_participants,
            "isLocked": self.is_locked,
            "allowParticipantAudio": self.allow_participant_audio,
            "allowParticipantVideo": self.allow_participant_video,
            "allowChat": self.allow_chat,
            "allowScreenShare": self.allow_screen_share,
            "allowWhiteboard": self.allow_whiteboard,
            "screenSharePolicy": self.screen_share_policy,
            "activeScreenShareParticipantId": self.active_screen_share_participant_id,
            "presenterLayout": self.presenter_layout,
            "sharedCursorEnabled": self.shared_cursor_enabled,
            "joinBeforeHost": self.join_before_host,
            "hostOnlyStart": self.host_only_start,
            "personalMeeting": self.personal_meeting,
            "recurrenceType": self.recurrence_type,
            "recurrenceCount": self.recurrence_count,
            "recurrenceGroupId": self.recurrence_group_id,
            "templateId": self.template_id,
            "endedAt": self.ended_at.isoformat() if self.ended_at else None,
            "advancedSettings": self.advanced_settings or {},
            "participantCount": self.participant_count(),
            "createdAt": self.created_at.isoformat() if self.created_at else None,
            "updatedAt": self.updated_at.isoformat() if self.updated_at else None,
        }
        if include_private:
            data["adminId"] = self.admin_id
            data["livekitRoomName"] = self.livekit_room_name
            data["invitationUrl"] = self.invitation.url if self.invitation else None
            data["invitationToken"] = self.invitation.token if self.invitation else None
        return data


class MeetingDraft(db.Model, TimestampMixin):
    __tablename__ = "meeting_drafts"

    id = db.Column(db.String(36), primary_key=True, default=new_id)
    admin_id = db.Column(db.String(36), db.ForeignKey("admin_accounts.id"), nullable=False, index=True)
    title = db.Column(db.String(220), nullable=False, default="Untitled meeting draft")
    payload_json = db.Column(db.JSON, nullable=False, default=dict)

    admin = db.relationship("AdminAccount")

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "adminId": self.admin_id,
            "title": self.title,
            "payload": self.payload_json or {},
            "createdAt": self.created_at.isoformat() if self.created_at else None,
            "updatedAt": self.updated_at.isoformat() if self.updated_at else None,
        }


class MeetingRoleAssignment(db.Model, TimestampMixin):
    __tablename__ = "meeting_role_assignments"

    id = db.Column(db.String(36), primary_key=True, default=new_id)
    meeting_id = db.Column(db.String(36), db.ForeignKey("meetings.id"), nullable=False, index=True)
    admin_id = db.Column(db.String(36), db.ForeignKey("admin_accounts.id"), index=True)
    participant_id = db.Column(db.String(36), db.ForeignKey("meeting_participants.id"), index=True)
    email = db.Column(db.String(255), index=True)
    display_name = db.Column(db.String(160), nullable=False)
    role = db.Column(db.String(40), nullable=False, index=True)
    permissions_json = db.Column(db.JSON, nullable=False, default=list)
    active = db.Column(db.Boolean, nullable=False, default=True, index=True)
    assigned_by_admin_id = db.Column(db.String(36), db.ForeignKey("admin_accounts.id"), index=True)
    revoked_at = db.Column(db.DateTime(timezone=True))

    meeting = db.relationship("Meeting", back_populates="role_assignments")
    admin = db.relationship("AdminAccount", foreign_keys=[admin_id])
    participant = db.relationship("MeetingParticipant", foreign_keys=[participant_id])
    assigned_by_admin = db.relationship("AdminAccount", foreign_keys=[assigned_by_admin_id])

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "meetingId": self.meeting_id,
            "adminId": self.admin_id,
            "participantId": self.participant_id,
            "email": self.email,
            "displayName": self.display_name,
            "role": self.role,
            "permissions": self.permissions_json or [],
            "active": self.active and self.revoked_at is None,
            "assignedByAdminId": self.assigned_by_admin_id,
            "revokedAt": self.revoked_at.isoformat() if self.revoked_at else None,
            "createdAt": self.created_at.isoformat() if self.created_at else None,
            "updatedAt": self.updated_at.isoformat() if self.updated_at else None,
        }


class MeetingParticipant(db.Model, TimestampMixin):
    __tablename__ = "meeting_participants"

    id = db.Column(db.String(36), primary_key=True, default=new_id)
    meeting_id = db.Column(db.String(36), db.ForeignKey("meetings.id"), nullable=False, index=True)
    display_name = db.Column(db.String(120), nullable=False)
    role = db.Column(db.String(40), nullable=False, default="participant", index=True)
    status = db.Column(db.String(40), nullable=False, default="waiting", index=True)
    participant_token_hash = db.Column(db.String(128), nullable=False, unique=True, index=True)
    device_info = db.Column(db.JSON, nullable=False, default=dict)
    muted = db.Column(db.Boolean, nullable=False, default=False)
    camera_enabled = db.Column(db.Boolean, nullable=False, default=True)
    audio_disabled = db.Column(db.Boolean, nullable=False, default=False)
    video_disabled = db.Column(db.Boolean, nullable=False, default=False)
    screen_share_disabled = db.Column(db.Boolean, nullable=False, default=False)
    screen_sharing = db.Column(db.Boolean, nullable=False, default=False)
    screen_share_paused = db.Column(db.Boolean, nullable=False, default=False)
    screen_share_source = db.Column(db.String(40))
    low_bandwidth_mode = db.Column(db.Boolean, nullable=False, default=False)
    audio_only_mode = db.Column(db.Boolean, nullable=False, default=False)
    preferred_layout = db.Column(db.String(40), nullable=False, default="auto")
    mobile_client = db.Column(db.Boolean, nullable=False, default=False)
    network_type = db.Column(db.String(80))
    last_quality_report = db.Column(db.JSON, nullable=False, default=dict)
    removed_reason = db.Column(db.String(160))
    ip_address = db.Column(db.String(64))
    user_agent = db.Column(db.Text)
    joined_at = db.Column(db.DateTime(timezone=True))
    admitted_at = db.Column(db.DateTime(timezone=True))
    rejected_at = db.Column(db.DateTime(timezone=True))
    left_at = db.Column(db.DateTime(timezone=True))

    meeting = db.relationship("Meeting", back_populates="participants")

    @property
    def admitted(self) -> bool:
        return self.status == "admitted"

    def to_dict(self, include_private: bool = False) -> dict[str, Any]:
        device_info = self.device_info or {}
        host_controls = device_info.get("hostControls") if isinstance(device_info, dict) else {}
        if not isinstance(host_controls, dict):
            host_controls = {}
        data = {
            "id": self.id,
            "meetingId": self.meeting_id,
            "displayName": self.display_name,
            "role": self.role,
            "status": self.status,
            "deviceInfo": device_info,
            "hostControls": host_controls,
            "muted": self.muted,
            "cameraEnabled": self.camera_enabled,
            "audioDisabled": self.audio_disabled,
            "videoDisabled": self.video_disabled,
            "screenShareDisabled": self.screen_share_disabled,
            "screenSharing": self.screen_sharing,
            "screenSharePaused": self.screen_share_paused,
            "screenShareSource": self.screen_share_source,
            "lowBandwidthMode": self.low_bandwidth_mode,
            "audioOnlyMode": self.audio_only_mode,
            "preferredLayout": self.preferred_layout,
            "mobileClient": self.mobile_client,
            "networkType": self.network_type,
            "lastQualityReport": self.last_quality_report or {},
            "removedReason": self.removed_reason,
            "joinedAt": self.joined_at.isoformat() if self.joined_at else None,
            "admittedAt": self.admitted_at.isoformat() if self.admitted_at else None,
            "rejectedAt": self.rejected_at.isoformat() if self.rejected_at else None,
            "leftAt": self.left_at.isoformat() if self.left_at else None,
            "createdAt": self.created_at.isoformat() if self.created_at else None,
        }
        if include_private:
            data["ipAddress"] = self.ip_address
            data["userAgent"] = self.user_agent
        return data


class MeetingFile(db.Model, TimestampMixin):
    __tablename__ = "meeting_files"

    id = db.Column(db.String(36), primary_key=True, default=new_id)
    meeting_id = db.Column(db.String(36), db.ForeignKey("meetings.id"), nullable=False, index=True)
    uploader_admin_id = db.Column(db.String(36), db.ForeignKey("admin_accounts.id"), index=True)
    uploader_participant_id = db.Column(db.String(36), db.ForeignKey("meeting_participants.id"), index=True)
    filename = db.Column(db.String(255), nullable=False)
    content_type = db.Column(db.String(160), nullable=False, default="application/octet-stream")
    size_bytes = db.Column(db.Integer, nullable=False)
    sha256 = db.Column(db.String(64), nullable=False, index=True)
    data = db.Column(db.LargeBinary, nullable=False)

    meeting = db.relationship("Meeting", back_populates="files")
    uploader_admin = db.relationship("AdminAccount")
    uploader_participant = db.relationship("MeetingParticipant")

    def to_dict(self) -> dict[str, Any]:
        uploader_name = self.uploader_admin.display_name if self.uploader_admin else (self.uploader_participant.display_name if self.uploader_participant else "Unknown")
        return {
            "id": self.id,
            "meetingId": self.meeting_id,
            "filename": self.filename,
            "contentType": self.content_type,
            "sizeBytes": self.size_bytes,
            "sha256": self.sha256,
            "uploaderName": uploader_name,
            "createdAt": self.created_at.isoformat() if self.created_at else None,
        }


class ChatMessage(db.Model, TimestampMixin):
    __tablename__ = "chat_messages"

    id = db.Column(db.String(36), primary_key=True, default=new_id)
    meeting_id = db.Column(db.String(36), db.ForeignKey("meetings.id"), nullable=False, index=True)
    sender_admin_id = db.Column(db.String(36), db.ForeignKey("admin_accounts.id"), index=True)
    sender_participant_id = db.Column(db.String(36), db.ForeignKey("meeting_participants.id"), index=True)
    sender_display_name = db.Column(db.String(160), nullable=False)
    body = db.Column(db.Text)
    message_type = db.Column(db.String(40), nullable=False, default="text", index=True)
    file_id = db.Column(db.String(36), db.ForeignKey("meeting_files.id"), index=True)
    reply_to_id = db.Column(db.String(36), db.ForeignKey("chat_messages.id"), index=True)
    thread_root_id = db.Column(db.String(36), db.ForeignKey("chat_messages.id"), index=True)
    pinned = db.Column(db.Boolean, nullable=False, default=False, index=True)
    metadata_json = db.Column(db.JSON, nullable=False, default=dict)

    meeting = db.relationship("Meeting", back_populates="messages")
    sender_admin = db.relationship("AdminAccount")
    sender_participant = db.relationship("MeetingParticipant")
    file = db.relationship("MeetingFile")

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "meetingId": self.meeting_id,
            "senderAdminId": self.sender_admin_id,
            "senderParticipantId": self.sender_participant_id,
            "senderDisplayName": self.sender_display_name,
            "body": self.body,
            "messageType": self.message_type,
            "file": self.file.to_dict() if self.file else None,
            "replyToId": self.reply_to_id,
            "threadRootId": self.thread_root_id,
            "pinned": self.pinned,
            "metadata": self.metadata_json or {},
            "createdAt": self.created_at.isoformat() if self.created_at else None,
        }


class MediaRegion(db.Model, TimestampMixin):
    __tablename__ = "media_regions"

    id = db.Column(db.String(36), primary_key=True, default=new_id)
    code = db.Column(db.String(40), nullable=False, unique=True, index=True)
    name = db.Column(db.String(120), nullable=False)
    livekit_url = db.Column(db.String(300), nullable=False)
    turn_url = db.Column(db.String(300))
    priority = db.Column(db.Integer, nullable=False, default=100)
    enabled = db.Column(db.Boolean, nullable=False, default=True, index=True)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "code": self.code,
            "name": self.name,
            "livekitUrl": self.livekit_url,
            "turnUrl": self.turn_url,
            "priority": self.priority,
            "enabled": self.enabled,
            "createdAt": self.created_at.isoformat() if self.created_at else None,
            "updatedAt": self.updated_at.isoformat() if self.updated_at else None,
        }


class NetworkDiagnostic(db.Model):
    __tablename__ = "network_diagnostics"

    id = db.Column(db.String(36), primary_key=True, default=new_id)
    meeting_id = db.Column(db.String(36), db.ForeignKey("meetings.id"), nullable=False, index=True)
    participant_id = db.Column(db.String(36), db.ForeignKey("meeting_participants.id"), nullable=False, index=True)
    quality = db.Column(db.String(40), index=True)
    rtt_ms = db.Column(db.Float)
    jitter_ms = db.Column(db.Float)
    packet_loss = db.Column(db.Float)
    downlink_mbps = db.Column(db.Float)
    effective_type = db.Column(db.String(40))
    save_data = db.Column(db.Boolean)
    online = db.Column(db.Boolean)
    ice_state = db.Column(db.String(80))
    room_state = db.Column(db.String(80))
    selected_region = db.Column(db.String(40), index=True)
    raw_json = db.Column(db.JSON, nullable=False, default=dict)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow, index=True)

    meeting = db.relationship("Meeting", back_populates="network_diagnostics")
    participant = db.relationship("MeetingParticipant")

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "meetingId": self.meeting_id,
            "participantId": self.participant_id,
            "participantName": self.participant.display_name if self.participant else None,
            "quality": self.quality,
            "rttMs": self.rtt_ms,
            "jitterMs": self.jitter_ms,
            "packetLoss": self.packet_loss,
            "downlinkMbps": self.downlink_mbps,
            "effectiveType": self.effective_type,
            "saveData": self.save_data,
            "online": self.online,
            "iceState": self.ice_state,
            "roomState": self.room_state,
            "selectedRegion": self.selected_region,
            "raw": self.raw_json or {},
            "createdAt": self.created_at.isoformat() if self.created_at else None,
        }


class Poll(db.Model, TimestampMixin):
    __tablename__ = "polls"

    id = db.Column(db.String(36), primary_key=True, default=new_id)
    meeting_id = db.Column(db.String(36), db.ForeignKey("meetings.id"), nullable=False, index=True)
    creator_admin_id = db.Column(db.String(36), db.ForeignKey("admin_accounts.id"), index=True)
    creator_participant_id = db.Column(db.String(36), db.ForeignKey("meeting_participants.id"), index=True)
    title = db.Column(db.String(240), nullable=False)
    anonymous = db.Column(db.Boolean, nullable=False, default=False)
    multiple_choice = db.Column(db.Boolean, nullable=False, default=False)
    status = db.Column(db.String(40), nullable=False, default="open", index=True)
    closes_at = db.Column(db.DateTime(timezone=True), index=True)
    closed_at = db.Column(db.DateTime(timezone=True))

    meeting = db.relationship("Meeting", back_populates="polls")
    creator_admin = db.relationship("AdminAccount")
    creator_participant = db.relationship("MeetingParticipant")
    options = db.relationship("PollOption", back_populates="poll", cascade="all, delete-orphan", order_by="PollOption.position")
    votes = db.relationship("PollVote", back_populates="poll", cascade="all, delete-orphan")

    def is_open(self) -> bool:
        expires = self.closes_at
        if expires and expires.tzinfo is None:
            expires = expires.replace(tzinfo=timezone.utc)
        return self.status == "open" and (expires is None or expires > utcnow())

    def results(self, include_voters: bool = False) -> dict[str, Any]:
        counts = {option.id: 0 for option in self.options}
        voters: dict[str, list[str]] = {option.id: [] for option in self.options}
        for vote in self.votes:
            counts[vote.option_id] = counts.get(vote.option_id, 0) + 1
            if include_voters and not self.anonymous:
                voters.setdefault(vote.option_id, []).append(vote.voter_display_name)
        total = sum(counts.values())
        return {
            "totalVotes": total,
            "options": [
                {
                    **option.to_dict(),
                    "votes": counts.get(option.id, 0),
                    "percent": round((counts.get(option.id, 0) / total) * 100, 2) if total else 0,
                    "voters": voters.get(option.id, []) if include_voters and not self.anonymous else [],
                }
                for option in self.options
            ],
        }

    def to_dict(self, include_results: bool = True, include_voters: bool = False) -> dict[str, Any]:
        data = {
            "id": self.id,
            "meetingId": self.meeting_id,
            "title": self.title,
            "anonymous": self.anonymous,
            "multipleChoice": self.multiple_choice,
            "status": self.status,
            "isOpen": self.is_open(),
            "closesAt": self.closes_at.isoformat() if self.closes_at else None,
            "closedAt": self.closed_at.isoformat() if self.closed_at else None,
            "options": [option.to_dict() for option in self.options],
            "createdAt": self.created_at.isoformat() if self.created_at else None,
        }
        if include_results:
            data["results"] = self.results(include_voters=include_voters)
        return data


class PollOption(db.Model, TimestampMixin):
    __tablename__ = "poll_options"

    id = db.Column(db.String(36), primary_key=True, default=new_id)
    poll_id = db.Column(db.String(36), db.ForeignKey("polls.id"), nullable=False, index=True)
    text = db.Column(db.String(500), nullable=False)
    position = db.Column(db.Integer, nullable=False, default=0)

    poll = db.relationship("Poll", back_populates="options")

    def to_dict(self) -> dict[str, Any]:
        return {"id": self.id, "pollId": self.poll_id, "text": self.text, "position": self.position}


class PollVote(db.Model, TimestampMixin):
    __tablename__ = "poll_votes"
    __table_args__ = (db.UniqueConstraint("poll_id", "option_id", "voter_admin_id", "voter_participant_id", name="uq_poll_option_voter"),)

    id = db.Column(db.String(36), primary_key=True, default=new_id)
    poll_id = db.Column(db.String(36), db.ForeignKey("polls.id"), nullable=False, index=True)
    option_id = db.Column(db.String(36), db.ForeignKey("poll_options.id"), nullable=False, index=True)
    voter_admin_id = db.Column(db.String(36), db.ForeignKey("admin_accounts.id"), index=True)
    voter_participant_id = db.Column(db.String(36), db.ForeignKey("meeting_participants.id"), index=True)
    voter_display_name = db.Column(db.String(160), nullable=False)

    poll = db.relationship("Poll", back_populates="votes")
    option = db.relationship("PollOption")
    voter_admin = db.relationship("AdminAccount")
    voter_participant = db.relationship("MeetingParticipant")

    def to_dict(self, anonymous: bool = False) -> dict[str, Any]:
        return {
            "id": self.id,
            "pollId": self.poll_id,
            "optionId": self.option_id,
            "voterDisplayName": None if anonymous else self.voter_display_name,
            "createdAt": self.created_at.isoformat() if self.created_at else None,
        }


class Question(db.Model, TimestampMixin):
    __tablename__ = "questions"

    id = db.Column(db.String(36), primary_key=True, default=new_id)
    meeting_id = db.Column(db.String(36), db.ForeignKey("meetings.id"), nullable=False, index=True)
    author_admin_id = db.Column(db.String(36), db.ForeignKey("admin_accounts.id"), index=True)
    author_participant_id = db.Column(db.String(36), db.ForeignKey("meeting_participants.id"), index=True)
    author_display_name = db.Column(db.String(160), nullable=False)
    text = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(40), nullable=False, default="open", index=True)
    answer_text = db.Column(db.Text)
    answered_by_admin_id = db.Column(db.String(36), db.ForeignKey("admin_accounts.id"), index=True)
    answered_by_participant_id = db.Column(db.String(36), db.ForeignKey("meeting_participants.id"), index=True)
    answered_by_display_name = db.Column(db.String(160))
    answered_at = db.Column(db.DateTime(timezone=True))

    meeting = db.relationship("Meeting", back_populates="questions")
    author_admin = db.relationship("AdminAccount", foreign_keys=[author_admin_id])
    author_participant = db.relationship("MeetingParticipant", foreign_keys=[author_participant_id])
    answered_by_admin = db.relationship("AdminAccount", foreign_keys=[answered_by_admin_id])
    answered_by_participant = db.relationship("MeetingParticipant", foreign_keys=[answered_by_participant_id])
    upvotes = db.relationship("QuestionUpvote", back_populates="question", cascade="all, delete-orphan")

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "meetingId": self.meeting_id,
            "authorDisplayName": self.author_display_name,
            "text": self.text,
            "status": self.status,
            "answerText": self.answer_text,
            "answeredByDisplayName": self.answered_by_display_name,
            "answeredAt": self.answered_at.isoformat() if self.answered_at else None,
            "upvotes": len(self.upvotes or []),
            "createdAt": self.created_at.isoformat() if self.created_at else None,
            "updatedAt": self.updated_at.isoformat() if self.updated_at else None,
        }


class QuestionUpvote(db.Model, TimestampMixin):
    __tablename__ = "question_upvotes"
    __table_args__ = (db.UniqueConstraint("question_id", "voter_admin_id", "voter_participant_id", name="uq_question_voter"),)

    id = db.Column(db.String(36), primary_key=True, default=new_id)
    question_id = db.Column(db.String(36), db.ForeignKey("questions.id"), nullable=False, index=True)
    voter_admin_id = db.Column(db.String(36), db.ForeignKey("admin_accounts.id"), index=True)
    voter_participant_id = db.Column(db.String(36), db.ForeignKey("meeting_participants.id"), index=True)
    voter_display_name = db.Column(db.String(160), nullable=False)

    question = db.relationship("Question", back_populates="upvotes")
    voter_admin = db.relationship("AdminAccount")
    voter_participant = db.relationship("MeetingParticipant")


class BreakoutRoom(db.Model, TimestampMixin):
    __tablename__ = "breakout_rooms"

    id = db.Column(db.String(36), primary_key=True, default=new_id)
    meeting_id = db.Column(db.String(36), db.ForeignKey("meetings.id"), nullable=False, index=True)
    name = db.Column(db.String(160), nullable=False)
    livekit_room_name = db.Column(db.String(180), nullable=False, unique=True, index=True)
    status = db.Column(db.String(40), nullable=False, default="open", index=True)
    timer_ends_at = db.Column(db.DateTime(timezone=True))
    created_by_admin_id = db.Column(db.String(36), db.ForeignKey("admin_accounts.id"), index=True)
    created_by_participant_id = db.Column(db.String(36), db.ForeignKey("meeting_participants.id"), index=True)
    closed_at = db.Column(db.DateTime(timezone=True))

    meeting = db.relationship("Meeting", back_populates="breakout_rooms")
    created_by_admin = db.relationship("AdminAccount")
    created_by_participant = db.relationship("MeetingParticipant")
    assignments = db.relationship("BreakoutAssignment", back_populates="room", cascade="all, delete-orphan")

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "meetingId": self.meeting_id,
            "name": self.name,
            "livekitRoomName": self.livekit_room_name,
            "status": self.status,
            "timerEndsAt": self.timer_ends_at.isoformat() if self.timer_ends_at else None,
            "closedAt": self.closed_at.isoformat() if self.closed_at else None,
            "assignments": [assignment.to_dict() for assignment in self.assignments or []],
            "createdAt": self.created_at.isoformat() if self.created_at else None,
        }


class BreakoutAssignment(db.Model, TimestampMixin):
    __tablename__ = "breakout_assignments"
    __table_args__ = (db.UniqueConstraint("meeting_id", "participant_id", name="uq_breakout_meeting_participant"),)

    id = db.Column(db.String(36), primary_key=True, default=new_id)
    meeting_id = db.Column(db.String(36), db.ForeignKey("meetings.id"), nullable=False, index=True)
    room_id = db.Column(db.String(36), db.ForeignKey("breakout_rooms.id"), nullable=False, index=True)
    participant_id = db.Column(db.String(36), db.ForeignKey("meeting_participants.id"), nullable=False, index=True)
    assigned_by_admin_id = db.Column(db.String(36), db.ForeignKey("admin_accounts.id"), index=True)
    assigned_by_participant_id = db.Column(db.String(36), db.ForeignKey("meeting_participants.id"), index=True)
    status = db.Column(db.String(40), nullable=False, default="assigned", index=True)
    moved_at = db.Column(db.DateTime(timezone=True))
    returned_at = db.Column(db.DateTime(timezone=True))

    meeting = db.relationship("Meeting")
    room = db.relationship("BreakoutRoom", back_populates="assignments")
    participant = db.relationship("MeetingParticipant", foreign_keys=[participant_id])
    assigned_by_admin = db.relationship("AdminAccount")
    assigned_by_participant = db.relationship("MeetingParticipant", foreign_keys=[assigned_by_participant_id])

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "meetingId": self.meeting_id,
            "roomId": self.room_id,
            "participantId": self.participant_id,
            "participant": self.participant.to_dict(include_private=True) if self.participant else None,
            "status": self.status,
            "movedAt": self.moved_at.isoformat() if self.moved_at else None,
            "returnedAt": self.returned_at.isoformat() if self.returned_at else None,
            "createdAt": self.created_at.isoformat() if self.created_at else None,
        }


class WhiteboardElement(db.Model, TimestampMixin):
    __tablename__ = "whiteboard_elements"

    id = db.Column(db.String(36), primary_key=True, default=new_id)
    meeting_id = db.Column(db.String(36), db.ForeignKey("meetings.id"), nullable=False, index=True)
    actor_admin_id = db.Column(db.String(36), db.ForeignKey("admin_accounts.id"), index=True)
    actor_participant_id = db.Column(db.String(36), db.ForeignKey("meeting_participants.id"), index=True)
    actor_display_name = db.Column(db.String(160), nullable=False)
    element_type = db.Column(db.String(40), nullable=False, index=True)
    payload = db.Column(db.JSON, nullable=False, default=dict)
    z_index = db.Column(db.Integer, nullable=False, default=0, index=True)
    active = db.Column(db.Boolean, nullable=False, default=True, index=True)
    deleted_at = db.Column(db.DateTime(timezone=True))

    meeting = db.relationship("Meeting", back_populates="whiteboard_elements")
    actor_admin = db.relationship("AdminAccount")
    actor_participant = db.relationship("MeetingParticipant")

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "meetingId": self.meeting_id,
            "actorAdminId": self.actor_admin_id,
            "actorParticipantId": self.actor_participant_id,
            "actorDisplayName": self.actor_display_name,
            "elementType": self.element_type,
            "payload": self.payload or {},
            "zIndex": self.z_index,
            "active": self.active,
            "deletedAt": self.deleted_at.isoformat() if self.deleted_at else None,
            "createdAt": self.created_at.isoformat() if self.created_at else None,
            "updatedAt": self.updated_at.isoformat() if self.updated_at else None,
        }


class Recording(db.Model, TimestampMixin):
    __tablename__ = "recordings"

    id = db.Column(db.String(36), primary_key=True, default=new_id)
    meeting_id = db.Column(db.String(36), db.ForeignKey("meetings.id"), nullable=False, index=True)
    admin_id = db.Column(db.String(36), db.ForeignKey("admin_accounts.id"), nullable=False, index=True)
    title = db.Column(db.String(220), nullable=False)
    status = db.Column(db.String(40), nullable=False, default="recording", index=True)
    started_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow, index=True)
    ended_at = db.Column(db.DateTime(timezone=True))
    duration_seconds = db.Column(db.Integer, nullable=False, default=0)
    filename = db.Column(db.String(255))
    content_type = db.Column(db.String(120), default="video/mp4")
    size_bytes = db.Column(db.Integer, nullable=False, default=0)
    sha256 = db.Column(db.String(64), index=True)
    data = db.Column(db.LargeBinary)
    error_message = db.Column(db.Text)
    metadata_json = db.Column(db.JSON, nullable=False, default=dict)
    category = db.Column(db.String(120), index=True)
    expires_at = db.Column(db.DateTime(timezone=True), index=True)
    transcript_text = db.Column(db.Text)
    summary_text = db.Column(db.Text)

    meeting = db.relationship("Meeting", back_populates="recordings")
    admin = db.relationship("AdminAccount")
    shares = db.relationship("RecordingShare", back_populates="recording", cascade="all, delete-orphan")
    access_events = db.relationship("RecordingAccessEvent", back_populates="recording", cascade="all, delete-orphan")

    def to_dict(self, include_text: bool = True) -> dict[str, Any]:
        return {
            "id": self.id,
            "meetingId": self.meeting_id,
            "adminId": self.admin_id,
            "title": self.title,
            "status": self.status,
            "startedAt": self.started_at.isoformat() if self.started_at else None,
            "endedAt": self.ended_at.isoformat() if self.ended_at else None,
            "durationSeconds": self.duration_seconds,
            "filename": self.filename,
            "contentType": self.content_type,
            "sizeBytes": self.size_bytes,
            "sha256": self.sha256,
            "errorMessage": self.error_message,
            "metadata": self.metadata_json or {},
            "category": self.category,
            "expiresAt": self.expires_at.isoformat() if self.expires_at else None,
            "transcriptText": self.transcript_text if include_text else None,
            "summaryText": self.summary_text if include_text else None,
            "shareCount": len(self.shares or []),
            "playbackCount": len([event for event in (self.access_events or []) if event.action == "playback"]),
            "downloadCount": len([event for event in (self.access_events or []) if event.action == "download"]),
            "createdAt": self.created_at.isoformat() if self.created_at else None,
            "updatedAt": self.updated_at.isoformat() if self.updated_at else None,
        }


class RecordingShare(db.Model, TimestampMixin):
    __tablename__ = "recording_shares"

    id = db.Column(db.String(36), primary_key=True, default=new_id)
    recording_id = db.Column(db.String(36), db.ForeignKey("recordings.id"), nullable=False, index=True)
    created_by_admin_id = db.Column(db.String(36), db.ForeignKey("admin_accounts.id"), nullable=False, index=True)
    token_hash = db.Column(db.String(128), nullable=False, unique=True, index=True)
    password_hash = db.Column(db.String(255))
    expires_at = db.Column(db.DateTime(timezone=True), index=True)
    allow_download = db.Column(db.Boolean, nullable=False, default=False)
    watermark_text = db.Column(db.String(160))
    clip_start_seconds = db.Column(db.Integer)
    clip_end_seconds = db.Column(db.Integer)
    revoked_at = db.Column(db.DateTime(timezone=True), index=True)
    last_accessed_at = db.Column(db.DateTime(timezone=True))

    recording = db.relationship("Recording", back_populates="shares")
    created_by_admin = db.relationship("AdminAccount")
    access_events = db.relationship("RecordingAccessEvent", back_populates="share", cascade="all, delete-orphan")

    @property
    def active(self) -> bool:
        expires = self.expires_at
        if expires and expires.tzinfo is None:
            expires = expires.replace(tzinfo=timezone.utc)
        return self.revoked_at is None and (expires is None or expires > utcnow())

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "recordingId": self.recording_id,
            "expiresAt": self.expires_at.isoformat() if self.expires_at else None,
            "allowDownload": self.allow_download,
            "watermarkText": self.watermark_text,
            "clipStartSeconds": self.clip_start_seconds,
            "clipEndSeconds": self.clip_end_seconds,
            "passwordRequired": bool(self.password_hash),
            "revokedAt": self.revoked_at.isoformat() if self.revoked_at else None,
            "lastAccessedAt": self.last_accessed_at.isoformat() if self.last_accessed_at else None,
            "active": self.active,
            "accessCount": len(self.access_events or []),
            "createdAt": self.created_at.isoformat() if self.created_at else None,
        }


class RecordingAccessEvent(db.Model):
    __tablename__ = "recording_access_events"

    id = db.Column(db.String(36), primary_key=True, default=new_id)
    recording_id = db.Column(db.String(36), db.ForeignKey("recordings.id"), nullable=False, index=True)
    share_id = db.Column(db.String(36), db.ForeignKey("recording_shares.id"), index=True)
    admin_id = db.Column(db.String(36), db.ForeignKey("admin_accounts.id"), index=True)
    action = db.Column(db.String(40), nullable=False, index=True)
    ip_address = db.Column(db.String(64))
    user_agent = db.Column(db.Text)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow, index=True)

    recording = db.relationship("Recording", back_populates="access_events")
    share = db.relationship("RecordingShare", back_populates="access_events")
    admin = db.relationship("AdminAccount")

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "recordingId": self.recording_id,
            "shareId": self.share_id,
            "adminId": self.admin_id,
            "action": self.action,
            "ipAddress": self.ip_address,
            "userAgent": self.user_agent,
            "createdAt": self.created_at.isoformat() if self.created_at else None,
        }


class MeetingInvitation(db.Model, TimestampMixin):
    __tablename__ = "meeting_invitations"

    id = db.Column(db.String(36), primary_key=True, default=new_id)
    meeting_id = db.Column(db.String(36), db.ForeignKey("meetings.id"), nullable=False, unique=True, index=True)
    token = db.Column(db.String(128), nullable=False, unique=True, index=True)
    url = db.Column(db.String(600), nullable=False)
    regenerated_at = db.Column(db.DateTime(timezone=True))

    meeting = db.relationship("Meeting", back_populates="invitation")

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "meetingId": self.meeting_id,
            "token": self.token,
            "url": self.url,
            "regeneratedAt": self.regenerated_at.isoformat() if self.regenerated_at else None,
            "createdAt": self.created_at.isoformat() if self.created_at else None,
        }


class ApiKey(db.Model, TimestampMixin):
    __tablename__ = "api_keys"

    id = db.Column(db.String(36), primary_key=True, default=new_id)
    admin_id = db.Column(db.String(36), db.ForeignKey("admin_accounts.id"), nullable=False, index=True)
    name = db.Column(db.String(160), nullable=False)
    key_hash = db.Column(db.String(128), nullable=False, unique=True, index=True)
    key_prefix = db.Column(db.String(24), nullable=False, index=True)
    scopes = db.Column(db.JSON, nullable=False, default=list)
    expires_at = db.Column(db.DateTime(timezone=True), index=True)
    last_used_at = db.Column(db.DateTime(timezone=True))
    revoked_at = db.Column(db.DateTime(timezone=True), index=True)

    admin = db.relationship("AdminAccount")

    @property
    def active(self) -> bool:
        expires = self.expires_at
        if expires and expires.tzinfo is None:
            expires = expires.replace(tzinfo=timezone.utc)
        return self.revoked_at is None and (expires is None or expires > utcnow())

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "keyPrefix": self.key_prefix,
            "scopes": self.scopes or [],
            "expiresAt": self.expires_at.isoformat() if self.expires_at else None,
            "lastUsedAt": self.last_used_at.isoformat() if self.last_used_at else None,
            "revokedAt": self.revoked_at.isoformat() if self.revoked_at else None,
            "active": self.active,
            "createdAt": self.created_at.isoformat() if self.created_at else None,
        }


class WebhookSubscription(db.Model, TimestampMixin):
    __tablename__ = "webhook_subscriptions"

    id = db.Column(db.String(36), primary_key=True, default=new_id)
    admin_id = db.Column(db.String(36), db.ForeignKey("admin_accounts.id"), nullable=False, index=True)
    target_url = db.Column(db.String(1000), nullable=False)
    events = db.Column(db.JSON, nullable=False, default=list)
    enabled = db.Column(db.Boolean, nullable=False, default=True, index=True)
    description = db.Column(db.String(255))
    secret_hash = db.Column(db.String(128), nullable=False)
    last_success_at = db.Column(db.DateTime(timezone=True))
    last_failure_at = db.Column(db.DateTime(timezone=True))

    admin = db.relationship("AdminAccount")
    deliveries = db.relationship("WebhookDelivery", back_populates="subscription", cascade="all, delete-orphan")

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "targetUrl": self.target_url,
            "events": self.events or [],
            "enabled": self.enabled,
            "description": self.description,
            "lastSuccessAt": self.last_success_at.isoformat() if self.last_success_at else None,
            "lastFailureAt": self.last_failure_at.isoformat() if self.last_failure_at else None,
            "createdAt": self.created_at.isoformat() if self.created_at else None,
            "updatedAt": self.updated_at.isoformat() if self.updated_at else None,
        }


class WebhookDelivery(db.Model):
    __tablename__ = "webhook_deliveries"

    id = db.Column(db.String(36), primary_key=True, default=new_id)
    subscription_id = db.Column(db.String(36), db.ForeignKey("webhook_subscriptions.id"), nullable=False, index=True)
    event_type = db.Column(db.String(120), nullable=False, index=True)
    payload_json = db.Column(db.JSON, nullable=False, default=dict)
    status = db.Column(db.String(40), nullable=False, default="pending", index=True)
    attempts = db.Column(db.Integer, nullable=False, default=0)
    last_attempt_at = db.Column(db.DateTime(timezone=True))
    next_retry_at = db.Column(db.DateTime(timezone=True), index=True)
    response_status = db.Column(db.Integer)
    response_body = db.Column(db.Text)
    error_message = db.Column(db.Text)
    signature = db.Column(db.String(128))
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow, index=True)

    subscription = db.relationship("WebhookSubscription", back_populates="deliveries")

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "subscriptionId": self.subscription_id,
            "eventType": self.event_type,
            "payload": self.payload_json or {},
            "status": self.status,
            "attempts": self.attempts,
            "lastAttemptAt": self.last_attempt_at.isoformat() if self.last_attempt_at else None,
            "nextRetryAt": self.next_retry_at.isoformat() if self.next_retry_at else None,
            "responseStatus": self.response_status,
            "responseBody": self.response_body,
            "errorMessage": self.error_message,
            "signature": self.signature,
            "createdAt": self.created_at.isoformat() if self.created_at else None,
        }


class AppSetting(db.Model, TimestampMixin):
    __tablename__ = "app_settings"

    key = db.Column(db.String(120), primary_key=True)
    value = db.Column(db.JSON, nullable=False, default=dict)
