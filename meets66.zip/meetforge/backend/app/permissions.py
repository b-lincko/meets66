from __future__ import annotations

from .models import AdminAccount

ALL_PERMISSIONS = [
    "admins.manage",
    "settings.manage",
    "meetings.manage",
    "recordings.manage",
    "security.manage",
    "integrations.manage",
    "analytics.view",
]

ROLE_PERMISSIONS = {
    "super_admin": ALL_PERMISSIONS,
    "admin": ["meetings.manage", "recordings.manage", "analytics.view"],
    "meeting_admin": ["meetings.manage", "analytics.view"],
}

VALID_ADMIN_ROLES = set(ROLE_PERMISSIONS.keys())


def effective_permissions(admin: AdminAccount) -> list[str]:
    explicit = admin.permissions_json if isinstance(admin.permissions_json, list) else None
    if explicit is not None:
        return sorted({str(item) for item in explicit if str(item) in ALL_PERMISSIONS})
    return sorted(ROLE_PERMISSIONS.get(admin.role, []))


def has_permission(admin: AdminAccount, permission: str) -> bool:
    if admin.role == "super_admin":
        return True
    return permission in effective_permissions(admin)
