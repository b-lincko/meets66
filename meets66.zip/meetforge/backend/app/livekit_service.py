from __future__ import annotations

import asyncio
import json
import threading
from datetime import timedelta
from typing import Any

from flask import current_app


def livekit_public_url() -> str:
    return current_app.config["LIVEKIT_URL"]


def api_url() -> str:
    url = current_app.config.get("LIVEKIT_INTERNAL_URL") or current_app.config["LIVEKIT_URL"]
    if url.startswith("ws://"):
        return "http://" + url.removeprefix("ws://")
    if url.startswith("wss://"):
        return "https://" + url.removeprefix("wss://")
    return url


def create_room_token(*, identity: str, name: str, room: str, role: str, sources: list[str] | None = None, ttl_minutes: int = 240) -> str:
    from livekit import api

    is_host = role in {"host", "cohost"}
    publish_sources = sources if sources is not None else ["camera", "microphone", "screen_share", "screen_share_audio"]
    grants = api.VideoGrants(
        room_join=True,
        room=room,
        can_publish=bool(publish_sources),
        can_subscribe=True,
        can_publish_data=True,
        room_admin=is_host,
        can_publish_sources=publish_sources,
    )
    token = (
        api.AccessToken(current_app.config["LIVEKIT_API_KEY"], current_app.config["LIVEKIT_API_SECRET"])
        .with_identity(identity)
        .with_name(name)
        .with_metadata(json.dumps({"role": role}))
        .with_grants(grants)
        .with_ttl(timedelta(minutes=ttl_minutes))
    )
    return token.to_jwt()


def _livekit_not_found(exc: BaseException) -> bool:
    """Return True for expected LiveKit admin 404s.

    LiveKit returns not_found when host controls are applied before a participant has
    fully joined the media room, or after a reconnect/leave race. These are safe
    no-ops for our state machine and should not pollute production logs with
    tracebacks.
    """
    status = getattr(exc, "status", None)
    code = getattr(exc, "code", None)
    message = str(getattr(exc, "message", "") or exc).lower()
    return status == 404 or code == "not_found" or "participant does not exist" in message or "not_found" in message


def _run(coro) -> bool:
    app = current_app._get_current_object()

    def execute() -> bool:
        with app.app_context():
            try:
                asyncio.run(coro)
                return True
            except Exception as exc:  # noqa: BLE001 - external SDK exceptions vary by version
                if _livekit_not_found(exc):
                    app.logger.debug("LiveKit participant was not present for admin operation; treating as a no-op: %s", exc)
                    return False
                app.logger.exception("LiveKit admin operation failed")
                return False

    try:
        asyncio.get_running_loop()
        running_loop = True
    except RuntimeError:
        running_loop = False

    if not running_loop:
        return execute()

    result: dict[str, Any] = {"ok": False}

    def target() -> None:
        result["ok"] = execute()

    thread = threading.Thread(target=target, name="livekit-admin-op", daemon=True)
    thread.start()
    thread.join(timeout=15)
    if thread.is_alive():
        app.logger.warning("LiveKit admin operation timed out")
        return False
    return bool(result["ok"])


def permission_source_values(sources: list[str]) -> list[int]:
    from livekit import api

    source_map = {
        "camera": api.CAMERA,
        "microphone": api.MICROPHONE,
        "screen_share": api.SCREEN_SHARE,
        "screen_share_audio": api.SCREEN_SHARE_AUDIO,
    }
    return [source_map[source] for source in sources if source in source_map]


async def _update_permissions(room: str, identity: str, sources: list[str], room_admin: bool) -> None:
    from livekit import api

    lk = api.LiveKitAPI(api_url(), current_app.config["LIVEKIT_API_KEY"], current_app.config["LIVEKIT_API_SECRET"])
    try:
        await lk.room.update_participant(
            api.UpdateParticipantRequest(
                room=room,
                identity=identity,
                permission=api.ParticipantPermission(
                    can_subscribe=True,
                    can_publish=bool(sources),
                    can_publish_data=True,
                    can_publish_sources=permission_source_values(sources),
                ),
            )
        )
    finally:
        await lk.aclose()


async def _remove_participant(room: str, identity: str) -> None:
    from livekit import api

    lk = api.LiveKitAPI(api_url(), current_app.config["LIVEKIT_API_KEY"], current_app.config["LIVEKIT_API_SECRET"])
    try:
        await lk.room.remove_participant(api.RoomParticipantIdentity(room=room, identity=identity))
    finally:
        await lk.aclose()


async def _mute_tracks(room: str, identity: str, sources: list[str], muted: bool) -> None:
    from livekit import api

    source_map = {"camera": api.CAMERA, "microphone": api.MICROPHONE, "screen_share": api.SCREEN_SHARE, "screen_share_audio": api.SCREEN_SHARE_AUDIO}
    wanted = {source_map[source] for source in sources if source in source_map}
    lk = api.LiveKitAPI(api_url(), current_app.config["LIVEKIT_API_KEY"], current_app.config["LIVEKIT_API_SECRET"])
    try:
        participant = await lk.room.get_participant(api.RoomParticipantIdentity(room=room, identity=identity))
        for track in participant.tracks:
            if track.source in wanted:
                await lk.room.mute_published_track(api.MuteRoomTrackRequest(room=room, identity=identity, track_sid=track.sid, muted=muted))
    finally:
        await lk.aclose()


def update_permissions(room: str, identity: str, sources: list[str], room_admin: bool = False) -> bool:
    return _run(_update_permissions(room, identity, sources, room_admin))


def remove_participant(room: str, identity: str) -> bool:
    return _run(_remove_participant(room, identity))


def mute_tracks(room: str, identity: str, sources: list[str], muted: bool = True) -> bool:
    return _run(_mute_tracks(room, identity, sources, muted))
