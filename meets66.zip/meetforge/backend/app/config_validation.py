from __future__ import annotations

from urllib.parse import urlparse

WEAK_VALUES = {
    "change-this-secret",
    "change-this-jwt-secret",
    "replace-this-secret",
    "secret",
    "devkey",
    "Nullbyte69",
    "meetforge",
    "meetforge-secret",
}


def is_local_url(value: str | None) -> bool:
    if not value:
        return False
    parsed = urlparse(value.replace("ws://", "http://").replace("wss://", "https://"))
    host = parsed.hostname or ""
    return host in {"localhost", "127.0.0.1", "0.0.0.0"}


def validate_config(config) -> dict:
    env = str(config.get("FLASK_ENV") or "development").lower()
    production = env == "production"
    errors: list[str] = []
    warnings: list[str] = []

    def check_secret(key: str, min_length: int = 32) -> None:
        value = str(config.get(key) or "")
        if not value:
            errors.append(f"{key} is required")
            return
        if value in WEAK_VALUES or len(value) < min_length:
            (errors if production else warnings).append(f"{key} must be a strong unique value of at least {min_length} characters")

    check_secret("SECRET_KEY")
    check_secret("JWT_SECRET")
    check_secret("LIVEKIT_API_SECRET")

    if str(config.get("DEFAULT_ADMIN_PASSWORD") or "") in WEAK_VALUES:
        (errors if production else warnings).append("DEFAULT_ADMIN_PASSWORD must be changed before production use")

    database_url = str(config.get("SQLALCHEMY_DATABASE_URI") or "")
    if production and database_url.startswith("sqlite"):
        errors.append("Production DATABASE_URL must use PostgreSQL, not SQLite")

    public_app_url = str(config.get("PUBLIC_APP_URL") or "")
    if production:
        if not public_app_url.startswith("https://"):
            errors.append("PUBLIC_APP_URL must use HTTPS in production")
        if is_local_url(public_app_url):
            errors.append("PUBLIC_APP_URL must not point to localhost in production")
        if not config.get("CSRF_ENFORCED"):
            errors.append("CSRF_ENFORCED must be true in production")

    cors_origins = config.get("CORS_ORIGINS") or []
    if production and any(is_local_url(origin) for origin in cors_origins):
        errors.append("CORS_ORIGINS must not include localhost origins in production")

    if not config.get("LIVEKIT_URL"):
        errors.append("LIVEKIT_URL is required")
    if not config.get("LIVEKIT_INTERNAL_URL"):
        warnings.append("LIVEKIT_INTERNAL_URL is not set; backend LiveKit admin calls may fail inside Docker")

    if not config.get("STUN_SERVERS"):
        warnings.append("STUN_SERVERS is empty; WebRTC NAT traversal may be unreliable")
    if production and not config.get("TURN_URLS"):
        warnings.append("TURN_URLS is empty; production WebRTC may fail on restrictive networks")

    return {
        "environment": env,
        "production": production,
        "valid": not errors,
        "errors": errors,
        "warnings": warnings,
    }
