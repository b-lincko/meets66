from __future__ import annotations

import os


def csv(value: str | None) -> list[str]:
    if not value:
        return []
    return [item.strip() for item in value.split(",") if item.strip()]


class Config:
    FLASK_ENV = os.getenv("FLASK_ENV", "development")
    APP_NAME = os.getenv("APP_NAME", "Defensiq Meet")
    PUBLIC_APP_URL = os.getenv("PUBLIC_APP_URL", "http://localhost:3000")
    SECRET_KEY = os.getenv("SECRET_KEY", "replace-this-secret")
    JWT_SECRET = os.getenv("JWT_SECRET", SECRET_KEY)
    JWT_ISSUER = os.getenv("JWT_ISSUER", "defensiq-meet")
    ACCESS_TOKEN_EXPIRES_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRES_MINUTES", "15"))
    REFRESH_TOKEN_EXPIRES_DAYS = int(os.getenv("REFRESH_TOKEN_EXPIRES_DAYS", "30"))
    DEFAULT_ADMIN_EMAIL = os.getenv("DEFAULT_ADMIN_EMAIL", "web@defensiqsecurity.com")
    DEFAULT_ADMIN_PASSWORD = os.getenv("DEFAULT_ADMIN_PASSWORD", "Nullbyte69")
    SMTP_HOST = os.getenv("SMTP_HOST", "")
    SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
    SMTP_USERNAME = os.getenv("SMTP_USERNAME", "")
    SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
    SMTP_FROM = os.getenv("SMTP_FROM", "")
    SMTP_USE_TLS = os.getenv("SMTP_USE_TLS", "true").lower() == "true"

    SQLALCHEMY_DATABASE_URI = os.getenv("DATABASE_URL", "sqlite:///defensiq_meet.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        "pool_pre_ping": True,
        "pool_recycle": 1800,
        "pool_size": int(os.getenv("DB_POOL_SIZE", "5")),
        "max_overflow": int(os.getenv("DB_MAX_OVERFLOW", "5")),
    }

    CORS_ORIGINS = csv(os.getenv("CORS_ORIGINS", "http://localhost:3000,http://localhost:8080"))
    SOCKETIO_MESSAGE_QUEUE = os.getenv("SOCKETIO_MESSAGE_QUEUE") or None
    LIVEKIT_URL = os.getenv("LIVEKIT_URL", "ws://localhost:7880")
    LIVEKIT_INTERNAL_URL = os.getenv("LIVEKIT_INTERNAL_URL", "ws://livekit:7880")
    LIVEKIT_API_KEY = os.getenv("LIVEKIT_API_KEY", "devkey")
    LIVEKIT_API_SECRET = os.getenv("LIVEKIT_API_SECRET", "secret")
    LIVEKIT_ROOM_PREFIX = os.getenv("LIVEKIT_ROOM_PREFIX", "defensiq")
    STUN_SERVERS = csv(os.getenv("STUN_SERVERS", "stun:stun.l.google.com:19302"))
    TURN_URLS = csv(os.getenv("TURN_URLS", ""))
    TURN_USERNAME = os.getenv("TURN_USERNAME", "")
    TURN_CREDENTIAL = os.getenv("TURN_CREDENTIAL", "")
    MEDIA_REGIONS = csv(os.getenv("MEDIA_REGIONS", "local|Local|ws://localhost:7880|1"))
    RATELIMIT_DEFAULT = os.getenv("RATE_LIMIT_DEFAULT", "300 per hour")
    RATELIMIT_STORAGE_URI = os.getenv("RATELIMIT_STORAGE_URI") or os.getenv("REDIS_URL") or "memory://"

    ACCOUNT_LOCK_ATTEMPTS = int(os.getenv("ACCOUNT_LOCK_ATTEMPTS", "5"))
    ACCOUNT_LOCK_MINUTES = int(os.getenv("ACCOUNT_LOCK_MINUTES", "15"))
    SESSION_IDLE_TIMEOUT_MINUTES = int(os.getenv("SESSION_IDLE_TIMEOUT_MINUTES", "120"))
    MAX_CHAT_FILE_MB = int(os.getenv("MAX_CHAT_FILE_MB", "25"))
    MAX_RECORDING_UPLOAD_MB = int(os.getenv("MAX_RECORDING_UPLOAD_MB", "1024"))
    CSRF_ENFORCED = os.getenv("CSRF_ENFORCED", "true").lower() == "true"


class TestingConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    SQLALCHEMY_ENGINE_OPTIONS = {}
    RATELIMIT_ENABLED = False
    SOCKETIO_MESSAGE_QUEUE = None
    CSRF_ENFORCED = False
    SECRET_KEY = "test-secret"
    JWT_SECRET = "test-jwt-secret"
