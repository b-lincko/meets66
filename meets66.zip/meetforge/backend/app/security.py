from __future__ import annotations

import hashlib
import secrets
from datetime import datetime, timedelta, timezone
from typing import Any

import jwt
from email_validator import EmailNotValidError, validate_email
from flask import current_app, g, request

from .extensions import db
from .models import AdminAccount, AdminDevice, AdminSession, AuditLog, utcnow


def aware(dt: datetime | None) -> datetime | None:
    if dt is None:
        return None
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt


def normalize_email(email: str) -> str:
    try:
        return validate_email(email, check_deliverability=False).normalized.lower()
    except EmailNotValidError as exc:
        raise ValueError(str(exc)) from exc


def validate_password_strength(password: str) -> None:
    if len(password) < 10:
        raise ValueError("Password must be at least 10 characters.")
    if not any(c.islower() for c in password):
        raise ValueError("Password must contain a lowercase letter.")
    if not any(c.isupper() for c in password):
        raise ValueError("Password must contain an uppercase letter.")
    if not any(c.isdigit() for c in password):
        raise ValueError("Password must contain a number.")


def random_token(length: int = 48) -> str:
    return secrets.token_urlsafe(length)


def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def client_ip() -> str:
    return request.headers.get("X-Forwarded-For", request.remote_addr or "").split(",")[0].strip()


def user_agent() -> str:
    return request.headers.get("User-Agent", "")[:1000]


def access_expiry() -> datetime:
    return utcnow() + timedelta(minutes=current_app.config["ACCESS_TOKEN_EXPIRES_MINUTES"])


def refresh_expiry() -> datetime:
    return utcnow() + timedelta(days=current_app.config["REFRESH_TOKEN_EXPIRES_DAYS"])


def create_participant_token(participant_id: str, meeting_id: str) -> str:
    now = utcnow()
    payload = {
        "iss": current_app.config["JWT_ISSUER"],
        "sub": participant_id,
        "meetingId": meeting_id,
        "iat": int(now.timestamp()),
        "nbf": int(now.timestamp()),
        "exp": int((now + timedelta(hours=8)).timestamp()),
        "type": "participant",
    }
    return jwt.encode(payload, current_app.config["JWT_SECRET"], algorithm="HS256")


def decode_participant_token(raw: str) -> dict[str, Any]:
    claims = jwt.decode(
        raw,
        current_app.config["JWT_SECRET"],
        algorithms=["HS256"],
        issuer=current_app.config["JWT_ISSUER"],
        options={"require": ["exp", "iat", "sub", "meetingId", "type"]},
    )
    if claims.get("type") != "participant":
        raise jwt.InvalidTokenError("Invalid participant token")
    return claims


def create_access_token(admin: AdminAccount, session: AdminSession) -> str:
    now = utcnow()
    jti = secrets.token_hex(16)
    session.access_jti = jti
    session.last_seen_at = now
    payload = {
        "iss": current_app.config["JWT_ISSUER"],
        "sub": admin.id,
        "sid": session.id,
        "role": "admin",
        "jti": jti,
        "iat": int(now.timestamp()),
        "nbf": int(now.timestamp()),
        "exp": int(access_expiry().timestamp()),
        "type": "access",
        "mustChangePassword": admin.must_change_password,
    }
    return jwt.encode(payload, current_app.config["JWT_SECRET"], algorithm="HS256")


def decode_access_token(raw: str) -> dict[str, Any]:
    return jwt.decode(
        raw,
        current_app.config["JWT_SECRET"],
        algorithms=["HS256"],
        issuer=current_app.config["JWT_ISSUER"],
        options={"require": ["exp", "iat", "sub", "sid", "jti", "type"]},
    )


def device_fingerprint() -> str:
    explicit = request.headers.get("X-Device-Id")
    base = explicit or user_agent() or client_ip()
    return token_hash(base[:1000])


def get_or_create_device(admin: AdminAccount) -> AdminDevice:
    fp = device_fingerprint()
    device = AdminDevice.query.filter_by(admin_id=admin.id, fingerprint_hash=fp).first()
    if not device:
        device = AdminDevice(admin_id=admin.id, fingerprint_hash=fp, label=request.headers.get("X-Device-Label") or None, first_ip=client_ip(), user_agent=user_agent(), trusted=False)
        db.session.add(device)
        db.session.flush()
    device.last_ip = client_ip()
    device.last_seen_at = utcnow()
    device.user_agent = user_agent()
    return device


def create_csrf_token(session: AdminSession) -> str:
    raw = random_token(32)
    session.csrf_token_hash = token_hash(raw)
    return raw


def verify_csrf_token(session: AdminSession, raw: str | None) -> bool:
    return bool(raw and session.csrf_token_hash and token_hash(raw) == session.csrf_token_hash)


def create_session(admin: AdminAccount) -> tuple[AdminSession, str]:
    refresh = random_token(48)
    device = get_or_create_device(admin)
    session = AdminSession(
        admin_id=admin.id,
        refresh_token_hash=token_hash(refresh),
        access_jti=secrets.token_hex(16),
        ip_address=client_ip(),
        user_agent=user_agent(),
        expires_at=refresh_expiry(),
        last_seen_at=utcnow(),
        device_id=device.id,
    )
    db.session.add(session)
    db.session.flush()
    create_csrf_token(session)
    return session, refresh


def rotate_refresh_token(session: AdminSession) -> str:
    refresh = random_token(48)
    session.refresh_token_hash = token_hash(refresh)
    session.last_seen_at = utcnow()
    create_csrf_token(session)
    if session.device:
        session.device.last_seen_at = utcnow()
        session.device.last_ip = client_ip()
    return refresh


def revoke_session(session: AdminSession, reason: str) -> None:
    if session.revoked_at is None:
        session.revoked_at = utcnow()
        session.revoked_reason = reason[:160]


def audit(action: str, actor: AdminAccount | None = None, session: AdminSession | None = None, entity_type: str | None = None, entity_id: str | None = None, metadata: dict[str, Any] | None = None) -> None:
    log = AuditLog(
        actor_admin_id=actor.id if actor else None,
        session_id=session.id if session else None,
        action=action,
        entity_type=entity_type,
        entity_id=entity_id,
        ip_address=client_ip(),
        user_agent=user_agent(),
        metadata_json=metadata or {},
    )
    db.session.add(log)


def current_context() -> tuple[AdminAccount | None, AdminSession | None]:
    return getattr(g, "current_admin", None), getattr(g, "current_session", None)
