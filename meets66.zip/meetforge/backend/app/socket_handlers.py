from __future__ import annotations

from flask import request
from flask_socketio import disconnect, emit, join_room, leave_room

from .extensions import db, socketio
from .models import AdminAccount, AdminSession, Meeting, MeetingParticipant
from .security import aware, decode_access_token, decode_participant_token, token_hash, utcnow

SID_ADMINS: dict[str, str] = {}
SID_PARTICIPANTS: dict[str, str] = {}
SID_MEETINGS: dict[str, str] = {}


def authenticate(token: str | None):
    if not token:
        return None, None
    try:
        claims = decode_access_token(token)
        admin = db.session.get(AdminAccount, claims["sub"])
        session = db.session.get(AdminSession, claims["sid"])
        if admin and session and session.revoked_at is None and aware(session.expires_at) > utcnow() and session.access_jti == claims.get("jti"):
            return "admin", admin.id
    except Exception:
        claims = None
    try:
        claims = decode_participant_token(token)
        participant = db.session.get(MeetingParticipant, claims["sub"])
        if participant and participant.status in {"waiting", "admitted"} and participant.participant_token_hash == token_hash(token):
            return "participant", participant.id
    except Exception:
        claims = None
    return None, None


@socketio.on("connect")
def connect(auth):
    token = (auth or {}).get("token") or request.args.get("token")
    kind, identity = authenticate(token)
    if not kind:
        return False
    if kind == "admin":
        SID_ADMINS[request.sid] = identity
        join_room(identity)
    else:
        SID_PARTICIPANTS[request.sid] = identity
        join_room(identity)
    emit("connected", {"kind": kind, "id": identity})


@socketio.on("disconnect")
def on_disconnect():
    SID_ADMINS.pop(request.sid, None)
    SID_PARTICIPANTS.pop(request.sid, None)
    meeting_id = SID_MEETINGS.pop(request.sid, None)
    if meeting_id:
        leave_room(meeting_id)


def watched_meeting_for_socket(meeting_id: str):
    meeting = Meeting.query.filter((Meeting.id == meeting_id) | (Meeting.meeting_id == meeting_id)).first()
    if not meeting:
        return None, None, False
    admin_id = SID_ADMINS.get(request.sid)
    participant_id = SID_PARTICIPANTS.get(request.sid)
    if admin_id and meeting.admin_id == admin_id:
        admin = db.session.get(AdminAccount, admin_id)
        return meeting, admin.display_name if admin else "Host", True
    if participant_id:
        participant = db.session.get(MeetingParticipant, participant_id)
        if participant and participant.meeting_id == meeting.id and participant.status == "admitted":
            return meeting, participant.display_name, True
    return meeting, None, False


@socketio.on("meeting:watch")
def meeting_watch(data):
    meeting_id = (data or {}).get("meetingId")
    if not meeting_id:
        emit("error", {"message": "meetingId is required"})
        return
    meeting = Meeting.query.filter((Meeting.id == meeting_id) | (Meeting.meeting_id == meeting_id)).first()
    if not meeting:
        emit("error", {"message": "Meeting not found"})
        return
    admin_id = SID_ADMINS.get(request.sid)
    participant_id = SID_PARTICIPANTS.get(request.sid)
    allowed = bool(admin_id and meeting.admin_id == admin_id)
    if participant_id:
        participant = db.session.get(MeetingParticipant, participant_id)
        allowed = bool(participant and participant.meeting_id == meeting.id)
    if not allowed:
        emit("error", {"message": "Forbidden"})
        return
    join_room(meeting.id)
    SID_MEETINGS[request.sid] = meeting.id
    emit("meeting:watching", {"meetingId": meeting.id})


@socketio.on("whiteboard:laser")
def whiteboard_laser(data):
    meeting_id = (data or {}).get("meetingId")
    if not meeting_id:
        emit("error", {"message": "meetingId is required"})
        return
    meeting, display_name, allowed = watched_meeting_for_socket(meeting_id)
    if not meeting or not allowed:
        emit("error", {"message": "Forbidden"})
        return
    emit(
        "whiteboard:laser",
        {"meetingId": meeting.id, "displayName": display_name, "x": (data or {}).get("x"), "y": (data or {}).get("y")},
        room=meeting.id,
        include_self=False,
    )


@socketio.on("chat:typing")
def chat_typing(data):
    meeting_id = (data or {}).get("meetingId")
    if not meeting_id:
        emit("error", {"message": "meetingId is required"})
        return
    meeting, display_name, allowed = watched_meeting_for_socket(meeting_id)
    if not meeting or not allowed:
        emit("error", {"message": "Forbidden"})
        return
    emit(
        "chat:typing",
        {"meetingId": meeting.id, "displayName": display_name, "isTyping": bool((data or {}).get("isTyping"))},
        room=meeting.id,
        include_self=False,
    )


@socketio.on("presentation:laser")
def presentation_laser(data):
    meeting_id = (data or {}).get("meetingId")
    if not meeting_id:
        emit("error", {"message": "meetingId is required"})
        return
    meeting, display_name, allowed = watched_meeting_for_socket(meeting_id)
    if not meeting or not allowed:
        emit("error", {"message": "Forbidden"})
        return
    emit(
        "presentation:laser",
        {"meetingId": meeting.id, "displayName": display_name, "x": (data or {}).get("x"), "y": (data or {}).get("y")},
        room=meeting.id,
        include_self=False,
    )


@socketio.on("presentation:annotation")
def presentation_annotation(data):
    meeting_id = (data or {}).get("meetingId")
    if not meeting_id:
        emit("error", {"message": "meetingId is required"})
        return
    meeting, display_name, allowed = watched_meeting_for_socket(meeting_id)
    if not meeting or not allowed:
        emit("error", {"message": "Forbidden"})
        return
    payload = {
        "meetingId": meeting.id,
        "displayName": display_name,
        "annotationId": (data or {}).get("annotationId"),
        "points": (data or {}).get("points") or [],
        "color": (data or {}).get("color") or "#f59e0b",
        "width": min(16, max(1, int((data or {}).get("width") or 4))),
        "clear": bool((data or {}).get("clear")),
    }
    emit("presentation:annotation", payload, room=meeting.id, include_self=False)


@socketio.on("presentation:slide_control")
def presentation_slide_control(data):
    meeting_id = (data or {}).get("meetingId")
    direction = (data or {}).get("direction")
    if direction not in {"next", "previous"}:
        emit("error", {"message": "direction must be next or previous"})
        return
    meeting, display_name, allowed = watched_meeting_for_socket(meeting_id)
    if not meeting or not allowed:
        emit("error", {"message": "Forbidden"})
        return
    emit("presentation:slide_control", {"meetingId": meeting.id, "direction": direction, "displayName": display_name}, room=meeting.id, include_self=False)
