from flask_cors import CORS
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_socketio import SocketIO
from flask_sqlalchemy import SQLAlchemy


db = SQLAlchemy()
cors = CORS()
limiter = Limiter(key_func=get_remote_address)
socketio = SocketIO(async_mode="gevent", cors_allowed_origins=[])
