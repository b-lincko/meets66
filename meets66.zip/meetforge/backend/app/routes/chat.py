from __future__ import annotations

import hashlib
from urllib.parse import quote

from flask import Blueprint, Response, current_app, g, jsonify, request
from werkzeug.datastructures import FileStorage
from werkzeug.utils import secure_filename

from ..decorators import error, paginate, require_admin
from ..extensions import db, socketio
from ..models import ChatMessage, Meeting, MeetingFile, MeetingInvitation, MeetingParticipant
from ..security import audit, decode_participant_token, token_hash
from ..webhooks import dispatch_webhook

bp = Blueprint("chat", __name__)


def meeting_by_id(identifier: str) -> Meeting | None:
    return Meeting.query.filter((Meeting.id == identifier) | (Meeting.meeting_id == identifier)).first()


def admin_meeting(identifier: str):
    meeting = meeting_by_id(identifier)
    if not meeting or meeting.admin_id != g.current_admin.id:
        return None, error("Meeting not found", 404, "meeting_not_found")
    return meeting, None


def participant_from_bearer(meeting: Meeting) -> MeetingParticipant | None:
    header = request.headers.get("Authorization", "")
    if not header.startswith("Bearer "):
        return None
    raw = header.removeprefix("Bearer ").strip()
    try:
        claims = decode_participant_token(raw)
    except Exception:
        return None
    participant = db.session.get(MeetingParticipant, claims["sub"])
    if not participant or participant.meeting_id != meeting.id or participant.participant_token_hash != token_hash(raw) or participant.status != "admitted":
        return None
    return participant


def public_meeting_from_invite(token: str):
    invitation = MeetingInvitation.query.filter_by(token=token).first()
    if not invitation:
        return None, None, error("Invitation link not found", 404, "invitation_not_found")
    meeting = invitation.meeting
    participant = participant_from_bearer(meeting)
    if not participant:
        return meeting, None, error("Invalid participant session", 401, "invalid_participant_session")
    return meeting, participant, None


def parse_message_payload():
    if request.content_type and request.content_type.startswith("multipart/form-data"):
        body = (request.form.get("body") or request.form.get("content") or "").strip()
        upload = request.files.get("file")
        return body, upload, request.form.to_dict()
    data = request.get_json(silent=True) or {}
    return str(data.get("body") or data.get("content") or "").strip(), None, data


def extract_mentions(body: str) -> list[str]:
    mentions: list[str] = []
    for word in body.split():
        if word.startswith("@") and len(word) > 1:
            clean = "".join(ch for ch in word[1:] if ch.isalnum() or ch in {".", "_", "-"})[:80]
            if clean and clean not in mentions:
                mentions.append(clean)
    return mentions


def store_file(meeting: Meeting, upload: FileStorage | None, *, admin_id: str | None = None, participant_id: str | None = None) -> MeetingFile | None:
    if not upload or not upload.filename:
        return None
    filename = secure_filename(upload.filename) or "attachment"
    max_bytes = current_app.config["MAX_CHAT_FILE_MB"] * 1024 * 1024
    data = upload.read(max_bytes + 1)
    if len(data) > max_bytes:
        raise ValueError(f"Attachment exceeds {current_app.config['MAX_CHAT_FILE_MB']} MB")
    if len(data) == 0:
        raise ValueError("Attachment is empty")
    digest = hashlib.sha256(data).hexdigest()
    asset = MeetingFile(
        meeting_id=meeting.id,
        uploader_admin_id=admin_id,
        uploader_participant_id=participant_id,
        filename=filename[:255],
        content_type=(upload.mimetype or "application/octet-stream")[:160],
        size_bytes=len(data),
        sha256=digest,
        data=data,
    )
    db.session.add(asset)
    db.session.flush()
    return asset


def create_message(meeting: Meeting, *, sender_name: str, body: str, file: MeetingFile | None = None, admin_id: str | None = None, participant_id: str | None = None, reply_to_id: str | None = None, thread_root_id: str | None = None) -> ChatMessage:
    if not body and not file:
        raise ValueError("Message text or attachment is required")
    reply_to = db.session.get(ChatMessage, reply_to_id) if reply_to_id else None
    if reply_to_id and (not reply_to or reply_to.meeting_id != meeting.id):
        raise ValueError("Reply target message was not found")
    root_id = thread_root_id or (reply_to.thread_root_id if reply_to and reply_to.thread_root_id else (reply_to.id if reply_to else None))
    if root_id:
        root = db.session.get(ChatMessage, root_id)
        if not root or root.meeting_id != meeting.id:
            raise ValueError("Thread root message was not found")
    message = ChatMessage(
        meeting_id=meeting.id,
        sender_admin_id=admin_id,
        sender_participant_id=participant_id,
        sender_display_name=sender_name[:160],
        body=body or None,
        message_type="file" if file else "text",
        file_id=file.id if file else None,
        reply_to_id=reply_to.id if reply_to else None,
        thread_root_id=root_id,
        metadata_json={"mentions": extract_mentions(body), "reactions": {}, "savedBy": [], "markdown": True},
    )
    db.session.add(message)
    db.session.flush()
    return message


def emit_message(meeting: Meeting, message: ChatMessage) -> None:
    socketio.emit("chat:message", message.to_dict(), room=meeting.id)


def download_response(asset: MeetingFile):
    disposition = f"attachment; filename*=UTF-8''{quote(asset.filename)}"
    return Response(asset.data, mimetype=asset.content_type, headers={"Content-Disposition": disposition, "Content-Length": str(asset.size_bytes)})


def message_query(meeting: Meeting):
    query = ChatMessage.query.filter_by(meeting_id=meeting.id)
    before = request.args.get("before")
    q = request.args.get("q", "").strip()
    if before:
        query = query.filter(ChatMessage.created_at < before)
    if q:
        query = query.filter(ChatMessage.body.ilike(f"%{q}%"))
    return query.order_by(ChatMessage.created_at.asc())


@bp.get("/invitations/<token>/chat/messages")
def participant_messages(token: str):
    meeting, participant, err = public_meeting_from_invite(token)
    if err:
        return err
    pagination = paginate(message_query(meeting), default_per_page=100, max_per_page=200)
    db.session.commit()
    return jsonify({"items": [m.to_dict() for m in pagination.items], "total": pagination.total})


@bp.post("/invitations/<token>/chat/messages")
def participant_send_message(token: str):
    meeting, participant, err = public_meeting_from_invite(token)
    if err:
        return err
    if not meeting.allow_chat and participant.role == "participant":
        return error("Chat is disabled by host", 403, "chat_disabled")
    try:
        body, upload, payload = parse_message_payload()
        asset = store_file(meeting, upload, participant_id=participant.id)
        message = create_message(meeting, sender_name=participant.display_name, body=body, file=asset, participant_id=participant.id, reply_to_id=payload.get("replyToId"), thread_root_id=payload.get("threadRootId"))
    except ValueError as exc:
        return error(str(exc), 400, "validation_error")
    audit("chat.participant_message", entity_type="chat_message", entity_id=message.id, metadata={"meetingId": meeting.meeting_id, "participantId": participant.id, "hasFile": bool(asset)})
    db.session.commit()
    dispatch_webhook("chat.message", {"meeting": meeting.to_dict(include_private=False), "message": message.to_dict()})
    if asset:
        dispatch_webhook("file.uploaded", {"meeting": meeting.to_dict(include_private=False), "file": asset.to_dict(), "message": message.to_dict()})
    db.session.commit()
    emit_message(meeting, message)
    return jsonify({"message": message.to_dict()}), 201


@bp.get("/invitations/<token>/chat/files/<file_id>/download")
def participant_download_file(token: str, file_id: str):
    meeting, participant, err = public_meeting_from_invite(token)
    if err:
        return err
    asset = MeetingFile.query.filter_by(id=file_id, meeting_id=meeting.id).first()
    if not asset:
        return error("File not found", 404, "file_not_found")
    db.session.commit()
    return download_response(asset)


@bp.get("/<identifier>/chat/messages")
@require_admin(permission="meetings.manage")
def admin_messages(identifier: str):
    meeting, err = admin_meeting(identifier)
    if err:
        return err
    pagination = paginate(message_query(meeting), default_per_page=100, max_per_page=200)
    db.session.commit()
    return jsonify({"items": [m.to_dict() for m in pagination.items], "total": pagination.total})


@bp.post("/<identifier>/chat/messages")
@require_admin(permission="meetings.manage")
def admin_send_message(identifier: str):
    meeting, err = admin_meeting(identifier)
    if err:
        return err
    try:
        body, upload, payload = parse_message_payload()
        asset = store_file(meeting, upload, admin_id=g.current_admin.id)
        message = create_message(meeting, sender_name=g.current_admin.display_name, body=body, file=asset, admin_id=g.current_admin.id, reply_to_id=payload.get("replyToId"), thread_root_id=payload.get("threadRootId"))
    except ValueError as exc:
        return error(str(exc), 400, "validation_error")
    audit("chat.admin_message", actor=g.current_admin, session=g.current_session, entity_type="chat_message", entity_id=message.id, metadata={"meetingId": meeting.meeting_id, "hasFile": bool(asset)})
    db.session.commit()
    dispatch_webhook("chat.message", {"meeting": meeting.to_dict(include_private=True), "message": message.to_dict()})
    if asset:
        dispatch_webhook("file.uploaded", {"meeting": meeting.to_dict(include_private=True), "file": asset.to_dict(), "message": message.to_dict()})
    db.session.commit()
    emit_message(meeting, message)
    return jsonify({"message": message.to_dict()}), 201


@bp.get("/<identifier>/chat/files/<file_id>/download")
@require_admin(permission="meetings.manage")
def admin_download_file(identifier: str, file_id: str):
    meeting, err = admin_meeting(identifier)
    if err:
        return err
    asset = MeetingFile.query.filter_by(id=file_id, meeting_id=meeting.id).first()
    if not asset:
        return error("File not found", 404, "file_not_found")
    db.session.commit()
    return download_response(asset)


def actor_key(*, admin_id: str | None = None, participant_id: str | None = None) -> str:
    return f"admin:{admin_id}" if admin_id else f"participant:{participant_id}"


def update_message_metadata(meeting: Meeting, message_id: str, *, admin_id: str | None = None, participant_id: str | None = None):
    message = ChatMessage.query.filter_by(id=message_id, meeting_id=meeting.id).first()
    if not message:
        return None, error("Message not found", 404, "message_not_found")
    data = request.get_json(silent=True) or {}
    action = str(data.get("action") or "").strip()
    metadata = dict(message.metadata_json or {})
    key = actor_key(admin_id=admin_id, participant_id=participant_id)
    if action == "react":
        emoji = str(data.get("emoji") or "").strip()[:16]
        if not emoji:
            return None, error("emoji is required", 400, "validation_error")
        reactions = dict(metadata.get("reactions") or {})
        users = list(reactions.get(emoji) or [])
        if key in users:
            users = [user for user in users if user != key]
        else:
            users.append(key)
        reactions[emoji] = users
        metadata["reactions"] = reactions
    elif action == "save":
        saved = list(metadata.get("savedBy") or [])
        if key in saved:
            saved = [user for user in saved if user != key]
        else:
            saved.append(key)
        metadata["savedBy"] = saved
    elif action == "pin":
        if not admin_id:
            actor = db.session.get(MeetingParticipant, participant_id) if participant_id else None
            if not actor or actor.role not in {"host", "cohost"}:
                return None, error("Only host or co-host can pin messages", 403, "pin_forbidden")
        message.pinned = bool(data.get("pinned", not message.pinned))
    else:
        return None, error("Unsupported message action", 400, "unsupported_action")
    message.metadata_json = metadata
    audit("chat.message_updated", actor=g.current_admin if admin_id else None, session=g.current_session if admin_id else None, entity_type="chat_message", entity_id=message.id, metadata={"action": action})
    db.session.commit()
    socketio.emit("chat:message", message.to_dict(), room=meeting.id)
    return message, None


@bp.post("/invitations/<token>/chat/messages/<message_id>/actions")
def participant_message_action(token: str, message_id: str):
    meeting, participant, err = public_meeting_from_invite(token)
    if err:
        return err
    message, err = update_message_metadata(meeting, message_id, participant_id=participant.id)
    if err:
        return err
    return jsonify({"message": message.to_dict()})


@bp.post("/<identifier>/chat/messages/<message_id>/actions")
@require_admin(permission="meetings.manage")
def admin_message_action(identifier: str, message_id: str):
    meeting, err = admin_meeting(identifier)
    if err:
        return err
    message, err = update_message_metadata(meeting, message_id, admin_id=g.current_admin.id)
    if err:
        return err
    return jsonify({"message": message.to_dict()})
