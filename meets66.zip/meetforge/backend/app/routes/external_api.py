from __future__ import annotations

from flask import Blueprint, jsonify

from ..extensions import db
from ..models import Meeting, Recording
from .integrations import require_api_key_scope

bp = Blueprint("external_api", __name__)


@bp.get("/meetings")
def external_meetings():
    key, err = require_api_key_scope("meetings:read")
    if err:
        return err
    meetings = Meeting.query.filter_by(admin_id=key.admin_id).order_by(Meeting.created_at.desc()).limit(200).all()
    db.session.commit()
    return jsonify({"items": [meeting.to_dict(include_private=True) for meeting in meetings], "total": len(meetings)})


@bp.get("/recordings")
def external_recordings():
    key, err = require_api_key_scope("recordings:read")
    if err:
        return err
    recordings = Recording.query.filter_by(admin_id=key.admin_id).order_by(Recording.created_at.desc()).limit(200).all()
    db.session.commit()
    return jsonify({"items": [recording.to_dict(include_text=False) for recording in recordings], "total": len(recordings)})
