from __future__ import annotations

from flask import Blueprint, Response, jsonify

from ..webhooks import ALL_WEBHOOK_EVENTS

bp = Blueprint("docs", __name__)


def openapi_doc():
    return {
        "openapi": "3.0.3",
        "info": {"title": "Defensiq Meet API", "version": "1.0.0", "description": "Private enterprise video conferencing API."},
        "servers": [{"url": "/api/v1"}],
        "components": {
            "securitySchemes": {
                "bearerAuth": {"type": "http", "scheme": "bearer", "bearerFormat": "JWT"},
                "apiKeyAuth": {"type": "apiKey", "in": "header", "name": "X-API-Key"},
            }
        },
        "paths": {
            "/auth/login": {"post": {"summary": "Admin login"}},
            "/meetings": {"get": {"summary": "List meetings", "security": [{"bearerAuth": []}]}, "post": {"summary": "Create meeting", "security": [{"bearerAuth": []}] }},
            "/meetings/{id}/participants": {"get": {"summary": "List participants", "security": [{"bearerAuth": []}] }},
            "/meetings/{id}/recordings/start": {"post": {"summary": "Start recording", "security": [{"bearerAuth": []}] }},
            "/recordings": {"get": {"summary": "List recordings", "security": [{"bearerAuth": []}] }},
            "/admin/api-keys": {"get": {"summary": "List API keys", "security": [{"bearerAuth": []}]}, "post": {"summary": "Create API key", "security": [{"bearerAuth": []}] }},
            "/admin/webhooks": {"get": {"summary": "List webhook subscriptions", "security": [{"bearerAuth": []}]}, "post": {"summary": "Create webhook subscription", "security": [{"bearerAuth": []}] }},
            "/external/meetings": {"get": {"summary": "External API key meeting list", "security": [{"apiKeyAuth": []}] }},
            "/external/recordings": {"get": {"summary": "External API key recording list", "security": [{"apiKeyAuth": []}] }},
        },
        "x-webhook-events": ALL_WEBHOOK_EVENTS,
    }


@bp.get("/openapi.json")
def openapi_json():
    response = jsonify(openapi_doc())
    response.headers["Cache-Control"] = "public, max-age=300"
    return response


@bp.get("/docs")
def docs_html():
    html = """
    <!doctype html><html><head><title>Defensiq Meet API</title><style>body{font-family:system-ui;margin:2rem;max-width:1000px}pre{background:#0f172a;color:#e2e8f0;padding:1rem;border-radius:12px;overflow:auto}</style></head>
    <body><h1>Defensiq Meet API</h1><p>OpenAPI JSON is available at <a href='/api/v1/openapi.json'>/api/v1/openapi.json</a>.</p><h2>Webhook events</h2><pre>%s</pre></body></html>
    """ % "\n".join(ALL_WEBHOOK_EVENTS)
    response = Response(html, mimetype="text/html")
    response.headers["Cache-Control"] = "public, max-age=300"
    return response
