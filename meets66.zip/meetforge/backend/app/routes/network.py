from __future__ import annotations

import csv
import io
from collections import Counter

from flask import Blueprint, Response, current_app, g, jsonify, request

from ..decorators import error, paginate, require_admin
from ..extensions import db
from ..models import MediaRegion, Meeting, MeetingInvitation, MeetingParticipant, NetworkDiagnostic
from ..security import audit, decode_participant_token, token_hash

bp = Blueprint("network", __name__)


def ice_servers() -> list[dict]:
    servers: list[dict] = []
    stun = current_app.config.get("STUN_SERVERS", [])
    if stun:
        servers.append({"urls": stun})
    turn_urls = current_app.config.get("TURN_URLS", [])
    if turn_urls:
        turn: dict = {"urls": turn_urls}
        if current_app.config.get("TURN_USERNAME"):
            turn["username"] = current_app.config["TURN_USERNAME"]
        if current_app.config.get("TURN_CREDENTIAL"):
            turn["credential"] = current_app.config["TURN_CREDENTIAL"]
        servers.append(turn)
    return servers


def participant_from_bearer(meeting: Meeting) -> MeetingParticipant | None:
    header = request.headers.get("Authorization", "")
    if not header.startswith("Bearer "):
        return None
    raw = header.removeprefix("Bearer ").strip()
    try:
        claims = decode_participant_token(raw)
    except Exception:
        return None
    participant = db.session.get(MeetingParticipant, claims["sub"])
    if not participant or participant.meeting_id != meeting.id or participant.participant_token_hash != token_hash(raw) or participant.status != "admitted":
        return None
    return participant


def invitation_participant(token: str):
    invitation = MeetingInvitation.query.filter_by(token=token).first()
    if not invitation:
        return None, None, error("Invitation link not found", 404, "invitation_not_found")
    meeting = invitation.meeting
    participant = participant_from_bearer(meeting)
    if not participant:
        return meeting, None, error("Invalid participant session", 401, "invalid_participant_session")
    return meeting, participant, None


def coerce_float(value):
    if value in (None, ""):
        return None
    return float(value)


def create_diagnostic(meeting: Meeting, participant: MeetingParticipant, data: dict) -> NetworkDiagnostic:
    diagnostic = NetworkDiagnostic(
        meeting_id=meeting.id,
        participant_id=participant.id,
        quality=str(data.get("quality") or "unknown")[:40],
        rtt_ms=coerce_float(data.get("rttMs") if "rttMs" in data else data.get("rtt")),
        jitter_ms=coerce_float(data.get("jitterMs") if "jitterMs" in data else data.get("jitter")),
        packet_loss=coerce_float(data.get("packetLoss")),
        downlink_mbps=coerce_float(data.get("downlinkMbps") if "downlinkMbps" in data else data.get("downlink")),
        effective_type=str(data.get("effectiveType") or data.get("networkType") or "")[:40] or None,
        save_data=bool(data.get("saveData")) if "saveData" in data else None,
        online=bool(data.get("online")) if "online" in data else None,
        ice_state=str(data.get("iceState") or "")[:80] or None,
        room_state=str(data.get("roomState") or "")[:80] or None,
        selected_region=str(data.get("selectedRegion") or (participant.device_info or {}).get("selectedRegion") or "")[:40] or None,
        raw_json=data,
    )
    participant.last_quality_report = data
    if diagnostic.effective_type:
        participant.network_type = diagnostic.effective_type
    db.session.add(diagnostic)
    db.session.flush()
    return diagnostic


@bp.get("/network/ice-servers")
def get_ice_servers():
    response = jsonify({"iceServers": ice_servers()})
    response.headers["Cache-Control"] = "public, max-age=60"
    return response


@bp.get("/network/regions")
def get_regions():
    regions = MediaRegion.query.filter_by(enabled=True).order_by(MediaRegion.priority.asc(), MediaRegion.name.asc()).all()
    response = jsonify({"items": [region.to_dict() for region in regions], "total": len(regions)})
    response.headers["Cache-Control"] = "public, max-age=60"
    return response


@bp.post("/meetings/invitations/<token>/network-diagnostics")
def participant_network_diagnostics(token: str):
    meeting, participant, err = invitation_participant(token)
    if err:
        return err
    data = request.get_json(silent=True) or {}
    if not isinstance(data, dict):
        return error("Diagnostic payload must be an object", 400, "validation_error")
    try:
        diagnostic = create_diagnostic(meeting, participant, data)
    except (TypeError, ValueError) as exc:
        return error(str(exc), 400, "validation_error")
    db.session.commit()
    return jsonify({"diagnostic": diagnostic.to_dict(), "participant": participant.to_dict()})


@bp.get("/meetings/invitations/<token>/network-diagnostics")
def participant_network_history(token: str):
    meeting, participant, err = invitation_participant(token)
    if err:
        return err
    query = NetworkDiagnostic.query.filter_by(meeting_id=meeting.id, participant_id=participant.id).order_by(NetworkDiagnostic.created_at.desc())
    pagination = paginate(query, default_per_page=20, max_per_page=100)
    return jsonify({"items": [d.to_dict() for d in pagination.items], "total": pagination.total})


@bp.get("/admin/network/regions")
@require_admin(permission="security.manage")
def admin_regions():
    regions = MediaRegion.query.order_by(MediaRegion.priority.asc(), MediaRegion.name.asc()).all()
    db.session.commit()
    return jsonify({"items": [region.to_dict() for region in regions], "total": len(regions), "iceServers": ice_servers()})


@bp.post("/admin/network/regions")
@require_admin(permission="security.manage")
def create_region():
    data = request.get_json(silent=True) or {}
    code = str(data.get("code") or "").strip().lower()
    name = str(data.get("name") or code).strip()
    livekit_url = str(data.get("livekitUrl") or "").strip()
    if not code or not livekit_url:
        return error("code and livekitUrl are required", 400, "validation_error")
    if MediaRegion.query.filter_by(code=code).first():
        return error("Region code already exists", 409, "region_exists")
    region = MediaRegion(code=code[:40], name=name[:120], livekit_url=livekit_url[:300], turn_url=(str(data.get("turnUrl") or "").strip()[:300] or None), priority=int(data.get("priority") or 100), enabled=bool(data.get("enabled", True)))
    db.session.add(region)
    audit("network.region_created", actor=g.current_admin, session=g.current_session, entity_type="media_region", entity_id=region.id)
    db.session.commit()
    return jsonify({"region": region.to_dict()}), 201


@bp.patch("/admin/network/regions/<region_id>")
@require_admin(permission="security.manage")
def update_region(region_id: str):
    region = db.session.get(MediaRegion, region_id)
    if not region:
        return error("Region not found", 404, "region_not_found")
    data = request.get_json(silent=True) or {}
    if "name" in data:
        region.name = str(data["name"]).strip()[:120]
    if "livekitUrl" in data:
        url = str(data["livekitUrl"]).strip()
        if not url:
            return error("livekitUrl cannot be empty", 400, "validation_error")
        region.livekit_url = url[:300]
    if "turnUrl" in data:
        region.turn_url = str(data.get("turnUrl") or "").strip()[:300] or None
    if "priority" in data:
        region.priority = int(data["priority"])
    if "enabled" in data:
        region.enabled = bool(data["enabled"])
    db.session.commit()
    return jsonify({"region": region.to_dict()})


@bp.delete("/admin/network/regions/<region_id>")
@require_admin(permission="security.manage")
def delete_region(region_id: str):
    region = db.session.get(MediaRegion, region_id)
    if not region:
        return error("Region not found", 404, "region_not_found")
    db.session.delete(region)
    db.session.commit()
    return jsonify({"message": "Region deleted"})


@bp.get("/admin/network/diagnostics")
@require_admin(permission="security.manage")
def admin_diagnostics():
    query = NetworkDiagnostic.query.join(Meeting).filter(Meeting.admin_id == g.current_admin.id)
    meeting_id = request.args.get("meetingId")
    participant_id = request.args.get("participantId")
    if meeting_id:
        query = query.filter(NetworkDiagnostic.meeting_id == meeting_id)
    if participant_id:
        query = query.filter(NetworkDiagnostic.participant_id == participant_id)
    pagination = paginate(query.order_by(NetworkDiagnostic.created_at.desc()), default_per_page=50, max_per_page=200)
    db.session.commit()
    return jsonify({"items": [d.to_dict() for d in pagination.items], "total": pagination.total})


@bp.get("/admin/network/summary")
@require_admin(permission="security.manage")
def admin_network_summary():
    diagnostics = NetworkDiagnostic.query.join(Meeting).filter(Meeting.admin_id == g.current_admin.id).all()
    qualities = Counter(d.quality or "unknown" for d in diagnostics)
    avg_rtt = sum(d.rtt_ms or 0 for d in diagnostics) / len(diagnostics) if diagnostics else 0
    avg_packet_loss = sum(d.packet_loss or 0 for d in diagnostics) / len(diagnostics) if diagnostics else 0
    regions = Counter(d.selected_region or "default" for d in diagnostics)
    db.session.commit()
    return jsonify({"totalReports": len(diagnostics), "qualities": dict(qualities), "averageRttMs": round(avg_rtt, 2), "averagePacketLoss": round(avg_packet_loss, 4), "regions": dict(regions), "iceServers": ice_servers()})


@bp.get("/admin/network/diagnostics.csv")
@require_admin(permission="security.manage")
def admin_diagnostics_csv():
    diagnostics = NetworkDiagnostic.query.join(Meeting).filter(Meeting.admin_id == g.current_admin.id).order_by(NetworkDiagnostic.created_at.desc()).limit(5000).all()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["created_at", "meeting_id", "participant", "quality", "rtt_ms", "jitter_ms", "packet_loss", "downlink_mbps", "effective_type", "ice_state", "room_state", "region"])
    for d in diagnostics:
        writer.writerow([d.created_at.isoformat(), d.meeting.meeting_id if d.meeting else d.meeting_id, d.participant.display_name if d.participant else d.participant_id, d.quality, d.rtt_ms, d.jitter_ms, d.packet_loss, d.downlink_mbps, d.effective_type, d.ice_state, d.room_state, d.selected_region])
    db.session.commit()
    return Response(output.getvalue(), mimetype="text/csv", headers={"Content-Disposition": "attachment; filename=network-diagnostics.csv"})
