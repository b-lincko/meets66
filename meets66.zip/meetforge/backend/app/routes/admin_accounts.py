from __future__ import annotations

from datetime import datetime, timezone

from flask import Blueprint, g, jsonify, request

from ..decorators import error, require_admin
from ..extensions import db
from ..models import AdminAccount, AdminSession, utcnow
from ..permissions import ALL_PERMISSIONS, VALID_ADMIN_ROLES, effective_permissions
from ..security import audit, normalize_email, revoke_session, validate_password_strength

bp = Blueprint("admin_accounts", __name__)


def require_super_admin():
    if g.current_admin.role != "super_admin":
        return error("Super admin role required", 403, "super_admin_required")
    return None


def sanitize_permissions(values) -> list[str] | None:
    if values is None:
        return None
    if not isinstance(values, list):
        raise ValueError("permissions must be a list")
    invalid = [item for item in values if item not in ALL_PERMISSIONS]
    if invalid:
        raise ValueError(f"Invalid permissions: {', '.join(invalid)}")
    return sorted(set(values))


@bp.get("/admins")
@require_admin(permission="admins.manage")
def list_admins():
    guard = require_super_admin()
    if guard:
        return guard
    admins = AdminAccount.query.order_by(AdminAccount.created_at.desc()).all()
    db.session.commit()
    return jsonify({"items": [{**admin.to_dict(), "effectivePermissions": effective_permissions(admin)} for admin in admins], "total": len(admins)})


@bp.post("/admins")
@require_admin(permission="admins.manage")
def create_admin():
    guard = require_super_admin()
    if guard:
        return guard
    data = request.get_json(silent=True) or {}
    try:
        email = normalize_email(data.get("email", ""))
        password = str(data.get("password", ""))
        validate_password_strength(password)
        role = str(data.get("role") or "admin")
        if role not in VALID_ADMIN_ROLES:
            return error("Invalid admin role", 400, "invalid_role")
        permissions = sanitize_permissions(data.get("permissions"))
    except ValueError as exc:
        return error(str(exc), 400, "validation_error")
    if AdminAccount.query.filter_by(email=email).first():
        return error("Admin email already exists", 409, "admin_exists")
    admin = AdminAccount(email=email, display_name=(str(data.get("displayName") or email).strip()[:160]), role=role, permissions_json=permissions, status="active", must_change_password=True)
    admin.set_password(password)
    db.session.add(admin)
    db.session.flush()
    audit("admin.created", actor=g.current_admin, session=g.current_session, entity_type="admin", entity_id=admin.id, metadata={"role": role})
    db.session.commit()
    return jsonify({"admin": {**admin.to_dict(), "effectivePermissions": effective_permissions(admin)}}), 201


@bp.patch("/admins/<admin_id>")
@require_admin(permission="admins.manage")
def update_admin(admin_id: str):
    guard = require_super_admin()
    if guard:
        return guard
    admin = db.session.get(AdminAccount, admin_id)
    if not admin:
        return error("Admin not found", 404, "admin_not_found")
    data = request.get_json(silent=True) or {}
    try:
        if "displayName" in data:
            admin.display_name = str(data["displayName"]).strip()[:160]
        if "role" in data:
            role = str(data["role"])
            if role not in VALID_ADMIN_ROLES:
                return error("Invalid admin role", 400, "invalid_role")
            if admin.id == g.current_admin.id and role != "super_admin":
                return error("Cannot remove your own super admin role", 400, "self_role_downgrade")
            admin.role = role
        if "permissions" in data:
            admin.permissions_json = sanitize_permissions(data.get("permissions"))
        if "status" in data:
            status = str(data["status"])
            if status not in {"active", "disabled"}:
                return error("status must be active or disabled", 400, "validation_error")
            if admin.id == g.current_admin.id and status != "active":
                return error("Cannot disable your own account", 400, "self_disable")
            admin.status = status
            admin.disabled_at = utcnow() if status == "disabled" else None
            if status == "disabled":
                for session in AdminSession.query.filter_by(admin_id=admin.id, revoked_at=None).all():
                    revoke_session(session, "admin_disabled")
    except ValueError as exc:
        return error(str(exc), 400, "validation_error")
    audit("admin.updated", actor=g.current_admin, session=g.current_session, entity_type="admin", entity_id=admin.id)
    db.session.commit()
    return jsonify({"admin": {**admin.to_dict(), "effectivePermissions": effective_permissions(admin)}})


@bp.post("/admins/<admin_id>/reset-password")
@require_admin(permission="admins.manage")
def reset_admin_password(admin_id: str):
    guard = require_super_admin()
    if guard:
        return guard
    admin = db.session.get(AdminAccount, admin_id)
    if not admin:
        return error("Admin not found", 404, "admin_not_found")
    password = str((request.get_json(silent=True) or {}).get("password") or "")
    try:
        validate_password_strength(password)
    except ValueError as exc:
        return error(str(exc), 400, "validation_error")
    admin.set_password(password)
    admin.must_change_password = True
    for session in AdminSession.query.filter_by(admin_id=admin.id, revoked_at=None).all():
        revoke_session(session, "password_reset")
    audit("admin.password_reset", actor=g.current_admin, session=g.current_session, entity_type="admin", entity_id=admin.id)
    db.session.commit()
    return jsonify({"admin": {**admin.to_dict(), "effectivePermissions": effective_permissions(admin)}})


@bp.delete("/admins/<admin_id>")
@require_admin(permission="admins.manage")
def delete_admin(admin_id: str):
    guard = require_super_admin()
    if guard:
        return guard
    admin = db.session.get(AdminAccount, admin_id)
    if not admin:
        return error("Admin not found", 404, "admin_not_found")
    if admin.id == g.current_admin.id:
        return error("Cannot delete your own account", 400, "self_delete")
    admin.status = "disabled"
    admin.disabled_at = utcnow()
    for session in AdminSession.query.filter_by(admin_id=admin.id, revoked_at=None).all():
        revoke_session(session, "admin_deleted")
    audit("admin.deleted", actor=g.current_admin, session=g.current_session, entity_type="admin", entity_id=admin.id)
    db.session.commit()
    return jsonify({"admin": {**admin.to_dict(), "effectivePermissions": effective_permissions(admin)}})


@bp.get("/admins/<admin_id>/activity")
@require_admin(permission="admins.manage")
def admin_activity(admin_id: str):
    guard = require_super_admin()
    if guard:
        return guard
    admin = db.session.get(AdminAccount, admin_id)
    if not admin:
        return error("Admin not found", 404, "admin_not_found")
    logs = admin_logs = admin.sessions
    from ..models import AuditLog
    audit_logs = AuditLog.query.filter_by(actor_admin_id=admin.id).order_by(AuditLog.created_at.desc()).limit(100).all()
    db.session.commit()
    return jsonify({"admin": {**admin.to_dict(), "effectivePermissions": effective_permissions(admin)}, "sessions": [s.to_dict() for s in admin.sessions], "auditLogs": [log.to_dict() for log in audit_logs]})
