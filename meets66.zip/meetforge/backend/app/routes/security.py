from __future__ import annotations

from datetime import datetime, timezone

from flask import Blueprint, g, jsonify, request

from ..decorators import error, require_admin
from ..extensions import db
from ..models import AdminDevice, AdminSession, AppSetting, IPBlock, utcnow
from ..security import audit, aware, client_ip, revoke_session

bp = Blueprint("security", __name__)


def parse_expiry(value: str | None):
    if not value:
        return None
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


def e2ee_setting() -> AppSetting:
    setting = db.session.get(AppSetting, "e2ee")
    if not setting:
        setting = AppSetting(key="e2ee", value={"enabled": False, "requirePassphrase": False, "mode": "off"})
        db.session.add(setting)
        db.session.flush()
    return setting


@bp.get("/ip-blocks")
@require_admin(permission="security.manage")
def list_ip_blocks():
    blocks = IPBlock.query.order_by(IPBlock.created_at.desc()).all()
    db.session.commit()
    return jsonify({"items": [block.to_dict() for block in blocks], "total": len(blocks)})


@bp.post("/ip-blocks")
@require_admin(permission="security.manage")
def create_ip_block():
    data = request.get_json(silent=True) or {}
    ip_address = str(data.get("ipAddress") or "").strip()
    if not ip_address:
        return error("ipAddress is required", 400, "validation_error")
    if ip_address == client_ip() and not data.get("force"):
        return error("Refusing to block the current admin IP without force=true", 400, "self_block_prevented")
    existing = IPBlock.query.filter_by(ip_address=ip_address).first()
    if existing and existing.active:
        return error("IP address is already blocked", 409, "ip_block_exists")
    block = existing or IPBlock(ip_address=ip_address)
    block.reason = str(data.get("reason") or "").strip()[:255] or None
    block.created_by_admin_id = g.current_admin.id
    block.expires_at = parse_expiry(data.get("expiresAt"))
    block.revoked_at = None
    db.session.add(block)
    audit("security.ip_block_created", actor=g.current_admin, session=g.current_session, entity_type="ip_block", entity_id=block.id, metadata={"ipAddress": ip_address})
    db.session.commit()
    return jsonify({"ipBlock": block.to_dict()}), 201


@bp.delete("/ip-blocks/<block_id>")
@require_admin(permission="security.manage")
def revoke_ip_block(block_id: str):
    block = db.session.get(IPBlock, block_id)
    if not block:
        return error("IP block not found", 404, "ip_block_not_found")
    block.revoked_at = utcnow()
    audit("security.ip_block_revoked", actor=g.current_admin, session=g.current_session, entity_type="ip_block", entity_id=block.id)
    db.session.commit()
    return jsonify({"ipBlock": block.to_dict()})


@bp.get("/devices")
@require_admin(permission="security.manage")
def list_devices():
    devices = AdminDevice.query.filter_by(admin_id=g.current_admin.id).order_by(AdminDevice.last_seen_at.desc()).all()
    db.session.commit()
    return jsonify({"items": [device.to_dict() for device in devices], "total": len(devices)})


@bp.post("/devices/<device_id>/trust")
@require_admin(permission="security.manage")
def trust_device(device_id: str):
    device = AdminDevice.query.filter_by(id=device_id, admin_id=g.current_admin.id).first()
    if not device:
        return error("Device not found", 404, "device_not_found")
    device.trusted = True
    audit("security.device_trusted", actor=g.current_admin, session=g.current_session, entity_type="admin_device", entity_id=device.id)
    db.session.commit()
    return jsonify({"device": device.to_dict()})


@bp.post("/devices/<device_id>/revoke")
@require_admin(permission="security.manage")
def revoke_device(device_id: str):
    device = AdminDevice.query.filter_by(id=device_id, admin_id=g.current_admin.id).first()
    if not device:
        return error("Device not found", 404, "device_not_found")
    if g.current_session.device_id == device.id:
        return error("Use logout to revoke the current device session", 400, "current_device")
    device.revoked_at = utcnow()
    for session in AdminSession.query.filter_by(device_id=device.id, revoked_at=None).all():
        revoke_session(session, "device_revoked")
    audit("security.device_revoked", actor=g.current_admin, session=g.current_session, entity_type="admin_device", entity_id=device.id)
    db.session.commit()
    return jsonify({"device": device.to_dict()})


@bp.get("/e2ee")
@require_admin(permission="security.manage")
def get_e2ee():
    setting = e2ee_setting()
    db.session.commit()
    return jsonify({"e2ee": setting.value})


@bp.patch("/e2ee")
@require_admin(permission="security.manage")
def update_e2ee():
    data = request.get_json(silent=True) or {}
    enabled = bool(data.get("enabled", False))
    require_passphrase = bool(data.get("requirePassphrase", False))
    mode = str(data.get("mode") or ("optional" if enabled else "off"))
    if mode not in {"off", "optional", "required"}:
        return error("mode must be off, optional, or required", 400, "validation_error")
    setting = e2ee_setting()
    setting.value = {"enabled": enabled, "requirePassphrase": require_passphrase, "mode": mode}
    audit("security.e2ee_updated", actor=g.current_admin, session=g.current_session, entity_type="app_setting", entity_id="e2ee", metadata=setting.value)
    db.session.commit()
    return jsonify({"e2ee": setting.value})


@bp.get("/public/e2ee")
def public_e2ee():
    setting = e2ee_setting()
    db.session.commit()
    value = setting.value or {}
    return jsonify({"e2ee": {"enabled": bool(value.get("enabled")), "mode": value.get("mode", "off"), "requirePassphrase": bool(value.get("requirePassphrase"))}})
