from __future__ import annotations

from flask import Blueprint, g, jsonify, request

from ..decorators import error, require_admin
from ..extensions import db
from ..models import AppSetting
from ..security import audit

bp = Blueprint("settings", __name__)

SETTING_DEFAULTS = {
    "user_management": {"registrationEnabled": False, "emailVerificationRequired": False, "adminApprovalRequired": True, "defaultUserRole": "guest"},
    "meeting_settings": {"maximumParticipants": 100, "defaultDurationMinutes": 60, "allowRecording": True, "allowScreenSharing": True, "allowWhiteboard": True, "allowFileSharing": True, "allowChat": True, "waitingRoomEnabled": True},
    "security_settings": {"passwordMinLength": 10, "sessionTimeoutMinutes": 120, "loginAttemptsLimit": 5, "ipRestrictionsEnabled": True, "deviceManagementEnabled": True, "auditLoggingEnabled": True},
    "storage_settings": {"recordingStorageLocation": "database", "maximumStorageGb": 100, "recordingRetentionDays": 365, "automaticCleanupEnabled": False},
    "email_settings": {"smtpHost": "", "smtpPort": 587, "smtpUseTls": True, "smtpUsername": "", "smtpPassword": "", "smtpFrom": "", "meetingInvitationsEnabled": False, "notificationsEnabled": False},
    "branding": {"brandName": "Defensiq Meet", "logoUrl": "", "primaryColor": "#1f68eb"},
}


def ensure_settings():
    for key, value in SETTING_DEFAULTS.items():
        if not db.session.get(AppSetting, key):
            db.session.add(AppSetting(key=key, value=value))
    db.session.flush()


def validate_setting(key: str, value: dict):
    if key not in SETTING_DEFAULTS:
        raise ValueError("Unknown settings category")
    if not isinstance(value, dict):
        raise ValueError("Settings value must be an object")
    merged = {**SETTING_DEFAULTS[key], **value}
    if key == "user_management":
        if merged["defaultUserRole"] not in {"guest", "participant", "moderator"}:
            raise ValueError("Invalid default user role")
    if key == "meeting_settings":
        if int(merged["maximumParticipants"]) < 1 or int(merged["maximumParticipants"]) > 10000:
            raise ValueError("maximumParticipants must be 1-10000")
        if int(merged["defaultDurationMinutes"]) < 5 or int(merged["defaultDurationMinutes"]) > 1440:
            raise ValueError("defaultDurationMinutes must be 5-1440")
    if key == "security_settings":
        if int(merged["passwordMinLength"]) < 10:
            raise ValueError("passwordMinLength must be at least 10")
        if int(merged["sessionTimeoutMinutes"]) < 5:
            raise ValueError("sessionTimeoutMinutes must be at least 5")
        if int(merged["loginAttemptsLimit"]) < 1:
            raise ValueError("loginAttemptsLimit must be at least 1")
    if key == "storage_settings":
        if int(merged["maximumStorageGb"]) < 1:
            raise ValueError("maximumStorageGb must be at least 1")
        if int(merged["recordingRetentionDays"]) < 1:
            raise ValueError("recordingRetentionDays must be at least 1")
    if key == "email_settings":
        if int(merged["smtpPort"]) < 1 or int(merged["smtpPort"]) > 65535:
            raise ValueError("smtpPort must be valid")
    return merged


@bp.get("/settings")
@require_admin(permission="settings.manage")
def list_settings():
    ensure_settings()
    rows = AppSetting.query.order_by(AppSetting.key.asc()).all()
    db.session.commit()
    return jsonify({"settings": {row.key: row.value for row in rows}})


@bp.patch("/settings/<key>")
@require_admin(permission="settings.manage")
def update_setting(key: str):
    ensure_settings()
    setting = db.session.get(AppSetting, key)
    if not setting:
        return error("Settings category not found", 404, "settings_not_found")
    try:
        setting.value = validate_setting(key, request.get_json(silent=True) or {})
    except ValueError as exc:
        return error(str(exc), 400, "validation_error")
    audit("settings.updated", actor=g.current_admin, session=g.current_session, entity_type="app_setting", entity_id=key)
    db.session.commit()
    return jsonify({"key": key, "value": setting.value})
