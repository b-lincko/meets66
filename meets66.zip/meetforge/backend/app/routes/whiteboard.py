from __future__ import annotations

import base64
import io
from typing import Any

from flask import Blueprint, Response, g, jsonify, request
from PIL import Image, ImageDraw, ImageFont
from reportlab.lib.utils import ImageReader
from reportlab.pdfgen import canvas

from ..decorators import error, require_admin
from ..extensions import db, socketio
from ..models import Meeting, MeetingInvitation, MeetingParticipant, WhiteboardElement, utcnow
from ..security import audit, decode_participant_token, token_hash

bp = Blueprint("whiteboard", __name__)

CANVAS_WIDTH = 1280
CANVAS_HEIGHT = 720
ALLOWED_TYPES = {"pen", "highlighter", "line", "rect", "ellipse", "text", "sticky", "image", "flow_rect", "flow_diamond", "uml_class", "mind_node"}


def meeting_by_id(identifier: str) -> Meeting | None:
    return Meeting.query.filter((Meeting.id == identifier) | (Meeting.meeting_id == identifier)).first()


def admin_meeting(identifier: str):
    meeting = meeting_by_id(identifier)
    if not meeting or meeting.admin_id != g.current_admin.id:
        return None, error("Meeting not found", 404, "meeting_not_found")
    return meeting, None


def participant_from_bearer(meeting: Meeting) -> MeetingParticipant | None:
    header = request.headers.get("Authorization", "")
    if not header.startswith("Bearer "):
        return None
    raw = header.removeprefix("Bearer ").strip()
    try:
        claims = decode_participant_token(raw)
    except Exception:
        return None
    participant = db.session.get(MeetingParticipant, claims["sub"])
    if not participant or participant.meeting_id != meeting.id or participant.participant_token_hash != token_hash(raw) or participant.status != "admitted":
        return None
    return participant


def participant_meeting(token: str):
    invitation = MeetingInvitation.query.filter_by(token=token).first()
    if not invitation:
        return None, None, error("Invitation link not found", 404, "invitation_not_found")
    meeting = invitation.meeting
    participant = participant_from_bearer(meeting)
    if not participant:
        return meeting, None, error("Invalid participant session", 401, "invalid_participant_session")
    device_info = participant.device_info if isinstance(participant.device_info, dict) else {}
    controls = device_info.get("hostControls") if isinstance(device_info, dict) else {}
    controls = controls if isinstance(controls, dict) else {}
    whiteboard_granted = bool(controls.get("whiteboardGranted"))
    whiteboard_revoked = bool(controls.get("whiteboardRevoked"))
    if participant.role == "participant" and (whiteboard_revoked or (not meeting.allow_whiteboard and not whiteboard_granted)):
        return meeting, participant, error("Whiteboard is disabled by host", 403, "whiteboard_disabled")
    return meeting, participant, None


def validate_payload(element_type: str, payload: dict[str, Any]) -> dict[str, Any]:
    if element_type not in ALLOWED_TYPES:
        raise ValueError("Unsupported whiteboard element type")
    if not isinstance(payload, dict):
        raise ValueError("payload must be an object")
    clean = dict(payload)
    if element_type in {"pen", "highlighter"}:
        points = clean.get("points")
        if not isinstance(points, list) or len(points) < 1 or len(points) > 2000:
            raise ValueError("drawing elements require 1-2000 points")
    if element_type in {"line", "rect", "ellipse", "flow_rect", "flow_diamond", "uml_class", "mind_node"}:
        for key in ["x", "y", "w", "h"]:
            if key not in clean:
                raise ValueError(f"{element_type} requires {key}")
    if element_type in {"text", "sticky", "flow_rect", "flow_diamond", "uml_class", "mind_node"}:
        text = str(clean.get("text") or "").strip()
        if not text:
            raise ValueError(f"{element_type} requires text")
        clean["text"] = text[:2000]
    if element_type == "image":
        data_url = str(clean.get("dataUrl") or "")
        if not data_url.startswith("data:image/"):
            raise ValueError("image requires a data:image dataUrl")
        if len(data_url) > 1_500_000:
            raise ValueError("image is too large")
    return clean


def next_z(meeting: Meeting) -> int:
    last = WhiteboardElement.query.filter_by(meeting_id=meeting.id).order_by(WhiteboardElement.z_index.desc()).first()
    return (last.z_index + 1) if last else 1


def create_element(meeting: Meeting, *, element_type: str, payload: dict, actor_name: str, admin_id: str | None = None, participant_id: str | None = None):
    payload = validate_payload(element_type, payload)
    element = WhiteboardElement(meeting_id=meeting.id, actor_admin_id=admin_id, actor_participant_id=participant_id, actor_display_name=actor_name, element_type=element_type, payload=payload, z_index=next_z(meeting), active=True)
    db.session.add(element)
    db.session.flush()
    audit("whiteboard.element_created", actor=g.current_admin if admin_id else None, session=g.current_session if admin_id else None, entity_type="whiteboard_element", entity_id=element.id, metadata={"meetingId": meeting.meeting_id, "type": element_type})
    db.session.commit()
    socketio.emit("whiteboard:element", element.to_dict(), room=meeting.id)
    return element


def elements_for(meeting: Meeting, include_inactive: bool = False):
    query = WhiteboardElement.query.filter_by(meeting_id=meeting.id)
    if not include_inactive:
        query = query.filter_by(active=True)
    return query.order_by(WhiteboardElement.z_index.asc()).all()


def undo_for(meeting: Meeting, admin_id: str | None = None, participant_id: str | None = None):
    query = WhiteboardElement.query.filter_by(meeting_id=meeting.id, active=True)
    if admin_id:
        query = query.filter_by(actor_admin_id=admin_id)
    if participant_id:
        query = query.filter_by(actor_participant_id=participant_id)
    element = query.order_by(WhiteboardElement.created_at.desc()).first()
    if not element:
        return None
    element.active = False
    element.deleted_at = utcnow()
    db.session.commit()
    socketio.emit("whiteboard:element", element.to_dict(), room=meeting.id)
    return element


def redo_for(meeting: Meeting, admin_id: str | None = None, participant_id: str | None = None):
    query = WhiteboardElement.query.filter_by(meeting_id=meeting.id, active=False)
    if admin_id:
        query = query.filter_by(actor_admin_id=admin_id)
    if participant_id:
        query = query.filter_by(actor_participant_id=participant_id)
    element = query.order_by(WhiteboardElement.deleted_at.desc()).first()
    if not element:
        return None
    element.active = True
    element.deleted_at = None
    db.session.commit()
    socketio.emit("whiteboard:element", element.to_dict(), room=meeting.id)
    return element


def color(value: str | None, default=(14, 165, 233, 255)):
    if not value or not isinstance(value, str) or not value.startswith("#"):
        return default
    value = value.lstrip("#")
    try:
        if len(value) == 6:
            return tuple(int(value[i:i+2], 16) for i in (0, 2, 4)) + (255,)
    except Exception:
        return default
    return default


def draw_element(draw: ImageDraw.ImageDraw, image: Image.Image, element: WhiteboardElement):
    p = element.payload or {}
    c = color(p.get("color"), (14, 165, 233, 255))
    width = int(p.get("width") or 4)
    if element.element_type in {"pen", "highlighter"}:
        pts = [(float(pt.get("x", 0)), float(pt.get("y", 0))) for pt in p.get("points", []) if isinstance(pt, dict)]
        if len(pts) > 1:
            if element.element_type == "highlighter":
                c = (c[0], c[1], c[2], 90)
            draw.line(pts, fill=c, width=width, joint="curve")
    elif element.element_type == "line":
        draw.line([(p.get("x", 0), p.get("y", 0)), (p.get("x", 0) + p.get("w", 0), p.get("y", 0) + p.get("h", 0))], fill=c, width=width)
    elif element.element_type == "rect":
        draw.rectangle([p.get("x", 0), p.get("y", 0), p.get("x", 0) + p.get("w", 0), p.get("y", 0) + p.get("h", 0)], outline=c, width=width)
    elif element.element_type == "ellipse":
        draw.ellipse([p.get("x", 0), p.get("y", 0), p.get("x", 0) + p.get("w", 0), p.get("y", 0) + p.get("h", 0)], outline=c, width=width)
    elif element.element_type == "text":
        draw.text((p.get("x", 0), p.get("y", 0)), p.get("text", ""), fill=c)
    elif element.element_type == "sticky":
        x, y, w, h = p.get("x", 0), p.get("y", 0), p.get("w", 180), p.get("h", 120)
        fill = color(p.get("fill"), (254, 240, 138, 255))
        draw.rounded_rectangle([x, y, x + w, y + h], radius=12, fill=fill, outline=(180, 140, 0, 255), width=2)
        draw.text((x + 12, y + 12), p.get("text", ""), fill=(30, 41, 59, 255))
    elif element.element_type == "flow_rect":
        x, y, w, h = p.get("x", 0), p.get("y", 0), p.get("w", 180), p.get("h", 90)
        draw.rounded_rectangle([x, y, x + w, y + h], radius=10, outline=c, width=width)
        draw.text((x + 12, y + h / 2 - 8), p.get("text", ""), fill=c)
    elif element.element_type == "flow_diamond":
        x, y, w, h = p.get("x", 0), p.get("y", 0), p.get("w", 160), p.get("h", 100)
        draw.polygon([(x + w / 2, y), (x + w, y + h / 2), (x + w / 2, y + h), (x, y + h / 2)], outline=c)
        draw.text((x + 25, y + h / 2 - 8), p.get("text", ""), fill=c)
    elif element.element_type == "uml_class":
        x, y, w, h = p.get("x", 0), p.get("y", 0), p.get("w", 220), p.get("h", 150)
        draw.rectangle([x, y, x + w, y + h], outline=c, width=width)
        draw.line([x, y + 40, x + w, y + 40], fill=c, width=width)
        draw.line([x, y + 85, x + w, y + 85], fill=c, width=width)
        draw.text((x + 10, y + 14), p.get("text", "Class"), fill=c)
    elif element.element_type == "mind_node":
        x, y, w, h = p.get("x", 0), p.get("y", 0), p.get("w", 180), p.get("h", 80)
        draw.ellipse([x, y, x + w, y + h], outline=c, width=width)
        draw.text((x + 20, y + h / 2 - 8), p.get("text", "Idea"), fill=c)
    elif element.element_type == "image": 
        data_url = p.get("dataUrl", "")
        try:
            raw = base64.b64decode(data_url.split(",", 1)[1])
            pasted = Image.open(io.BytesIO(raw)).convert("RGBA")
            pasted.thumbnail((int(p.get("w", 320)), int(p.get("h", 240))))
            image.alpha_composite(pasted, (int(p.get("x", 0)), int(p.get("y", 0))))
        except Exception:
            return


def render_png(meeting: Meeting) -> bytes:
    image = Image.new("RGBA", (CANVAS_WIDTH, CANVAS_HEIGHT), (255, 255, 255, 255))
    draw = ImageDraw.Draw(image, "RGBA")
    for element in elements_for(meeting):
        draw_element(draw, image, element)
    output = io.BytesIO()
    image.convert("RGB").save(output, format="PNG")
    return output.getvalue()


def render_svg(meeting: Meeting) -> str:
    parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{CANVAS_WIDTH}" height="{CANVAS_HEIGHT}" viewBox="0 0 {CANVAS_WIDTH} {CANVAS_HEIGHT}">', '<rect width="100%" height="100%" fill="white"/>']
    for element in elements_for(meeting):
        p = element.payload or {}
        stroke = str(p.get("color") or "#0ea5e9")
        width = int(p.get("width") or 4)
        text = str(p.get("text") or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        if element.element_type in {"pen", "highlighter"}:
            pts = " ".join(f'{pt.get("x",0)},{pt.get("y",0)}' for pt in p.get("points", []) if isinstance(pt, dict))
            opacity = "0.35" if element.element_type == "highlighter" else "1"
            parts.append(f'<polyline points="{pts}" fill="none" stroke="{stroke}" stroke-width="{width}" stroke-linecap="round" stroke-linejoin="round" opacity="{opacity}"/>')
        elif element.element_type == "line":
            parts.append(f'<line x1="{p.get("x",0)}" y1="{p.get("y",0)}" x2="{p.get("x",0)+p.get("w",0)}" y2="{p.get("y",0)+p.get("h",0)}" stroke="{stroke}" stroke-width="{width}"/>')
        elif element.element_type in {"rect", "flow_rect", "uml_class"}:
            parts.append(f'<rect x="{p.get("x",0)}" y="{p.get("y",0)}" width="{p.get("w",180)}" height="{p.get("h",90)}" rx="10" fill="none" stroke="{stroke}" stroke-width="{width}"/>')
            if text: parts.append(f'<text x="{p.get("x",0)+12}" y="{p.get("y",0)+30}" fill="{stroke}" font-family="sans-serif" font-size="18">{text}</text>')
        elif element.element_type in {"ellipse", "mind_node"}:
            parts.append(f'<ellipse cx="{p.get("x",0)+p.get("w",180)/2}" cy="{p.get("y",0)+p.get("h",80)/2}" rx="{abs(p.get("w",180)/2)}" ry="{abs(p.get("h",80)/2)}" fill="none" stroke="{stroke}" stroke-width="{width}"/>')
            if text: parts.append(f'<text x="{p.get("x",0)+20}" y="{p.get("y",0)+p.get("h",80)/2}" fill="{stroke}" font-family="sans-serif" font-size="18">{text}</text>')
        elif element.element_type == "flow_diamond":
            x, y, w, h = p.get("x",0), p.get("y",0), p.get("w",160), p.get("h",100)
            parts.append(f'<polygon points="{x+w/2},{y} {x+w},{y+h/2} {x+w/2},{y+h} {x},{y+h/2}" fill="none" stroke="{stroke}" stroke-width="{width}"/>')
            if text: parts.append(f'<text x="{x+25}" y="{y+h/2}" fill="{stroke}" font-family="sans-serif" font-size="18">{text}</text>')
        elif element.element_type in {"text", "sticky"}:
            if element.element_type == "sticky": parts.append(f'<rect x="{p.get("x",0)}" y="{p.get("y",0)}" width="{p.get("w",180)}" height="{p.get("h",120)}" rx="12" fill="{p.get("fill", "#fef08a")}" stroke="#b48c00"/>')
            parts.append(f'<text x="{p.get("x",0)+12}" y="{p.get("y",0)+28}" fill="{stroke}" font-family="sans-serif" font-size="{p.get("size",24)}">{text}</text>')
    parts.append('</svg>')
    return "".join(parts)


@bp.get("/<identifier>/whiteboard/elements")
@require_admin(permission="meetings.manage")
def admin_list_elements(identifier: str):
    meeting, err = admin_meeting(identifier)
    if err:
        return err
    db.session.commit()
    return jsonify({"items": [e.to_dict() for e in elements_for(meeting)], "total": len(elements_for(meeting))})


def admin_meeting(identifier: str):
    meeting = Meeting.query.filter((Meeting.id == identifier) | (Meeting.meeting_id == identifier)).first()
    if not meeting or meeting.admin_id != g.current_admin.id:
        return None, error("Meeting not found", 404, "meeting_not_found")
    return meeting, None


@bp.post("/<identifier>/whiteboard/elements")
@require_admin(permission="meetings.manage")
def admin_create_element(identifier: str):
    meeting, err = admin_meeting(identifier)
    if err:
        return err
    data = request.get_json(silent=True) or {}
    try:
        element = create_element(meeting, element_type=str(data.get("elementType")), payload=data.get("payload") or {}, actor_name=g.current_admin.display_name, admin_id=g.current_admin.id)
    except ValueError as exc:
        return error(str(exc), 400, "validation_error")
    return jsonify({"element": element.to_dict()}), 201


@bp.post("/<identifier>/whiteboard/undo")
@require_admin(permission="meetings.manage")
def admin_undo(identifier: str):
    meeting, err = admin_meeting(identifier)
    if err:
        return err
    element = undo_for(meeting, admin_id=g.current_admin.id)
    return jsonify({"element": element.to_dict() if element else None})


@bp.post("/<identifier>/whiteboard/redo")
@require_admin(permission="meetings.manage")
def admin_redo(identifier: str):
    meeting, err = admin_meeting(identifier)
    if err:
        return err
    element = redo_for(meeting, admin_id=g.current_admin.id)
    return jsonify({"element": element.to_dict() if element else None})


@bp.get("/<identifier>/whiteboard/export.png")
@require_admin(permission="meetings.manage")
def admin_export_png(identifier: str):
    meeting, err = admin_meeting(identifier)
    if err:
        return err
    return Response(render_png(meeting), mimetype="image/png", headers={"Content-Disposition": f"attachment; filename={meeting.meeting_id}-whiteboard.png"})


@bp.get("/<identifier>/whiteboard/history")
@require_admin(permission="meetings.manage")
def admin_history(identifier: str):
    meeting, err = admin_meeting(identifier)
    if err:
        return err
    items = elements_for(meeting, include_inactive=True)
    db.session.commit()
    return jsonify({"items": [e.to_dict() for e in items], "total": len(items)})


@bp.get("/<identifier>/whiteboard/export.svg")
@require_admin(permission="meetings.manage")
def admin_export_svg(identifier: str):
    meeting, err = admin_meeting(identifier)
    if err:
        return err
    return Response(render_svg(meeting), mimetype="image/svg+xml", headers={"Content-Disposition": f"attachment; filename={meeting.meeting_id}-whiteboard.svg"})


@bp.get("/<identifier>/whiteboard/export.pdf")
@require_admin(permission="meetings.manage")
def admin_export_pdf(identifier: str):
    meeting, err = admin_meeting(identifier)
    if err:
        return err
    png = render_png(meeting)
    output = io.BytesIO()
    pdf = canvas.Canvas(output, pagesize=(CANVAS_WIDTH, CANVAS_HEIGHT))
    pdf.drawImage(ImageReader(io.BytesIO(png)), 0, 0, width=CANVAS_WIDTH, height=CANVAS_HEIGHT)
    pdf.save()
    return Response(output.getvalue(), mimetype="application/pdf", headers={"Content-Disposition": f"attachment; filename={meeting.meeting_id}-whiteboard.pdf"})


@bp.get("/invitations/<token>/whiteboard/elements")
def participant_list_elements(token: str):
    meeting, participant, err = participant_meeting(token)
    if err:
        return err
    db.session.commit()
    return jsonify({"items": [e.to_dict() for e in elements_for(meeting)], "total": len(elements_for(meeting))})


@bp.post("/invitations/<token>/whiteboard/elements")
def participant_create_element(token: str):
    meeting, participant, err = participant_meeting(token)
    if err:
        return err
    data = request.get_json(silent=True) or {}
    try:
        element = create_element(meeting, element_type=str(data.get("elementType")), payload=data.get("payload") or {}, actor_name=participant.display_name, participant_id=participant.id)
    except ValueError as exc:
        return error(str(exc), 400, "validation_error")
    return jsonify({"element": element.to_dict()}), 201


@bp.post("/invitations/<token>/whiteboard/undo")
def participant_undo(token: str):
    meeting, participant, err = participant_meeting(token)
    if err:
        return err
    element = undo_for(meeting, participant_id=participant.id)
    return jsonify({"element": element.to_dict() if element else None})


@bp.post("/invitations/<token>/whiteboard/redo")
def participant_redo(token: str):
    meeting, participant, err = participant_meeting(token)
    if err:
        return err
    element = redo_for(meeting, participant_id=participant.id)
    return jsonify({"element": element.to_dict() if element else None})
