from __future__ import annotations

import csv
import io
from collections import Counter
from datetime import timedelta

import psutil
from flask import Blueprint, Response, current_app, g, jsonify, request
from sqlalchemy import func, inspect, text

from ..decorators import error, paginate, require_admin
from ..extensions import db
from ..models import ApiKey, AdminSession, AuditLog, BreakoutAssignment, BreakoutRoom, ChatMessage, MediaRegion, Meeting, MeetingFile, MeetingParticipant, NetworkDiagnostic, Poll, PollVote, Question, Recording, RecordingAccessEvent, RecordingShare, WebhookDelivery, WebhookSubscription, WhiteboardElement, utcnow
from ..security import aware, audit

bp = Blueprint("admin", __name__)


def active_session_query():
    now = utcnow()
    return AdminSession.query.filter(AdminSession.revoked_at.is_(None), AdminSession.expires_at > now)


def attach_participant_counts(meetings: list[Meeting]) -> list[Meeting]:
    ids = [meeting.id for meeting in meetings]
    if not ids:
        return meetings
    counts = dict(db.session.query(MeetingParticipant.meeting_id, func.count(MeetingParticipant.id)).filter(MeetingParticipant.meeting_id.in_(ids)).group_by(MeetingParticipant.meeting_id).all())
    for meeting in meetings:
        setattr(meeting, "_participant_count_override", int(counts.get(meeting.id, 0)))
    return meetings


def meeting_duration_seconds(meeting: Meeting) -> int:
    start = aware(meeting.scheduled_start_at)
    end = aware(meeting.ended_at) or aware(meeting.scheduled_end_at)
    if not start or not end or end <= start:
        return 0
    return int((end - start).total_seconds())


def storage_usage_bytes() -> dict[str, int]:
    recording_bytes = db.session.query(func.coalesce(func.sum(Recording.size_bytes), 0)).scalar() or 0
    file_bytes = db.session.query(func.coalesce(func.sum(MeetingFile.size_bytes), 0)).scalar() or 0
    return {"recordings": int(recording_bytes), "files": int(file_bytes), "total": int(recording_bytes + file_bytes)}


def system_metrics() -> dict:
    vm = psutil.virtual_memory()
    disk = psutil.disk_usage("/")
    net = psutil.net_io_counters()
    return {
        "cpuPercent": psutil.cpu_percent(interval=None),
        "ram": {"total": vm.total, "available": vm.available, "used": vm.used, "percent": vm.percent},
        "disk": {"total": disk.total, "used": disk.used, "free": disk.free, "percent": disk.percent},
        "network": {"bytesSent": net.bytes_sent, "bytesRecv": net.bytes_recv, "packetsSent": net.packets_sent, "packetsRecv": net.packets_recv},
    }


def service_status() -> dict:
    database = "ok"
    try:
        db.session.execute(text("SELECT 1"))
    except Exception:
        database = "error"
    return {
        "api": "ok",
        "database": database,
        "livekit": "configured" if current_app.config.get("LIVEKIT_URL") else "not_configured",
        "redis": "configured" if current_app.config.get("RATELIMIT_STORAGE_URI", "").startswith("redis://") else "not_configured",
    }


def browser_from_user_agent(user_agent: str | None) -> str:
    ua = user_agent or ""
    if "Edg/" in ua:
        return "Edge"
    if "Chrome/" in ua:
        return "Chrome"
    if "Firefox/" in ua:
        return "Firefox"
    if "Safari/" in ua:
        return "Safari"
    return "Unknown"


def os_from_user_agent(user_agent: str | None) -> str:
    ua = user_agent or ""
    if "Windows" in ua:
        return "Windows"
    if "Mac OS X" in ua:
        return "macOS"
    if "Android" in ua:
        return "Android"
    if "iPhone" in ua or "iPad" in ua:
        return "iOS"
    if "Linux" in ua:
        return "Linux"
    return "Unknown"


@bp.get("/overview")
@require_admin(permission="analytics.view")
def overview():
    admin_id = g.current_admin.id
    meeting_rows = db.session.query(Meeting.status, func.count(Meeting.id)).filter(Meeting.admin_id == admin_id).group_by(Meeting.status).all()
    status_counts = {status: count for status, count in meeting_rows}
    recording_rows = db.session.query(Recording.status, func.count(Recording.id)).filter(Recording.admin_id == admin_id).group_by(Recording.status).all()
    recording_status_counts = {status: count for status, count in recording_rows}
    participant_rows = (
        db.session.query(MeetingParticipant.status, func.count(MeetingParticipant.id))
        .join(Meeting, MeetingParticipant.meeting_id == Meeting.id)
        .filter(Meeting.admin_id == admin_id)
        .group_by(MeetingParticipant.status)
        .all()
    )
    participant_counts = {status: count for status, count in participant_rows}
    duration_rows = Meeting.query.filter(Meeting.admin_id == admin_id, Meeting.status.in_(["completed", "running"])).with_entities(Meeting.scheduled_start_at, Meeting.scheduled_end_at, Meeting.ended_at).all()
    total_duration = 0
    for start_at, scheduled_end_at, ended_at in duration_rows:
        start = aware(start_at)
        end = aware(ended_at) or aware(scheduled_end_at)
        if start and end and end > start:
            total_duration += int((end - start).total_seconds())
    completed_count = int(status_counts.get("completed", 0) or 0)
    recent_meetings = attach_participant_counts(Meeting.query.filter_by(admin_id=admin_id).order_by(Meeting.created_at.desc()).limit(10).all())
    recent_recordings = Recording.query.filter_by(admin_id=admin_id).order_by(Recording.created_at.desc()).limit(10).all()
    auth_events = AuditLog.query.filter(AuditLog.action.in_(["auth.login", "auth.login_failed", "auth.logout", "auth.password_changed"])).order_by(AuditLog.created_at.desc()).limit(10).all()
    db.session.commit()
    return jsonify(
        {
            "meetings": {
                "total": int(sum(status_counts.values())),
                "scheduled": int(status_counts.get("scheduled", 0) or 0),
                "running": int(status_counts.get("running", 0) or 0),
                "completed": int(status_counts.get("completed", 0) or 0),
                "cancelled": int(status_counts.get("cancelled", 0) or 0),
                "averageDurationSeconds": int(total_duration / completed_count) if completed_count else 0,
            },
            "participants": {
                "total": int(sum(participant_counts.values())),
                "active": int(participant_counts.get("admitted", 0) or 0),
                "waiting": int(participant_counts.get("waiting", 0) or 0),
            },
            "adminSessions": {"active": active_session_query().count()},
            "recordings": {"total": int(sum(recording_status_counts.values())), "byStatus": dict(recording_status_counts), "failedJobs": int(recording_status_counts.get("failed", 0) or 0)},
            "storage": storage_usage_bytes(),
            "system": system_metrics(),
            "services": service_status(),
            "recentMeetings": [m.to_dict(include_private=True) for m in recent_meetings],
            "recentRecordings": [r.to_dict() for r in recent_recordings],
            "authEvents": [event.to_dict() for event in auth_events],
        }
    )


@bp.get("/meetings")
@require_admin(permission="meetings.manage")
def admin_meetings():
    query = Meeting.query.filter_by(admin_id=g.current_admin.id)
    q = request.args.get("q", "").strip()
    status = request.args.get("status", "").strip()
    if q:
        query = query.filter((Meeting.title.ilike(f"%{q}%")) | (Meeting.meeting_id.ilike(f"%{q}%")))
    if status:
        query = query.filter_by(status=status)
    pagination = paginate(query.order_by(Meeting.scheduled_start_at.desc(), Meeting.created_at.desc()), default_per_page=50, max_per_page=200)
    items = attach_participant_counts(list(pagination.items))
    db.session.commit()
    return jsonify({"items": [m.to_dict(include_private=True) for m in items], "total": pagination.total})


@bp.get("/meeting-history")
@require_admin(permission="analytics.view")
def meeting_history():
    query = Meeting.query.filter_by(admin_id=g.current_admin.id)
    q = request.args.get("q", "").strip()
    if q:
        query = query.filter((Meeting.title.ilike(f"%{q}%")) | (Meeting.meeting_id.ilike(f"%{q}%")))
    pagination = paginate(query.order_by(Meeting.scheduled_start_at.desc()), default_per_page=50, max_per_page=200)
    page_meetings = attach_participant_counts(list(pagination.items))
    items = []
    for meeting in page_meetings:
        data = meeting.to_dict(include_private=True)
        data["durationSeconds"] = meeting_duration_seconds(meeting)
        data["participantsJoined"] = MeetingParticipant.query.filter(MeetingParticipant.meeting_id == meeting.id, MeetingParticipant.joined_at.isnot(None)).count()
        data["recordingCount"] = Recording.query.filter_by(meeting_id=meeting.id).count()
        data["chatMessageCount"] = ChatMessage.query.filter_by(meeting_id=meeting.id).count()
        items.append(data)
    db.session.commit()
    return jsonify({"items": items, "total": pagination.total})


@bp.get("/recordings")
@require_admin(permission="recordings.manage")
def admin_recordings():
    query = Recording.query.filter_by(admin_id=g.current_admin.id)
    q = request.args.get("q", "").strip()
    status = request.args.get("status", "").strip()
    if q:
        query = query.filter(Recording.title.ilike(f"%{q}%"))
    if status:
        query = query.filter_by(status=status)
    pagination = paginate(query.order_by(Recording.created_at.desc()), default_per_page=50, max_per_page=200)
    db.session.commit()
    return jsonify({"items": [r.to_dict() for r in pagination.items], "total": pagination.total})


@bp.get("/analytics")
@require_admin(permission="analytics.view")
def analytics():
    now = utcnow().date()
    labels = [(now - timedelta(days=i)).isoformat() for i in reversed(range(14))]
    by_day = {label: {"meetings": 0, "participants": 0, "recordings": 0, "chatMessages": 0} for label in labels}
    meetings = Meeting.query.filter_by(admin_id=g.current_admin.id).all()
    meeting_ids = [m.id for m in meetings]
    for meeting in meetings:
        label = (aware(meeting.created_at) or utcnow()).date().isoformat()
        if label in by_day:
            by_day[label]["meetings"] += 1
    if meeting_ids:
        for participant in MeetingParticipant.query.filter(MeetingParticipant.meeting_id.in_(meeting_ids)).all():
            label = (aware(participant.created_at) or utcnow()).date().isoformat()
            if label in by_day:
                by_day[label]["participants"] += 1
        for recording in Recording.query.filter(Recording.meeting_id.in_(meeting_ids)).all():
            label = (aware(recording.created_at) or utcnow()).date().isoformat()
            if label in by_day:
                by_day[label]["recordings"] += 1
        for message in ChatMessage.query.filter(ChatMessage.meeting_id.in_(meeting_ids)).all():
            label = (aware(message.created_at) or utcnow()).date().isoformat()
            if label in by_day:
                by_day[label]["chatMessages"] += 1
    device_counter = Counter()
    browser_counter = Counter()
    os_counter = Counter()
    for participant in MeetingParticipant.query.join(Meeting).filter(Meeting.admin_id == g.current_admin.id).all():
        device = participant.device_info or {}
        browser_counter[device.get("browser") or browser_from_user_agent(participant.user_agent)] += 1
        os_counter[device.get("os") or os_from_user_agent(participant.user_agent)] += 1
        device_counter["cameraProvided" if device.get("camera") else "cameraUnknown"] += 1
    db.session.commit()
    return jsonify(
        {
            "labels": labels,
            "series": by_day,
            "browsers": dict(browser_counter),
            "operatingSystems": dict(os_counter),
            "devices": dict(device_counter),
            "storage": storage_usage_bytes(),
        }
    )


def csv_response(filename: str, rows: list[dict]) -> Response:
    output = io.StringIO()
    if rows:
        writer = csv.DictWriter(output, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    else:
        output.write("empty\n")
    return Response(output.getvalue(), mimetype="text/csv", headers={"Content-Disposition": f"attachment; filename={filename}"})


@bp.get("/exports/meetings.csv")
@require_admin(permission="analytics.view")
def export_meetings_csv():
    meetings = Meeting.query.filter_by(admin_id=g.current_admin.id).order_by(Meeting.scheduled_start_at.desc()).all()
    rows = [
        {
            "meeting_id": m.meeting_id,
            "title": m.title,
            "status": m.status,
            "scheduled_start_at": m.scheduled_start_at.isoformat() if m.scheduled_start_at else "",
            "scheduled_end_at": m.scheduled_end_at.isoformat() if m.scheduled_end_at else "",
            "participants": len(m.participants or []),
            "recordings": len(m.recordings or []),
        }
        for m in meetings
    ]
    audit("admin.export_meetings_csv", actor=g.current_admin, session=g.current_session, entity_type="report")
    db.session.commit()
    return csv_response("meetings.csv", rows)


@bp.get("/exports/recordings.csv")
@require_admin(permission="analytics.view")
def export_recordings_csv():
    recordings = Recording.query.filter_by(admin_id=g.current_admin.id).order_by(Recording.created_at.desc()).all()
    rows = [
        {
            "recording_id": r.id,
            "meeting_id": r.meeting.meeting_id if r.meeting else "",
            "title": r.title,
            "status": r.status,
            "duration_seconds": r.duration_seconds,
            "size_bytes": r.size_bytes,
            "created_at": r.created_at.isoformat() if r.created_at else "",
        }
        for r in recordings
    ]
    audit("admin.export_recordings_csv", actor=g.current_admin, session=g.current_session, entity_type="report")
    db.session.commit()
    return csv_response("recordings.csv", rows)


@bp.get("/exports/audit.csv")
@require_admin(permission="analytics.view")
def export_audit_csv():
    logs = AuditLog.query.order_by(AuditLog.created_at.desc()).limit(5000).all()
    rows = [
        {
            "created_at": log.created_at.isoformat() if log.created_at else "",
            "actor": log.actor.email if log.actor else "",
            "action": log.action,
            "entity_type": log.entity_type or "",
            "entity_id": log.entity_id or "",
            "ip_address": log.ip_address or "",
        }
        for log in logs
    ]
    audit("admin.export_audit_csv", actor=g.current_admin, session=g.current_session, entity_type="report")
    db.session.commit()
    return csv_response("audit.csv", rows)


@bp.get("/performance")
@require_admin(permission="analytics.view")
def performance_report():
    inspector = inspect(db.engine)
    models = [
        Meeting,
        MeetingParticipant,
        Recording,
        ChatMessage,
        MeetingFile,
        AuditLog,
        NetworkDiagnostic,
        WebhookDelivery,
        WebhookSubscription,
        ApiKey,
        WhiteboardElement,
        Poll,
        PollVote,
        Question,
        BreakoutRoom,
        BreakoutAssignment,
        RecordingShare,
        RecordingAccessEvent,
        MediaRegion,
    ]
    tables = {}
    for model in models:
        table = model.__tablename__
        try:
            count = db.session.query(func.count(model.id)).scalar() if hasattr(model, "id") else 0
            indexes = inspector.get_indexes(table) if table in inspector.get_table_names() else []
            tables[table] = {
                "rows": int(count or 0),
                "indexes": [{"name": idx.get("name"), "columns": idx.get("column_names", [])} for idx in indexes],
            }
        except Exception as exc:
            tables[table] = {"error": str(exc), "indexes": []}
    db.session.commit()
    return jsonify(
        {
            "database": {"dialect": db.engine.dialect.name, "tables": tables},
            "pagination": {"defaultPerPage": 20, "maxPerPage": 100, "adminMaxPerPage": 200},
            "system": system_metrics(),
            "cachePolicy": {"sensitiveApi": "no-store", "publicDocs": "public max-age=300", "networkConfig": "public max-age=60"},
        }
    )
