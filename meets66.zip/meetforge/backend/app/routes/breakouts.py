from __future__ import annotations

from datetime import timedelta

from flask import Blueprint, current_app, g, jsonify, request

from ..decorators import error, require_admin
from ..extensions import db, socketio
from ..livekit_service import create_room_token, livekit_public_url
from ..models import BreakoutAssignment, BreakoutRoom, Meeting, MeetingInvitation, MeetingParticipant, utcnow
from ..security import audit, decode_participant_token, token_hash
from .meetings import publish_sources

bp = Blueprint("breakouts", __name__)


def meeting_by_id(identifier: str) -> Meeting | None:
    return Meeting.query.filter((Meeting.id == identifier) | (Meeting.meeting_id == identifier)).first()


def participant_from_bearer(meeting: Meeting) -> MeetingParticipant | None:
    header = request.headers.get("Authorization", "")
    if not header.startswith("Bearer "):
        return None
    raw = header.removeprefix("Bearer ").strip()
    try:
        claims = decode_participant_token(raw)
    except Exception:
        return None
    participant = db.session.get(MeetingParticipant, claims["sub"])
    if not participant or participant.meeting_id != meeting.id or participant.participant_token_hash != token_hash(raw) or participant.status != "admitted":
        return None
    return participant


def admin_actor(identifier: str):
    meeting = meeting_by_id(identifier)
    if not meeting or meeting.admin_id != g.current_admin.id:
        return None, None, error("Meeting not found", 404, "meeting_not_found")
    return meeting, {"admin_id": g.current_admin.id, "participant": None, "name": g.current_admin.display_name, "can_manage": True}, None


def cohost_actor(token: str):
    invitation = MeetingInvitation.query.filter_by(token=token).first()
    if not invitation:
        return None, None, error("Invitation link not found", 404, "invitation_not_found")
    meeting = invitation.meeting
    participant = participant_from_bearer(meeting)
    if not participant or participant.role not in {"host", "cohost"}:
        return meeting, None, error("Co-host permissions required", 403, "cohost_required")
    return meeting, {"admin_id": None, "participant": participant, "name": participant.display_name, "can_manage": True}, None


def room_name(meeting: Meeting, name: str) -> str:
    safe = "".join(ch.lower() if ch.isalnum() else "-" for ch in name).strip("-")[:40] or "room"
    return f"{current_app.config['LIVEKIT_ROOM_PREFIX']}-{meeting.meeting_id}-bo-{safe}-{BreakoutRoom.query.filter_by(meeting_id=meeting.id).count() + 1}"


def room_payload(room: BreakoutRoom) -> dict:
    data = room.to_dict()
    data["activeCount"] = len([a for a in room.assignments if a.status == "active"])
    data["assignedCount"] = len([a for a in room.assignments if a.status in {"assigned", "active"}])
    return data


def list_payload(meeting: Meeting) -> dict:
    rooms = BreakoutRoom.query.filter_by(meeting_id=meeting.id).order_by(BreakoutRoom.created_at.asc()).all()
    participants = MeetingParticipant.query.filter_by(meeting_id=meeting.id).order_by(MeetingParticipant.created_at.asc()).all()
    return {"items": [room_payload(room) for room in rooms], "participants": [p.to_dict(include_private=True) for p in participants], "total": len(rooms)}


def participant_livekit(meeting: Meeting, room: BreakoutRoom, participant: MeetingParticipant) -> dict:
    return {
        "url": livekit_public_url(),
        "roomName": room.livekit_room_name,
        "token": create_room_token(identity=participant.id, name=participant.display_name, room=room.livekit_room_name, role=participant.role, sources=publish_sources(meeting, participant)),
    }


def main_room_livekit(meeting: Meeting, participant: MeetingParticipant) -> dict:
    return {
        "url": livekit_public_url(),
        "roomName": meeting.livekit_room_name,
        "token": create_room_token(identity=participant.id, name=participant.display_name, room=meeting.livekit_room_name, role=participant.role, sources=publish_sources(meeting, participant)),
    }


def upsert_assignment(meeting: Meeting, room: BreakoutRoom, participant: MeetingParticipant, actor: dict, activate: bool = False) -> BreakoutAssignment:
    if participant.meeting_id != meeting.id or participant.status != "admitted":
        raise ValueError("Only admitted participants in this meeting can be assigned")
    assignment = BreakoutAssignment.query.filter_by(meeting_id=meeting.id, participant_id=participant.id).first()
    if not assignment:
        assignment = BreakoutAssignment(meeting_id=meeting.id, participant_id=participant.id)
        db.session.add(assignment)
    assignment.room_id = room.id
    assignment.assigned_by_admin_id = actor.get("admin_id")
    assignment.assigned_by_participant_id = actor.get("participant").id if actor.get("participant") else None
    assignment.status = "active" if activate else "assigned"
    if activate:
        assignment.moved_at = utcnow()
        assignment.returned_at = None
    return assignment


def create_rooms_common(meeting: Meeting, actor: dict):
    data = request.get_json(silent=True) or {}
    names = data.get("names")
    count = int(data.get("count") or 0)
    timer_minutes = int(data.get("timerMinutes") or 0)
    if names and isinstance(names, list):
        room_names = [str(name).strip()[:160] for name in names if str(name).strip()]
    else:
        if count < 1 or count > 20:
            return error("count must be between 1 and 20", 400, "validation_error")
        room_names = [f"Breakout {i}" for i in range(1, count + 1)]
    if not room_names:
        return error("At least one room name is required", 400, "validation_error")
    timer_ends_at = utcnow() + timedelta(minutes=timer_minutes) if timer_minutes > 0 else None
    rooms = []
    for name in room_names:
        room = BreakoutRoom(meeting_id=meeting.id, name=name, livekit_room_name=room_name(meeting, name), status="open", timer_ends_at=timer_ends_at, created_by_admin_id=actor.get("admin_id"), created_by_participant_id=actor.get("participant").id if actor.get("participant") else None)
        db.session.add(room)
        rooms.append(room)
    audit("breakout.rooms_created", actor=g.current_admin if actor.get("admin_id") else None, session=g.current_session if actor.get("admin_id") else None, entity_type="meeting", entity_id=meeting.id, metadata={"count": len(rooms), "createdBy": actor.get("name")})
    db.session.commit()
    payload = list_payload(meeting)
    socketio.emit("breakout:updated", payload, room=meeting.id)
    return jsonify(payload), 201


def assign_common(meeting: Meeting, actor: dict, room_id: str, activate: bool):
    room = BreakoutRoom.query.filter_by(id=room_id, meeting_id=meeting.id).first()
    if not room or room.status != "open":
        return error("Open breakout room not found", 404, "breakout_room_not_found")
    ids = request.get_json(silent=True) or {}
    participant_ids = ids.get("participantIds") or ([ids.get("participantId")] if ids.get("participantId") else [])
    if not participant_ids:
        return error("participantIds is required", 400, "validation_error")
    assignments = []
    try:
        for participant_id in participant_ids:
            participant = MeetingParticipant.query.filter_by(id=participant_id, meeting_id=meeting.id).first()
            if not participant:
                raise ValueError("Participant not found")
            assignment = upsert_assignment(meeting, room, participant, actor, activate=activate)
            assignments.append(assignment)
    except ValueError as exc:
        db.session.rollback()
        return error(str(exc), 400, "validation_error")
    db.session.commit()
    for assignment in assignments:
        if activate:
            socketio.emit("breakout:moved", {"meetingId": meeting.id, "room": room_payload(room), "assignment": assignment.to_dict(), "livekit": participant_livekit(meeting, room, assignment.participant)}, room=assignment.participant_id)
    socketio.emit("breakout:updated", list_payload(meeting), room=meeting.id)
    return jsonify({"room": room_payload(room), "assignments": [a.to_dict() for a in assignments]})


def auto_assign_common(meeting: Meeting, actor: dict):
    rooms = BreakoutRoom.query.filter_by(meeting_id=meeting.id, status="open").order_by(BreakoutRoom.created_at.asc()).all()
    if not rooms:
        return error("Create breakout rooms before auto assignment", 409, "no_breakout_rooms")
    participants = MeetingParticipant.query.filter(MeetingParticipant.meeting_id == meeting.id, MeetingParticipant.status == "admitted", MeetingParticipant.role != "host").order_by(MeetingParticipant.created_at.asc()).all()
    if not participants:
        return error("No admitted non-host participants to assign", 409, "no_participants")
    assignments = []
    for idx, participant in enumerate(participants):
        assignments.append(upsert_assignment(meeting, rooms[idx % len(rooms)], participant, actor, activate=False))
    audit("breakout.auto_assigned", actor=g.current_admin if actor.get("admin_id") else None, session=g.current_session if actor.get("admin_id") else None, entity_type="meeting", entity_id=meeting.id, metadata={"participants": len(assignments)})
    db.session.commit()
    socketio.emit("breakout:updated", list_payload(meeting), room=meeting.id)
    return jsonify({**list_payload(meeting), "assignments": [a.to_dict() for a in assignments]})


def broadcast_common(meeting: Meeting, room_id: str):
    room = BreakoutRoom.query.filter_by(id=room_id, meeting_id=meeting.id).first()
    if not room:
        return error("Breakout room not found", 404, "breakout_room_not_found")
    message = str((request.get_json(silent=True) or {}).get("message") or "").strip()
    if not message:
        return error("message is required", 400, "validation_error")
    for assignment in BreakoutAssignment.query.filter_by(room_id=room.id, status="active").all():
        socketio.emit("breakout:broadcast", {"meetingId": meeting.id, "roomId": room.id, "message": message}, room=assignment.participant_id)
    socketio.emit("breakout:broadcast", {"meetingId": meeting.id, "roomId": room.id, "message": message}, room=meeting.id)
    return jsonify({"message": message, "room": room_payload(room)})


def close_room_common(meeting: Meeting, room_id: str):
    room = BreakoutRoom.query.filter_by(id=room_id, meeting_id=meeting.id).first()
    if not room:
        return error("Breakout room not found", 404, "breakout_room_not_found")
    room.status = "closed"
    room.closed_at = utcnow()
    assignments = BreakoutAssignment.query.filter_by(room_id=room.id).all()
    for assignment in assignments:
        assignment.status = "returned"
        assignment.returned_at = utcnow()
    db.session.commit()
    for assignment in assignments:
        socketio.emit("breakout:return", {"meetingId": meeting.id, "assignment": assignment.to_dict(), "livekit": main_room_livekit(meeting, assignment.participant)}, room=assignment.participant_id)
    socketio.emit("breakout:updated", list_payload(meeting), room=meeting.id)
    return jsonify({"room": room_payload(room), "assignments": [a.to_dict() for a in assignments]})


def return_all_common(meeting: Meeting):
    assignments = BreakoutAssignment.query.filter(BreakoutAssignment.meeting_id == meeting.id, BreakoutAssignment.status.in_(["assigned", "active"])).all()
    for assignment in assignments:
        assignment.status = "returned"
        assignment.returned_at = utcnow()
    db.session.commit()
    for assignment in assignments:
        socketio.emit("breakout:return", {"meetingId": meeting.id, "assignment": assignment.to_dict(), "livekit": main_room_livekit(meeting, assignment.participant)}, room=assignment.participant_id)
    socketio.emit("breakout:updated", list_payload(meeting), room=meeting.id)
    return jsonify({**list_payload(meeting), "assignments": [a.to_dict() for a in assignments]})


@bp.get("/<identifier>/breakout-rooms")
@require_admin(permission="meetings.manage")
def admin_list(identifier: str):
    meeting, actor, err = admin_actor(identifier)
    if err:
        return err
    db.session.commit()
    return jsonify(list_payload(meeting))


@bp.post("/<identifier>/breakout-rooms")
@require_admin(permission="meetings.manage")
def admin_create(identifier: str):
    meeting, actor, err = admin_actor(identifier)
    if err:
        return err
    return create_rooms_common(meeting, actor)


@bp.post("/<identifier>/breakout-rooms/auto-assign")
@require_admin(permission="meetings.manage")
def admin_auto(identifier: str):
    meeting, actor, err = admin_actor(identifier)
    if err:
        return err
    return auto_assign_common(meeting, actor)


@bp.post("/<identifier>/breakout-rooms/return-all")
@require_admin(permission="meetings.manage")
def admin_return_all(identifier: str):
    meeting, actor, err = admin_actor(identifier)
    if err:
        return err
    return return_all_common(meeting)


@bp.post("/<identifier>/breakout-rooms/<room_id>/assign")
@require_admin(permission="meetings.manage")
def admin_assign(identifier: str, room_id: str):
    meeting, actor, err = admin_actor(identifier)
    if err:
        return err
    return assign_common(meeting, actor, room_id, activate=False)


@bp.post("/<identifier>/breakout-rooms/<room_id>/move")
@require_admin(permission="meetings.manage")
def admin_move(identifier: str, room_id: str):
    meeting, actor, err = admin_actor(identifier)
    if err:
        return err
    return assign_common(meeting, actor, room_id, activate=True)


@bp.post("/<identifier>/breakout-rooms/<room_id>/broadcast")
@require_admin(permission="meetings.manage")
def admin_broadcast(identifier: str, room_id: str):
    meeting, actor, err = admin_actor(identifier)
    if err:
        return err
    return broadcast_common(meeting, room_id)


@bp.post("/<identifier>/breakout-rooms/<room_id>/close")
@require_admin(permission="meetings.manage")
def admin_close(identifier: str, room_id: str):
    meeting, actor, err = admin_actor(identifier)
    if err:
        return err
    return close_room_common(meeting, room_id)


@bp.get("/invitations/<token>/breakout-rooms")
def cohost_list(token: str):
    meeting, actor, err = cohost_actor(token)
    if err:
        return err
    db.session.commit()
    return jsonify(list_payload(meeting))


@bp.post("/invitations/<token>/breakout-rooms")
def cohost_create(token: str):
    meeting, actor, err = cohost_actor(token)
    if err:
        return err
    return create_rooms_common(meeting, actor)


@bp.post("/invitations/<token>/breakout-rooms/auto-assign")
def cohost_auto(token: str):
    meeting, actor, err = cohost_actor(token)
    if err:
        return err
    return auto_assign_common(meeting, actor)


@bp.post("/invitations/<token>/breakout-rooms/return-all")
def cohost_return_all(token: str):
    meeting, actor, err = cohost_actor(token)
    if err:
        return err
    return return_all_common(meeting)


@bp.post("/invitations/<token>/breakout-rooms/<room_id>/assign")
def cohost_assign(token: str, room_id: str):
    meeting, actor, err = cohost_actor(token)
    if err:
        return err
    return assign_common(meeting, actor, room_id, activate=False)


@bp.post("/invitations/<token>/breakout-rooms/<room_id>/move")
def cohost_move(token: str, room_id: str):
    meeting, actor, err = cohost_actor(token)
    if err:
        return err
    return assign_common(meeting, actor, room_id, activate=True)


@bp.post("/invitations/<token>/breakout-rooms/<room_id>/broadcast")
def cohost_broadcast(token: str, room_id: str):
    meeting, actor, err = cohost_actor(token)
    if err:
        return err
    return broadcast_common(meeting, room_id)


@bp.post("/invitations/<token>/breakout-rooms/<room_id>/close")
def cohost_close(token: str, room_id: str):
    meeting, actor, err = cohost_actor(token)
    if err:
        return err
    return close_room_common(meeting, room_id)


@bp.get("/invitations/<token>/breakout-status")
def participant_status(token: str):
    invitation = MeetingInvitation.query.filter_by(token=token).first()
    if not invitation:
        return error("Invitation link not found", 404, "invitation_not_found")
    meeting = invitation.meeting
    participant = participant_from_bearer(meeting)
    if not participant:
        return error("Invalid participant session", 401, "invalid_participant_session")
    assignment = BreakoutAssignment.query.filter_by(meeting_id=meeting.id, participant_id=participant.id).first()
    response = {"assignment": assignment.to_dict() if assignment else None, "room": room_payload(assignment.room) if assignment else None}
    if assignment and assignment.status == "active":
        response["livekit"] = participant_livekit(meeting, assignment.room, participant)
    db.session.commit()
    return jsonify(response)
