from __future__ import annotations

import hashlib
import json
import os
import secrets
import shutil
import subprocess
import tempfile
from datetime import timedelta
from pathlib import Path
from urllib.parse import quote

import jwt
from flask import Blueprint, Response, current_app, g, jsonify, request
from werkzeug.security import check_password_hash, generate_password_hash

from ..decorators import error, paginate, require_admin
from ..extensions import db, socketio
from ..models import AuditLog, ChatMessage, Meeting, MeetingInvitation, MeetingParticipant, Poll, Recording, RecordingAccessEvent, RecordingShare, utcnow
from ..security import audit, aware, client_ip, decode_participant_token, token_hash, user_agent
from ..webhooks import dispatch_webhook

bp = Blueprint("recordings", __name__)


def meeting_by_id(identifier: str) -> Meeting | None:
    return Meeting.query.filter((Meeting.id == identifier) | (Meeting.meeting_id == identifier)).first()


def admin_meeting(identifier: str):
    meeting = meeting_by_id(identifier)
    if not meeting or meeting.admin_id != g.current_admin.id:
        return None, error("Meeting not found", 404, "meeting_not_found")
    return meeting, None


def admin_recording(recording_id: str):
    recording = Recording.query.filter_by(id=recording_id).first()
    if not recording or recording.admin_id != g.current_admin.id:
        return None, error("Recording not found", 404, "recording_not_found")
    return recording, None


def safe_filename(value: str) -> str:
    cleaned = "".join(ch if ch.isalnum() or ch in " ._-" else "_" for ch in value).strip()
    return (cleaned or "recording")[:180]


def transcode_webm_to_mp4(input_bytes: bytes) -> bytes:
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise RuntimeError("ffmpeg is not installed in the backend container")
    with tempfile.TemporaryDirectory() as tmp:
        src = Path(tmp) / "input.webm"
        dst = Path(tmp) / "output.mp4"
        src.write_bytes(input_bytes)
        subprocess.run(
            [ffmpeg, "-y", "-i", str(src), "-c:v", "libx264", "-preset", "veryfast", "-pix_fmt", "yuv420p", "-c:a", "aac", "-movflags", "+faststart", str(dst)],
            check=True,
            capture_output=True,
        )
        return dst.read_bytes()


def binary_response(recording: Recording, *, inline: bool):
    if recording.status not in {"ready", "archived"} or not recording.data:
        return error("Recording file is not ready", 409, "recording_not_ready")
    filename = recording.filename or f"{safe_filename(recording.title)}.mp4"
    disposition_type = "inline" if inline else "attachment"
    disposition = f"{disposition_type}; filename*=UTF-8''{quote(filename)}"
    data = recording.data
    size = len(data)
    headers = {"Content-Disposition": disposition, "Accept-Ranges": "bytes"}
    range_header = request.headers.get("Range", "")
    if range_header.startswith("bytes="):
        raw_range = range_header.removeprefix("bytes=").split(",", 1)[0].strip()
        try:
            start_raw, end_raw = (raw_range.split("-", 1) + [""])[:2]
            if start_raw == "":
                suffix = max(0, int(end_raw))
                start = max(0, size - suffix)
                end = size - 1
            else:
                start = max(0, int(start_raw))
                end = min(size - 1, int(end_raw)) if end_raw else size - 1
            if start > end or start >= size:
                return Response(status=416, headers={"Content-Range": f"bytes */{size}", "Accept-Ranges": "bytes"})
        except ValueError:
            return Response(status=416, headers={"Content-Range": f"bytes */{size}", "Accept-Ranges": "bytes"})
        chunk = data[start:end + 1]
        headers.update({"Content-Range": f"bytes {start}-{end}/{size}", "Content-Length": str(len(chunk))})
        return Response(chunk, status=206, mimetype=recording.content_type or "video/mp4", headers=headers)
    headers["Content-Length"] = str(size)
    return Response(data, mimetype=recording.content_type or "video/mp4", headers=headers)


def recording_public_dict(recording: Recording) -> dict:
    metadata = recording.metadata_json or {}
    return {
        "id": recording.id,
        "title": recording.title,
        "status": recording.status,
        "durationSeconds": recording.duration_seconds,
        "category": recording.category,
        "summaryText": recording.summary_text,
        "transcriptText": recording.transcript_text,
        "metadata": {"chapters": metadata.get("chapters") or [], "timelineEvents": metadata.get("timelineEvents") or [], "transcriptSegments": metadata.get("transcriptSegments") or [], "thumbnailDataUrl": metadata.get("thumbnailDataUrl")},
        "startedAt": recording.started_at.isoformat() if recording.started_at else None,
        "endedAt": recording.ended_at.isoformat() if recording.ended_at else None,
        "sizeBytes": recording.size_bytes,
    }


def event_offset(recording: Recording, event_time) -> int:
    if not event_time or not recording.started_at:
        return 0
    start = aware(recording.started_at)
    event = aware(event_time)
    if not start or not event:
        return 0
    return max(0, int((event - start).total_seconds()))


def generate_recording_timeline(recording: Recording) -> dict:
    existing = recording.metadata_json or {}
    chapters = list(existing.get("chapters") or [])
    timeline = list(existing.get("timelineEvents") or [])
    if not chapters:
        chapters.append({"time": 0, "title": "Recording started", "type": "recording"})
    for log in AuditLog.query.filter(AuditLog.created_at >= recording.started_at, AuditLog.created_at <= (recording.ended_at or utcnow())).order_by(AuditLog.created_at.asc()).limit(200).all():
        metadata = log.metadata_json or {}
        if metadata.get("meetingId") and metadata.get("meetingId") != recording.meeting.meeting_id:
            continue
        action = log.action.replace(".", " ").replace("_", " ").title()
        offset = min(recording.duration_seconds or 0, event_offset(recording, log.created_at))
        timeline.append({"time": offset, "title": action, "type": log.action, "action": log.action})
        if log.action in {"screen_share.state", "poll.created", "recording.started", "participant.admitted"}:
            chapters.append({"time": offset, "title": action, "type": log.action})
    message_count = ChatMessage.query.filter_by(meeting_id=recording.meeting_id).count()
    poll_count = Poll.query.filter_by(meeting_id=recording.meeting_id).count()
    participant_count = MeetingParticipant.query.filter_by(meeting_id=recording.meeting_id).count()
    timeline.extend([
        {"time": 0, "title": f"{participant_count} participants tracked", "type": "participants"},
        {"time": 0, "title": f"{message_count} chat messages", "type": "chat"},
        {"time": 0, "title": f"{poll_count} polls", "type": "polls"},
    ])
    unique_chapters = []
    seen = set()
    for item in sorted(chapters, key=lambda entry: int(entry.get("time") or 0)):
        key = (int(item.get("time") or 0), item.get("title"))
        if key not in seen:
            seen.add(key); unique_chapters.append(item)
    return {"chapters": unique_chapters[:50], "timelineEvents": sorted(timeline, key=lambda entry: int(entry.get("time") or 0))[:300]}


def transcript_segments_from_text(text: str | None, duration: int) -> list[dict]:
    if not text:
        return []
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    if not lines:
        words = text.split()
        lines = [" ".join(words[index:index+22]) for index in range(0, len(words), 22)]
    step = max(5, int((duration or 60) / max(1, len(lines))))
    return [{"time": min(duration or 0, index * step), "text": line[:500]} for index, line in enumerate(lines[:200])]


def create_share_access_token(share: RecordingShare) -> str:
    now = utcnow()
    expires = now + timedelta(hours=8)
    if share.expires_at and aware(share.expires_at) and aware(share.expires_at) < expires:
        expires = aware(share.expires_at)
    payload = {
        "iss": current_app.config["JWT_ISSUER"],
        "sub": share.id,
        "recordingId": share.recording_id,
        "type": "recording_share_access",
        "iat": int(now.timestamp()),
        "nbf": int(now.timestamp()),
        "exp": int(expires.timestamp()),
    }
    return jwt.encode(payload, current_app.config["JWT_SECRET"], algorithm="HS256")


def share_by_raw_token(raw_token: str) -> RecordingShare | None:
    return RecordingShare.query.filter_by(token_hash=token_hash(raw_token)).first()


def validate_share(raw_token: str, access_token: str | None = None, require_download: bool = False):
    share = share_by_raw_token(raw_token)
    if not share or share.revoked_at is not None:
        return None, None, error("Recording share not found", 404, "share_not_found")
    if share.expires_at and aware(share.expires_at) <= utcnow():
        return share, None, error("Recording share has expired", 410, "share_expired")
    recording = share.recording
    if recording.status not in {"ready", "archived"} or not recording.data:
        return share, recording, error("Recording is not ready", 409, "recording_not_ready")
    if require_download and not share.allow_download:
        return share, recording, error("Download is not allowed for this share", 403, "download_not_allowed")
    if share.password_hash:
        if not access_token:
            return share, recording, error("Share access token required", 401, "share_access_required")
        try:
            claims = jwt.decode(access_token, current_app.config["JWT_SECRET"], algorithms=["HS256"], issuer=current_app.config["JWT_ISSUER"])
            if claims.get("type") != "recording_share_access" or claims.get("sub") != share.id or claims.get("recordingId") != recording.id:
                raise jwt.InvalidTokenError("invalid share claims")
        except jwt.PyJWTError:
            return share, recording, error("Invalid or expired share access token", 401, "invalid_share_access")
    return share, recording, None


def log_access(recording: Recording, action: str, share: RecordingShare | None = None, admin_id: str | None = None) -> None:
    event = RecordingAccessEvent(recording_id=recording.id, share_id=share.id if share else None, admin_id=admin_id, action=action, ip_address=client_ip(), user_agent=user_agent())
    db.session.add(event)
    if share:
        share.last_accessed_at = utcnow()


def participant_from_bearer(meeting: Meeting) -> MeetingParticipant | None:
    header = request.headers.get("Authorization", "")
    if not header.startswith("Bearer "):
        return None
    raw = header.removeprefix("Bearer ").strip()
    try:
        claims = decode_participant_token(raw)
    except Exception:
        return None
    participant = db.session.get(MeetingParticipant, claims.get("sub"))
    if not participant or participant.meeting_id != meeting.id or participant.participant_token_hash != token_hash(raw) or participant.status != "admitted":
        return None
    return participant


def participant_permissions(participant: MeetingParticipant) -> set[str]:
    info = participant.device_info if isinstance(participant.device_info, dict) else {}
    controls = info.get("hostControls") if isinstance(info, dict) else {}
    if not isinstance(controls, dict):
        return set()
    values = controls.get("cohostPermissions") or []
    return {str(item) for item in values if str(item)} if isinstance(values, list) else set()


def participant_can_record(participant: MeetingParticipant, action: str = "recording.start") -> bool:
    if participant.role == "host":
        return True
    if participant.role != "cohost":
        return False
    permissions = participant_permissions(participant)
    return "participants.manage" in permissions or action in permissions or "recording.start" in permissions


def create_recording_row(meeting: Meeting, *, title: str, metadata: dict, actor_admin_id: str, actor_participant: MeetingParticipant | None = None) -> Recording:
    metadata_json = {
        "meetingTitle": meeting.title,
        "meetingPublicId": meeting.meeting_id,
        "recordingLayout": "presenter_screen_only",
        "excludedFromRecording": ["participant_sidebar", "waiting_room", "chat", "reactions", "raised_hands", "whiteboard_toolbar", "participant_thumbnails", "meeting_controls", "top_toolbar", "join_requests", "admin_panels", "menus", "browser_ui"],
        **metadata,
    }
    if actor_participant:
        metadata_json["actorParticipantId"] = actor_participant.id
        metadata_json["actorParticipantName"] = actor_participant.display_name
        metadata_json["actorParticipantRole"] = actor_participant.role
    recording = Recording(meeting_id=meeting.id, admin_id=actor_admin_id, title=str(title)[:220], status="recording", started_at=utcnow(), metadata_json=metadata_json)
    db.session.add(recording)
    db.session.flush()
    return recording


def process_recording_upload(recording: Recording, *, actor_admin=None, actor_participant: MeetingParticipant | None = None):
    if recording.status not in {"recording", "failed"}:
        return error("Recording upload is not allowed in this state", 409, "invalid_recording_state")
    upload = request.files.get("file")
    if not upload:
        return error("Recording file is required", 400, "recording_file_required")
    max_bytes = current_app.config["MAX_RECORDING_UPLOAD_MB"] * 1024 * 1024
    raw = upload.read(max_bytes + 1)
    if len(raw) > max_bytes:
        return error(f"Recording exceeds {current_app.config['MAX_RECORDING_UPLOAD_MB']} MB", 400, "recording_too_large")
    if not raw:
        return error("Recording file is empty", 400, "recording_empty")
    duration_seconds = int(request.form.get("durationSeconds") or 0)
    upload_metadata: dict = {}
    raw_metadata = request.form.get("metadata")
    if raw_metadata:
        try:
            parsed = json.loads(raw_metadata)
            if isinstance(parsed, dict):
                upload_metadata.update(parsed)
        except json.JSONDecodeError:
            return error("Recording metadata must be valid JSON", 400, "validation_error")
    for key in ["presenterName", "recordingMode", "pipPosition", "resolution", "watermarkEnabled", "presenterCameraEnabled"]:
        if key in request.form:
            upload_metadata[key] = request.form.get(key)
    thumbnail = request.form.get("thumbnailDataUrl")
    if thumbnail and thumbnail.startswith("data:image/") and len(thumbnail) <= 1_500_000:
        upload_metadata["thumbnailDataUrl"] = thumbnail
    if actor_participant:
        upload_metadata["uploadedByParticipantId"] = actor_participant.id
        upload_metadata["uploadedByParticipantName"] = actor_participant.display_name
    if upload_metadata:
        recording.metadata_json = {**(recording.metadata_json or {}), **upload_metadata}
    recording.status = "processing"
    db.session.commit()
    upload_name = (upload.filename or "").lower()
    upload_type = (upload.mimetype or "").lower()
    server_transcoded = not (upload_type.startswith("video/mp4") or upload_name.endswith(".mp4"))
    try:
        mp4 = transcode_webm_to_mp4(raw) if server_transcoded else raw
    except Exception as exc:
        recording.status = "failed"
        recording.error_message = str(exc)[:2000]
        recording.ended_at = utcnow()
        db.session.commit()
        socketio.emit("recording:failed", {"meetingId": recording.meeting_id, "recording": recording.to_dict()}, room=recording.meeting_id)
        return error(f"Recording transcode failed: {exc}", 500, "recording_transcode_failed")
    recording.metadata_json = {**(recording.metadata_json or {}), "serverTranscoded": server_transcoded, "clientEncodedMp4": not server_transcoded}
    digest = hashlib.sha256(mp4).hexdigest()
    recording.data = mp4
    recording.status = "ready"
    recording.ended_at = utcnow()
    recording.duration_seconds = duration_seconds
    recording.filename = f"{safe_filename(recording.title)}.mp4"
    recording.content_type = "video/mp4"
    recording.size_bytes = len(mp4)
    recording.sha256 = digest
    recording.error_message = None
    generated = generate_recording_timeline(recording)
    recording.metadata_json = {**(recording.metadata_json or {}), **generated, "transcriptSegments": transcript_segments_from_text(recording.transcript_text or (recording.metadata_json or {}).get("transcriptText"), duration_seconds)}
    audit("recording.ready", actor=actor_admin, session=getattr(g, "current_session", None) if actor_admin else None, entity_type="recording", entity_id=recording.id, metadata={"sizeBytes": len(mp4), "durationSeconds": duration_seconds, "actorParticipantId": actor_participant.id if actor_participant else None})
    db.session.commit()
    dispatch_webhook("recording.completed", {"meeting": recording.meeting.to_dict(include_private=True), "recording": recording.to_dict()})
    db.session.commit()
    socketio.emit("recording:ready", {"meetingId": recording.meeting_id, "recording": recording.to_dict()}, room=recording.meeting_id)
    return jsonify({"recording": recording.to_dict()})


@bp.post("/meetings/<identifier>/recordings/start")
@require_admin(permission="recordings.manage")
def start_recording(identifier: str):
    meeting, err = admin_meeting(identifier)
    if err:
        return err
    if meeting.status != "running":
        return error("Meeting must be running before recording starts", 409, "meeting_not_running")
    active = Recording.query.filter_by(meeting_id=meeting.id, admin_id=g.current_admin.id, status="recording").first()
    if active:
        return error("A recording is already active for this meeting", 409, "recording_already_active")
    data = request.get_json(silent=True) or {}
    title = data.get("title") or f"{meeting.title} - {utcnow().strftime('%Y-%m-%d %H:%M:%S')}"
    metadata = data.get("metadata") if isinstance(data.get("metadata"), dict) else {}
    recording = create_recording_row(meeting, title=title, metadata=metadata, actor_admin_id=g.current_admin.id)
    audit("recording.started", actor=g.current_admin, session=g.current_session, entity_type="recording", entity_id=recording.id, metadata={"meetingId": meeting.meeting_id})
    db.session.commit()
    dispatch_webhook("recording.started", {"meeting": meeting.to_dict(include_private=True), "recording": recording.to_dict()})
    db.session.commit()
    socketio.emit("recording:started", {"meetingId": meeting.id, "recording": recording.to_dict()}, room=meeting.id)
    return jsonify({"recording": recording.to_dict()}), 201


@bp.post("/meetings/invitations/<token>/recordings/start")
def participant_start_recording(token: str):
    invitation = MeetingInvitation.query.filter_by(token=token).first()
    if not invitation:
        return error("Invitation link not found", 404, "invitation_not_found")
    meeting = invitation.meeting
    participant = participant_from_bearer(meeting)
    if not participant:
        return error("Invalid participant session", 401, "invalid_participant_session")
    if not participant_can_record(participant, "recording.start"):
        return error("Recording permission is required", 403, "recording_permission_required")
    if meeting.status != "running":
        return error("Meeting must be running before recording starts", 409, "meeting_not_running")
    active = Recording.query.filter_by(meeting_id=meeting.id, admin_id=meeting.admin_id, status="recording").first()
    if active:
        return error("A recording is already active for this meeting", 409, "recording_already_active")
    data = request.get_json(silent=True) or {}
    title = data.get("title") or f"{meeting.title} - {utcnow().strftime('%Y-%m-%d %H:%M:%S')}"
    metadata = data.get("metadata") if isinstance(data.get("metadata"), dict) else {}
    recording = create_recording_row(meeting, title=title, metadata=metadata, actor_admin_id=meeting.admin_id, actor_participant=participant)
    audit("recording.started", entity_type="recording", entity_id=recording.id, metadata={"meetingId": meeting.meeting_id, "actorParticipantId": participant.id, "actorRole": participant.role})
    db.session.commit()
    dispatch_webhook("recording.started", {"meeting": meeting.to_dict(include_private=True), "recording": recording.to_dict()})
    db.session.commit()
    socketio.emit("recording:started", {"meetingId": meeting.id, "recording": recording.to_dict()}, room=meeting.id)
    return jsonify({"recording": recording.to_dict()}), 201


@bp.get("/meetings/<identifier>/recordings")
@require_admin(permission="recordings.manage")
def meeting_recordings(identifier: str):
    meeting, err = admin_meeting(identifier)
    if err:
        return err
    query = Recording.query.filter_by(meeting_id=meeting.id, admin_id=g.current_admin.id)
    pagination = paginate(query.order_by(Recording.created_at.desc()), default_per_page=50, max_per_page=100)
    db.session.commit()
    return jsonify({"items": [r.to_dict() for r in pagination.items], "total": pagination.total})


@bp.get("/recordings")
@require_admin(permission="recordings.manage")
def all_recordings():
    query = Recording.query.filter_by(admin_id=g.current_admin.id)
    q = request.args.get("q", "").strip()
    status = request.args.get("status", "").strip()
    if q:
        like = f"%{q}%"
        query = query.filter((Recording.title.ilike(like)) | (Recording.category.ilike(like)) | (Recording.transcript_text.ilike(like)) | (Recording.summary_text.ilike(like)))
    if status:
        query = query.filter_by(status=status)
    pagination = paginate(query.order_by(Recording.created_at.desc()), default_per_page=50, max_per_page=100)
    db.session.commit()
    return jsonify({"items": [r.to_dict() for r in pagination.items], "total": pagination.total})


@bp.get("/recordings/<recording_id>")
@require_admin(permission="recordings.manage")
def get_recording(recording_id: str):
    recording, err = admin_recording(recording_id)
    if err:
        return err
    db.session.commit()
    return jsonify({"recording": recording.to_dict(), "meeting": recording.meeting.to_dict(include_private=True)})


@bp.post("/recordings/<recording_id>/upload")
@require_admin(permission="recordings.manage")
def upload_recording(recording_id: str):
    recording, err = admin_recording(recording_id)
    if err:
        return err
    return process_recording_upload(recording, actor_admin=g.current_admin)


@bp.post("/meetings/invitations/<token>/recordings/<recording_id>/upload")
def participant_upload_recording(token: str, recording_id: str):
    invitation = MeetingInvitation.query.filter_by(token=token).first()
    if not invitation:
        return error("Invitation link not found", 404, "invitation_not_found")
    meeting = invitation.meeting
    participant = participant_from_bearer(meeting)
    if not participant:
        return error("Invalid participant session", 401, "invalid_participant_session")
    if not participant_can_record(participant, "recording.stop"):
        return error("Recording permission is required", 403, "recording_permission_required")
    recording = Recording.query.filter_by(id=recording_id, meeting_id=meeting.id, admin_id=meeting.admin_id).first()
    if not recording:
        return error("Recording not found", 404, "recording_not_found")
    return process_recording_upload(recording, actor_participant=participant)


@bp.patch("/recordings/<recording_id>")
@require_admin(permission="recordings.manage")
def update_recording(recording_id: str):
    recording, err = admin_recording(recording_id)
    if err:
        return err
    data = request.get_json(silent=True) or {}
    if "title" in data:
        title = str(data["title"]).strip()
        if len(title) < 1 or len(title) > 220:
            return error("Title must be between 1 and 220 characters", 400, "validation_error")
        recording.title = title
        if recording.filename:
            recording.filename = f"{safe_filename(title)}.mp4"
    if "status" in data:
        status = str(data["status"])
        if status not in {"ready", "archived"}:
            return error("status must be ready or archived", 400, "validation_error")
        if recording.status not in {"ready", "archived"}:
            return error("Only ready recordings can be archived or restored", 409, "invalid_recording_state")
        recording.status = status
    if "category" in data:
        category = str(data.get("category") or "").strip()
        recording.category = category[:120] if category else None
    if "expiresAt" in data:
        value = data.get("expiresAt")
        if value:
            from datetime import datetime, timezone
            parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
            recording.expires_at = parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
        else:
            recording.expires_at = None
    if "transcriptText" in data:
        recording.transcript_text = str(data.get("transcriptText") or "")[:200000] or None
    if "summaryText" in data:
        recording.summary_text = str(data.get("summaryText") or "")[:20000] or None
    audit("recording.updated", actor=g.current_admin, session=g.current_session, entity_type="recording", entity_id=recording.id, metadata={key: value for key, value in data.items() if key not in {"transcriptText"}})
    db.session.commit()
    return jsonify({"recording": recording.to_dict()})


@bp.get("/recordings/<recording_id>/download")
@require_admin(permission="recordings.manage")
def download_recording(recording_id: str):
    recording, err = admin_recording(recording_id)
    if err:
        return err
    log_access(recording, "download", admin_id=g.current_admin.id)
    db.session.commit()
    return binary_response(recording, inline=False)


@bp.get("/recordings/<recording_id>/playback")
@require_admin(permission="recordings.manage")
def playback_recording(recording_id: str):
    recording, err = admin_recording(recording_id)
    if err:
        return err
    log_access(recording, "playback", admin_id=g.current_admin.id)
    db.session.commit()
    return binary_response(recording, inline=True)


@bp.post("/recordings/<recording_id>/shares")
@require_admin(permission="recordings.manage")
def create_recording_share(recording_id: str):
    recording, err = admin_recording(recording_id)
    if err:
        return err
    if recording.status not in {"ready", "archived"}:
        return error("Only ready recordings can be shared", 409, "recording_not_ready")
    data = request.get_json(silent=True) or {}
    raw_token = secrets.token_urlsafe(32)
    expires_at = None
    if data.get("expiresAt"):
        from datetime import datetime, timezone
        parsed = datetime.fromisoformat(str(data["expiresAt"]).replace("Z", "+00:00"))
        expires_at = parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
        if expires_at <= utcnow():
            return error("expiresAt must be in the future", 400, "validation_error")
    password = str(data.get("password") or "")
    if password and len(password) < 6:
        return error("Share password must be at least 6 characters", 400, "validation_error")
    clip_start = data.get("clipStartSeconds")
    clip_end = data.get("clipEndSeconds")
    clip_start = int(clip_start) if clip_start not in (None, "") else None
    clip_end = int(clip_end) if clip_end not in (None, "") else None
    if clip_start is not None or clip_end is not None:
        clip_start = max(0, clip_start or 0)
        clip_end = min(recording.duration_seconds or 0, clip_end or recording.duration_seconds or 0)
        if clip_end <= clip_start:
            return error("Clip end must be after clip start", 400, "validation_error")
        if data.get("allowDownload"):
            return error("Downloads are disabled for clip shares to prevent exposing the full recording", 400, "clip_download_forbidden")
    share = RecordingShare(
        recording_id=recording.id,
        created_by_admin_id=g.current_admin.id,
        token_hash=token_hash(raw_token),
        password_hash=generate_password_hash(password) if password else None,
        expires_at=expires_at,
        allow_download=bool(data.get("allowDownload", False)) if clip_start is None and clip_end is None else False,
        watermark_text=(str(data.get("watermarkText") or "").strip()[:160] or None),
        clip_start_seconds=clip_start,
        clip_end_seconds=clip_end,
    )
    db.session.add(share)
    db.session.flush()
    share_url = f"{current_app.config['PUBLIC_APP_URL'].rstrip('/')}/recording-share/{raw_token}"
    audit("recording.share_created", actor=g.current_admin, session=g.current_session, entity_type="recording_share", entity_id=share.id, metadata={"recordingId": recording.id, "allowDownload": share.allow_download, "expiresAt": share.expires_at.isoformat() if share.expires_at else None})
    db.session.commit()
    payload = share.to_dict()
    payload["url"] = share_url
    return jsonify({"share": payload, "recording": recording.to_dict(include_text=False)}), 201


@bp.get("/recordings/<recording_id>/shares")
@require_admin(permission="recordings.manage")
def list_recording_shares(recording_id: str):
    recording, err = admin_recording(recording_id)
    if err:
        return err
    shares = RecordingShare.query.filter_by(recording_id=recording.id).order_by(RecordingShare.created_at.desc()).all()
    db.session.commit()
    return jsonify({"items": [share.to_dict() for share in shares], "total": len(shares)})


@bp.patch("/recording-shares/<share_id>")
@require_admin(permission="recordings.manage")
def update_recording_share(share_id: str):
    share = RecordingShare.query.filter_by(id=share_id).first()
    if not share or share.recording.admin_id != g.current_admin.id:
        return error("Recording share not found", 404, "share_not_found")
    data = request.get_json(silent=True) or {}
    if "allowDownload" in data:
        share.allow_download = bool(data["allowDownload"])
    if "watermarkText" in data:
        share.watermark_text = str(data.get("watermarkText") or "").strip()[:160] or None
    if "clipStartSeconds" in data or "clipEndSeconds" in data:
        start = int(data.get("clipStartSeconds") or 0) if data.get("clipStartSeconds") not in (None, "") else None
        end = int(data.get("clipEndSeconds") or 0) if data.get("clipEndSeconds") not in (None, "") else None
        if start is not None or end is not None:
            start = max(0, start or 0); end = min(share.recording.duration_seconds or 0, end or share.recording.duration_seconds or 0)
            if end <= start:
                return error("Clip end must be after clip start", 400, "validation_error")
            share.allow_download = False
        share.clip_start_seconds = start
        share.clip_end_seconds = end
    if "expiresAt" in data:
        if data.get("expiresAt"):
            from datetime import datetime, timezone
            parsed = datetime.fromisoformat(str(data["expiresAt"]).replace("Z", "+00:00"))
            share.expires_at = parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
        else:
            share.expires_at = None
    if "password" in data:
        password = str(data.get("password") or "")
        if password and len(password) < 6:
            return error("Share password must be at least 6 characters", 400, "validation_error")
        share.password_hash = generate_password_hash(password) if password else None
    audit("recording.share_updated", actor=g.current_admin, session=g.current_session, entity_type="recording_share", entity_id=share.id)
    db.session.commit()
    return jsonify({"share": share.to_dict()})


@bp.delete("/recording-shares/<share_id>")
@require_admin(permission="recordings.manage")
def revoke_recording_share(share_id: str):
    share = RecordingShare.query.filter_by(id=share_id).first()
    if not share or share.recording.admin_id != g.current_admin.id:
        return error("Recording share not found", 404, "share_not_found")
    share.revoked_at = utcnow()
    audit("recording.share_revoked", actor=g.current_admin, session=g.current_session, entity_type="recording_share", entity_id=share.id)
    db.session.commit()
    return jsonify({"share": share.to_dict()})


@bp.get("/recording-shares/<raw_token>")
def public_recording_share(raw_token: str):
    share = share_by_raw_token(raw_token)
    if not share or share.revoked_at is not None:
        return error("Recording share not found", 404, "share_not_found")
    if share.expires_at and aware(share.expires_at) <= utcnow():
        return error("Recording share has expired", 410, "share_expired")
    recording = share.recording
    db.session.commit()
    return jsonify({"share": share.to_dict(), "recording": recording_public_dict(recording)})


@bp.post("/recording-shares/<raw_token>/access")
def recording_share_access(raw_token: str):
    share = share_by_raw_token(raw_token)
    if not share or share.revoked_at is not None:
        return error("Recording share not found", 404, "share_not_found")
    if share.expires_at and aware(share.expires_at) <= utcnow():
        return error("Recording share has expired", 410, "share_expired")
    password = str((request.get_json(silent=True) or {}).get("password") or "")
    if share.password_hash and not check_password_hash(share.password_hash, password):
        return error("Recording share password is incorrect", 401, "invalid_share_password")
    token = create_share_access_token(share)
    db.session.commit()
    return jsonify({"accessToken": token, "share": share.to_dict(), "recording": recording_public_dict(share.recording)})


@bp.get("/recording-shares/<raw_token>/playback")
def public_share_playback(raw_token: str):
    access_token = request.args.get("accessToken") or request.headers.get("Authorization", "").removeprefix("Bearer ").strip() or None
    share, recording, err = validate_share(raw_token, access_token, require_download=False)
    if err:
        return err
    log_access(recording, "playback", share=share)
    db.session.commit()
    return binary_response(recording, inline=True)


@bp.get("/recording-shares/<raw_token>/download")
def public_share_download(raw_token: str):
    access_token = request.args.get("accessToken") or request.headers.get("Authorization", "").removeprefix("Bearer ").strip() or None
    share, recording, err = validate_share(raw_token, access_token, require_download=True)
    if err:
        return err
    log_access(recording, "download", share=share)
    db.session.commit()
    return binary_response(recording, inline=False)


@bp.get("/recordings/<recording_id>/analytics")
@require_admin(permission="recordings.manage")
def recording_analytics(recording_id: str):
    recording, err = admin_recording(recording_id)
    if err:
        return err
    events = RecordingAccessEvent.query.filter_by(recording_id=recording.id).order_by(RecordingAccessEvent.created_at.desc()).all()
    shares = RecordingShare.query.filter_by(recording_id=recording.id).order_by(RecordingShare.created_at.desc()).all()
    by_action: dict[str, int] = {}
    for event in events:
        by_action[event.action] = by_action.get(event.action, 0) + 1
    db.session.commit()
    return jsonify({"recording": recording.to_dict(), "shares": [s.to_dict() for s in shares], "events": [e.to_dict() for e in events], "byAction": by_action})


@bp.delete("/recordings/<recording_id>")
@require_admin(permission="recordings.manage")
def delete_recording(recording_id: str):
    recording, err = admin_recording(recording_id)
    if err:
        return err
    meeting_id = recording.meeting_id
    audit("recording.deleted", actor=g.current_admin, session=g.current_session, entity_type="recording", entity_id=recording.id)
    db.session.delete(recording)
    db.session.commit()
    socketio.emit("recording:deleted", {"meetingId": meeting_id, "recordingId": recording_id}, room=meeting_id)
    return jsonify({"message": "Recording deleted"})
