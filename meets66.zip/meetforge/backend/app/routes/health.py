from __future__ import annotations

import os

import psutil
from flask import Blueprint, Response, current_app, jsonify
from sqlalchemy import text

from ..config_validation import validate_config
from ..extensions import db

bp = Blueprint("health", __name__)


def database_check() -> str:
    try:
        db.session.execute(text("SELECT 1"))
        return "ok"
    except Exception:
        db.session.rollback()
        return "error"


@bp.get("")
def health():
    db_status = database_check()
    status = 200 if db_status == "ok" else 503
    return jsonify({"status": "ok" if status == 200 else "degraded", "checks": {"api": "ok", "database": db_status}, "pid": os.getpid()}), status


@bp.get("/live")
def live():
    return jsonify({"status": "alive", "pid": os.getpid()})


@bp.get("/ready")
def ready():
    db_status = database_check()
    config_status = validate_config(current_app.config)
    ready_status = db_status == "ok" and config_status["valid"]
    return jsonify({"ready": ready_status, "checks": {"database": db_status, "config": config_status}}), 200 if ready_status else 503


@bp.get("/config")
def config_health():
    status = validate_config(current_app.config)
    return jsonify(status), 200 if status["valid"] else 503


@bp.get("/metrics")
def metrics():
    db_ok = 1 if database_check() == "ok" else 0
    vm = psutil.virtual_memory()
    disk = psutil.disk_usage("/")
    lines = [
        "# HELP defensiq_api_up API process is serving requests.",
        "# TYPE defensiq_api_up gauge",
        "defensiq_api_up 1",
        "# HELP defensiq_database_up Database connectivity status.",
        "# TYPE defensiq_database_up gauge",
        f"defensiq_database_up {db_ok}",
        "# HELP defensiq_process_resident_memory_bytes Resident memory of backend process.",
        "# TYPE defensiq_process_resident_memory_bytes gauge",
        f"defensiq_process_resident_memory_bytes {psutil.Process(os.getpid()).memory_info().rss}",
        "# HELP defensiq_system_memory_percent Host memory utilization percent.",
        "# TYPE defensiq_system_memory_percent gauge",
        f"defensiq_system_memory_percent {vm.percent}",
        "# HELP defensiq_disk_percent Host root disk utilization percent.",
        "# TYPE defensiq_disk_percent gauge",
        f"defensiq_disk_percent {disk.percent}",
        "",
    ]
    response = Response("\n".join(lines), mimetype="text/plain; version=0.0.4")
    response.headers["Cache-Control"] = "no-store"
    return response
