from __future__ import annotations

from datetime import timedelta

from flask import Blueprint, current_app, g, jsonify, request

from ..decorators import error, paginate, require_admin
from ..extensions import db, limiter
from ..models import AdminAccount, AdminSession, AuditLog, utcnow
from ..permissions import effective_permissions
from ..security import (
    audit,
    aware,
    create_access_token,
    create_csrf_token,
    create_session,
    normalize_email,
    revoke_session,
    rotate_refresh_token,
    token_hash,
    validate_password_strength,
)

bp = Blueprint("auth", __name__)


def auth_payload(admin: AdminAccount, session: AdminSession, refresh_token: str):
    access = create_access_token(admin, session)
    csrf = create_csrf_token(session)
    db.session.commit()
    return jsonify({
        "admin": {**admin.to_dict(), "effectivePermissions": effective_permissions(admin)},
        "accessToken": access,
        "refreshToken": refresh_token,
        "csrfToken": csrf,
        "session": session.to_dict(),
        "forceChangePassword": admin.must_change_password,
    })


@bp.post("/login")
@limiter.limit("10 per minute")
def login():
    data = request.get_json(silent=True) or {}
    try:
        email = normalize_email(data.get("email", ""))
    except ValueError:
        return error("Invalid credentials", 401, "invalid_credentials")
    password = str(data.get("password", ""))

    admin = AdminAccount.query.filter_by(email=email).first()
    if not admin or admin.status != "active":
        return error("Invalid credentials", 401, "invalid_credentials")

    if admin.lock_until and aware(admin.lock_until) > utcnow():
        return error("Administrator account is temporarily locked", 423, "account_locked")

    if not admin.check_password(password):
        admin.failed_login_count += 1
        if admin.failed_login_count >= current_app.config["ACCOUNT_LOCK_ATTEMPTS"]:
            admin.lock_until = utcnow() + timedelta(minutes=current_app.config["ACCOUNT_LOCK_MINUTES"])
        audit("auth.login_failed", actor=admin, entity_type="admin", entity_id=admin.id)
        db.session.commit()
        return error("Invalid credentials", 401, "invalid_credentials")

    admin.failed_login_count = 0
    admin.lock_until = None
    admin.last_login_at = utcnow()
    session, refresh = create_session(admin)
    audit("auth.login", actor=admin, session=session, entity_type="admin_session", entity_id=session.id, metadata={"forceChangePassword": admin.must_change_password})
    return auth_payload(admin, session, refresh)


@bp.post("/refresh")
@limiter.limit("60 per minute")
def refresh():
    data = request.get_json(silent=True) or {}
    raw = data.get("refreshToken")
    if not raw:
        return error("Refresh token required", 401, "refresh_required")
    session = AdminSession.query.filter_by(refresh_token_hash=token_hash(raw)).first()
    if not session or session.revoked_at is not None or aware(session.expires_at) <= utcnow():
        return error("Invalid refresh token", 401, "invalid_refresh")
    admin = session.admin
    if not admin or admin.status != "active":
        return error("Administrator account is inactive", 403, "admin_inactive")
    new_refresh = rotate_refresh_token(session)
    audit("auth.refresh", actor=admin, session=session, entity_type="admin_session", entity_id=session.id)
    return auth_payload(admin, session, new_refresh)


@bp.post("/change-password")
@require_admin(allow_password_change_required=True)
def change_password():
    data = request.get_json(silent=True) or {}
    current_password = str(data.get("currentPassword", ""))
    new_password = str(data.get("newPassword", ""))
    confirm_password = str(data.get("confirmPassword", ""))
    if not g.current_admin.check_password(current_password):
        return error("Current password is incorrect", 401, "invalid_current_password")
    if new_password != confirm_password:
        return error("New password and confirmation do not match", 400, "password_mismatch")
    try:
        validate_password_strength(new_password)
    except ValueError as exc:
        return error(str(exc), 400, "weak_password")
    if current_password == new_password:
        return error("New password must be different from the current password", 400, "password_reuse")

    g.current_admin.set_password(new_password)
    g.current_admin.must_change_password = False
    g.current_admin.password_changed_at = utcnow()
    for session in AdminSession.query.filter(AdminSession.admin_id == g.current_admin.id, AdminSession.id != g.current_session.id, AdminSession.revoked_at.is_(None)).all():
        revoke_session(session, "password_changed")
    refresh_token = rotate_refresh_token(g.current_session)
    audit("auth.password_changed", actor=g.current_admin, session=g.current_session, entity_type="admin", entity_id=g.current_admin.id)
    return auth_payload(g.current_admin, g.current_session, refresh_token)


@bp.post("/logout")
@require_admin(allow_password_change_required=True)
def logout():
    revoke_session(g.current_session, "logout")
    audit("auth.logout", actor=g.current_admin, session=g.current_session, entity_type="admin_session", entity_id=g.current_session.id)
    db.session.commit()
    return jsonify({"message": "Logged out"})


@bp.get("/me")
@require_admin(allow_password_change_required=True)
def me():
    db.session.commit()
    return jsonify({"admin": {**g.current_admin.to_dict(), "effectivePermissions": effective_permissions(g.current_admin)}, "session": g.current_session.to_dict(), "forceChangePassword": g.current_admin.must_change_password})


@bp.get("/sessions")
@require_admin
def sessions():
    pagination = paginate(AdminSession.query.filter_by(admin_id=g.current_admin.id).order_by(AdminSession.created_at.desc()), default_per_page=20, max_per_page=100)
    db.session.commit()
    return jsonify({"items": [session.to_dict() for session in pagination.items], "total": pagination.total})


@bp.delete("/sessions/<session_id>")
@require_admin
def revoke(session_id: str):
    session = AdminSession.query.filter_by(id=session_id, admin_id=g.current_admin.id).first()
    if not session:
        return error("Session not found", 404, "session_not_found")
    if session.id == g.current_session.id:
        return error("Use logout to revoke the current session", 400, "current_session")
    revoke_session(session, "admin_revoked")
    audit("auth.session_revoked", actor=g.current_admin, session=g.current_session, entity_type="admin_session", entity_id=session.id)
    db.session.commit()
    return jsonify({"session": session.to_dict()})


@bp.get("/audit-logs")
@require_admin(permission="analytics.view")
def audit_logs():
    pagination = paginate(AuditLog.query.order_by(AuditLog.created_at.desc()), default_per_page=30, max_per_page=100)
    db.session.commit()
    return jsonify({"items": [log.to_dict() for log in pagination.items], "total": pagination.total})
