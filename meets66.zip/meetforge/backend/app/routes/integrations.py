from __future__ import annotations

from datetime import datetime, timezone
from urllib.parse import urlparse

from flask import Blueprint, current_app, g, jsonify, request

from ..decorators import error, paginate, require_admin
from ..extensions import db
from ..models import ApiKey, Meeting, Recording, WebhookDelivery, WebhookSubscription, utcnow
from ..security import audit, aware, token_hash
from ..webhooks import ALL_WEBHOOK_EVENTS, attempt_delivery, generate_webhook_secret, hash_api_key, new_api_key

bp = Blueprint("integrations", __name__)


def parse_expiry(value: str | None):
    if not value:
        return None
    parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


def validate_scopes(scopes) -> list[str]:
    allowed = {"meetings:read", "recordings:read", "webhooks:read"}
    if not isinstance(scopes, list) or not scopes:
        raise ValueError("At least one API key scope is required")
    clean = sorted({str(scope) for scope in scopes})
    invalid = [scope for scope in clean if scope not in allowed]
    if invalid:
        raise ValueError(f"Invalid API key scopes: {', '.join(invalid)}")
    return clean


def validate_url(value: str) -> str:
    parsed = urlparse(value)
    if parsed.scheme not in {"https", "http"} or not parsed.netloc:
        raise ValueError("Webhook URL must be an absolute HTTP or HTTPS URL")
    if current_app.config.get("FLASK_ENV") == "production" and parsed.scheme != "https":
        raise ValueError("Webhook URL must use HTTPS in production")
    return value[:1000]


def require_api_key_scope(scope: str):
    raw = request.headers.get("X-API-Key") or request.headers.get("Authorization", "").removeprefix("Bearer ").strip()
    if not raw:
        return None, error("API key required", 401, "api_key_required")
    key = ApiKey.query.filter_by(key_hash=hash_api_key(raw)).first()
    if not key or key.revoked_at is not None or (key.expires_at and aware(key.expires_at) <= utcnow()):
        return None, error("Invalid API key", 401, "invalid_api_key")
    if scope not in (key.scopes or []):
        return None, error("API key scope is insufficient", 403, "insufficient_scope")
    key.last_used_at = utcnow()
    db.session.flush()
    return key, None


@bp.get("/api-keys")
@require_admin(permission="integrations.manage")
def list_api_keys():
    keys = ApiKey.query.filter_by(admin_id=g.current_admin.id).order_by(ApiKey.created_at.desc()).all()
    db.session.commit()
    return jsonify({"items": [key.to_dict() for key in keys], "total": len(keys)})


@bp.post("/api-keys")
@require_admin(permission="integrations.manage")
def create_api_key():
    data = request.get_json(silent=True) or {}
    name = str(data.get("name") or "").strip()
    if len(name) < 2 or len(name) > 160:
        return error("API key name must be between 2 and 160 characters", 400, "validation_error")
    try:
        scopes = validate_scopes(data.get("scopes") or ["meetings:read"])
        expires_at = parse_expiry(data.get("expiresAt"))
    except ValueError as exc:
        return error(str(exc), 400, "validation_error")
    raw = new_api_key()
    key = ApiKey(admin_id=g.current_admin.id, name=name, key_hash=hash_api_key(raw), key_prefix=raw[:12], scopes=scopes, expires_at=expires_at)
    db.session.add(key)
    db.session.flush()
    audit("api_key.created", actor=g.current_admin, session=g.current_session, entity_type="api_key", entity_id=key.id, metadata={"scopes": scopes})
    db.session.commit()
    return jsonify({"apiKey": key.to_dict(), "secret": raw}), 201


@bp.delete("/api-keys/<key_id>")
@require_admin(permission="integrations.manage")
def revoke_api_key(key_id: str):
    key = ApiKey.query.filter_by(id=key_id, admin_id=g.current_admin.id).first()
    if not key:
        return error("API key not found", 404, "api_key_not_found")
    key.revoked_at = utcnow()
    audit("api_key.revoked", actor=g.current_admin, session=g.current_session, entity_type="api_key", entity_id=key.id)
    db.session.commit()
    return jsonify({"apiKey": key.to_dict()})


@bp.get("/webhooks/events")
@require_admin(permission="integrations.manage")
def webhook_events():
    return jsonify({"items": ALL_WEBHOOK_EVENTS})


@bp.get("/webhooks")
@require_admin(permission="integrations.manage")
def list_webhooks():
    hooks = WebhookSubscription.query.filter_by(admin_id=g.current_admin.id).order_by(WebhookSubscription.created_at.desc()).all()
    db.session.commit()
    return jsonify({"items": [hook.to_dict() for hook in hooks], "total": len(hooks)})


@bp.post("/webhooks")
@require_admin(permission="integrations.manage")
def create_webhook():
    data = request.get_json(silent=True) or {}
    try:
        target_url = validate_url(str(data.get("targetUrl") or "").strip())
    except ValueError as exc:
        return error(str(exc), 400, "validation_error")
    events = data.get("events") or []
    if not isinstance(events, list) or not events:
        return error("Webhook must subscribe to at least one event", 400, "validation_error")
    clean_events = sorted({str(event) for event in events})
    invalid = [event for event in clean_events if event != "*" and event not in ALL_WEBHOOK_EVENTS]
    if invalid:
        return error(f"Invalid webhook events: {', '.join(invalid)}", 400, "validation_error")
    hook = WebhookSubscription(admin_id=g.current_admin.id, target_url=target_url, events=clean_events, enabled=bool(data.get("enabled", True)), description=str(data.get("description") or "").strip()[:255] or None, secret_hash="pending")
    db.session.add(hook)
    db.session.flush()
    secret = generate_webhook_secret(hook.id)
    hook.secret_hash = token_hash(secret)
    audit("webhook.created", actor=g.current_admin, session=g.current_session, entity_type="webhook_subscription", entity_id=hook.id, metadata={"events": clean_events})
    db.session.commit()
    payload = hook.to_dict()
    payload["signingSecret"] = secret
    return jsonify({"webhook": payload}), 201


@bp.patch("/webhooks/<hook_id>")
@require_admin(permission="integrations.manage")
def update_webhook(hook_id: str):
    hook = WebhookSubscription.query.filter_by(id=hook_id, admin_id=g.current_admin.id).first()
    if not hook:
        return error("Webhook not found", 404, "webhook_not_found")
    data = request.get_json(silent=True) or {}
    if "targetUrl" in data:
        try:
            hook.target_url = validate_url(str(data["targetUrl"]).strip())
        except ValueError as exc:
            return error(str(exc), 400, "validation_error")
    if "events" in data:
        events = data.get("events") or []
        if not isinstance(events, list) or not events:
            return error("Webhook must subscribe to at least one event", 400, "validation_error")
        invalid = [event for event in events if event != "*" and event not in ALL_WEBHOOK_EVENTS]
        if invalid:
            return error(f"Invalid webhook events: {', '.join(invalid)}", 400, "validation_error")
        hook.events = sorted({str(event) for event in events})
    if "enabled" in data:
        hook.enabled = bool(data["enabled"])
    if "description" in data:
        hook.description = str(data.get("description") or "").strip()[:255] or None
    audit("webhook.updated", actor=g.current_admin, session=g.current_session, entity_type="webhook_subscription", entity_id=hook.id)
    db.session.commit()
    return jsonify({"webhook": hook.to_dict()})


@bp.delete("/webhooks/<hook_id>")
@require_admin(permission="integrations.manage")
def delete_webhook(hook_id: str):
    hook = WebhookSubscription.query.filter_by(id=hook_id, admin_id=g.current_admin.id).first()
    if not hook:
        return error("Webhook not found", 404, "webhook_not_found")
    hook.enabled = False
    audit("webhook.disabled", actor=g.current_admin, session=g.current_session, entity_type="webhook_subscription", entity_id=hook.id)
    db.session.commit()
    return jsonify({"webhook": hook.to_dict()})


@bp.get("/webhook-deliveries")
@require_admin(permission="integrations.manage")
def deliveries():
    query = WebhookDelivery.query.join(WebhookSubscription).filter(WebhookSubscription.admin_id == g.current_admin.id)
    status = request.args.get("status", "").strip()
    if status:
        query = query.filter(WebhookDelivery.status == status)
    pagination = paginate(query.order_by(WebhookDelivery.created_at.desc()), default_per_page=50, max_per_page=200)
    db.session.commit()
    return jsonify({"items": [delivery.to_dict() for delivery in pagination.items], "total": pagination.total})


@bp.post("/webhook-deliveries/<delivery_id>/retry")
@require_admin(permission="integrations.manage")
def retry_delivery(delivery_id: str):
    delivery = WebhookDelivery.query.join(WebhookSubscription).filter(WebhookDelivery.id == delivery_id, WebhookSubscription.admin_id == g.current_admin.id).first()
    if not delivery:
        return error("Webhook delivery not found", 404, "webhook_delivery_not_found")
    attempt_delivery(delivery)
    audit("webhook.delivery_retried", actor=g.current_admin, session=g.current_session, entity_type="webhook_delivery", entity_id=delivery.id)
    db.session.commit()
    return jsonify({"delivery": delivery.to_dict()})
