from __future__ import annotations

import secrets
import string
from datetime import datetime, timedelta, timezone
from urllib.parse import quote_plus

from email_validator import EmailNotValidError, validate_email
from flask import Blueprint, current_app, g, jsonify, request
from sqlalchemy import func, or_

from ..decorators import error, paginate, require_admin
from ..emailer import send_meeting_invite_email
from ..extensions import db, socketio
from ..livekit_service import create_room_token, livekit_public_url, mute_tracks, remove_participant as livekit_remove_participant, update_permissions
from ..models import AdminAccount, MediaRegion, Meeting, MeetingDraft, MeetingInvitation, MeetingParticipant, MeetingRoleAssignment, MeetingTemplate, ChatMessage, Recording, WhiteboardElement, Poll, PollVote, BreakoutAssignment, new_id, utcnow
from ..permissions import has_permission
from ..security import audit, aware, client_ip, create_participant_token, decode_participant_token, token_hash, user_agent
from ..webhooks import dispatch_webhook

bp = Blueprint("meetings", __name__)

MEETING_ROLES = {"meeting_admin", "cohost", "moderator", "presenter"}
MEETING_ROLE_PERMISSIONS = [
    "waiting.admit", "waiting.reject", "waiting.ban", "meeting.start", "meeting.end", "meeting.lock", "participants.remove", "participants.mute", "participants.mute_all", "participants.camera.disable",
    "sharing.grant", "sharing.revoke", "whiteboard.grant", "whiteboard.revoke", "recording.start", "recording.pause", "recording.stop", "breakouts.manage", "polls.manage", "qna.manage",
    "chat.manage", "files.manage", "cohosts.manage", "presenter.change", "participants.pin", "analytics.view", "attendance.view", "captions.manage", "ai_transcription.manage", "recordings.download",
]
ROLE_DEFAULT_PERMISSIONS = {
    "meeting_admin": MEETING_ROLE_PERMISSIONS,
    "cohost": ["waiting.admit", "waiting.reject", "waiting.ban", "meeting.lock", "meeting.end", "participants.mute", "participants.remove", "participants.camera.disable", "sharing.grant", "sharing.revoke", "whiteboard.grant", "whiteboard.revoke", "recording.start", "recording.pause", "recording.stop", "breakouts.manage", "polls.manage", "qna.manage", "chat.manage", "presenter.change", "participants.pin"],
    "moderator": ["waiting.admit", "waiting.reject", "participants.mute", "chat.manage", "polls.manage", "qna.manage"],
    "presenter": ["sharing.grant", "whiteboard.grant", "presenter.change"],
}


def role_permissions(role: str, requested: list[str] | None = None) -> list[str]:
    allowed = set(MEETING_ROLE_PERMISSIONS)
    if requested is None:
        requested = ROLE_DEFAULT_PERMISSIONS.get(role, [])
    return sorted({str(item) for item in requested if str(item) in allowed})


def parse_datetime(value: str | None, field: str):
    if not value:
        raise ValueError(f"{field} is required")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(f"{field} must be an ISO-8601 datetime") from exc
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def optional_datetime(value: str | None, field: str):
    if not value:
        return None
    return parse_datetime(value, field)


def generate_meeting_id() -> str:
    alphabet = string.ascii_lowercase + string.digits
    while True:
        value = "-".join("".join(secrets.choice(alphabet) for _ in range(3)) for _ in range(3))
        if not Meeting.query.filter_by(meeting_id=value).first():
            return value


def generate_invitation_token() -> str:
    while True:
        token = secrets.token_urlsafe(32)
        if len(token) >= 32 and not MeetingInvitation.query.filter_by(token=token).first():
            return token


def invitation_url(token: str) -> str:
    return f"{current_app.config['PUBLIC_APP_URL'].rstrip('/')}/invite/{token}"


def generate_livekit_room(meeting_id: str) -> str:
    return f"{current_app.config['LIVEKIT_ROOM_PREFIX']}-{meeting_id}"


def add_recurrence_delta(value: datetime, recurrence_type: str, occurrence_index: int, interval: int = 1) -> datetime:
    if occurrence_index == 0 or recurrence_type == "none":
        return value
    step = max(1, interval) * occurrence_index
    if recurrence_type == "daily":
        return value + timedelta(days=step)
    if recurrence_type == "weekly":
        return value + timedelta(weeks=step)
    if recurrence_type == "custom":
        return value + timedelta(days=step)
    if recurrence_type == "monthly":
        month_index = value.month - 1 + step
        year = value.year + month_index // 12
        month = month_index % 12 + 1
        day = min(value.day, 28)
        return value.replace(year=year, month=month, day=day)
    if recurrence_type == "yearly":
        return value.replace(year=value.year + step, day=min(value.day, 28))
    return value


def validate_template_payload(data: dict, partial: bool = False) -> dict:
    result: dict = {}
    if not partial or "name" in data:
        name = str(data.get("name", "")).strip()
        if len(name) < 2 or len(name) > 160:
            raise ValueError("Template name must be between 2 and 160 characters")
        result["name"] = name
    if not partial or "title" in data:
        title = str(data.get("title", "")).strip()
        if len(title) < 3 or len(title) > 200:
            raise ValueError("Template title must be between 3 and 200 characters")
        result["title"] = title
    if "description" in data:
        result["description"] = (str(data.get("description") or "").strip() or None)
    if not partial or "durationMinutes" in data:
        duration = int(data.get("durationMinutes") or 60)
        if duration < 5 or duration > 1440:
            raise ValueError("Template duration must be between 5 and 1440 minutes")
        result["duration_minutes"] = duration
    if "timezone" in data or not partial:
        result["timezone"] = str(data.get("timezone") or "UTC")[:80]
    for api_key, attr in {"waitingRoomEnabled": "waiting_room_enabled", "joinBeforeHost": "join_before_host", "hostOnlyStart": "host_only_start", "allowParticipantAudio": "allow_participant_audio", "allowParticipantVideo": "allow_participant_video", "allowChat": "allow_chat", "allowScreenShare": "allow_screen_share"}.items():
        if api_key in data or not partial:
            result[attr] = bool(data.get(api_key, True if attr not in {"join_before_host", "host_only_start"} else False))
    return result


def sanitize_advanced_settings(data: dict) -> dict:
    if not isinstance(data, dict):
        raise ValueError("advancedSettings must be an object")
    allowed_meeting_types = {"general", "webinar", "training", "interview", "support", "custom"}
    allowed_recording_roles = {"disabled", "host", "host_cohost", "everyone"}
    allowed_recording_modes = {"presentation", "screen_only", "camera_only", "gallery"}
    allowed_storage = {"local", "server", "cloud", "hybrid"}
    allowed_share = {"host", "cohosts", "approved", "all"}
    allowed_whiteboard = {"host", "cohosts", "approved", "all"}
    allowed_chat = {"disabled", "host", "everyone"}
    cleaned: dict = {}
    basic = data.get("basic") if isinstance(data.get("basic"), dict) else {}
    meeting_type = str(basic.get("meetingType") or "general")
    if meeting_type not in allowed_meeting_types:
        raise ValueError("meetingType is invalid")
    tags = basic.get("tags") or []
    if isinstance(tags, str):
        tags = [item.strip() for item in tags.split(",") if item.strip()]
    if not isinstance(tags, list) or len(tags) > 20:
        raise ValueError("Meeting tags must be a list with at most 20 values")
    cleaned["basic"] = {
        "meetingType": meeting_type,
        "category": str(basic.get("category") or "").strip()[:80],
        "tags": [str(item).strip()[:40] for item in tags if str(item).strip()][:20],
        "color": str(basic.get("color") or "#2563eb")[:20],
        "customType": str(basic.get("customType") or "").strip()[:80],
    }
    recording = data.get("recording") if isinstance(data.get("recording"), dict) else {}
    role = str(recording.get("permission") or "host")
    mode = str(recording.get("mode") or "presentation")
    storage = str(recording.get("storage") or "server")
    if role not in allowed_recording_roles or mode not in allowed_recording_modes or storage not in allowed_storage:
        raise ValueError("Recording settings contain invalid values")
    retention = int(recording.get("retentionDays") or 30)
    if retention < 1 or retention > 3650:
        raise ValueError("Recording retention must be between 1 and 3650 days")
    cleaned["recording"] = {"permission": role, "mode": mode, "autoRecord": bool(recording.get("autoRecord", False)), "storage": storage, "retentionDays": retention, "watermark": bool(recording.get("watermark", False))}
    sharing = data.get("screenSharing") if isinstance(data.get("screenSharing"), dict) else {}
    share_policy = str(sharing.get("whoCanShare") or "all")
    if share_policy not in allowed_share:
        raise ValueError("Screen sharing policy is invalid")
    cleaned["screenSharing"] = {"whoCanShare": share_policy, "participantRequests": bool(sharing.get("participantRequests", True)), "hostApprovalRequired": bool(sharing.get("hostApprovalRequired", False)), "multiplePresenters": bool(sharing.get("multiplePresenters", False)), "systemAudio": bool(sharing.get("systemAudio", True))}
    whiteboard = data.get("whiteboard") if isinstance(data.get("whiteboard"), dict) else {}
    whiteboard_policy = str(whiteboard.get("whoCanUse") or "all")
    if whiteboard_policy not in allowed_whiteboard:
        raise ValueError("Whiteboard policy is invalid")
    cleaned["whiteboard"] = {"enabled": bool(whiteboard.get("enabled", True)), "whoCanUse": whiteboard_policy, "collaborativeEditing": bool(whiteboard.get("collaborativeEditing", True)), "autoSave": bool(whiteboard.get("autoSave", True))}
    chat = data.get("chat") if isinstance(data.get("chat"), dict) else {}
    chat_policy = str(chat.get("whoCanChat") or "everyone")
    if chat_policy not in allowed_chat:
        raise ValueError("Chat policy is invalid")
    max_upload = int(chat.get("maxUploadMb") or current_app.config.get("MAX_CHAT_FILE_MB", 25))
    if max_upload < 1 or max_upload > 200:
        raise ValueError("Maximum chat upload must be between 1 and 200 MB")
    cleaned["chat"] = {"whoCanChat": chat_policy, "privateChat": bool(chat.get("privateChat", True)), "fileSharing": bool(chat.get("fileSharing", True)), "maxUploadMb": max_upload, "allowedFileTypes": str(chat.get("allowedFileTypes") or "pdf,docx,xlsx,png,jpg,txt")[:200], "messageHistory": bool(chat.get("messageHistory", True)), "moderation": bool(chat.get("moderation", False))}
    audio_video = data.get("audioVideo") if isinstance(data.get("audioVideo"), dict) else {}
    cleaned["audioVideo"] = {"defaultCamera": str(audio_video.get("defaultCamera") or "system")[:80], "defaultMicrophone": str(audio_video.get("defaultMicrophone") or "system")[:80], "noiseSuppression": bool(audio_video.get("noiseSuppression", True)), "echoCancellation": bool(audio_video.get("echoCancellation", True)), "backgroundBlur": bool(audio_video.get("backgroundBlur", False)), "virtualBackground": bool(audio_video.get("virtualBackground", False)), "hdVideo": bool(audio_video.get("hdVideo", True)), "bandwidthOptimization": bool(audio_video.get("bandwidthOptimization", True))}
    security = data.get("security") if isinstance(data.get("security"), dict) else {}
    timeout = int(security.get("sessionTimeoutMinutes") or 120)
    if timeout < 5 or timeout > 1440:
        raise ValueError("Session timeout must be between 5 and 1440 minutes")
    cleaned["security"] = {"requireAuthentication": bool(security.get("requireAuthentication", False)), "watermark": bool(security.get("watermark", False)), "e2ee": bool(security.get("e2ee", False)), "muteOnJoin": bool(security.get("muteOnJoin", False)), "disableRename": bool(security.get("disableRename", False)), "disableUnmute": bool(security.get("disableUnmute", False)), "disableCamera": bool(security.get("disableCamera", False)), "lockAfterStart": bool(security.get("lockAfterStart", False)), "preventAnonymous": bool(security.get("preventAnonymous", False)), "ipRestrictions": str(security.get("ipRestrictions") or "")[:500], "deviceRestrictions": str(security.get("deviceRestrictions") or "")[:500], "sessionTimeoutMinutes": timeout}
    breakout = data.get("breakout") if isinstance(data.get("breakout"), dict) else {}
    max_rooms = int(breakout.get("maxRooms") or 4)
    if max_rooms < 1 or max_rooms > 100:
        raise ValueError("Maximum breakout rooms must be between 1 and 100")
    cleaned["breakout"] = {"enabled": bool(breakout.get("enabled", False)), "assignment": str(breakout.get("assignment") or "automatic")[:40], "maxRooms": max_rooms, "allowChooseRooms": bool(breakout.get("allowChooseRooms", False))}
    polls = data.get("pollsQna") if isinstance(data.get("pollsQna"), dict) else {}
    cleaned["pollsQna"] = {"pollsEnabled": bool(polls.get("pollsEnabled", True)), "qnaEnabled": bool(polls.get("qnaEnabled", True)), "anonymousQuestions": bool(polls.get("anonymousQuestions", False)), "moderation": bool(polls.get("moderation", True)), "pollTemplate": str(polls.get("pollTemplate") or "none")[:80]}
    notifications = data.get("notifications") if isinstance(data.get("notifications"), dict) else {}
    cleaned["notifications"] = {"emailInvitations": bool(notifications.get("emailInvitations", False)), "calendarInvitations": bool(notifications.get("calendarInvitations", True)), "reminderEmails": bool(notifications.get("reminderEmails", False)), "smsReminders": bool(notifications.get("smsReminders", False)), "pushNotifications": bool(notifications.get("pushNotifications", False))}
    invitees = data.get("invitees") if isinstance(data.get("invitees"), dict) else {}
    emails = invitees.get("emails") or []
    if isinstance(emails, str):
        emails = [item.strip() for item in emails.replace(";", ",").split(",") if item.strip()]
    if not isinstance(emails, list) or len(emails) > 100:
        raise ValueError("Invitee emails must be a list with at most 100 values")
    cleaned["invitees"] = {"emails": [str(item).strip()[:254] for item in emails if str(item).strip()][:100], "inviteByLink": bool(invitees.get("inviteByLink", True))}
    return cleaned


def validate_payload(data: dict, partial: bool = False) -> dict:
    result: dict = {}
    if not partial or "title" in data:
        title = str(data.get("title", "")).strip()
        if len(title) < 3 or len(title) > 200:
            raise ValueError("Title must be between 3 and 200 characters")
        result["title"] = title
    if "description" in data:
        description = str(data.get("description") or "").strip()
        result["description"] = description[:5000] if description else None
    if not partial or "scheduledStartAt" in data:
        result["scheduled_start_at"] = parse_datetime(data.get("scheduledStartAt"), "scheduledStartAt")
    if not partial or "scheduledEndAt" in data:
        result["scheduled_end_at"] = parse_datetime(data.get("scheduledEndAt"), "scheduledEndAt")
    if "scheduled_start_at" in result and "scheduled_end_at" in result and result["scheduled_end_at"] <= result["scheduled_start_at"]:
        raise ValueError("scheduledEndAt must be after scheduledStartAt")
    if "timezone" in data or not partial:
        timezone_name = str(data.get("timezone") or "UTC").strip()
        if len(timezone_name) > 80:
            raise ValueError("timezone is too long")
        result["timezone"] = timezone_name or "UTC"
    if "linkExpiresAt" in data:
        expires = optional_datetime(data.get("linkExpiresAt"), "linkExpiresAt")
        if expires and "scheduled_end_at" in result and expires < result["scheduled_end_at"]:
            raise ValueError("linkExpiresAt cannot be before scheduledEndAt")
        result["link_expires_at"] = expires
    if "reminderMinutes" in data or not partial:
        reminder = int(data.get("reminderMinutes") if data.get("reminderMinutes") not in (None, "") else 10)
        if reminder < 0 or reminder > 10080:
            raise ValueError("reminderMinutes must be between 0 and 10080")
        result["reminder_minutes"] = reminder
    if "waitingRoomEnabled" in data or not partial:
        result["waiting_room_enabled"] = bool(data.get("waitingRoomEnabled", True))
    if "joinBeforeHost" in data or not partial:
        result["join_before_host"] = bool(data.get("joinBeforeHost", False))
    if "hostOnlyStart" in data or not partial:
        result["host_only_start"] = bool(data.get("hostOnlyStart", False))
    for api_key, attr in {"allowParticipantAudio": "allow_participant_audio", "allowParticipantVideo": "allow_participant_video", "allowChat": "allow_chat", "allowScreenShare": "allow_screen_share", "allowWhiteboard": "allow_whiteboard"}.items():
        if api_key in data:
            result[attr] = bool(data.get(api_key))
    if "screenSharePolicy" in data:
        policy = str(data.get("screenSharePolicy") or "all")
        if policy not in {"host", "cohosts", "all"}:
            raise ValueError("screenSharePolicy must be host, cohosts, or all")
        result["screen_share_policy"] = policy
    if "recurrenceType" in data or not partial:
        recurrence_type = str(data.get("recurrenceType") or "none")
        if recurrence_type not in {"none", "daily", "weekly", "monthly", "yearly", "custom"}:
            raise ValueError("recurrenceType must be none, daily, weekly, monthly, yearly, or custom")
        result["recurrence_type"] = recurrence_type
    if "recurrenceCount" in data or not partial:
        recurrence_count = int(data.get("recurrenceCount") or 1)
        if recurrence_count < 1 or recurrence_count > 52:
            raise ValueError("recurrenceCount must be between 1 and 52")
        result["recurrence_count"] = recurrence_count
    if "recurrenceInterval" in data:
        recurrence_interval = int(data.get("recurrenceInterval") or 1)
        if recurrence_interval < 1 or recurrence_interval > 365:
            raise ValueError("recurrenceInterval must be between 1 and 365")
        result["recurrence_interval"] = recurrence_interval
    if "templateId" in data:
        result["template_id"] = str(data.get("templateId") or "") or None
    if "maxParticipants" in data:
        raw = data.get("maxParticipants")
        result["max_participants"] = int(raw) if raw not in (None, "") else None
        if result["max_participants"] is not None and (result["max_participants"] < 1 or result["max_participants"] > 10000):
            raise ValueError("maxParticipants must be between 1 and 10000")
    meeting_id_mode = str(data.get("meetingIdMode") or "auto")
    if meeting_id_mode not in {"auto", "personal", "custom"}:
        raise ValueError("meetingIdMode must be auto, personal, or custom")
    result["meeting_id_mode"] = meeting_id_mode
    if meeting_id_mode == "custom":
        requested = str(data.get("customMeetingId") or data.get("meetingId") or "").strip().lower()
        allowed = string.ascii_lowercase + string.digits + "-"
        if len(requested) < 3 or len(requested) > 32 or any(ch not in allowed for ch in requested):
            raise ValueError("Custom meeting ID must be 3-32 lowercase letters, numbers, or hyphens")
        if Meeting.query.filter_by(meeting_id=requested).first():
            raise ValueError("Meeting ID already exists")
        result["requested_meeting_id"] = requested
    if "advancedSettings" in data:
        result["advanced_settings"] = sanitize_advanced_settings(data.get("advancedSettings") or {})
    password = data.get("password", None)
    if password is not None:
        password = str(password)
        if password and len(password) < 6:
            raise ValueError("Meeting password must be at least 6 characters when provided")
        result["password"] = password or None
    return result


def meeting_by_id(identifier: str) -> Meeting | None:
    return Meeting.query.filter((Meeting.id == identifier) | (Meeting.meeting_id == identifier)).first()


def attach_participant_counts(meetings: list[Meeting]) -> list[Meeting]:
    ids = [meeting.id for meeting in meetings]
    if not ids:
        return meetings
    counts = dict(db.session.query(MeetingParticipant.meeting_id, func.count(MeetingParticipant.id)).filter(MeetingParticipant.meeting_id.in_(ids)).group_by(MeetingParticipant.meeting_id).all())
    for meeting in meetings:
        setattr(meeting, "_participant_count_override", int(counts.get(meeting.id, 0)))
    return meetings


def invitation_available(meeting: Meeting):
    if meeting.status == "cancelled":
        return error("Meeting is cancelled", 409, "meeting_cancelled")
    if meeting.status == "completed":
        return error("Meeting has ended", 409, "meeting_ended")
    if meeting.link_expires_at and aware(meeting.link_expires_at) <= utcnow():
        return error("Invitation link has expired", 410, "invitation_expired")
    return None


def participant_from_bearer(meeting: Meeting) -> MeetingParticipant | None:
    header = request.headers.get("Authorization", "")
    if not header.startswith("Bearer "):
        return None
    try:
        claims = decode_participant_token(header.removeprefix("Bearer ").strip())
    except Exception:
        return None
    participant = db.session.get(MeetingParticipant, claims["sub"])
    if not participant or participant.meeting_id != meeting.id or participant.participant_token_hash != token_hash(header.removeprefix("Bearer ").strip()):
        return None
    return participant


def host_controls(participant: MeetingParticipant) -> dict:
    device_info = participant.device_info if isinstance(participant.device_info, dict) else {}
    controls = device_info.get("hostControls") if isinstance(device_info, dict) else {}
    return dict(controls) if isinstance(controls, dict) else {}


def set_host_control(participant: MeetingParticipant, key: str, value):
    device_info = dict(participant.device_info or {})
    controls = dict(device_info.get("hostControls") or {})
    if value is None:
        controls.pop(key, None)
    else:
        controls[key] = value
    device_info["hostControls"] = controls
    participant.device_info = device_info


def cohost_permissions(participant: MeetingParticipant) -> set[str]:
    controls = host_controls(participant)
    values = controls.get("cohostPermissions") or []
    return {str(item) for item in values if str(item)} if isinstance(values, list) else set()


def participant_action_permissions(action: str) -> set[str]:
    mapping = {
        "participants.view_private": {"participants.manage", "waiting.admit", "waiting.reject", "waiting.ban"},
        "admit": {"participants.manage", "waiting.admit"},
        "reject": {"participants.manage", "waiting.reject"},
        "ban": {"participants.manage", "waiting.ban"},
        "mute": {"participants.manage", "participants.mute"},
        "ask_unmute": {"participants.manage", "participants.mute"},
        "disable_audio": {"participants.manage", "participants.mute"},
        "enable_audio": {"participants.manage", "participants.mute"},
        "disable_video": {"participants.manage", "participants.camera.disable"},
        "enable_video": {"participants.manage", "participants.camera.disable"},
        "grant_screen_share": {"participants.manage", "sharing.grant"},
        "revoke_screen_share": {"participants.manage", "sharing.revoke"},
        "grant_whiteboard": {"participants.manage", "whiteboard.grant"},
        "revoke_whiteboard": {"participants.manage", "whiteboard.revoke"},
        "change_presenter": {"participants.manage", "presenter.change"},
        "clear_presenter": {"participants.manage", "presenter.change"},
        "pin": {"participants.manage", "participants.pin"},
        "unpin": {"participants.manage", "participants.pin"},
        "spotlight": {"participants.manage", "participants.pin"},
        "clear_spotlight": {"participants.manage", "participants.pin"},
        "rename": {"participants.manage", "participants.rename"},
        "remove": {"participants.manage", "participants.remove"},
        "move_waiting": {"participants.manage", "participants.remove"},
        "stop_screen_share": {"participants.manage", "sharing.revoke"},
    }
    return mapping.get(action, {action, "participants.manage"})


def participant_can_manage(actor: MeetingParticipant, action: str) -> bool:
    if actor.role == "host":
        return True
    if actor.role != "cohost":
        return False
    permissions = cohost_permissions(actor)
    return bool(permissions.intersection(participant_action_permissions(action)))


def participant_whiteboard_allowed(meeting: Meeting, participant: MeetingParticipant) -> bool:
    controls = host_controls(participant)
    if participant.role in {"host", "cohost"}:
        return True
    if controls.get("whiteboardRevoked"):
        return False
    return bool(meeting.allow_whiteboard or controls.get("whiteboardGranted"))


def can_share_screen(meeting: Meeting, participant: MeetingParticipant) -> bool:
    controls = host_controls(participant)
    if participant.screen_share_disabled or controls.get("screenShareRevoked"):
        return False
    if controls.get("screenShareGranted"):
        return True
    if not meeting.allow_screen_share:
        return False
    if meeting.screen_share_policy == "host":
        return participant.role == "host"
    if meeting.screen_share_policy == "cohosts":
        return participant.role in {"host", "cohost"}
    return participant.role in {"host", "cohost", "participant"}


def publish_sources(meeting: Meeting, participant: MeetingParticipant) -> list[str]:
    if participant.audio_only_mode:
        return [] if participant.audio_disabled else ["microphone"]
    if participant.role in {"host", "cohost"}:
        sources = ["camera", "microphone"]
    else:
        sources = []
        if meeting.allow_participant_video and not participant.video_disabled:
            sources.append("camera")
        if meeting.allow_participant_audio and not participant.audio_disabled:
            sources.append("microphone")
    if can_share_screen(meeting, participant):
        sources.extend(["screen_share", "screen_share_audio"])
    return sources


def sync_livekit_permissions(meeting: Meeting, participant: MeetingParticipant) -> None:
    if participant.status == "admitted":
        update_permissions(meeting.livekit_room_name, participant.id, publish_sources(meeting, participant), participant.role in {"host", "cohost"})


def sync_all_livekit_permissions(meeting: Meeting) -> None:
    for participant in MeetingParticipant.query.filter_by(meeting_id=meeting.id, status="admitted").all():
        sync_livekit_permissions(meeting, participant)


def apply_participant_preferences(participant: MeetingParticipant, data: dict) -> None:
    if "displayName" in data:
        display_name = str(data.get("displayName") or "").strip()
        if len(display_name) < 2 or len(display_name) > 120:
            raise ValueError("Display name must be between 2 and 120 characters")
        participant.display_name = display_name
    if "microphoneEnabled" in data:
        enabled = bool(data["microphoneEnabled"])
        if enabled and participant.audio_disabled:
            enabled = False
        participant.muted = not enabled
    if "cameraEnabled" in data:
        enabled = bool(data["cameraEnabled"])
        if enabled and participant.video_disabled:
            enabled = False
        participant.camera_enabled = enabled
    if "handRaised" in data:
        raised = bool(data["handRaised"])
        set_host_control(participant, "handRaised", raised)
        set_host_control(participant, "handRaisedAt", utcnow().isoformat() if raised else None)
    if "lowBandwidthMode" in data:
        participant.low_bandwidth_mode = bool(data["lowBandwidthMode"])
    if "audioOnlyMode" in data:
        participant.audio_only_mode = bool(data["audioOnlyMode"])
        if participant.audio_only_mode:
            participant.camera_enabled = False
            participant.screen_sharing = False
            participant.screen_share_paused = False
    if "preferredLayout" in data:
        layout = str(data.get("preferredLayout") or "auto")
        if layout not in {"auto", "mobile", "gallery", "speaker"}:
            raise ValueError("preferredLayout must be auto, mobile, gallery, or speaker")
        participant.preferred_layout = layout
    if "mobileClient" in data:
        participant.mobile_client = bool(data["mobileClient"])
    if "networkType" in data:
        participant.network_type = str(data.get("networkType") or "")[:80] or None
    if "deviceInfo" in data and isinstance(data["deviceInfo"], dict):
        merged = dict(participant.device_info or {})
        safe_device_info = dict(data["deviceInfo"])
        safe_device_info.pop("hostControls", None)
        merged.update(safe_device_info)
        participant.device_info = merged
    if "qualityReport" in data and isinstance(data["qualityReport"], dict):
        participant.last_quality_report = data["qualityReport"]


def selected_livekit_url(participant: MeetingParticipant) -> str:
    region_code = (participant.device_info or {}).get("selectedRegion")
    if region_code:
        region = MediaRegion.query.filter_by(code=str(region_code), enabled=True).first()
        if region:
            return region.livekit_url
    return livekit_public_url()


def livekit_payload(meeting: Meeting, participant: MeetingParticipant):
    return {
        "url": selected_livekit_url(participant),
        "token": create_room_token(identity=participant.id, name=participant.display_name, room=meeting.livekit_room_name, role=participant.role, sources=publish_sources(meeting, participant)),
        "roomName": meeting.livekit_room_name,
    }


def public_meeting_dict(meeting: Meeting):
    data = meeting.to_dict(include_private=False)
    data["waitingRoomEnabled"] = meeting.waiting_room_enabled
    data["maxParticipants"] = meeting.max_participants
    return data


@bp.get("/templates")
@require_admin(permission="meetings.manage")
def list_templates():
    templates = MeetingTemplate.query.filter_by(admin_id=g.current_admin.id).order_by(MeetingTemplate.created_at.desc()).all()
    db.session.commit()
    return jsonify({"items": [template.to_dict() for template in templates], "total": len(templates)})


@bp.post("/templates")
@require_admin(permission="meetings.manage")
def create_template():
    data = request.get_json(silent=True) or {}
    try:
        values = validate_template_payload(data)
    except (ValueError, TypeError) as exc:
        return error(str(exc), 400, "validation_error")
    template = MeetingTemplate(admin_id=g.current_admin.id, **values)
    db.session.add(template)
    db.session.flush()
    audit("meeting_template.created", actor=g.current_admin, session=g.current_session, entity_type="meeting_template", entity_id=template.id)
    db.session.commit()
    return jsonify({"template": template.to_dict()}), 201


@bp.patch("/templates/<template_id>")
@require_admin(permission="meetings.manage")
def update_template(template_id: str):
    template = MeetingTemplate.query.filter_by(id=template_id, admin_id=g.current_admin.id).first()
    if not template:
        return error("Meeting template not found", 404, "template_not_found")
    data = request.get_json(silent=True) or {}
    try:
        values = validate_template_payload(data, partial=True)
    except (ValueError, TypeError) as exc:
        return error(str(exc), 400, "validation_error")
    for key, value in values.items():
        setattr(template, key, value)
    audit("meeting_template.updated", actor=g.current_admin, session=g.current_session, entity_type="meeting_template", entity_id=template.id)
    db.session.commit()
    return jsonify({"template": template.to_dict()})


@bp.delete("/templates/<template_id>")
@require_admin(permission="meetings.manage")
def delete_template(template_id: str):
    template = MeetingTemplate.query.filter_by(id=template_id, admin_id=g.current_admin.id).first()
    if not template:
        return error("Meeting template not found", 404, "template_not_found")
    audit("meeting_template.deleted", actor=g.current_admin, session=g.current_session, entity_type="meeting_template", entity_id=template.id)
    db.session.delete(template)
    db.session.commit()
    return jsonify({"message": "Template deleted"})


@bp.get("/personal-room")
@require_admin(permission="meetings.manage")
def get_personal_room():
    room = Meeting.query.filter_by(admin_id=g.current_admin.id, personal_meeting=True).first()
    if not room:
        meeting_id = g.current_admin.personal_meeting_id or generate_meeting_id()
        g.current_admin.personal_meeting_id = meeting_id
        now = utcnow()
        room = Meeting(
            admin_id=g.current_admin.id,
            meeting_id=meeting_id,
            livekit_room_name=generate_livekit_room(meeting_id),
            title="Personal Meeting Room",
            scheduled_start_at=now,
            scheduled_end_at=now + timedelta(days=3650),
            timezone="UTC",
            status="scheduled",
            waiting_room_enabled=True,
            join_before_host=True,
            host_only_start=False,
            personal_meeting=True,
            recurrence_type="none",
            recurrence_count=1,
        )
        db.session.add(room)
        db.session.flush()
        token = generate_invitation_token()
        db.session.add(MeetingInvitation(meeting_id=room.id, token=token, url=invitation_url(token)))
        audit("meeting.personal_room_created", actor=g.current_admin, session=g.current_session, entity_type="meeting", entity_id=room.id)
        db.session.commit()
    return jsonify({"meeting": room.to_dict(include_private=True), "invitation": room.invitation.to_dict()})


@bp.post("/instant")
@require_admin(permission="meetings.manage")
def create_instant_meeting():
    now = utcnow()
    request._cached_json = ({
        "title": (request.get_json(silent=True) or {}).get("title") or "Instant Meeting",
        "description": (request.get_json(silent=True) or {}).get("description"),
        "scheduledStartAt": now.isoformat(),
        "scheduledEndAt": (now + timedelta(hours=1)).isoformat(),
        "timezone": "UTC",
        "waitingRoomEnabled": bool((request.get_json(silent=True) or {}).get("waitingRoomEnabled", True)),
        "joinBeforeHost": False,
        "hostOnlyStart": False,
        "password": (request.get_json(silent=True) or {}).get("password"),
    }, None)
    return create_meeting()


@bp.get("")
@require_admin(permission="meetings.manage")
def list_meetings():
    query = Meeting.query.filter_by(admin_id=g.current_admin.id)
    q = request.args.get("q", "").strip()
    status = request.args.get("status", "").strip()
    if q:
        like = f"%{q}%"
        query = query.filter((Meeting.title.ilike(like)) | (Meeting.meeting_id.ilike(like)))
    if status:
        query = query.filter_by(status=status)
    pagination = paginate(query.order_by(Meeting.scheduled_start_at.desc(), Meeting.created_at.desc()), default_per_page=20, max_per_page=100)
    items = attach_participant_counts(list(pagination.items))
    db.session.commit()
    return jsonify({"items": [meeting.to_dict(include_private=True) for meeting in items], "total": pagination.total})


@bp.get("/check-id/<meeting_id>")
@require_admin(permission="meetings.manage")
def check_meeting_id(meeting_id: str):
    value = str(meeting_id or "").strip().lower()
    allowed = string.ascii_lowercase + string.digits + "-"
    valid = 3 <= len(value) <= 32 and all(ch in allowed for ch in value)
    available = bool(valid and not Meeting.query.filter_by(meeting_id=value).first())
    db.session.commit()
    return jsonify({"meetingId": value, "valid": valid, "available": available})


@bp.post("/conflicts")
@require_admin(permission="meetings.manage")
def meeting_conflicts():
    data = request.get_json(silent=True) or {}
    try:
        start_at = parse_datetime(data.get("scheduledStartAt"), "scheduledStartAt")
        end_at = parse_datetime(data.get("scheduledEndAt"), "scheduledEndAt")
    except ValueError as exc:
        return error(str(exc), 400, "validation_error")
    if end_at <= start_at:
        return error("scheduledEndAt must be after scheduledStartAt", 400, "validation_error")
    exclude_id = str(data.get("excludeMeetingId") or "")
    query = Meeting.query.filter(
        Meeting.admin_id == g.current_admin.id,
        Meeting.status.in_(["scheduled", "running"]),
        Meeting.scheduled_start_at < end_at,
        Meeting.scheduled_end_at > start_at,
    )
    if exclude_id:
        query = query.filter(Meeting.id != exclude_id)
    items = query.order_by(Meeting.scheduled_start_at.asc()).limit(20).all()
    db.session.commit()
    return jsonify({"items": [item.to_dict(include_private=True) for item in items], "total": len(items), "hasConflicts": bool(items)})


@bp.get("/drafts")
@require_admin(permission="meetings.manage")
def list_drafts():
    drafts = MeetingDraft.query.filter_by(admin_id=g.current_admin.id).order_by(MeetingDraft.updated_at.desc()).limit(50).all()
    db.session.commit()
    return jsonify({"items": [draft.to_dict() for draft in drafts], "total": len(drafts)})


@bp.post("/drafts")
@require_admin(permission="meetings.manage")
def create_draft():
    data = request.get_json(silent=True) or {}
    payload = data.get("payload") if isinstance(data.get("payload"), dict) else data
    title = str(payload.get("title") or data.get("title") or "Untitled meeting draft").strip()[:220] or "Untitled meeting draft"
    draft = MeetingDraft(admin_id=g.current_admin.id, title=title, payload_json=payload)
    db.session.add(draft)
    audit("meeting_draft.created", actor=g.current_admin, session=g.current_session, entity_type="meeting_draft", entity_id=draft.id)
    db.session.commit()
    return jsonify({"draft": draft.to_dict()}), 201


@bp.patch("/drafts/<draft_id>")
@require_admin(permission="meetings.manage")
def update_draft(draft_id: str):
    draft = MeetingDraft.query.filter_by(id=draft_id, admin_id=g.current_admin.id).first()
    if not draft:
        return error("Draft not found", 404, "draft_not_found")
    data = request.get_json(silent=True) or {}
    payload = data.get("payload") if isinstance(data.get("payload"), dict) else data
    draft.payload_json = payload
    draft.title = str(payload.get("title") or draft.title or "Untitled meeting draft").strip()[:220] or "Untitled meeting draft"
    audit("meeting_draft.updated", actor=g.current_admin, session=g.current_session, entity_type="meeting_draft", entity_id=draft.id)
    db.session.commit()
    return jsonify({"draft": draft.to_dict()})


@bp.delete("/drafts/<draft_id>")
@require_admin(permission="meetings.manage")
def delete_draft(draft_id: str):
    draft = MeetingDraft.query.filter_by(id=draft_id, admin_id=g.current_admin.id).first()
    if not draft:
        return error("Draft not found", 404, "draft_not_found")
    db.session.delete(draft)
    audit("meeting_draft.deleted", actor=g.current_admin, session=g.current_session, entity_type="meeting_draft", entity_id=draft_id)
    db.session.commit()
    return jsonify({"deleted": True, "id": draft_id})


def admin_can_manage_meeting(meeting: Meeting, permission: str | None = None) -> bool:
    if not hasattr(g, "current_admin"):
        return False
    admin = g.current_admin
    if admin.role == "super_admin" or meeting.admin_id == admin.id or has_permission(admin, "meetings.manage"):
        return True
    assignment = MeetingRoleAssignment.query.filter_by(meeting_id=meeting.id, admin_id=admin.id, active=True).filter(MeetingRoleAssignment.revoked_at.is_(None)).first()
    if not assignment:
        return False
    if assignment.role == "meeting_admin":
        return True
    return bool(permission and permission in (assignment.permissions_json or []))


def roles_meeting(identifier: str, permission: str | None = None):
    meeting = meeting_by_id(identifier)
    if not meeting:
        return None, error("Meeting not found", 404, "meeting_not_found")
    if not admin_can_manage_meeting(meeting, permission):
        return None, error("Meeting administration permission is required", 403, "meeting_admin_required")
    return meeting, None


def sync_assignment_to_participant(assignment: MeetingRoleAssignment) -> None:
    participant = assignment.participant
    if not participant:
        return
    if assignment.active and assignment.revoked_at is None:
        if assignment.role == "cohost":
            participant.role = "cohost"
        elif assignment.role in {"moderator", "presenter"}:
            participant.role = assignment.role
        set_host_control(participant, "cohostPermissions", assignment.permissions_json or [])
        set_host_control(participant, "meetingRoleAssignmentId", assignment.id)
    else:
        if participant.role in {"cohost", "moderator", "presenter"}:
            participant.role = "participant"
        set_host_control(participant, "cohostPermissions", [])
        set_host_control(participant, "meetingRoleAssignmentId", None)


@bp.get("/<identifier>/role-candidates")
@require_admin
def role_candidates(identifier: str):
    meeting, err = roles_meeting(identifier, "cohosts.manage")
    if err:
        return err
    q = request.args.get("q", "").strip().lower()
    admin_query = AdminAccount.query.filter_by(status="active")
    participant_query = MeetingParticipant.query.filter_by(meeting_id=meeting.id)
    if q:
        like = f"%{q}%"
        admin_query = admin_query.filter((AdminAccount.email.ilike(like)) | (AdminAccount.display_name.ilike(like)))
        participant_query = participant_query.filter(MeetingParticipant.display_name.ilike(like))
    admins = admin_query.order_by(AdminAccount.display_name.asc()).limit(25).all()
    participants = participant_query.order_by(MeetingParticipant.display_name.asc()).limit(25).all()
    items = []
    for admin in admins:
        items.append({"subjectType": "admin", "id": admin.id, "displayName": admin.display_name, "email": admin.email, "role": admin.role, "department": "", "organization": "Defensiq Security"})
    for participant in participants:
        info = participant.device_info if isinstance(participant.device_info, dict) else {}
        items.append({"subjectType": "participant", "id": participant.id, "displayName": participant.display_name, "email": info.get("email"), "role": participant.role, "department": info.get("department", ""), "organization": info.get("organization", "")})
    db.session.commit()
    return jsonify({"items": items, "total": len(items)})


@bp.get("/<identifier>/roles")
@require_admin
def list_meeting_roles(identifier: str):
    meeting, err = roles_meeting(identifier, "cohosts.manage")
    if err:
        return err
    assignments = MeetingRoleAssignment.query.filter_by(meeting_id=meeting.id).order_by(MeetingRoleAssignment.role.asc(), MeetingRoleAssignment.display_name.asc()).all()
    db.session.commit()
    return jsonify({"items": [item.to_dict() for item in assignments], "permissions": MEETING_ROLE_PERMISSIONS, "defaults": ROLE_DEFAULT_PERMISSIONS, "total": len(assignments)})


@bp.post("/<identifier>/roles")
@require_admin
def create_meeting_role(identifier: str):
    meeting, err = roles_meeting(identifier, "cohosts.manage")
    if err:
        return err
    data = request.get_json(silent=True) or {}
    role = str(data.get("role") or "").strip()
    if role not in MEETING_ROLES:
        return error("Unsupported meeting role", 400, "validation_error")
    subject_type = str(data.get("subjectType") or "").strip()
    admin = None
    participant = None
    email = None
    display_name = ""
    if subject_type == "admin":
        admin = db.session.get(AdminAccount, data.get("adminId") or data.get("subjectId"))
        if not admin or admin.status != "active":
            return error("Admin user not found", 404, "admin_not_found")
        email = admin.email
        display_name = admin.display_name
    elif subject_type == "participant":
        participant = MeetingParticipant.query.filter_by(id=data.get("participantId") or data.get("subjectId"), meeting_id=meeting.id).first()
        if not participant:
            return error("Participant not found", 404, "participant_not_found")
        display_name = participant.display_name
        info = participant.device_info if isinstance(participant.device_info, dict) else {}
        email = info.get("email")
    elif subject_type == "external":
        email = str(data.get("email") or "").strip().lower()
        display_name = str(data.get("displayName") or email).strip()[:160]
        if not email:
            return error("External email is required", 400, "validation_error")
    else:
        return error("subjectType must be admin, participant, or external", 400, "validation_error")
    existing = MeetingRoleAssignment.query.filter_by(meeting_id=meeting.id, admin_id=admin.id if admin else None, participant_id=participant.id if participant else None, email=email).first()
    assignment = existing or MeetingRoleAssignment(meeting_id=meeting.id)
    assignment.admin_id = admin.id if admin else None
    assignment.participant_id = participant.id if participant else None
    assignment.email = email
    assignment.display_name = display_name
    assignment.role = role
    assignment.permissions_json = role_permissions(role, data.get("permissions") if isinstance(data.get("permissions"), list) else None)
    assignment.active = True
    assignment.revoked_at = None
    assignment.assigned_by_admin_id = g.current_admin.id
    db.session.add(assignment)
    db.session.flush()
    sync_assignment_to_participant(assignment)
    audit("meeting_role.assigned", actor=g.current_admin, session=g.current_session, entity_type="meeting_role_assignment", entity_id=assignment.id, metadata={"meetingId": meeting.meeting_id, "role": role, "displayName": display_name})
    db.session.commit()
    if participant:
        socketio.emit("participant:updated", participant.to_dict(include_private=True), room=meeting.id)
    socketio.emit("meeting:roles_updated", {"meetingId": meeting.id, "assignment": assignment.to_dict()}, room=meeting.id)
    return jsonify({"assignment": assignment.to_dict(), "meeting": meeting.to_dict(include_private=True)}), 201


@bp.patch("/<identifier>/roles/<assignment_id>")
@require_admin
def update_meeting_role(identifier: str, assignment_id: str):
    meeting, err = roles_meeting(identifier, "cohosts.manage")
    if err:
        return err
    assignment = MeetingRoleAssignment.query.filter_by(id=assignment_id, meeting_id=meeting.id).first()
    if not assignment:
        return error("Role assignment not found", 404, "assignment_not_found")
    data = request.get_json(silent=True) or {}
    if "role" in data:
        role = str(data.get("role"))
        if role not in MEETING_ROLES:
            return error("Unsupported meeting role", 400, "validation_error")
        assignment.role = role
    if "permissions" in data:
        if not isinstance(data.get("permissions"), list):
            return error("permissions must be a list", 400, "validation_error")
        assignment.permissions_json = role_permissions(assignment.role, data.get("permissions"))
    if "active" in data:
        assignment.active = bool(data.get("active"))
        assignment.revoked_at = None if assignment.active else utcnow()
    sync_assignment_to_participant(assignment)
    audit("meeting_role.updated", actor=g.current_admin, session=g.current_session, entity_type="meeting_role_assignment", entity_id=assignment.id, metadata={"meetingId": meeting.meeting_id, "role": assignment.role})
    db.session.commit()
    if assignment.participant:
        socketio.emit("participant:updated", assignment.participant.to_dict(include_private=True), room=meeting.id)
    socketio.emit("meeting:roles_updated", {"meetingId": meeting.id, "assignment": assignment.to_dict()}, room=meeting.id)
    return jsonify({"assignment": assignment.to_dict(), "meeting": meeting.to_dict(include_private=True)})


@bp.delete("/<identifier>/roles/<assignment_id>")
@require_admin
def delete_meeting_role(identifier: str, assignment_id: str):
    meeting, err = roles_meeting(identifier, "cohosts.manage")
    if err:
        return err
    assignment = MeetingRoleAssignment.query.filter_by(id=assignment_id, meeting_id=meeting.id).first()
    if not assignment:
        return error("Role assignment not found", 404, "assignment_not_found")
    assignment.active = False
    assignment.revoked_at = utcnow()
    sync_assignment_to_participant(assignment)
    audit("meeting_role.revoked", actor=g.current_admin, session=g.current_session, entity_type="meeting_role_assignment", entity_id=assignment.id, metadata={"meetingId": meeting.meeting_id, "role": assignment.role})
    db.session.commit()
    if assignment.participant:
        socketio.emit("participant:updated", assignment.participant.to_dict(include_private=True), room=meeting.id)
    socketio.emit("meeting:roles_updated", {"meetingId": meeting.id, "assignment": assignment.to_dict()}, room=meeting.id)
    return jsonify({"assignment": assignment.to_dict(), "deleted": True})


@bp.get("/<identifier>/admin-dashboard")
@require_admin
def meeting_admin_dashboard(identifier: str):
    meeting, err = roles_meeting(identifier, "analytics.view")
    if err:
        return err
    participants = MeetingParticipant.query.filter_by(meeting_id=meeting.id).all()
    waiting = [p for p in participants if p.status == "waiting"]
    admitted = [p for p in participants if p.status == "admitted"]
    recordings = Recording.query.filter_by(meeting_id=meeting.id).all()
    response = {
        "meeting": meeting.to_dict(include_private=True),
        "durationSeconds": int((utcnow() - (aware(meeting.ended_at) or aware(meeting.scheduled_start_at) or utcnow())).total_seconds()) if meeting.status == "running" else 0,
        "participants": {"total": len(participants), "admitted": len(admitted), "waiting": len(waiting)},
        "recording": {"active": any(r.status == "recording" for r in recordings), "total": len(recordings)},
        "screenSharing": {"active": bool(meeting.active_screen_share_participant_id), "participantId": meeting.active_screen_share_participant_id},
        "whiteboard": {"enabled": meeting.allow_whiteboard, "elements": WhiteboardElement.query.filter_by(meeting_id=meeting.id, active=True).count()},
        "chat": {"enabled": meeting.allow_chat, "messages": ChatMessage.query.filter_by(meeting_id=meeting.id).count()},
        "polls": {"active": Poll.query.filter_by(meeting_id=meeting.id, status="open").count()},
        "breakouts": {"activeAssignments": BreakoutAssignment.query.filter_by(meeting_id=meeting.id, status="active").count()},
    }
    db.session.commit()
    return jsonify(response)


def attendance_rows_for(meeting: Meeting) -> list[dict]:
    rows = []
    for participant in MeetingParticipant.query.filter_by(meeting_id=meeting.id).order_by(MeetingParticipant.joined_at.asc()).all():
        joined = aware(participant.joined_at) if participant.joined_at else None
        left = aware(participant.left_at) if participant.left_at else None
        end = left or utcnow()
        rows.append({
            "participantId": participant.id,
            "displayName": participant.display_name,
            "role": participant.role,
            "status": participant.status,
            "joinTime": participant.joined_at.isoformat() if participant.joined_at else None,
            "leaveTime": participant.left_at.isoformat() if participant.left_at else None,
            "attendanceSeconds": int((end - joined).total_seconds()) if joined and end > joined else 0,
            "cameraUsed": bool(participant.camera_enabled),
            "microphoneUsed": not participant.muted,
            "screenSharing": bool(participant.screen_sharing),
            "whiteboardActivity": WhiteboardElement.query.filter_by(meeting_id=meeting.id, actor_participant_id=participant.id).count(),
            "pollVotes": PollVote.query.filter_by(voter_participant_id=participant.id).count(),
            "chatMessages": ChatMessage.query.filter_by(meeting_id=meeting.id, sender_participant_id=participant.id).count(),
        })
    return rows


@bp.get("/<identifier>/attendance")
@require_admin
def meeting_attendance(identifier: str):
    meeting, err = roles_meeting(identifier, "attendance.view")
    if err:
        return err
    rows = attendance_rows_for(meeting)
    db.session.commit()
    return jsonify({"items": rows, "total": len(rows)})


@bp.get("/<identifier>/attendance.csv")
@require_admin
def meeting_attendance_csv(identifier: str):
    meeting, err = roles_meeting(identifier, "attendance.view")
    if err:
        return err
    import csv, io
    rows = attendance_rows_for(meeting)
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=list(rows[0].keys()) if rows else ["displayName"])
    writer.writeheader()
    writer.writerows(rows)
    db.session.commit()
    return current_app.response_class(output.getvalue(), mimetype="text/csv", headers={"Content-Disposition": f"attachment; filename={meeting.meeting_id}-attendance.csv"})


@bp.get("/<identifier>/audit-events")
@require_admin
def meeting_audit_events(identifier: str):
    meeting, err = roles_meeting(identifier, "analytics.view")
    if err:
        return err
    logs = []
    from ..models import AuditLog
    for log in AuditLog.query.filter((AuditLog.entity_id == meeting.id) | (AuditLog.metadata_json["meetingId"].as_string() == meeting.meeting_id)).order_by(AuditLog.created_at.desc()).limit(200).all():
        logs.append(log.to_dict())
    db.session.commit()
    return jsonify({"items": logs, "total": len(logs)})


@bp.post("")
@require_admin(permission="meetings.manage")
def create_meeting():
    data = request.get_json(silent=True) or {}
    template = None
    if data.get("templateId"):
        template = MeetingTemplate.query.filter_by(id=data["templateId"], admin_id=g.current_admin.id).first()
        if not template:
            return error("Meeting template not found", 404, "template_not_found")
        data = {**template.to_dict(), **data}
        if not data.get("scheduledEndAt") and data.get("scheduledStartAt"):
            start = parse_datetime(data["scheduledStartAt"], "scheduledStartAt")
            data["scheduledEndAt"] = (start + timedelta(minutes=template.duration_minutes)).isoformat()
    try:
        values = validate_payload(data)
    except (ValueError, TypeError) as exc:
        return error(str(exc), 400, "validation_error")

    if values.get("meeting_id_mode") == "personal":
        if values.get("recurrence_count", 1) > 1:
            return error("Personal Meeting ID can only be used for one-time meetings", 400, "validation_error")
        room = Meeting.query.filter_by(admin_id=g.current_admin.id, personal_meeting=True).first()
        if not room:
            personal_id = g.current_admin.personal_meeting_id or generate_meeting_id()
            g.current_admin.personal_meeting_id = personal_id
            room = Meeting(
                admin_id=g.current_admin.id,
                meeting_id=personal_id,
                title=values["title"],
                description=values.get("description"),
                scheduled_start_at=values["scheduled_start_at"],
                scheduled_end_at=values["scheduled_end_at"],
                timezone=values["timezone"],
                status="scheduled",
                livekit_room_name=generate_livekit_room(personal_id),
                personal_meeting=True,
            )
            db.session.add(room)
            db.session.flush()
            token = generate_invitation_token()
            db.session.add(MeetingInvitation(meeting_id=room.id, token=token, url=invitation_url(token)))
        else:
            room.title = values["title"]
            room.description = values.get("description")
            room.scheduled_start_at = values["scheduled_start_at"]
            room.scheduled_end_at = values["scheduled_end_at"]
            room.timezone = values["timezone"]
            room.status = "scheduled"
        room.link_expires_at = values.get("link_expires_at")
        room.reminder_minutes = values.get("reminder_minutes", 10)
        room.waiting_room_enabled = values.get("waiting_room_enabled", True)
        room.join_before_host = values.get("join_before_host", False)
        room.host_only_start = values.get("host_only_start", False)
        room.max_participants = values.get("max_participants")
        room.allow_participant_audio = values.get("allow_participant_audio", True)
        room.allow_participant_video = values.get("allow_participant_video", True)
        room.allow_chat = values.get("allow_chat", True)
        room.allow_screen_share = values.get("allow_screen_share", True)
        room.allow_whiteboard = values.get("allow_whiteboard", True)
        room.screen_share_policy = values.get("screen_share_policy", "all")
        room.advanced_settings = values.get("advanced_settings", {})
        room.set_password(values.get("password"))
        if not room.invitation:
            token = generate_invitation_token()
            db.session.add(MeetingInvitation(meeting_id=room.id, token=token, url=invitation_url(token)))
        audit("meeting.personal_room_scheduled", actor=g.current_admin, session=g.current_session, entity_type="meeting", entity_id=room.id, metadata={"meetingId": room.meeting_id})
        db.session.commit()
        dispatch_webhook("meeting.created", {"meeting": room.to_dict(include_private=True), "occurrences": [room.to_dict(include_private=True)]})
        db.session.commit()
        return jsonify({"meeting": room.to_dict(include_private=True), "invitation": room.invitation.to_dict(), "occurrences": [room.to_dict(include_private=True)], "invitations": [room.invitation.to_dict()]}), 201

    recurrence_type = values.get("recurrence_type", "none")
    recurrence_count = values.get("recurrence_count", 1)
    recurrence_interval = values.get("recurrence_interval", 1)
    if values.get("advanced_settings"):
        values["advanced_settings"] = {**values["advanced_settings"], "dateTime": {**((values["advanced_settings"].get("dateTime") or {}) if isinstance(values["advanced_settings"].get("dateTime"), dict) else {}), "recurrenceInterval": recurrence_interval}}
    if values.get("requested_meeting_id") and recurrence_count > 1:
        return error("Custom meeting IDs can only be used for one-time meetings", 400, "validation_error")
    recurrence_group_id = new_id() if recurrence_count > 1 or recurrence_type != "none" else None
    meetings: list[Meeting] = []
    invitations: list[MeetingInvitation] = []
    for index in range(recurrence_count):
        meeting_id = values.get("requested_meeting_id") if index == 0 and values.get("requested_meeting_id") else generate_meeting_id()
        start_at = add_recurrence_delta(values["scheduled_start_at"], recurrence_type, index, recurrence_interval)
        end_at = add_recurrence_delta(values["scheduled_end_at"], recurrence_type, index, recurrence_interval)
        meeting = Meeting(
            admin_id=g.current_admin.id,
            meeting_id=meeting_id,
            livekit_room_name=generate_livekit_room(meeting_id),
            title=values["title"],
            description=values.get("description"),
            scheduled_start_at=start_at,
            scheduled_end_at=end_at,
            timezone=values["timezone"],
            status="scheduled",
            link_expires_at=add_recurrence_delta(values.get("link_expires_at"), recurrence_type, index, recurrence_interval) if values.get("link_expires_at") else None,
            reminder_minutes=values.get("reminder_minutes", 10),
            waiting_room_enabled=values.get("waiting_room_enabled", True),
            join_before_host=values.get("join_before_host", False),
            host_only_start=values.get("host_only_start", False),
            recurrence_type=recurrence_type,
            recurrence_count=recurrence_count,
            recurrence_group_id=recurrence_group_id,
            template_id=template.id if template else None,
            max_participants=values.get("max_participants"),
            allow_participant_audio=values.get("allow_participant_audio", True),
            allow_participant_video=values.get("allow_participant_video", True),
            allow_chat=values.get("allow_chat", True),
            allow_screen_share=values.get("allow_screen_share", True),
            allow_whiteboard=values.get("allow_whiteboard", True),
            screen_share_policy=values.get("screen_share_policy", "all"),
            advanced_settings=values.get("advanced_settings", {}),
        )
        meeting.set_password(values.get("password"))
        db.session.add(meeting)
        db.session.flush()
        token = generate_invitation_token()
        invitation = MeetingInvitation(meeting_id=meeting.id, token=token, url=invitation_url(token))
        db.session.add(invitation)
        meetings.append(meeting)
        invitations.append(invitation)
    db.session.flush()
    audit("meeting.created", actor=g.current_admin, session=g.current_session, entity_type="meeting", entity_id=meetings[0].id, metadata={"meetingId": meetings[0].meeting_id, "hasPassword": meetings[0].has_password, "occurrences": len(meetings)})
    db.session.commit()
    dispatch_webhook("meeting.created", {"meeting": meetings[0].to_dict(include_private=True), "occurrences": [m.to_dict(include_private=True) for m in meetings]})
    db.session.commit()
    return jsonify({"meeting": meetings[0].to_dict(include_private=True), "invitation": invitations[0].to_dict(), "occurrences": [m.to_dict(include_private=True) for m in meetings], "invitations": [i.to_dict() for i in invitations]}), 201


@bp.get("/history")
@require_admin(permission="meetings.manage")
def meeting_history():
    query = Meeting.query.filter_by(admin_id=g.current_admin.id)
    pagination = paginate(query.order_by(Meeting.scheduled_start_at.desc()), default_per_page=50, max_per_page=200)
    items = attach_participant_counts(list(pagination.items))
    db.session.commit()
    return jsonify({"items": [m.to_dict(include_private=True) for m in items], "total": pagination.total})


def ics_escape(value: str | None) -> str:
    return (value or "").replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")


def ics_dt(value: datetime) -> str:
    return value.astimezone(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def recurrence_rrule(meeting: Meeting) -> str | None:
    if meeting.recurrence_type == "none" or meeting.recurrence_count <= 1:
        return None
    advanced = meeting.advanced_settings or {}
    interval = int((advanced.get("dateTime") or {}).get("recurrenceInterval") or 1) if isinstance(advanced.get("dateTime"), dict) else 1
    freq = {"daily": "DAILY", "weekly": "WEEKLY", "monthly": "MONTHLY", "yearly": "YEARLY", "custom": "DAILY"}.get(meeting.recurrence_type)
    if not freq:
        return None
    interval_part = f";INTERVAL={max(1, interval)}" if max(1, interval) != 1 else ""
    return f"RRULE:FREQ={freq}{interval_part};COUNT={meeting.recurrence_count}"


def build_ics(meeting: Meeting) -> str:
    url = meeting.invitation.url if meeting.invitation else ""
    description = f"{meeting.description or ''}\n\nJoin: {url}\nMeeting ID: {meeting.meeting_id}"
    lines = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "CALSCALE:GREGORIAN",
        "METHOD:PUBLISH",
        "PRODID:-//Defensiq Security//Defensiq Meet//EN",
        "BEGIN:VEVENT",
        f"UID:{meeting.id}@defensiq-meet",
        f"DTSTAMP:{ics_dt(utcnow())}",
        f"DTSTART:{ics_dt(meeting.scheduled_start_at)}",
        f"DTEND:{ics_dt(meeting.scheduled_end_at)}",
        f"SUMMARY:{ics_escape(meeting.title)}",
        f"DESCRIPTION:{ics_escape(description)}",
        f"LOCATION:{ics_escape(url)}",
        f"URL:{ics_escape(url)}",
    ]
    rrule = recurrence_rrule(meeting)
    if rrule:
        lines.append(rrule)
    if meeting.reminder_minutes and meeting.reminder_minutes > 0:
        lines.extend(["BEGIN:VALARM", "ACTION:DISPLAY", f"DESCRIPTION:{ics_escape('Reminder: ' + meeting.title)}", f"TRIGGER:-PT{meeting.reminder_minutes}M", "END:VALARM"])
    lines.extend(["END:VEVENT", "END:VCALENDAR", ""])
    return "\r\n".join(lines)


def calendar_links(meeting: Meeting) -> dict[str, str]:
    url = meeting.invitation.url if meeting.invitation else ""
    start = meeting.scheduled_start_at.astimezone(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    end = meeting.scheduled_end_at.astimezone(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    start_iso = meeting.scheduled_start_at.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
    end_iso = meeting.scheduled_end_at.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
    details = f"{meeting.description or ''}\n\nJoin: {url}\nMeeting ID: {meeting.meeting_id}"
    google = f"https://calendar.google.com/calendar/render?action=TEMPLATE&text={quote_plus(meeting.title)}&dates={start}/{end}&details={quote_plus(details)}&location={quote_plus(url)}&ctz={quote_plus(meeting.timezone)}"
    outlook = f"https://outlook.office.com/calendar/0/deeplink/compose?path=/calendar/action/compose&rru=addevent&subject={quote_plus(meeting.title)}&startdt={quote_plus(start_iso)}&enddt={quote_plus(end_iso)}&body={quote_plus(details)}&location={quote_plus(url)}"
    yahoo = f"https://calendar.yahoo.com/?v=60&title={quote_plus(meeting.title)}&st={start}&et={end}&desc={quote_plus(details)}&in_loc={quote_plus(url)}"
    return {"google": google, "outlook": outlook, "office365": outlook, "exchangeIcs": url, "yahoo": yahoo}


@bp.post("/<identifier>/email-invitations")
@require_admin(permission="meetings.manage")
def email_invitations(identifier: str):
    meeting = meeting_by_id(identifier)
    if not meeting or meeting.admin_id != g.current_admin.id:
        return error("Meeting not found", 404, "meeting_not_found")
    data = request.get_json(silent=True) or {}
    recipients = data.get("recipients") or []
    if isinstance(recipients, str):
        recipients = [item.strip() for item in recipients.replace(";", ",").split(",") if item.strip()]
    if not isinstance(recipients, list) or not recipients:
        return error("At least one recipient is required", 400, "validation_error")
    if len(recipients) > 100:
        return error("At most 100 recipients can be emailed at once", 400, "validation_error")
    normalized: list[str] = []
    try:
        for recipient in recipients:
            normalized.append(validate_email(str(recipient), check_deliverability=False).normalized)
    except EmailNotValidError as exc:
        return error(str(exc), 400, "invalid_email")
    ics = build_ics(meeting)
    sent: list[str] = []
    failed: list[dict] = []
    for recipient in normalized:
        try:
            send_meeting_invite_email(meeting=meeting, to_email=recipient, ics=ics, extra_message=data.get("message"))
            sent.append(recipient)
        except Exception as exc:
            failed.append({"email": recipient, "error": str(exc)})
    audit("meeting.email_invitations", actor=g.current_admin, session=g.current_session, entity_type="meeting", entity_id=meeting.id, metadata={"sent": len(sent), "failed": len(failed)})
    db.session.commit()
    status = 207 if failed and sent else 500 if failed and not sent else 200
    return jsonify({"sent": sent, "failed": failed, "meeting": meeting.to_dict(include_private=True)}), status


@bp.get("/<identifier>/calendar.ics")
@require_admin(permission="meetings.manage")
def calendar_invite(identifier: str):
    meeting = meeting_by_id(identifier)
    if not meeting or meeting.admin_id != g.current_admin.id:
        return error("Meeting not found", 404, "meeting_not_found")
    ics = build_ics(meeting)
    db.session.commit()
    return current_app.response_class(ics, mimetype="text/calendar", headers={"Content-Disposition": f"attachment; filename={meeting.meeting_id}.ics"})


@bp.get("/<identifier>/calendar-links")
@require_admin(permission="meetings.manage")
def admin_calendar_links(identifier: str):
    meeting = meeting_by_id(identifier)
    if not meeting or meeting.admin_id != g.current_admin.id:
        return error("Meeting not found", 404, "meeting_not_found")
    db.session.commit()
    return jsonify({"meeting": meeting.to_dict(include_private=True), "links": calendar_links(meeting), "icsUrl": f"{current_app.config['PUBLIC_APP_URL'].rstrip('/')}/api/v1/meetings/{meeting.id}/calendar.ics"})


@bp.get("/invitations/<token>/calendar.ics")
def public_calendar_invite(token: str):
    invitation = MeetingInvitation.query.filter_by(token=token).first()
    if not invitation:
        return error("Invitation link not found", 404, "invitation_not_found")
    meeting = invitation.meeting
    unavailable = invitation_available(meeting)
    if unavailable:
        return unavailable
    ics = build_ics(meeting)
    db.session.commit()
    return current_app.response_class(ics, mimetype="text/calendar", headers={"Content-Disposition": f"attachment; filename={meeting.meeting_id}.ics"})


@bp.get("/invitations/<token>/calendar-links")
def public_calendar_links(token: str):
    invitation = MeetingInvitation.query.filter_by(token=token).first()
    if not invitation:
        return error("Invitation link not found", 404, "invitation_not_found")
    meeting = invitation.meeting
    unavailable = invitation_available(meeting)
    if unavailable:
        return unavailable
    db.session.commit()
    return jsonify({"meeting": public_meeting_dict(meeting), "links": calendar_links(meeting), "icsUrl": f"{current_app.config['PUBLIC_APP_URL'].rstrip('/')}/api/v1/meetings/invitations/{token}/calendar.ics"})


@bp.get("/code/<meeting_code>")
def public_by_meeting_code(meeting_code: str):
    meeting_code = str(meeting_code or "").strip().lower()
    allowed = string.ascii_lowercase + string.digits + "-"
    if len(meeting_code) > 32 or any(ch not in allowed for ch in meeting_code):
        return error("Meeting code not found", 404, "meeting_code_not_found")
    meeting = Meeting.query.filter_by(meeting_id=meeting_code).first()
    if not meeting or not meeting.invitation:
        return error("Meeting code not found", 404, "meeting_code_not_found")
    unavailable = invitation_available(meeting)
    if unavailable:
        return unavailable
    db.session.commit()
    return jsonify({"meeting": public_meeting_dict(meeting), "invitation": {"url": meeting.invitation.url, "createdAt": meeting.invitation.created_at.isoformat() if meeting.invitation.created_at else None}})


@bp.get("/<identifier>")
@require_admin(permission="meetings.manage")
def get_meeting(identifier: str):
    meeting = meeting_by_id(identifier)
    if not meeting or meeting.admin_id != g.current_admin.id:
        return error("Meeting not found", 404, "meeting_not_found")
    db.session.commit()
    return jsonify({"meeting": meeting.to_dict(include_private=True), "invitation": meeting.invitation.to_dict() if meeting.invitation else None})


@bp.patch("/<identifier>")
@require_admin(permission="meetings.manage")
def update_meeting(identifier: str):
    meeting = meeting_by_id(identifier)
    if not meeting or meeting.admin_id != g.current_admin.id:
        return error("Meeting not found", 404, "meeting_not_found")
    if meeting.status not in {"scheduled", "running"}:
        return error("Only active or scheduled meetings can be edited", 409, "meeting_not_editable")
    data = request.get_json(silent=True) or {}
    try:
        values = validate_payload(data, partial=True)
    except (ValueError, TypeError) as exc:
        return error(str(exc), 400, "validation_error")
    for key in ["title", "description", "scheduled_start_at", "scheduled_end_at", "timezone", "link_expires_at", "reminder_minutes", "waiting_room_enabled", "join_before_host", "host_only_start", "recurrence_type", "recurrence_count", "template_id", "max_participants", "allow_participant_audio", "allow_participant_video", "allow_chat", "allow_screen_share", "allow_whiteboard", "screen_share_policy", "advanced_settings"]:
        if key in values:
            setattr(meeting, key, values[key])
    if "password" in values:
        meeting.set_password(values["password"])
    if meeting.scheduled_end_at <= meeting.scheduled_start_at:
        return error("scheduledEndAt must be after scheduledStartAt", 400, "validation_error")
    audit("meeting.updated", actor=g.current_admin, session=g.current_session, entity_type="meeting", entity_id=meeting.id, metadata={"meetingId": meeting.meeting_id})
    db.session.commit()
    socketio.emit("meeting:updated", meeting.to_dict(include_private=True), room=meeting.id)
    return jsonify({"meeting": meeting.to_dict(include_private=True), "invitation": meeting.invitation.to_dict() if meeting.invitation else None})


@bp.delete("/<identifier>")
@require_admin(permission="meetings.manage")
def delete_meeting(identifier: str):
    meeting = meeting_by_id(identifier)
    if not meeting or meeting.admin_id != g.current_admin.id:
        return error("Meeting not found", 404, "meeting_not_found")
    if meeting.status == "running":
        return error("Running meetings must be ended before deletion", 409, "meeting_running")
    payload = meeting.to_dict(include_private=True)
    audit("meeting.deleted", actor=g.current_admin, session=g.current_session, entity_type="meeting", entity_id=meeting.id, metadata={"meetingId": meeting.meeting_id, "title": meeting.title})
    db.session.delete(meeting)
    db.session.commit()
    socketio.emit("meeting:deleted", {"meetingId": payload["id"], "meeting": payload}, room=payload["id"])
    return jsonify({"deleted": True, "meeting": payload})


@bp.post("/<identifier>/regenerate-link")
@require_admin(permission="meetings.manage")
def regenerate_link(identifier: str):
    meeting = meeting_by_id(identifier)
    if not meeting or meeting.admin_id != g.current_admin.id:
        return error("Meeting not found", 404, "meeting_not_found")
    invitation = meeting.invitation
    if not invitation:
        token = generate_invitation_token()
        invitation = MeetingInvitation(meeting_id=meeting.id, token=token, url=invitation_url(token))
        db.session.add(invitation)
    else:
        token = generate_invitation_token()
        invitation.token = token
        invitation.url = invitation_url(token)
        invitation.regenerated_at = utcnow()
    audit("meeting.link_regenerated", actor=g.current_admin, session=g.current_session, entity_type="meeting", entity_id=meeting.id, metadata={"meetingId": meeting.meeting_id})
    db.session.commit()
    return jsonify({"meeting": meeting.to_dict(include_private=True), "invitation": invitation.to_dict()})


@bp.get("/<identifier>/participants")
@require_admin(permission="meetings.manage")
def list_participants(identifier: str):
    meeting = meeting_by_id(identifier)
    if not meeting or meeting.admin_id != g.current_admin.id:
        return error("Meeting not found", 404, "meeting_not_found")
    participants = MeetingParticipant.query.filter_by(meeting_id=meeting.id).order_by(MeetingParticipant.created_at.asc()).all()
    db.session.commit()
    return jsonify({"items": [p.to_dict(include_private=True) for p in participants], "total": len(participants)})


@bp.get("/invitations/<token>/participants")
def participant_list_participants(token: str):
    invitation = MeetingInvitation.query.filter_by(token=token).first()
    if not invitation:
        return error("Invitation link not found", 404, "invitation_not_found")
    meeting = invitation.meeting
    actor = participant_from_bearer(meeting)
    if not actor:
        return error("Invalid participant session", 401, "invalid_participant_session")
    if actor.status != "admitted":
        return error("Participant is not admitted", 403, "not_admitted")
    include_waiting = actor.role in {"host", "cohost"} and participant_can_manage(actor, "participants.view_private")
    items = serialize_participants_for_actor(meeting, actor, include_waiting=include_waiting)
    db.session.commit()
    return jsonify({"items": items, "total": len(items)})


@bp.post("/<identifier>/host-token")
@require_admin(permission="meetings.manage")
def host_token(identifier: str):
    meeting = meeting_by_id(identifier)
    if not meeting or meeting.admin_id != g.current_admin.id:
        return error("Meeting not found", 404, "meeting_not_found")
    data = request.get_json(silent=True) or {}
    participant = MeetingParticipant.query.filter_by(meeting_id=meeting.id, role="host").first()
    raw_token = create_participant_token(participant.id, meeting.id) if participant else None
    if not participant:
        raw_token = create_participant_token("pending", meeting.id)
        participant = MeetingParticipant(
            meeting_id=meeting.id,
            display_name=g.current_admin.display_name,
            role="host",
            status="admitted",
            participant_token_hash=token_hash(raw_token),
            ip_address=client_ip(),
            user_agent=user_agent(),
            joined_at=utcnow(),
            admitted_at=utcnow(),
        )
        db.session.add(participant)
        db.session.flush()
        raw_token = create_participant_token(participant.id, meeting.id)
        participant.participant_token_hash = token_hash(raw_token)
    else:
        raw_token = create_participant_token(participant.id, meeting.id)
        participant.participant_token_hash = token_hash(raw_token)
        participant.status = "admitted"
        participant.joined_at = participant.joined_at or utcnow()
        participant.admitted_at = participant.admitted_at or utcnow()
    try:
        apply_participant_preferences(participant, data)
    except ValueError as exc:
        return error(str(exc), 400, "validation_error")
    meeting.status = "running"
    audit("meeting.host_joined", actor=g.current_admin, session=g.current_session, entity_type="meeting", entity_id=meeting.id)
    db.session.commit()
    dispatch_webhook("meeting.started", {"meeting": meeting.to_dict(include_private=True), "host": participant.to_dict(include_private=True)})
    db.session.commit()
    socketio.emit("participant:updated", participant.to_dict(include_private=True), room=meeting.id)
    return jsonify({"participant": participant.to_dict(include_private=True), "participantToken": raw_token, "livekit": livekit_payload(meeting, participant), "meeting": meeting.to_dict(include_private=True)})


@bp.post("/<identifier>/participants/<participant_id>/admit")
@require_admin(permission="meetings.manage")
def admit_participant(identifier: str, participant_id: str):
    meeting = meeting_by_id(identifier)
    if not meeting or meeting.admin_id != g.current_admin.id:
        return error("Meeting not found", 404, "meeting_not_found")
    participant = MeetingParticipant.query.filter_by(id=participant_id, meeting_id=meeting.id).first()
    if not participant:
        return error("Participant not found", 404, "participant_not_found")
    participant.status = "admitted"
    participant.admitted_at = utcnow()
    meeting.status = "running"
    audit("participant.admitted", actor=g.current_admin, session=g.current_session, entity_type="participant", entity_id=participant.id)
    db.session.commit()
    sync_livekit_permissions(meeting, participant)
    socketio.emit("participant:updated", participant.to_dict(include_private=True), room=meeting.id)
    socketio.emit("participant:admitted", participant.to_dict(), room=participant.id)
    return jsonify({"participant": participant.to_dict(include_private=True)})


@bp.post("/<identifier>/participants/<participant_id>/reject")
@require_admin(permission="meetings.manage")
def reject_participant(identifier: str, participant_id: str):
    meeting = meeting_by_id(identifier)
    if not meeting or meeting.admin_id != g.current_admin.id:
        return error("Meeting not found", 404, "meeting_not_found")
    participant = MeetingParticipant.query.filter_by(id=participant_id, meeting_id=meeting.id).first()
    if not participant:
        return error("Participant not found", 404, "participant_not_found")
    participant.status = "rejected"
    participant.rejected_at = utcnow()
    audit("participant.rejected", actor=g.current_admin, session=g.current_session, entity_type="participant", entity_id=participant.id)
    db.session.commit()
    socketio.emit("participant:updated", participant.to_dict(include_private=True), room=meeting.id)
    socketio.emit("participant:rejected", participant.to_dict(), room=participant.id)
    return jsonify({"participant": participant.to_dict(include_private=True)})


@bp.patch("/<identifier>/controls")
@require_admin(permission="meetings.manage")
def update_controls(identifier: str):
    meeting = meeting_by_id(identifier)
    if not meeting or meeting.admin_id != g.current_admin.id:
        return error("Meeting not found", 404, "meeting_not_found")
    data = request.get_json(silent=True) or {}
    allowed = {
        "isLocked": "is_locked",
        "allowParticipantAudio": "allow_participant_audio",
        "allowParticipantVideo": "allow_participant_video",
        "allowChat": "allow_chat",
        "allowScreenShare": "allow_screen_share",
        "allowWhiteboard": "allow_whiteboard",
        "waitingRoomEnabled": "waiting_room_enabled",
        "sharedCursorEnabled": "shared_cursor_enabled",
    }
    changed: dict = {}
    for api_key, attr in allowed.items():
        if api_key in data:
            value = bool(data[api_key])
            setattr(meeting, attr, value)
            changed[api_key] = value
    if "screenSharePolicy" in data:
        policy = str(data["screenSharePolicy"])
        if policy not in {"host", "cohosts", "all"}:
            return error("screenSharePolicy must be host, cohosts, or all", 400, "validation_error")
        meeting.screen_share_policy = policy
        changed["screenSharePolicy"] = policy
    if "presenterLayout" in data:
        layout = str(data["presenterLayout"])
        if layout not in {"presenter", "side_by_side", "gallery"}:
            return error("presenterLayout must be presenter, side_by_side, or gallery", 400, "validation_error")
        meeting.presenter_layout = layout
        changed["presenterLayout"] = layout
    if not changed:
        return error("No supported controls were provided", 400, "validation_error")
    if changed.get("allowScreenShare") is False or "screenSharePolicy" in changed:
        for participant in MeetingParticipant.query.filter_by(meeting_id=meeting.id, screen_sharing=True).all():
            if not can_share_screen(meeting, participant):
                participant.screen_sharing = False
                participant.screen_share_paused = False
                mute_tracks(meeting.livekit_room_name, participant.id, ["screen_share", "screen_share_audio"], True)
                socketio.emit("host:control", {"meetingId": meeting.id, "targetParticipantId": participant.id, "action": "stop_screen_share"}, room=meeting.id)
        if changed.get("allowScreenShare") is False:
            meeting.active_screen_share_participant_id = None
    audit("meeting.controls_updated", actor=g.current_admin, session=g.current_session, entity_type="meeting", entity_id=meeting.id, metadata=changed)
    db.session.commit()
    if any(key in changed for key in ["allowParticipantAudio", "allowParticipantVideo", "allowScreenShare", "screenSharePolicy"]):
        sync_all_livekit_permissions(meeting)
    socketio.emit("meeting:controls", {"meetingId": meeting.id, **changed, "meeting": meeting.to_dict(include_private=True)}, room=meeting.id)
    socketio.emit("meeting:updated", meeting.to_dict(include_private=True), room=meeting.id)
    return jsonify({"meeting": meeting.to_dict(include_private=True), "changed": changed})


def participant_control_required_permissions(patch: dict) -> set[str]:
    required: set[str] = set()
    for key in patch.keys():
        if key in {"isLocked", "waitingRoomEnabled"}:
            required.add("meeting.lock")
        elif key in {"allowChat"}:
            required.add("chat.manage")
        elif key in {"allowWhiteboard"}:
            required.add("whiteboard.grant")
        elif key in {"allowScreenShare", "screenSharePolicy"}:
            required.add("sharing.grant")
        elif key in {"allowParticipantAudio"}:
            required.add("participants.mute")
        elif key in {"allowParticipantVideo"}:
            required.add("participants.camera.disable")
        elif key in {"presenterLayout"}:
            required.add("presenter.change")
        else:
            required.add("meeting.lock")
    return required


@bp.patch("/invitations/<token>/controls")
def participant_update_controls(token: str):
    invitation = MeetingInvitation.query.filter_by(token=token).first()
    if not invitation:
        return error("Invitation link not found", 404, "invitation_not_found")
    meeting = invitation.meeting
    actor = participant_from_bearer(meeting)
    if not actor:
        return error("Invalid participant session", 401, "invalid_participant_session")
    data = request.get_json(silent=True) or {}
    required = participant_control_required_permissions(data)
    if actor.role != "host" and not any(participant_can_manage(actor, permission) for permission in required):
        return error("Meeting control permission has not been granted", 403, "cohost_permission_required")
    # Reuse the same validation/mutation rules as the admin endpoint.
    allowed = {
        "isLocked": "is_locked",
        "allowParticipantAudio": "allow_participant_audio",
        "allowParticipantVideo": "allow_participant_video",
        "allowChat": "allow_chat",
        "allowScreenShare": "allow_screen_share",
        "allowWhiteboard": "allow_whiteboard",
        "waitingRoomEnabled": "waiting_room_enabled",
        "sharedCursorEnabled": "shared_cursor_enabled",
    }
    changed: dict = {}
    for api_key, attr in allowed.items():
        if api_key in data:
            value = bool(data[api_key])
            setattr(meeting, attr, value)
            changed[api_key] = value
    if "screenSharePolicy" in data:
        policy = str(data["screenSharePolicy"])
        if policy not in {"host", "cohosts", "all"}:
            return error("screenSharePolicy must be host, cohosts, or all", 400, "validation_error")
        meeting.screen_share_policy = policy
        changed["screenSharePolicy"] = policy
    if "presenterLayout" in data:
        layout = str(data["presenterLayout"])
        if layout not in {"presenter", "side_by_side", "gallery"}:
            return error("presenterLayout must be presenter, side_by_side, or gallery", 400, "validation_error")
        meeting.presenter_layout = layout
        changed["presenterLayout"] = layout
    if not changed:
        return error("No supported controls were provided", 400, "validation_error")
    audit("meeting.controls_updated", entity_type="meeting", entity_id=meeting.id, metadata={"actorParticipantId": actor.id, "actorRole": actor.role, **changed})
    db.session.commit()
    if any(key in changed for key in ["allowParticipantAudio", "allowParticipantVideo", "allowScreenShare", "screenSharePolicy"]):
        sync_all_livekit_permissions(meeting)
    socketio.emit("meeting:controls", {"meetingId": meeting.id, **changed, "meeting": meeting.to_dict(include_private=True)}, room=meeting.id)
    socketio.emit("meeting:updated", meeting.to_dict(include_private=True), room=meeting.id)
    return jsonify({"meeting": meeting.to_dict(include_private=True), "changed": changed})


@bp.post("/invitations/<token>/end")
def participant_end_meeting(token: str):
    invitation = MeetingInvitation.query.filter_by(token=token).first()
    if not invitation:
        return error("Invitation link not found", 404, "invitation_not_found")
    meeting = invitation.meeting
    actor = participant_from_bearer(meeting)
    if not actor:
        return error("Invalid participant session", 401, "invalid_participant_session")
    if actor.role != "host" and not participant_can_manage(actor, "meeting.end"):
        return error("Meeting end permission has not been granted", 403, "cohost_permission_required")
    meeting.status = "completed"
    meeting.ended_at = utcnow()
    participants = MeetingParticipant.query.filter(MeetingParticipant.meeting_id == meeting.id, MeetingParticipant.status.in_(["waiting", "admitted"])).all()
    for participant in participants:
        participant.status = "left"
        participant.left_at = participant.left_at or utcnow()
        participant.removed_reason = "meeting_ended"
        livekit_remove_participant(meeting.livekit_room_name, participant.id)
    audit("meeting.ended", entity_type="meeting", entity_id=meeting.id, metadata={"actorParticipantId": actor.id, "actorRole": actor.role})
    db.session.commit()
    dispatch_webhook("participant.left", {"meeting": meeting.to_dict(include_private=True), "participants": [p.to_dict(include_private=True) for p in participants]})
    db.session.commit()
    socketio.emit("meeting:ended", {"meetingId": meeting.id}, room=meeting.id)
    return jsonify({"meeting": meeting.to_dict(include_private=True), "participants": [p.to_dict(include_private=True) for p in participants]})


@bp.post("/<identifier>/end")
@require_admin(permission="meetings.manage")
def end_meeting(identifier: str):
    meeting = meeting_by_id(identifier)
    if not meeting or meeting.admin_id != g.current_admin.id:
        return error("Meeting not found", 404, "meeting_not_found")
    meeting.status = "completed"
    meeting.ended_at = utcnow()
    participants = MeetingParticipant.query.filter(MeetingParticipant.meeting_id == meeting.id, MeetingParticipant.status.in_(["waiting", "admitted"])).all()
    for participant in participants:
        participant.status = "left"
        participant.left_at = participant.left_at or utcnow()
        participant.removed_reason = "meeting_ended"
        livekit_remove_participant(meeting.livekit_room_name, participant.id)
    audit("meeting.ended", actor=g.current_admin, session=g.current_session, entity_type="meeting", entity_id=meeting.id)
    db.session.commit()
    dispatch_webhook("participant.left", {"meeting": meeting.to_dict(include_private=True), "participants": [p.to_dict(include_private=True) for p in participants]})
    db.session.commit()
    socketio.emit("meeting:ended", {"meetingId": meeting.id}, room=meeting.id)
    return jsonify({"meeting": meeting.to_dict(include_private=True), "participants": [p.to_dict(include_private=True) for p in participants]})


def serialize_participants_for_actor(meeting: Meeting, actor: MeetingParticipant | None = None, *, include_waiting: bool = False) -> list[dict]:
    query = MeetingParticipant.query.filter_by(meeting_id=meeting.id)
    if actor and actor.role not in {"host", "cohost"}:
        query = query.filter_by(status="admitted")
    elif not include_waiting:
        query = query.filter(MeetingParticipant.status.in_(["admitted", "waiting"]))
    participants = query.order_by(MeetingParticipant.created_at.asc()).all()
    include_private = actor is None or (actor.role in {"host", "cohost"} and participant_can_manage(actor, "participants.view_private"))
    if actor and actor.role == "host":
        include_private = True
    return [p.to_dict(include_private=include_private) for p in participants]


def clear_boolean_host_control(meeting: Meeting, key: str, except_participant_id: str | None = None) -> list[MeetingParticipant]:
    changed: list[MeetingParticipant] = []
    participants = MeetingParticipant.query.filter_by(meeting_id=meeting.id).all()
    for item in participants:
        if except_participant_id and item.id == except_participant_id:
            continue
        if host_controls(item).get(key):
            set_host_control(item, key, False)
            changed.append(item)
    return changed


def apply_participant_action(meeting: Meeting, participant: MeetingParticipant, action: str, data: dict, *, actor_admin=None, actor_participant: MeetingParticipant | None = None):
    action = action.strip()
    aliases = {
        "disable_microphone": "disable_audio",
        "disable_camera": "disable_video",
        "grant_screen": "grant_screen_share",
        "revoke_screen": "revoke_screen_share",
        "promote": "promote_cohost",
        "remove_cohost": "demote_cohost",
    }
    action = aliases.get(action, action)
    host_only_actions = {"promote_cohost", "demote_cohost", "grant_cohost_controls", "revoke_cohost_controls"}
    if actor_participant:
        if actor_participant.meeting_id != meeting.id or actor_participant.status != "admitted":
            return None, error("Invalid participant session", 401, "invalid_participant_session")
        if action in host_only_actions and actor_participant.role != "host":
            return None, error("Only the meeting host can change co-host roles or co-host management permissions", 403, "host_permission_required")
        if action not in host_only_actions and not participant_can_manage(actor_participant, action):
            return None, error("Co-host management permission has not been granted", 403, "cohost_permission_required")
    if participant.role == "host" and action in {"remove", "ban", "move_waiting", "reject", "disable_audio", "disable_video", "revoke_screen_share"}:
        return None, error("The meeting host cannot be targeted by this action", 400, "host_action_forbidden")

    changed: dict[str, MeetingParticipant] = {participant.id: participant}
    meeting_changed = False
    livekit_sync: set[str] = set()
    remove_from_livekit = False
    reject_to_waiting_room = False
    participant_notice = action
    notify_payload: dict = {}

    if action == "admit":
        participant.status = "admitted"
        participant.admitted_at = participant.admitted_at or utcnow()
        participant.rejected_at = None
        participant.left_at = None
        participant.removed_reason = None
        meeting.status = "running"
        meeting_changed = True
        livekit_sync.add(participant.id)
    elif action == "reject":
        participant.status = "rejected"
        participant.rejected_at = utcnow()
        participant.removed_reason = "rejected_by_host"
        reject_to_waiting_room = True
    elif action == "ban":
        participant.screen_sharing = False
        participant.screen_share_paused = False
        if meeting.active_screen_share_participant_id == participant.id:
            meeting.active_screen_share_participant_id = None
            meeting_changed = True
        if participant.status == "waiting":
            participant.status = "rejected"
            participant.rejected_at = utcnow()
            reject_to_waiting_room = True
        else:
            participant.status = "left"
            participant.left_at = utcnow()
            remove_from_livekit = True
        participant.removed_reason = "banned_by_host"
    elif action == "mute":
        participant.muted = True
        mute_tracks(meeting.livekit_room_name, participant.id, ["microphone"], True)
    elif action == "ask_unmute":
        set_host_control(participant, "unmuteRequestedAt", utcnow().isoformat())
    elif action == "disable_audio":
        participant.audio_disabled = True
        participant.muted = True
        livekit_sync.add(participant.id)
        mute_tracks(meeting.livekit_room_name, participant.id, ["microphone"], True)
    elif action == "enable_audio":
        participant.audio_disabled = False
        livekit_sync.add(participant.id)
    elif action == "disable_video":
        participant.video_disabled = True
        participant.camera_enabled = False
        livekit_sync.add(participant.id)
        mute_tracks(meeting.livekit_room_name, participant.id, ["camera"], True)
    elif action == "enable_video":
        participant.video_disabled = False
        livekit_sync.add(participant.id)
    elif action == "grant_screen_share":
        participant.screen_share_disabled = False
        set_host_control(participant, "screenShareGranted", True)
        set_host_control(participant, "screenShareRevoked", False)
        livekit_sync.add(participant.id)
    elif action == "revoke_screen_share":
        participant.screen_share_disabled = True
        set_host_control(participant, "screenShareGranted", False)
        set_host_control(participant, "screenShareRevoked", True)
        if participant.screen_sharing:
            participant.screen_sharing = False
            participant.screen_share_paused = False
            if meeting.active_screen_share_participant_id == participant.id:
                meeting.active_screen_share_participant_id = None
                meeting_changed = True
            mute_tracks(meeting.livekit_room_name, participant.id, ["screen_share", "screen_share_audio"], True)
        livekit_sync.add(participant.id)
    elif action == "grant_whiteboard":
        set_host_control(participant, "whiteboardGranted", True)
        set_host_control(participant, "whiteboardRevoked", False)
    elif action == "revoke_whiteboard":
        set_host_control(participant, "whiteboardGranted", False)
        set_host_control(participant, "whiteboardRevoked", True)
    elif action == "stop_screen_share":
        participant.screen_sharing = False
        participant.screen_share_paused = False
        if meeting.active_screen_share_participant_id == participant.id:
            meeting.active_screen_share_participant_id = None
            meeting_changed = True
        mute_tracks(meeting.livekit_room_name, participant.id, ["screen_share", "screen_share_audio"], True)
    elif action == "promote_cohost":
        if participant.role != "participant":
            return None, error("Only participants can be promoted to co-host", 400, "invalid_role_transition")
        participant.role = "cohost"
        set_host_control(participant, "cohostPermissions", ROLE_DEFAULT_PERMISSIONS["cohost"])
        livekit_sync.add(participant.id)
    elif action == "demote_cohost":
        if participant.role != "cohost":
            return None, error("Only co-hosts can be demoted", 400, "invalid_role_transition")
        participant.role = "participant"
        set_host_control(participant, "cohostPermissions", [])
        livekit_sync.add(participant.id)
    elif action == "grant_cohost_controls":
        if participant.role != "cohost":
            return None, error("Only co-hosts can receive management controls", 400, "invalid_role_transition")
        set_host_control(participant, "cohostPermissions", ["participants.manage"])
    elif action == "revoke_cohost_controls":
        if participant.role != "cohost":
            return None, error("Only co-host management controls can be revoked", 400, "invalid_role_transition")
        set_host_control(participant, "cohostPermissions", [])
    elif action == "change_presenter":
        for item in clear_boolean_host_control(meeting, "presenter", participant.id):
            changed[item.id] = item
        set_host_control(participant, "presenter", True)
    elif action == "clear_presenter":
        set_host_control(participant, "presenter", False)
    elif action == "pin":
        set_host_control(participant, "pinned", True)
    elif action == "unpin":
        set_host_control(participant, "pinned", False)
    elif action == "spotlight":
        for item in clear_boolean_host_control(meeting, "spotlighted", participant.id):
            changed[item.id] = item
        set_host_control(participant, "spotlighted", True)
    elif action == "clear_spotlight":
        set_host_control(participant, "spotlighted", False)
    elif action == "rename":
        display_name = str(data.get("displayName") or "").strip()
        if len(display_name) < 2 or len(display_name) > 120:
            return None, error("Display name must be between 2 and 120 characters", 400, "validation_error")
        participant.display_name = display_name
        notify_payload["displayName"] = display_name
    elif action == "move_waiting":
        participant.status = "waiting"
        participant.removed_reason = "moved_to_waiting_room"
        participant.screen_sharing = False
        participant.screen_share_paused = False
        if meeting.active_screen_share_participant_id == participant.id:
            meeting.active_screen_share_participant_id = None
            meeting_changed = True
        remove_from_livekit = True
    elif action == "remove":
        participant.status = "left"
        participant.left_at = utcnow()
        participant.removed_reason = "removed_by_host"
        participant.screen_sharing = False
        participant.screen_share_paused = False
        if meeting.active_screen_share_participant_id == participant.id:
            meeting.active_screen_share_participant_id = None
            meeting_changed = True
        remove_from_livekit = True
    else:
        return None, error("Unsupported participant action", 400, "unsupported_action")

    if remove_from_livekit:
        livekit_remove_participant(meeting.livekit_room_name, participant.id)

    audit_metadata = {"action": action}
    if actor_participant:
        audit_metadata["actorParticipantId"] = actor_participant.id
    audit("participant.action", actor=actor_admin, session=getattr(g, "current_session", None) if actor_admin else None, entity_type="participant", entity_id=participant.id, metadata=audit_metadata)
    db.session.commit()

    for participant_id in livekit_sync:
        sync_target = db.session.get(MeetingParticipant, participant_id)
        if sync_target:
            sync_livekit_permissions(meeting, sync_target)
            changed[sync_target.id] = sync_target

    for item in changed.values():
        socketio.emit("participant:updated", item.to_dict(include_private=True), room=meeting.id)

    control_payload = {"meetingId": meeting.id, "targetParticipantId": participant.id, "action": participant_notice, **notify_payload}
    socketio.emit("host:control", control_payload, room=meeting.id)
    if meeting_changed or action in {"stop_screen_share", "remove", "ban", "move_waiting", "admit"}:
        socketio.emit("meeting:updated", meeting.to_dict(include_private=True), room=meeting.id)
    if action == "admit":
        socketio.emit("participant:admitted", participant.to_dict(), room=participant.id)
    if reject_to_waiting_room:
        socketio.emit("participant:rejected", participant.to_dict(), room=participant.id)
    if action in {"remove", "ban", "move_waiting"} and participant.status in {"left", "waiting"}:
        socketio.emit("participant:removed", participant.to_dict(), room=participant.id)

    return {"participant": participant.to_dict(include_private=True), "meeting": meeting.to_dict(include_private=True), "changedParticipants": [item.to_dict(include_private=True) for item in changed.values()]}, None


@bp.post("/<identifier>/participants/<participant_id>/action")
@require_admin(permission="meetings.manage")
def participant_action(identifier: str, participant_id: str):
    meeting = meeting_by_id(identifier)
    if not meeting or meeting.admin_id != g.current_admin.id:
        return error("Meeting not found", 404, "meeting_not_found")
    participant = MeetingParticipant.query.filter_by(id=participant_id, meeting_id=meeting.id).first()
    if not participant:
        return error("Participant not found", 404, "participant_not_found")
    data = request.get_json(silent=True) or {}
    result, err = apply_participant_action(meeting, participant, str(data.get("action", "")), data, actor_admin=g.current_admin)
    if err:
        return err
    return jsonify(result)


@bp.post("/invitations/<token>/participants/<participant_id>/action")
def participant_token_action(token: str, participant_id: str):
    invitation = MeetingInvitation.query.filter_by(token=token).first()
    if not invitation:
        return error("Invitation link not found", 404, "invitation_not_found")
    meeting = invitation.meeting
    actor = participant_from_bearer(meeting)
    if not actor:
        return error("Invalid participant session", 401, "invalid_participant_session")
    target = MeetingParticipant.query.filter_by(id=participant_id, meeting_id=meeting.id).first()
    if not target:
        return error("Participant not found", 404, "participant_not_found")
    data = request.get_json(silent=True) or {}
    result, err = apply_participant_action(meeting, target, str(data.get("action", "")), data, actor_participant=actor)
    if err:
        return err
    return jsonify(result)


def apply_screen_share_state(meeting: Meeting, participant: MeetingParticipant, data: dict):
    sharing = bool(data.get("sharing"))
    paused = bool(data.get("paused", False))
    source = str(data.get("source") or "screen")
    if source not in {"screen", "window", "browser"}:
        return error("source must be screen, window, or browser", 400, "validation_error")
    if sharing and not can_share_screen(meeting, participant):
        return error("Screen sharing is not allowed for this participant", 403, "screen_share_forbidden")
    participant.screen_sharing = sharing
    participant.screen_share_paused = paused if sharing else False
    participant.screen_share_source = source if sharing else None
    if sharing:
        meeting.active_screen_share_participant_id = participant.id
    elif meeting.active_screen_share_participant_id == participant.id:
        meeting.active_screen_share_participant_id = None
    audit("screen_share.state", actor=g.current_admin if hasattr(g, "current_admin") else None, session=g.current_session if hasattr(g, "current_session") else None, entity_type="participant", entity_id=participant.id, metadata={"sharing": sharing, "paused": participant.screen_share_paused, "source": participant.screen_share_source})
    db.session.commit()
    payload = {"meetingId": meeting.id, "participant": participant.to_dict(include_private=True), "meeting": meeting.to_dict(include_private=True)}
    socketio.emit("screen:state", payload, room=meeting.id)
    socketio.emit("participant:updated", participant.to_dict(include_private=True), room=meeting.id)
    socketio.emit("meeting:updated", meeting.to_dict(include_private=True), room=meeting.id)
    return jsonify(payload)


@bp.post("/<identifier>/participants/<participant_id>/screen-share")
@require_admin(permission="meetings.manage")
def admin_screen_share_state(identifier: str, participant_id: str):
    meeting = meeting_by_id(identifier)
    if not meeting or meeting.admin_id != g.current_admin.id:
        return error("Meeting not found", 404, "meeting_not_found")
    participant = MeetingParticipant.query.filter_by(id=participant_id, meeting_id=meeting.id).first()
    if not participant:
        return error("Participant not found", 404, "participant_not_found")
    return apply_screen_share_state(meeting, participant, request.get_json(silent=True) or {})


@bp.post("/invitations/<token>/screen-share")
def participant_screen_share_state(token: str):
    invitation = MeetingInvitation.query.filter_by(token=token).first()
    if not invitation:
        return error("Invitation link not found", 404, "invitation_not_found")
    meeting = invitation.meeting
    participant = participant_from_bearer(meeting)
    if not participant:
        return error("Invalid participant session", 401, "invalid_participant_session")
    if participant.status != "admitted":
        return error("Participant is not admitted", 403, "not_admitted")
    return apply_screen_share_state(meeting, participant, request.get_json(silent=True) or {})


@bp.get("/invitations/<token>")
def public_invitation(token: str):
    invitation = MeetingInvitation.query.filter_by(token=token).first()
    if not invitation:
        return error("Invitation link not found", 404, "invitation_not_found")
    meeting = invitation.meeting
    unavailable = invitation_available(meeting)
    if unavailable:
        return unavailable
    db.session.commit()
    return jsonify({"meeting": public_meeting_dict(meeting), "invitation": {"url": invitation.url, "createdAt": invitation.created_at.isoformat() if invitation.created_at else None}})


@bp.post("/invitations/<token>/verify-password")
def verify_invitation_password(token: str):
    invitation = MeetingInvitation.query.filter_by(token=token).first()
    if not invitation:
        return error("Invitation link not found", 404, "invitation_not_found")
    meeting = invitation.meeting
    unavailable = invitation_available(meeting)
    if unavailable:
        return unavailable
    password = (request.get_json(silent=True) or {}).get("password")
    if not meeting.check_password(password):
        return error("Meeting password is incorrect", 401, "invalid_meeting_password")
    db.session.commit()
    return jsonify({"valid": True, "meeting": public_meeting_dict(meeting)})


@bp.post("/invitations/<token>/join")
def join_invitation(token: str):
    invitation = MeetingInvitation.query.filter_by(token=token).first()
    if not invitation:
        return error("Invitation link not found", 404, "invitation_not_found")
    meeting = invitation.meeting
    unavailable = invitation_available(meeting)
    if unavailable:
        return unavailable
    if meeting.is_locked:
        return error("Meeting is locked by the host", 423, "meeting_locked")
    if meeting.host_only_start and not meeting.join_before_host and meeting.status == "scheduled":
        return error("Host has not started the meeting", 409, "host_not_started")
    data = request.get_json(silent=True) or {}
    display_name = str(data.get("displayName", "")).strip()
    if len(display_name) < 2 or len(display_name) > 120:
        return error("Display name must be between 2 and 120 characters", 400, "validation_error")
    if str(data.get("preferredLayout") or "auto") not in {"auto", "mobile", "gallery", "speaker"}:
        return error("preferredLayout must be auto, mobile, gallery, or speaker", 400, "validation_error")
    if not meeting.check_password(data.get("password")):
        return error("Meeting password is incorrect", 401, "invalid_meeting_password")
    banned_identity = MeetingParticipant.query.filter(
        MeetingParticipant.meeting_id == meeting.id,
        MeetingParticipant.removed_reason == "banned_by_host",
        or_(MeetingParticipant.ip_address == client_ip(), MeetingParticipant.user_agent == user_agent()),
    ).first()
    if banned_identity:
        return error("This participant has been banned from the meeting", 403, "participant_banned")
    active_count = MeetingParticipant.query.filter(MeetingParticipant.meeting_id == meeting.id, MeetingParticipant.status.in_(["waiting", "admitted"]), MeetingParticipant.role == "participant").count()
    if meeting.max_participants and active_count >= meeting.max_participants:
        return error("Meeting participant limit has been reached", 409, "meeting_full")
    raw_token = create_participant_token("pending", meeting.id)
    participant = MeetingParticipant(
        meeting_id=meeting.id,
        display_name=display_name,
        role="participant",
        status="waiting" if meeting.waiting_room_enabled else "admitted",
        participant_token_hash=token_hash(raw_token),
        device_info=data.get("deviceInfo") if isinstance(data.get("deviceInfo"), dict) else {},
        muted=not bool(data.get("microphoneEnabled", True)),
        camera_enabled=bool(data.get("cameraEnabled", True)) and not bool(data.get("audioOnlyMode", False)),
        low_bandwidth_mode=bool(data.get("lowBandwidthMode", False)),
        audio_only_mode=bool(data.get("audioOnlyMode", False)),
        preferred_layout=str(data.get("preferredLayout") or "auto"),
        mobile_client=bool(data.get("mobileClient", False)),
        network_type=str(data.get("networkType") or "")[:80] or None,
        ip_address=client_ip(),
        user_agent=user_agent(),
        joined_at=utcnow(),
        admitted_at=None if meeting.waiting_room_enabled else utcnow(),
    )
    db.session.add(participant)
    db.session.flush()
    raw_token = create_participant_token(participant.id, meeting.id)
    participant.participant_token_hash = token_hash(raw_token)
    if participant.status == "admitted":
        meeting.status = "running"
    audit("participant.join_requested", entity_type="participant", entity_id=participant.id, metadata={"meetingId": meeting.meeting_id, "status": participant.status})
    db.session.commit()
    dispatch_webhook("participant.joined", {"meeting": public_meeting_dict(meeting), "participant": participant.to_dict()})
    db.session.commit()
    private_participant = participant.to_dict(include_private=True)
    join_payload = {"meetingId": meeting.id, "meeting": meeting.to_dict(include_private=True), "participant": private_participant}
    socketio.emit("participant:updated", private_participant, room=meeting.id)
    socketio.emit("participant:updated", private_participant, room=meeting.admin_id)
    socketio.emit("participant:join_requested", join_payload, room=meeting.id)
    socketio.emit("participant:join_requested", join_payload, room=meeting.admin_id)
    response = {"meeting": public_meeting_dict(meeting), "participant": participant.to_dict(), "participantToken": raw_token, "requiresAdmission": participant.status == "waiting"}
    if participant.status == "admitted":
        response["livekit"] = livekit_payload(meeting, participant)
    return jsonify(response), 201


@bp.patch("/<identifier>/participants/<participant_id>/preferences")
@require_admin(permission="meetings.manage")
def admin_update_participant_preferences(identifier: str, participant_id: str):
    meeting = meeting_by_id(identifier)
    if not meeting or meeting.admin_id != g.current_admin.id:
        return error("Meeting not found", 404, "meeting_not_found")
    participant = MeetingParticipant.query.filter_by(id=participant_id, meeting_id=meeting.id).first()
    if not participant:
        return error("Participant not found", 404, "participant_not_found")
    try:
        apply_participant_preferences(participant, request.get_json(silent=True) or {})
    except ValueError as exc:
        return error(str(exc), 400, "validation_error")
    db.session.commit()
    sync_livekit_permissions(meeting, participant)
    socketio.emit("participant:updated", participant.to_dict(include_private=True), room=meeting.id)
    return jsonify({"participant": participant.to_dict(include_private=True), "livekit": livekit_payload(meeting, participant) if participant.status == "admitted" else None})


@bp.patch("/invitations/<token>/preferences")
def participant_update_preferences(token: str):
    invitation = MeetingInvitation.query.filter_by(token=token).first()
    if not invitation:
        return error("Invitation link not found", 404, "invitation_not_found")
    meeting = invitation.meeting
    participant = participant_from_bearer(meeting)
    if not participant:
        return error("Invalid participant session", 401, "invalid_participant_session")
    try:
        apply_participant_preferences(participant, request.get_json(silent=True) or {})
    except ValueError as exc:
        return error(str(exc), 400, "validation_error")
    db.session.commit()
    sync_livekit_permissions(meeting, participant)
    socketio.emit("participant:updated", participant.to_dict(), room=meeting.id)
    return jsonify({"participant": participant.to_dict(), "livekit": livekit_payload(meeting, participant) if participant.status == "admitted" else None})


@bp.post("/invitations/<token>/quality")
def participant_quality_report(token: str):
    invitation = MeetingInvitation.query.filter_by(token=token).first()
    if not invitation:
        return error("Invitation link not found", 404, "invitation_not_found")
    meeting = invitation.meeting
    participant = participant_from_bearer(meeting)
    if not participant:
        return error("Invalid participant session", 401, "invalid_participant_session")
    data = request.get_json(silent=True) or {}
    if not isinstance(data, dict):
        return error("Quality report must be an object", 400, "validation_error")
    participant.last_quality_report = data
    if data.get("networkType"):
        participant.network_type = str(data["networkType"])[:80]
    db.session.commit()
    socketio.emit("participant:updated", participant.to_dict(), room=meeting.id)
    return jsonify({"participant": participant.to_dict()})


@bp.get("/invitations/<token>/status")
def participant_status(token: str):
    invitation = MeetingInvitation.query.filter_by(token=token).first()
    if not invitation:
        return error("Invitation link not found", 404, "invitation_not_found")
    meeting = invitation.meeting
    participant = participant_from_bearer(meeting)
    if not participant:
        return error("Invalid participant session", 401, "invalid_participant_session")
    response = {"meeting": public_meeting_dict(meeting), "participant": participant.to_dict(), "requiresAdmission": participant.status == "waiting"}
    if participant.status == "admitted":
        response["livekit"] = livekit_payload(meeting, participant)
    db.session.commit()
    return jsonify(response)
