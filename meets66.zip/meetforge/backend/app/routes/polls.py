from __future__ import annotations

import csv
import io
from datetime import datetime, timedelta, timezone

from flask import Blueprint, Response, g, jsonify, request

from ..decorators import error, require_admin
from ..extensions import db, socketio
from ..models import Meeting, MeetingInvitation, MeetingParticipant, Poll, PollOption, PollVote, Question, QuestionUpvote, utcnow
from ..security import audit, decode_participant_token, token_hash
from ..webhooks import dispatch_webhook

bp = Blueprint("polls", __name__)


def meeting_by_id(identifier: str) -> Meeting | None:
    return Meeting.query.filter((Meeting.id == identifier) | (Meeting.meeting_id == identifier)).first()


def participant_from_bearer(meeting: Meeting) -> MeetingParticipant | None:
    header = request.headers.get("Authorization", "")
    if not header.startswith("Bearer "):
        return None
    raw = header.removeprefix("Bearer ").strip()
    try:
        claims = decode_participant_token(raw)
    except Exception:
        return None
    participant = db.session.get(MeetingParticipant, claims["sub"])
    if not participant or participant.meeting_id != meeting.id or participant.participant_token_hash != token_hash(raw) or participant.status != "admitted":
        return None
    return participant


def admin_actor(identifier: str):
    meeting = meeting_by_id(identifier)
    if not meeting or meeting.admin_id != g.current_admin.id:
        return None, None, error("Meeting not found", 404, "meeting_not_found")
    return meeting, {"admin_id": g.current_admin.id, "participant": None, "name": g.current_admin.display_name, "moderator": True}, None


def participant_actor(token: str, require_moderator: bool = False):
    invitation = MeetingInvitation.query.filter_by(token=token).first()
    if not invitation:
        return None, None, error("Invitation link not found", 404, "invitation_not_found")
    meeting = invitation.meeting
    participant = participant_from_bearer(meeting)
    if not participant:
        return meeting, None, error("Invalid participant session", 401, "invalid_participant_session")
    moderator = participant.role in {"host", "cohost"}
    if require_moderator and not moderator:
        return meeting, None, error("Moderator permissions required", 403, "moderator_required")
    return meeting, {"admin_id": None, "participant": participant, "name": participant.display_name, "moderator": moderator}, None


def parse_time(value: str | None):
    if not value:
        return None
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def poll_payload(poll: Poll, moderator: bool = False):
    return poll.to_dict(include_results=True, include_voters=moderator)


def create_poll_common(meeting: Meeting, actor: dict):
    data = request.get_json(silent=True) or {}
    title = str(data.get("title") or "").strip()
    options = data.get("options") or []
    if len(title) < 3 or len(title) > 240:
        return error("Poll title must be between 3 and 240 characters", 400, "validation_error")
    if not isinstance(options, list) or len(options) < 2 or len(options) > 20:
        return error("Poll requires 2-20 options", 400, "validation_error")
    clean_options = [str(option).strip()[:500] for option in options if str(option).strip()]
    if len(clean_options) < 2:
        return error("Poll requires at least two non-empty options", 400, "validation_error")
    closes_at = parse_time(data.get("closesAt"))
    if data.get("durationSeconds"):
        closes_at = utcnow() + timedelta(seconds=max(1, int(data["durationSeconds"])))
    poll = Poll(
        meeting_id=meeting.id,
        creator_admin_id=actor.get("admin_id"),
        creator_participant_id=actor.get("participant").id if actor.get("participant") else None,
        title=title,
        anonymous=bool(data.get("anonymous", False)),
        multiple_choice=bool(data.get("multipleChoice", False)),
        status="open",
        closes_at=closes_at,
    )
    db.session.add(poll)
    db.session.flush()
    for idx, option_text in enumerate(clean_options):
        db.session.add(PollOption(poll_id=poll.id, text=option_text, position=idx))
    audit("poll.created", actor=g.current_admin if actor.get("admin_id") else None, session=g.current_session if actor.get("admin_id") else None, entity_type="poll", entity_id=poll.id, metadata={"meetingId": meeting.meeting_id})
    db.session.commit()
    dispatch_webhook("poll.created", {"meeting": meeting.to_dict(include_private=False), "poll": poll_payload(poll, moderator=True)})
    db.session.commit()
    socketio.emit("poll:updated", poll_payload(poll, moderator=True), room=meeting.id)
    return jsonify({"poll": poll_payload(poll, moderator=True)}), 201


def list_polls_common(meeting: Meeting, moderator: bool = False):
    polls = Poll.query.filter_by(meeting_id=meeting.id).order_by(Poll.created_at.desc()).all()
    db.session.commit()
    return jsonify({"items": [poll_payload(p, moderator=moderator) for p in polls], "total": len(polls)})


def close_poll_common(meeting: Meeting, poll_id: str, actor: dict):
    poll = Poll.query.filter_by(id=poll_id, meeting_id=meeting.id).first()
    if not poll:
        return error("Poll not found", 404, "poll_not_found")
    poll.status = "closed"
    poll.closed_at = utcnow()
    audit("poll.closed", actor=g.current_admin if actor.get("admin_id") else None, session=g.current_session if actor.get("admin_id") else None, entity_type="poll", entity_id=poll.id)
    db.session.commit()
    dispatch_webhook("poll.closed", {"meeting": meeting.to_dict(include_private=False), "poll": poll_payload(poll, moderator=True)})
    db.session.commit()
    socketio.emit("poll:updated", poll_payload(poll, moderator=True), room=meeting.id)
    return jsonify({"poll": poll_payload(poll, moderator=True)})


def vote_common(meeting: Meeting, poll_id: str, actor: dict):
    poll = Poll.query.filter_by(id=poll_id, meeting_id=meeting.id).first()
    if not poll:
        return error("Poll not found", 404, "poll_not_found")
    if not poll.is_open():
        return error("Poll is closed", 409, "poll_closed")
    data = request.get_json(silent=True) or {}
    option_ids = data.get("optionIds") or ([data.get("optionId")] if data.get("optionId") else [])
    if not isinstance(option_ids, list) or not option_ids:
        return error("optionIds is required", 400, "validation_error")
    option_ids = list(dict.fromkeys(str(option_id) for option_id in option_ids))
    if not poll.multiple_choice and len(option_ids) != 1:
        return error("This poll accepts exactly one option", 400, "validation_error")
    valid = {option.id for option in poll.options}
    if any(option_id not in valid for option_id in option_ids):
        return error("Invalid poll option", 400, "validation_error")
    admin_id = actor.get("admin_id")
    participant = actor.get("participant")
    participant_id = participant.id if participant else None
    PollVote.query.filter_by(poll_id=poll.id, voter_admin_id=admin_id, voter_participant_id=participant_id).delete()
    for option_id in option_ids:
        db.session.add(PollVote(poll_id=poll.id, option_id=option_id, voter_admin_id=admin_id, voter_participant_id=participant_id, voter_display_name=actor["name"]))
    audit("poll.voted", actor=g.current_admin if admin_id else None, session=g.current_session if admin_id else None, entity_type="poll", entity_id=poll.id, metadata={"optionCount": len(option_ids)})
    db.session.commit()
    dispatch_webhook("poll.voted", {"meeting": meeting.to_dict(include_private=False), "poll": poll_payload(poll, moderator=False), "voter": actor["name"] if not poll.anonymous else None})
    db.session.commit()
    socketio.emit("poll:updated", poll_payload(poll, moderator=True), room=meeting.id)
    return jsonify({"poll": poll_payload(poll, moderator=actor.get("moderator", False))})


def poll_results_common(meeting: Meeting, poll_id: str):
    poll = Poll.query.filter_by(id=poll_id, meeting_id=meeting.id).first()
    if not poll:
        return error("Poll not found", 404, "poll_not_found")
    db.session.commit()
    return jsonify({"poll": poll_payload(poll, moderator=True)})


def poll_export_common(meeting: Meeting, poll_id: str):
    poll = Poll.query.filter_by(id=poll_id, meeting_id=meeting.id).first()
    if not poll:
        return error("Poll not found", 404, "poll_not_found")
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["poll", "option", "votes", "voters"])
    results = poll.results(include_voters=True)
    for option in results["options"]:
        writer.writerow([poll.title, option["text"], option["votes"], "; ".join(option.get("voters", []))])
    return Response(output.getvalue(), mimetype="text/csv", headers={"Content-Disposition": f"attachment; filename=poll-{poll.id}.csv"})


def create_question_common(meeting: Meeting, actor: dict):
    text = str((request.get_json(silent=True) or {}).get("text") or "").strip()
    if len(text) < 3 or len(text) > 3000:
        return error("Question must be between 3 and 3000 characters", 400, "validation_error")
    question = Question(meeting_id=meeting.id, author_admin_id=actor.get("admin_id"), author_participant_id=actor.get("participant").id if actor.get("participant") else None, author_display_name=actor["name"], text=text, status="open")
    db.session.add(question)
    db.session.flush()
    audit("question.created", actor=g.current_admin if actor.get("admin_id") else None, session=g.current_session if actor.get("admin_id") else None, entity_type="question", entity_id=question.id)
    db.session.commit()
    socketio.emit("question:updated", question.to_dict(), room=meeting.id)
    return jsonify({"question": question.to_dict()}), 201


def list_questions_common(meeting: Meeting):
    questions = Question.query.filter_by(meeting_id=meeting.id).order_by(Question.created_at.desc()).all()
    db.session.commit()
    return jsonify({"items": [q.to_dict() for q in questions], "total": len(questions)})


def upvote_question_common(meeting: Meeting, question_id: str, actor: dict):
    question = Question.query.filter_by(id=question_id, meeting_id=meeting.id).first()
    if not question:
        return error("Question not found", 404, "question_not_found")
    admin_id = actor.get("admin_id")
    participant = actor.get("participant")
    participant_id = participant.id if participant else None
    existing = QuestionUpvote.query.filter_by(question_id=question.id, voter_admin_id=admin_id, voter_participant_id=participant_id).first()
    if existing:
        db.session.delete(existing)
    else:
        db.session.add(QuestionUpvote(question_id=question.id, voter_admin_id=admin_id, voter_participant_id=participant_id, voter_display_name=actor["name"]))
    db.session.commit()
    socketio.emit("question:updated", question.to_dict(), room=meeting.id)
    return jsonify({"question": question.to_dict(), "upvoted": existing is None})


def moderate_question_common(meeting: Meeting, question_id: str, actor: dict):
    question = Question.query.filter_by(id=question_id, meeting_id=meeting.id).first()
    if not question:
        return error("Question not found", 404, "question_not_found")
    data = request.get_json(silent=True) or {}
    status = str(data.get("status") or question.status)
    if status not in {"open", "answered", "dismissed"}:
        return error("status must be open, answered, or dismissed", 400, "validation_error")
    question.status = status
    if "answerText" in data:
        question.answer_text = str(data.get("answerText") or "").strip()[:5000] or None
        question.answered_by_admin_id = actor.get("admin_id")
        question.answered_by_participant_id = actor.get("participant").id if actor.get("participant") else None
        question.answered_by_display_name = actor["name"]
        question.answered_at = utcnow()
        question.status = "answered"
    audit("question.moderated", actor=g.current_admin if actor.get("admin_id") else None, session=g.current_session if actor.get("admin_id") else None, entity_type="question", entity_id=question.id, metadata={"status": question.status})
    db.session.commit()
    socketio.emit("question:updated", question.to_dict(), room=meeting.id)
    return jsonify({"question": question.to_dict()})


def qna_export_common(meeting: Meeting):
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["question", "author", "status", "upvotes", "answer", "answered_by"])
    for question in Question.query.filter_by(meeting_id=meeting.id).order_by(Question.created_at.asc()).all():
        writer.writerow([question.text, question.author_display_name, question.status, len(question.upvotes or []), question.answer_text or "", question.answered_by_display_name or ""])
    return Response(output.getvalue(), mimetype="text/csv", headers={"Content-Disposition": f"attachment; filename=qna-{meeting.meeting_id}.csv"})


# Admin/host endpoints
@bp.get("/<identifier>/polls")
@require_admin(permission="meetings.manage")
def admin_list_polls(identifier: str):
    meeting, actor, err = admin_actor(identifier)
    if err: return err
    return list_polls_common(meeting, moderator=True)


@bp.post("/<identifier>/polls")
@require_admin(permission="meetings.manage")
def admin_create_poll(identifier: str):
    meeting, actor, err = admin_actor(identifier)
    if err: return err
    return create_poll_common(meeting, actor)


@bp.post("/<identifier>/polls/<poll_id>/vote")
@require_admin(permission="meetings.manage")
def admin_vote(identifier: str, poll_id: str):
    meeting, actor, err = admin_actor(identifier)
    if err: return err
    return vote_common(meeting, poll_id, actor)


@bp.post("/<identifier>/polls/<poll_id>/close")
@require_admin(permission="meetings.manage")
def admin_close_poll(identifier: str, poll_id: str):
    meeting, actor, err = admin_actor(identifier)
    if err: return err
    return close_poll_common(meeting, poll_id, actor)


@bp.get("/<identifier>/polls/<poll_id>/results")
@require_admin(permission="meetings.manage")
def admin_poll_results(identifier: str, poll_id: str):
    meeting, actor, err = admin_actor(identifier)
    if err: return err
    return poll_results_common(meeting, poll_id)


@bp.get("/<identifier>/polls/<poll_id>/export.csv")
@require_admin(permission="meetings.manage")
def admin_poll_export(identifier: str, poll_id: str):
    meeting, actor, err = admin_actor(identifier)
    if err: return err
    return poll_export_common(meeting, poll_id)


@bp.get("/<identifier>/questions")
@require_admin(permission="meetings.manage")
def admin_questions(identifier: str):
    meeting, actor, err = admin_actor(identifier)
    if err: return err
    return list_questions_common(meeting)


@bp.post("/<identifier>/questions")
@require_admin(permission="meetings.manage")
def admin_create_question(identifier: str):
    meeting, actor, err = admin_actor(identifier)
    if err: return err
    return create_question_common(meeting, actor)


@bp.post("/<identifier>/questions/<question_id>/upvote")
@require_admin(permission="meetings.manage")
def admin_upvote_question(identifier: str, question_id: str):
    meeting, actor, err = admin_actor(identifier)
    if err: return err
    return upvote_question_common(meeting, question_id, actor)


@bp.patch("/<identifier>/questions/<question_id>")
@require_admin(permission="meetings.manage")
def admin_moderate_question(identifier: str, question_id: str):
    meeting, actor, err = admin_actor(identifier)
    if err: return err
    return moderate_question_common(meeting, question_id, actor)


@bp.get("/<identifier>/questions/export.csv")
@require_admin(permission="meetings.manage")
def admin_qna_export(identifier: str):
    meeting, actor, err = admin_actor(identifier)
    if err: return err
    return qna_export_common(meeting)


# Participant and co-host invitation endpoints
@bp.get("/invitations/<token>/polls")
def participant_list_polls(token: str):
    meeting, actor, err = participant_actor(token)
    if err: return err
    return list_polls_common(meeting, moderator=actor["moderator"])


@bp.post("/invitations/<token>/polls")
def participant_create_poll(token: str):
    meeting, actor, err = participant_actor(token, require_moderator=True)
    if err: return err
    return create_poll_common(meeting, actor)


@bp.post("/invitations/<token>/polls/<poll_id>/vote")
def participant_vote(token: str, poll_id: str):
    meeting, actor, err = participant_actor(token)
    if err: return err
    return vote_common(meeting, poll_id, actor)


@bp.post("/invitations/<token>/polls/<poll_id>/close")
def participant_close_poll(token: str, poll_id: str):
    meeting, actor, err = participant_actor(token, require_moderator=True)
    if err: return err
    return close_poll_common(meeting, poll_id, actor)


@bp.get("/invitations/<token>/questions")
def participant_questions(token: str):
    meeting, actor, err = participant_actor(token)
    if err: return err
    return list_questions_common(meeting)


@bp.post("/invitations/<token>/questions")
def participant_create_question(token: str):
    meeting, actor, err = participant_actor(token)
    if err: return err
    return create_question_common(meeting, actor)


@bp.post("/invitations/<token>/questions/<question_id>/upvote")
def participant_upvote_question(token: str, question_id: str):
    meeting, actor, err = participant_actor(token)
    if err: return err
    return upvote_question_common(meeting, question_id, actor)


@bp.patch("/invitations/<token>/questions/<question_id>")
def participant_moderate_question(token: str, question_id: str):
    meeting, actor, err = participant_actor(token, require_moderator=True)
    if err: return err
    return moderate_question_common(meeting, question_id, actor)
