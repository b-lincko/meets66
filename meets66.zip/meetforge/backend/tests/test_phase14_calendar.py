from datetime import datetime, timedelta, timezone

import pytest

from app import create_app, seed_database
from app.config import TestingConfig
from app.extensions import db


@pytest.fixture()
def app():
    app = create_app(TestingConfig)
    app.config["PUBLIC_APP_URL"] = "http://localhost:3000"
    with app.app_context():
        db.drop_all()
        db.create_all()
        seed_database(app)
    yield app


@pytest.fixture()
def client(app):
    return app.test_client()


def admin_token(client):
    login = client.post("/api/v1/auth/login", json={"email": "web@defensiqsecurity.com", "password": "Nullbyte69"})
    changed = client.post(
        "/api/v1/auth/change-password",
        headers={"Authorization": f"Bearer {login.json['accessToken']}"},
        json={"currentPassword": "Nullbyte69", "newPassword": "NewStrong123", "confirmPassword": "NewStrong123"},
    )
    return changed.json["accessToken"]


def create_calendar_meeting(client, token, recurrence="weekly", count=3, reminder=15):
    start = datetime.now(timezone.utc).replace(microsecond=0) + timedelta(days=1)
    end = start + timedelta(hours=1)
    response = client.post(
        "/api/v1/meetings",
        headers={"Authorization": f"Bearer {token}"},
        json={
            "title": "Calendar Sync",
            "description": "Calendar integration test",
            "scheduledStartAt": start.isoformat(),
            "scheduledEndAt": end.isoformat(),
            "timezone": "Asia/Qatar",
            "reminderMinutes": reminder,
            "recurrenceType": recurrence,
            "recurrenceCount": count,
        },
    )
    assert response.status_code == 201, response.json
    return response.json


def test_admin_ics_contains_alarm_recurrence_and_join_details(client):
    token = admin_token(client)
    created = create_calendar_meeting(client, token)
    meeting_id = created["meeting"]["id"]
    response = client.get(f"/api/v1/meetings/{meeting_id}/calendar.ics", headers={"Authorization": f"Bearer {token}"})
    assert response.status_code == 200
    text = response.get_data(as_text=True)
    assert "BEGIN:VCALENDAR" in text
    assert "BEGIN:VEVENT" in text
    assert "SUMMARY:Calendar Sync" in text
    assert "RRULE:FREQ=WEEKLY;COUNT=3" in text
    assert "BEGIN:VALARM" in text
    assert "TRIGGER:-PT15M" in text
    assert created["invitation"]["url"] in text
    assert response.mimetype == "text/calendar"


def test_public_calendar_ics_and_provider_links(client):
    token = admin_token(client)
    created = create_calendar_meeting(client, token, recurrence="none", count=1, reminder=0)
    invite = created["invitation"]["token"]
    public_ics = client.get(f"/api/v1/meetings/invitations/{invite}/calendar.ics")
    assert public_ics.status_code == 200
    text = public_ics.get_data(as_text=True)
    assert "BEGIN:VCALENDAR" in text
    assert "VALARM" not in text

    links = client.get(f"/api/v1/meetings/invitations/{invite}/calendar-links")
    assert links.status_code == 200
    assert links.json["links"]["google"].startswith("https://calendar.google.com/calendar/render")
    assert "outlook.office.com" in links.json["links"]["outlook"]
    assert links.json["icsUrl"].endswith(f"/api/v1/meetings/invitations/{invite}/calendar.ics")


def test_admin_calendar_links_require_auth_and_include_timezone(client):
    token = admin_token(client)
    created = create_calendar_meeting(client, token)
    meeting_id = created["meeting"]["id"]
    unauth = client.get(f"/api/v1/meetings/{meeting_id}/calendar-links")
    assert unauth.status_code == 401
    links = client.get(f"/api/v1/meetings/{meeting_id}/calendar-links", headers={"Authorization": f"Bearer {token}"})
    assert links.status_code == 200
    assert "ctz=Asia%2FQatar" in links.json["links"]["google"]
    assert links.json["meeting"]["reminderMinutes"] == 15


def test_reminder_validation(client):
    token = admin_token(client)
    start = datetime.now(timezone.utc) + timedelta(days=1)
    end = start + timedelta(hours=1)
    bad = client.post(
        "/api/v1/meetings",
        headers={"Authorization": f"Bearer {token}"},
        json={"title": "Bad Reminder", "scheduledStartAt": start.isoformat(), "scheduledEndAt": end.isoformat(), "timezone": "UTC", "reminderMinutes": 10081},
    )
    assert bad.status_code == 400
    assert bad.json["error"]["code"] == "validation_error"
