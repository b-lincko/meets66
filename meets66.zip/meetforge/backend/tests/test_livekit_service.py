from app import create_app
from app.config import TestingConfig
from app.livekit_service import permission_source_values


def test_permission_source_values_are_livekit_enum_values():
    app = create_app(TestingConfig)
    with app.app_context():
        from livekit import api
        assert permission_source_values(["camera", "microphone", "screen_share", "screen_share_audio"]) == [api.CAMERA, api.MICROPHONE, api.SCREEN_SHARE, api.SCREEN_SHARE_AUDIO]
        permission = api.ParticipantPermission(can_publish_sources=permission_source_values(["camera", "microphone"]))
        assert list(permission.can_publish_sources) == [api.CAMERA, api.MICROPHONE]


def test_permission_source_values_ignores_unknown_sources():
    app = create_app(TestingConfig)
    with app.app_context():
        from livekit import api
        assert permission_source_values(["camera", "bad-source"]) == [api.CAMERA]


def test_livekit_run_works_from_existing_event_loop():
    import asyncio
    from flask import current_app
    from app.livekit_service import _run

    app = create_app(TestingConfig)

    async def main():
        with app.app_context():
            async def uses_app_context():
                assert current_app.config["TESTING"] is True
            assert _run(uses_app_context()) is True

    asyncio.run(main())


def test_livekit_not_found_is_treated_as_noop():
    from app.livekit_service import _run

    class LiveKitNotFound(Exception):
        status = 404
        code = "not_found"

    app = create_app(TestingConfig)
    with app.app_context():
        async def missing_participant():
            raise LiveKitNotFound("participant does not exist")
        assert _run(missing_participant()) is False
