from datetime import datetime, timedelta, timezone

import pytest

from app import create_app, seed_database
from app.config import TestingConfig
from app.extensions import db


@pytest.fixture()
def app():
    app = create_app(TestingConfig)
    with app.app_context():
        db.drop_all()
        db.create_all()
        seed_database(app)
    yield app


@pytest.fixture()
def client(app):
    return app.test_client()


def login(client, email="web@defensiqsecurity.com", password="Nullbyte69"):
    return client.post("/api/v1/auth/login", json={"email": email, "password": password})


def super_token(client):
    logged = login(client)
    changed = client.post(
        "/api/v1/auth/change-password",
        headers={"Authorization": f"Bearer {logged.json['accessToken']}"},
        json={"currentPassword": "Nullbyte69", "newPassword": "NewStrong123", "confirmPassword": "NewStrong123"},
    )
    return changed.json["accessToken"]


def create_admin(client, token, email, permissions):
    response = client.post(
        "/api/v1/admin/admins",
        headers={"Authorization": f"Bearer {token}"},
        json={"email": email, "displayName": email, "password": "AdminStrong123", "role": "admin", "permissions": permissions},
    )
    assert response.status_code == 201, response.json
    return response.json["admin"]


def changed_admin_token(client, email):
    logged = login(client, email=email, password="AdminStrong123")
    assert logged.status_code == 200, logged.json
    changed = client.post(
        "/api/v1/auth/change-password",
        headers={"Authorization": f"Bearer {logged.json['accessToken']}"},
        json={"currentPassword": "AdminStrong123", "newPassword": "AdminStrong124", "confirmPassword": "AdminStrong124"},
    )
    assert changed.status_code == 200, changed.json
    return changed.json["accessToken"]


def test_admin_auth_payload_includes_effective_permissions(client):
    token = super_token(client)
    me = client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert me.status_code == 200
    assert me.json["admin"]["role"] == "super_admin"
    assert "admins.manage" in me.json["admin"]["effectivePermissions"]


def test_permissions_enforced_on_meetings_recordings_security_integrations(client):
    super_admin = super_token(client)
    create_admin(client, super_admin, "meeting-only@example.com", ["meetings.manage"])
    token = changed_admin_token(client, "meeting-only@example.com")

    start = datetime.now(timezone.utc) + timedelta(hours=1)
    end = start + timedelta(hours=1)
    meeting = client.post(
        "/api/v1/meetings",
        headers={"Authorization": f"Bearer {token}"},
        json={"title": "RBAC Meeting", "scheduledStartAt": start.isoformat(), "scheduledEndAt": end.isoformat(), "timezone": "UTC"},
    )
    assert meeting.status_code == 201

    recordings = client.get("/api/v1/recordings", headers={"Authorization": f"Bearer {token}"})
    assert recordings.status_code == 403
    security = client.get("/api/v1/security/devices", headers={"Authorization": f"Bearer {token}"})
    assert security.status_code == 403
    integrations = client.get("/api/v1/admin/api-keys", headers={"Authorization": f"Bearer {token}"})
    assert integrations.status_code == 403
    analytics = client.get("/api/v1/admin/overview", headers={"Authorization": f"Bearer {token}"})
    assert analytics.status_code == 403


def test_recordings_permission_can_access_recordings_but_not_meetings(client):
    super_admin = super_token(client)
    create_admin(client, super_admin, "recordings-only@example.com", ["recordings.manage"])
    token = changed_admin_token(client, "recordings-only@example.com")
    assert client.get("/api/v1/recordings", headers={"Authorization": f"Bearer {token}"}).status_code == 200
    assert client.get("/api/v1/meetings", headers={"Authorization": f"Bearer {token}"}).status_code == 403
