from datetime import datetime, timedelta, timezone

import hmac
import json
from hashlib import sha256

import pytest

from app import create_app, seed_database
from app.config import TestingConfig
from app.extensions import db
from app.models import ApiKey, WebhookDelivery, WebhookSubscription
from app.webhooks import generate_webhook_secret


@pytest.fixture()
def app():
    app = create_app(TestingConfig)
    app.config["PUBLIC_APP_URL"] = "http://localhost:3000"
    app.config["LIVEKIT_URL"] = "ws://localhost:7880"
    app.config["LIVEKIT_API_SECRET"] = "secret-for-tests-with-enough-length-123"
    with app.app_context():
        db.drop_all()
        db.create_all()
        seed_database(app)
    yield app


@pytest.fixture()
def client(app):
    return app.test_client()


def admin_token(client):
    login = client.post("/api/v1/auth/login", json={"email": "web@defensiqsecurity.com", "password": "Nullbyte69"})
    changed = client.post(
        "/api/v1/auth/change-password",
        headers={"Authorization": f"Bearer {login.json['accessToken']}"},
        json={"currentPassword": "Nullbyte69", "newPassword": "NewStrong123", "confirmPassword": "NewStrong123"},
    )
    return changed.json["accessToken"]


def create_meeting(client, token):
    start = datetime.now(timezone.utc) + timedelta(hours=1)
    end = start + timedelta(hours=1)
    res = client.post(
        "/api/v1/meetings",
        headers={"Authorization": f"Bearer {token}"},
        json={"title": "Webhook Meeting", "scheduledStartAt": start.isoformat(), "scheduledEndAt": end.isoformat(), "timezone": "UTC", "waitingRoomEnabled": False},
    )
    assert res.status_code == 201, res.json
    return res.json


def test_openapi_documentation_exposes_real_paths(client):
    res = client.get("/api/v1/openapi.json")
    assert res.status_code == 200
    assert res.json["openapi"] == "3.0.3"
    assert "/meetings" in res.json["paths"]
    assert "meeting.created" in res.json["x-webhook-events"]
    html = client.get("/api/v1/docs")
    assert html.status_code == 200
    assert b"Defensiq Meet API" in html.data


def test_api_key_create_list_external_use_and_revoke(client):
    token = admin_token(client)
    created = client.post("/api/v1/admin/api-keys", headers={"Authorization": f"Bearer {token}"}, json={"name": "Reporting", "scopes": ["meetings:read", "recordings:read"]})
    assert created.status_code == 201, created.json
    secret = created.json["secret"]
    assert secret.startswith("dfq_")
    assert ApiKey.query.count() == 1
    assert created.json["apiKey"]["keyPrefix"] == secret[:12]

    create_meeting(client, token)
    external = client.get("/api/v1/external/meetings", headers={"X-API-Key": secret})
    assert external.status_code == 200
    assert external.json["total"] == 1
    key = ApiKey.query.first()
    assert key.last_used_at is not None

    listed = client.get("/api/v1/admin/api-keys", headers={"Authorization": f"Bearer {token}"})
    assert listed.status_code == 200
    assert listed.json["total"] == 1
    assert "secret" not in listed.json["items"][0]

    revoked = client.delete(f"/api/v1/admin/api-keys/{created.json['apiKey']['id']}", headers={"Authorization": f"Bearer {token}"})
    assert revoked.status_code == 200
    denied = client.get("/api/v1/external/meetings", headers={"X-API-Key": secret})
    assert denied.status_code == 401


def test_api_key_scope_enforcement(client):
    token = admin_token(client)
    created = client.post("/api/v1/admin/api-keys", headers={"Authorization": f"Bearer {token}"}, json={"name": "Meetings only", "scopes": ["meetings:read"]})
    secret = created.json["secret"]
    denied = client.get("/api/v1/external/recordings", headers={"X-API-Key": secret})
    assert denied.status_code == 403
    assert denied.json["error"]["code"] == "insufficient_scope"


def test_webhook_delivery_signature_and_event_dispatch(client, monkeypatch):
    posts = []

    class FakeResponse:
        status_code = 204
        text = "accepted"

    def capture_post(url, data, headers, timeout):
        posts.append({"url": url, "data": data, "headers": headers, "timeout": timeout})
        return FakeResponse()

    monkeypatch.setattr("app.webhooks.requests.post", capture_post)
    token = admin_token(client)
    hook = client.post("/api/v1/admin/webhooks", headers={"Authorization": f"Bearer {token}"}, json={"targetUrl": "https://example.com/hook", "events": ["meeting.created"], "description": "test"})
    assert hook.status_code == 201, hook.json
    assert hook.json["webhook"]["signingSecret"].startswith("whsec_")
    create_meeting(client, token)

    assert WebhookDelivery.query.count() == 1
    delivery = WebhookDelivery.query.first()
    assert delivery.status == "delivered"
    assert delivery.attempts == 1
    assert WebhookSubscription.query.first().last_success_at is not None
    assert posts and posts[0]["url"] == "https://example.com/hook"
    timestamp = posts[0]["headers"]["X-Defensiq-Timestamp"]
    expected = hmac.new(generate_webhook_secret(hook.json["webhook"]["id"]).encode(), f"{timestamp}.{posts[0]['data']}".encode(), sha256).hexdigest()
    assert posts[0]["headers"]["X-Defensiq-Signature"] == f"sha256={expected}"
    payload = json.loads(posts[0]["data"])
    assert payload["event"] == "meeting.created"


def test_webhook_failure_retry_and_delivery_listing(client, monkeypatch):
    attempts = []

    class FailResponse:
        status_code = 500
        text = "fail"

    class OkResponse:
        status_code = 200
        text = "ok"

    def failing(url, data, headers, timeout):
        attempts.append("fail")
        return FailResponse()

    def succeeding(url, data, headers, timeout):
        attempts.append("ok")
        return OkResponse()

    monkeypatch.setattr("app.webhooks.requests.post", failing)
    token = admin_token(client)
    client.post("/api/v1/admin/webhooks", headers={"Authorization": f"Bearer {token}"}, json={"targetUrl": "https://example.com/hook", "events": ["meeting.created"]})
    create_meeting(client, token)
    delivery = WebhookDelivery.query.first()
    assert delivery.status == "failed"
    assert delivery.next_retry_at is not None

    deliveries = client.get("/api/v1/admin/webhook-deliveries?status=failed", headers={"Authorization": f"Bearer {token}"})
    assert deliveries.status_code == 200
    assert deliveries.json["total"] == 1

    monkeypatch.setattr("app.webhooks.requests.post", succeeding)
    retried = client.post(f"/api/v1/admin/webhook-deliveries/{delivery.id}/retry", headers={"Authorization": f"Bearer {token}"})
    assert retried.status_code == 200
    assert retried.json["delivery"]["status"] == "delivered"
    assert attempts == ["fail", "ok"]


def test_webhook_crud_validation(client):
    token = admin_token(client)
    bad_url = client.post("/api/v1/admin/webhooks", headers={"Authorization": f"Bearer {token}"}, json={"targetUrl": "ftp://bad", "events": ["meeting.created"]})
    assert bad_url.status_code == 400
    bad_event = client.post("/api/v1/admin/webhooks", headers={"Authorization": f"Bearer {token}"}, json={"targetUrl": "https://example.com", "events": ["bad.event"]})
    assert bad_event.status_code == 400
    created = client.post("/api/v1/admin/webhooks", headers={"Authorization": f"Bearer {token}"}, json={"targetUrl": "https://example.com", "events": ["*"]})
    hook_id = created.json["webhook"]["id"]
    updated = client.patch(f"/api/v1/admin/webhooks/{hook_id}", headers={"Authorization": f"Bearer {token}"}, json={"enabled": False, "events": ["recording.started"]})
    assert updated.status_code == 200
    assert updated.json["webhook"]["enabled"] is False
    disabled = client.delete(f"/api/v1/admin/webhooks/{hook_id}", headers={"Authorization": f"Bearer {token}"})
    assert disabled.status_code == 200
    assert disabled.json["webhook"]["enabled"] is False
