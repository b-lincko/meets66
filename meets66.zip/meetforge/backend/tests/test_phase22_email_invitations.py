from datetime import datetime, timedelta, timezone

import pytest

from app import create_app, seed_database
from app.config import TestingConfig
from app.extensions import db
from app.models import AppSetting


@pytest.fixture()
def app():
    app = create_app(TestingConfig)
    app.config["PUBLIC_APP_URL"] = "http://localhost:3000"
    with app.app_context():
        db.drop_all()
        db.create_all()
        seed_database(app)
    yield app


@pytest.fixture()
def client(app):
    return app.test_client()


def admin_token(client):
    login = client.post("/api/v1/auth/login", json={"email": "web@defensiqsecurity.com", "password": "Nullbyte69"})
    changed = client.post(
        "/api/v1/auth/change-password",
        headers={"Authorization": f"Bearer {login.json['accessToken']}"},
        json={"currentPassword": "Nullbyte69", "newPassword": "NewStrong123", "confirmPassword": "NewStrong123"},
    )
    return changed.json["accessToken"]


def create_meeting(client, token):
    start = datetime.now(timezone.utc) + timedelta(hours=1)
    end = start + timedelta(hours=1)
    response = client.post(
        "/api/v1/meetings",
        headers={"Authorization": f"Bearer {token}"},
        json={"title": "Email Invite", "scheduledStartAt": start.isoformat(), "scheduledEndAt": end.isoformat(), "timezone": "UTC"},
    )
    assert response.status_code == 201, response.json
    return response.json


def configure_email(app):
    with app.app_context():
        setting = db.session.get(AppSetting, "email_settings")
        setting.value = {**setting.value, "meetingInvitationsEnabled": True, "smtpHost": "smtp.example.com", "smtpPort": 587, "smtpFrom": "meet@example.com", "smtpUseTls": True}
        db.session.commit()


def test_email_invitations_send_ics_and_validate_recipients(client, app, monkeypatch):
    configure_email(app)
    sent = []
    def capture_send(*, meeting, to_email, ics, extra_message=None):
        sent.append({"meeting": meeting.title, "to": to_email, "ics": ics, "message": extra_message})
    monkeypatch.setattr("app.routes.meetings.send_meeting_invite_email", capture_send)
    token = admin_token(client)
    meeting = create_meeting(client, token)
    response = client.post(
        f"/api/v1/meetings/{meeting['meeting']['id']}/email-invitations",
        headers={"Authorization": f"Bearer {token}"},
        json={"recipients": ["USER@EXAMPLE.COM"], "message": "Please join on time"},
    )
    assert response.status_code == 200, response.json
    assert response.json["sent"] == ["USER@example.com"]
    assert sent[0]["to"] == "USER@example.com"
    assert "BEGIN:VCALENDAR" in sent[0]["ics"]
    assert "Please join on time" == sent[0]["message"]

    bad = client.post(f"/api/v1/meetings/{meeting['meeting']['id']}/email-invitations", headers={"Authorization": f"Bearer {token}"}, json={"recipients": ["bad-email"]})
    assert bad.status_code == 400
    assert bad.json["error"]["code"] == "invalid_email"


def test_email_invitations_reports_smtp_failures(client, monkeypatch):
    token = admin_token(client)
    meeting = create_meeting(client, token)
    def failing_send(**kwargs):
        raise RuntimeError("SMTP host is not configured")
    monkeypatch.setattr("app.routes.meetings.send_meeting_invite_email", failing_send)
    response = client.post(f"/api/v1/meetings/{meeting['meeting']['id']}/email-invitations", headers={"Authorization": f"Bearer {token}"}, json={"recipients": ["user@example.com"]})
    assert response.status_code == 500
    assert response.json["failed"][0]["error"] == "SMTP host is not configured"


def test_email_invitations_require_meeting_permission(client):
    login = client.post("/api/v1/auth/login", json={"email": "web@defensiqsecurity.com", "password": "Nullbyte69"})
    assert login.status_code == 200
    blocked = client.post("/api/v1/meetings/nope/email-invitations", headers={"Authorization": f"Bearer {login.json['accessToken']}"}, json={"recipients": ["user@example.com"]})
    assert blocked.status_code == 403
