from datetime import datetime, timedelta, timezone

import jwt
import pytest

from app import create_app, seed_database
from app.config import TestingConfig
from app.extensions import db
from app.models import MeetingParticipant


@pytest.fixture()
def app():
    app = create_app(TestingConfig)
    app.config["PUBLIC_APP_URL"] = "http://localhost:3000"
    app.config["LIVEKIT_URL"] = "ws://localhost:7880"
    app.config["LIVEKIT_API_KEY"] = "devkey"
    app.config["LIVEKIT_API_SECRET"] = "secret-for-tests-with-enough-length-123"
    with app.app_context():
        db.drop_all()
        db.create_all()
        seed_database(app)
    yield app


@pytest.fixture()
def client(app):
    return app.test_client()


def admin_token(client):
    login = client.post("/api/v1/auth/login", json={"email": "web@defensiqsecurity.com", "password": "Nullbyte69"})
    changed = client.post(
        "/api/v1/auth/change-password",
        headers={"Authorization": f"Bearer {login.json['accessToken']}"},
        json={"currentPassword": "Nullbyte69", "newPassword": "NewStrong123", "confirmPassword": "NewStrong123"},
    )
    return changed.json["accessToken"]


def create_meeting(client, token, waiting=True, password="Secure123", max_participants=None):
    start = datetime.now(timezone.utc) + timedelta(hours=1)
    end = start + timedelta(hours=1)
    payload = {
        "title": "Phase 3 Meeting",
        "scheduledStartAt": start.isoformat(),
        "scheduledEndAt": end.isoformat(),
        "timezone": "UTC",
        "waitingRoomEnabled": waiting,
        "password": password,
    }
    if max_participants is not None:
        payload["maxParticipants"] = max_participants
    res = client.post("/api/v1/meetings", headers={"Authorization": f"Bearer {token}"}, json=payload)
    assert res.status_code == 201, res.json
    return res.json


def test_participant_join_waiting_room_host_admit_and_livekit_token(client):
    token = admin_token(client)
    created = create_meeting(client, token, waiting=True)
    invitation = created["invitation"]["token"]
    meeting_id = created["meeting"]["id"]

    host = client.post(f"/api/v1/meetings/{meeting_id}/host-token", headers={"Authorization": f"Bearer {token}"})
    assert host.status_code == 200, host.json
    host_claims = jwt.decode(host.json["livekit"]["token"], options={"verify_signature": False})
    assert host_claims["video"]["room"] == created["meeting"]["livekitRoomName"]
    assert host_claims["video"]["roomAdmin"] is True

    joined = client.post(f"/api/v1/meetings/invitations/{invitation}/join", json={"displayName": "Analyst One", "password": "Secure123", "deviceInfo": {"browser": "Chrome"}})
    assert joined.status_code == 201, joined.json
    assert joined.json["requiresAdmission"] is True
    assert "livekit" not in joined.json
    participant_id = joined.json["participant"]["id"]
    participant_token = joined.json["participantToken"]

    waiting_status = client.get(f"/api/v1/meetings/invitations/{invitation}/status", headers={"Authorization": f"Bearer {participant_token}"})
    assert waiting_status.status_code == 200
    assert waiting_status.json["requiresAdmission"] is True

    participants = client.get(f"/api/v1/meetings/{meeting_id}/participants", headers={"Authorization": f"Bearer {token}"})
    assert participants.status_code == 200
    assert participants.json["total"] == 2  # host + waiting participant

    admitted = client.post(f"/api/v1/meetings/{meeting_id}/participants/{participant_id}/admit", headers={"Authorization": f"Bearer {token}"})
    assert admitted.status_code == 200
    assert admitted.json["participant"]["status"] == "admitted"

    status = client.get(f"/api/v1/meetings/invitations/{invitation}/status", headers={"Authorization": f"Bearer {participant_token}"})
    assert status.status_code == 200
    assert status.json["requiresAdmission"] is False
    assert "livekit" in status.json
    participant_claims = jwt.decode(status.json["livekit"]["token"], options={"verify_signature": False})
    assert participant_claims["sub"] == participant_id
    assert participant_claims["video"]["roomJoin"] is True
    assert participant_claims["video"]["canPublish"] is True
    assert participant_claims["video"]["canSubscribe"] is True


def test_join_without_waiting_room_returns_livekit_immediately(client):
    token = admin_token(client)
    created = create_meeting(client, token, waiting=False, password=None)
    invitation = created["invitation"]["token"]
    joined = client.post(f"/api/v1/meetings/invitations/{invitation}/join", json={"displayName": "Analyst Two"})
    assert joined.status_code == 201, joined.json
    assert joined.json["requiresAdmission"] is False
    assert joined.json["participant"]["status"] == "admitted"
    assert "livekit" in joined.json


def test_reject_waiting_participant(client):
    token = admin_token(client)
    created = create_meeting(client, token, waiting=True)
    invitation = created["invitation"]["token"]
    meeting_id = created["meeting"]["id"]
    joined = client.post(f"/api/v1/meetings/invitations/{invitation}/join", json={"displayName": "Analyst Three", "password": "Secure123"})
    participant_id = joined.json["participant"]["id"]
    participant_token = joined.json["participantToken"]
    rejected = client.post(f"/api/v1/meetings/{meeting_id}/participants/{participant_id}/reject", headers={"Authorization": f"Bearer {token}"})
    assert rejected.status_code == 200
    status = client.get(f"/api/v1/meetings/invitations/{invitation}/status", headers={"Authorization": f"Bearer {participant_token}"})
    assert status.status_code == 200
    assert status.json["participant"]["status"] == "rejected"


def test_join_validation_password_and_capacity(client):
    token = admin_token(client)
    created = create_meeting(client, token, waiting=False, max_participants=1)
    invitation = created["invitation"]["token"]
    short_name = client.post(f"/api/v1/meetings/invitations/{invitation}/join", json={"displayName": "A", "password": "Secure123"})
    assert short_name.status_code == 400
    wrong_password = client.post(f"/api/v1/meetings/invitations/{invitation}/join", json={"displayName": "Valid Name", "password": "wrong"})
    assert wrong_password.status_code == 401
    first = client.post(f"/api/v1/meetings/invitations/{invitation}/join", json={"displayName": "First", "password": "Secure123"})
    assert first.status_code == 201
    full = client.post(f"/api/v1/meetings/invitations/{invitation}/join", json={"displayName": "Second", "password": "Secure123"})
    assert full.status_code == 409


def test_participant_token_is_required_for_status(client):
    token = admin_token(client)
    created = create_meeting(client, token, waiting=False, password=None)
    invitation = created["invitation"]["token"]
    denied = client.get(f"/api/v1/meetings/invitations/{invitation}/status")
    assert denied.status_code == 401


def test_waiting_room_join_request_is_emitted_to_meeting_and_admin_rooms(client, monkeypatch):
    emitted = []
    monkeypatch.setattr("app.routes.meetings.socketio.emit", lambda name, payload=None, **kwargs: emitted.append({"name": name, "payload": payload, "kwargs": kwargs}))
    token = admin_token(client)
    created = create_meeting(client, token, waiting=True)
    invitation = created["invitation"]["token"]
    meeting_id = created["meeting"]["id"]
    admin_id = created["meeting"]["adminId"]

    joined = client.post(f"/api/v1/meetings/invitations/{invitation}/join", json={"displayName": "Realtime Waiting", "password": "Secure123"})
    assert joined.status_code == 201, joined.json

    join_events = [event for event in emitted if event["name"] == "participant:join_requested"]
    assert len(join_events) == 2
    assert {event["kwargs"]["room"] for event in join_events} == {meeting_id, admin_id}
    assert all(event["payload"]["participant"]["displayName"] == "Realtime Waiting" for event in join_events)
    update_events = [event for event in emitted if event["name"] == "participant:updated"]
    assert {event["kwargs"]["room"] for event in update_events} >= {meeting_id, admin_id}
