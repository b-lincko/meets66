from datetime import datetime, timedelta, timezone

import pytest

from app import create_app, seed_database
from app.config import TestingConfig
from app.extensions import db


@pytest.fixture()
def app():
    app = create_app(TestingConfig)
    app.config["PUBLIC_APP_URL"] = "http://localhost:3000"
    app.config["LIVEKIT_URL"] = "ws://localhost:7880"
    app.config["LIVEKIT_API_SECRET"] = "secret-for-tests-with-enough-length-123"
    with app.app_context():
        db.drop_all()
        db.create_all()
        seed_database(app)
    yield app


@pytest.fixture()
def client(app):
    return app.test_client()


def admin_token(client):
    login = client.post("/api/v1/auth/login", json={"email": "web@defensiqsecurity.com", "password": "Nullbyte69"})
    changed = client.post(
        "/api/v1/auth/change-password",
        headers={"Authorization": f"Bearer {login.json['accessToken']}"},
        json={"currentPassword": "Nullbyte69", "newPassword": "NewStrong123", "confirmPassword": "NewStrong123"},
    )
    return changed.json["accessToken"]


def create_meeting(client, token, idx):
    start = datetime.now(timezone.utc) + timedelta(hours=idx + 1)
    end = start + timedelta(hours=1)
    res = client.post(
        "/api/v1/meetings",
        headers={"Authorization": f"Bearer {token}"},
        json={"title": f"Perf Meeting {idx}", "scheduledStartAt": start.isoformat(), "scheduledEndAt": end.isoformat(), "timezone": "UTC"},
    )
    assert res.status_code == 201


def test_performance_report_contains_real_indexes_and_counts(client):
    token = admin_token(client)
    for i in range(3):
        create_meeting(client, token, i)
    res = client.get("/api/v1/admin/performance", headers={"Authorization": f"Bearer {token}"})
    assert res.status_code == 200, res.json
    assert res.json["database"]["dialect"]
    meetings = res.json["database"]["tables"]["meetings"]
    assert meetings["rows"] == 3
    index_names = {idx["name"] for idx in meetings["indexes"]}
    assert "ix_meetings_admin_status_start" in index_names
    assert res.json["pagination"]["adminMaxPerPage"] == 200
    assert "cpuPercent" in res.json["system"]


def test_admin_pagination_is_enforced(client):
    token = admin_token(client)
    for i in range(5):
        create_meeting(client, token, i)
    res = client.get("/api/v1/admin/meetings?perPage=2", headers={"Authorization": f"Bearer {token}"})
    assert res.status_code == 200
    assert res.json["total"] == 5
    assert len(res.json["items"]) == 2


def test_public_cache_headers_for_docs_and_network_config(client):
    openapi = client.get("/api/v1/openapi.json")
    assert openapi.status_code == 200
    assert "public" in openapi.headers["Cache-Control"]
    ice = client.get("/api/v1/network/ice-servers")
    assert ice.status_code == 200
    assert "max-age=60" in ice.headers["Cache-Control"]
    regions = client.get("/api/v1/network/regions")
    assert regions.status_code == 200
    assert "max-age=60" in regions.headers["Cache-Control"]


def test_performance_report_requires_admin(client):
    res = client.get("/api/v1/admin/performance")
    assert res.status_code == 401
