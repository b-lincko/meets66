from datetime import datetime, timedelta, timezone

import jwt
import pytest

from app import create_app, seed_database
from app.config import TestingConfig
from app.extensions import db
from app.models import MeetingParticipant


@pytest.fixture()
def app(monkeypatch):
    app = create_app(TestingConfig)
    app.config["PUBLIC_APP_URL"] = "http://localhost:3000"
    app.config["LIVEKIT_URL"] = "ws://localhost:7880"
    app.config["LIVEKIT_API_SECRET"] = "secret-for-tests-with-enough-length-123"
    with app.app_context():
        db.drop_all()
        db.create_all()
        seed_database(app)
    yield app


@pytest.fixture()
def client(app):
    return app.test_client()


def admin_token(client):
    login = client.post("/api/v1/auth/login", json={"email": "web@defensiqsecurity.com", "password": "Nullbyte69"})
    changed = client.post(
        "/api/v1/auth/change-password",
        headers={"Authorization": f"Bearer {login.json['accessToken']}"},
        json={"currentPassword": "Nullbyte69", "newPassword": "NewStrong123", "confirmPassword": "NewStrong123"},
    )
    return changed.json["accessToken"]


def create_running_meeting(client, token, waiting=False):
    start = datetime.now(timezone.utc) + timedelta(hours=1)
    end = start + timedelta(hours=1)
    meeting = client.post(
        "/api/v1/meetings",
        headers={"Authorization": f"Bearer {token}"},
        json={"title": "Controls Meeting", "scheduledStartAt": start.isoformat(), "scheduledEndAt": end.isoformat(), "timezone": "UTC", "waitingRoomEnabled": waiting},
    ).json
    host = client.post(f"/api/v1/meetings/{meeting['meeting']['id']}/host-token", headers={"Authorization": f"Bearer {token}"})
    assert host.status_code == 200, host.json
    return meeting, host.json


def join_participant(client, invitation_token, name="Analyst"):
    res = client.post(f"/api/v1/meetings/invitations/{invitation_token}/join", json={"displayName": name})
    assert res.status_code == 201, res.json
    return res.json


def test_lock_meeting_blocks_new_participants(client, monkeypatch):
    calls = []
    monkeypatch.setattr("app.routes.meetings.update_permissions", lambda *args, **kwargs: calls.append((args, kwargs)) or True)
    token = admin_token(client)
    created, _host = create_running_meeting(client, token, waiting=False)
    meeting_id = created["meeting"]["id"]
    invite = created["invitation"]["token"]

    locked = client.patch(f"/api/v1/meetings/{meeting_id}/controls", headers={"Authorization": f"Bearer {token}"}, json={"isLocked": True})
    assert locked.status_code == 200, locked.json
    assert locked.json["meeting"]["isLocked"] is True

    blocked = client.post(f"/api/v1/meetings/invitations/{invite}/join", json={"displayName": "Late User"})
    assert blocked.status_code == 423
    assert blocked.json["error"]["code"] == "meeting_locked"


def test_global_media_controls_update_permissions_and_tokens(client, monkeypatch):
    permission_calls = []
    monkeypatch.setattr("app.routes.meetings.update_permissions", lambda room, identity, sources, room_admin=False: permission_calls.append({"room": room, "identity": identity, "sources": sources, "admin": room_admin}) or True)
    token = admin_token(client)
    created, _host = create_running_meeting(client, token, waiting=False)
    meeting_id = created["meeting"]["id"]
    invite = created["invitation"]["token"]
    participant = join_participant(client, invite)

    disabled = client.patch(
        f"/api/v1/meetings/{meeting_id}/controls",
        headers={"Authorization": f"Bearer {token}"},
        json={"allowParticipantAudio": False, "allowParticipantVideo": False, "allowScreenShare": False, "allowChat": False},
    )
    assert disabled.status_code == 200, disabled.json
    assert disabled.json["meeting"]["allowParticipantAudio"] is False
    assert disabled.json["meeting"]["allowParticipantVideo"] is False
    assert disabled.json["meeting"]["allowScreenShare"] is False
    assert permission_calls

    status = client.get(f"/api/v1/meetings/invitations/{invite}/status", headers={"Authorization": f"Bearer {participant['participantToken']}"})
    claims = jwt.decode(status.json["livekit"]["token"], options={"verify_signature": False})
    assert claims["video"]["canPublish"] is False
    assert claims["video"]["canPublishSources"] == []


def test_participant_actions_mute_disable_video_promote_and_remove(client, monkeypatch):
    muted_tracks = []
    removed = []
    permissions = []
    monkeypatch.setattr("app.routes.meetings.mute_tracks", lambda room, identity, sources, muted=True: muted_tracks.append((identity, tuple(sources), muted)) or True)
    monkeypatch.setattr("app.routes.meetings.livekit_remove_participant", lambda room, identity: removed.append(identity) or True)
    monkeypatch.setattr("app.routes.meetings.update_permissions", lambda room, identity, sources, room_admin=False: permissions.append((identity, tuple(sources), room_admin)) or True)
    token = admin_token(client)
    created, _host = create_running_meeting(client, token, waiting=False)
    meeting_id = created["meeting"]["id"]
    invite = created["invitation"]["token"]
    participant = join_participant(client, invite)
    pid = participant["participant"]["id"]

    mute = client.post(f"/api/v1/meetings/{meeting_id}/participants/{pid}/action", headers={"Authorization": f"Bearer {token}"}, json={"action": "mute"})
    assert mute.status_code == 200
    assert mute.json["participant"]["muted"] is True
    assert muted_tracks[-1][0] == pid
    assert "microphone" in muted_tracks[-1][1]

    disable_video = client.post(f"/api/v1/meetings/{meeting_id}/participants/{pid}/action", headers={"Authorization": f"Bearer {token}"}, json={"action": "disable_video"})
    assert disable_video.status_code == 200
    assert disable_video.json["participant"]["videoDisabled"] is True
    assert disable_video.json["participant"]["cameraEnabled"] is False

    promote = client.post(f"/api/v1/meetings/{meeting_id}/participants/{pid}/action", headers={"Authorization": f"Bearer {token}"}, json={"action": "promote_cohost"})
    assert promote.status_code == 200
    assert promote.json["participant"]["role"] == "cohost"
    assert permissions[-1][2] is True

    demote = client.post(f"/api/v1/meetings/{meeting_id}/participants/{pid}/action", headers={"Authorization": f"Bearer {token}"}, json={"action": "demote_cohost"})
    assert demote.status_code == 200
    assert demote.json["participant"]["role"] == "participant"

    remove = client.post(f"/api/v1/meetings/{meeting_id}/participants/{pid}/action", headers={"Authorization": f"Bearer {token}"}, json={"action": "remove"})
    assert remove.status_code == 200
    assert remove.json["participant"]["status"] == "left"
    assert remove.json["participant"]["removedReason"] == "removed_by_host"
    assert removed[-1] == pid


def test_end_meeting_disconnects_participants_and_blocks_invite(client, monkeypatch):
    removed = []
    monkeypatch.setattr("app.routes.meetings.livekit_remove_participant", lambda room, identity: removed.append(identity) or True)
    token = admin_token(client)
    created, host = create_running_meeting(client, token, waiting=False)
    meeting_id = created["meeting"]["id"]
    invite = created["invitation"]["token"]
    participant = join_participant(client, invite)

    ended = client.post(f"/api/v1/meetings/{meeting_id}/end", headers={"Authorization": f"Bearer {token}"})
    assert ended.status_code == 200, ended.json
    assert ended.json["meeting"]["status"] == "completed"
    assert removed

    blocked = client.post(f"/api/v1/meetings/invitations/{invite}/join", json={"displayName": "Too Late"})
    assert blocked.status_code == 409
    assert blocked.json["error"]["code"] == "meeting_ended"


def test_host_controls_emit_websocket_events(client, app, monkeypatch):
    emitted = []
    monkeypatch.setattr("app.routes.meetings.update_permissions", lambda *args, **kwargs: True)
    monkeypatch.setattr("app.routes.meetings.socketio.emit", lambda name, payload=None, **kwargs: emitted.append({"name": name, "payload": payload, "kwargs": kwargs}))
    token = admin_token(client)
    created, _host = create_running_meeting(client, token, waiting=False)
    meeting_id = created["meeting"]["id"]

    res = client.patch(f"/api/v1/meetings/{meeting_id}/controls", headers={"Authorization": f"Bearer {token}"}, json={"allowParticipantAudio": False})
    assert res.status_code == 200
    names = [event["name"] for event in emitted]
    assert "meeting:controls" in names
    assert "meeting:updated" in names
    control_event = next(event for event in emitted if event["name"] == "meeting:controls")
    assert control_event["payload"]["allowParticipantAudio"] is False
    assert control_event["kwargs"]["room"] == meeting_id


def test_extended_participant_controls_update_state_and_block_banned_rejoin(client, monkeypatch):
    monkeypatch.setattr("app.routes.meetings.update_permissions", lambda *args, **kwargs: True)
    monkeypatch.setattr("app.routes.meetings.mute_tracks", lambda *args, **kwargs: True)
    monkeypatch.setattr("app.routes.meetings.livekit_remove_participant", lambda *args, **kwargs: True)
    token = admin_token(client)
    created, _host = create_running_meeting(client, token, waiting=False)
    meeting_id = created["meeting"]["id"]
    invite = created["invitation"]["token"]
    participant = join_participant(client, invite, "Presenter")
    pid = participant["participant"]["id"]

    rename = client.post(
        f"/api/v1/meetings/{meeting_id}/participants/{pid}/action",
        headers={"Authorization": f"Bearer {token}"},
        json={"action": "rename", "displayName": "Lead Presenter"},
    )
    assert rename.status_code == 200, rename.json
    assert rename.json["participant"]["displayName"] == "Lead Presenter"

    disabled_global_share = client.patch(f"/api/v1/meetings/{meeting_id}/controls", headers={"Authorization": f"Bearer {token}"}, json={"allowScreenShare": False})
    assert disabled_global_share.status_code == 200, disabled_global_share.json
    grant_screen = client.post(f"/api/v1/meetings/{meeting_id}/participants/{pid}/action", headers={"Authorization": f"Bearer {token}"}, json={"action": "grant_screen_share"})
    assert grant_screen.status_code == 200, grant_screen.json
    assert grant_screen.json["participant"]["hostControls"]["screenShareGranted"] is True
    assert grant_screen.json["participant"]["screenShareDisabled"] is False
    status = client.get(f"/api/v1/meetings/invitations/{invite}/status", headers={"Authorization": f"Bearer {participant['participantToken']}"})
    claims = jwt.decode(status.json["livekit"]["token"], options={"verify_signature": False})
    assert "screen_share" in claims["video"]["canPublishSources"]

    revoke_whiteboard = client.post(f"/api/v1/meetings/{meeting_id}/participants/{pid}/action", headers={"Authorization": f"Bearer {token}"}, json={"action": "revoke_whiteboard"})
    assert revoke_whiteboard.status_code == 200, revoke_whiteboard.json
    assert revoke_whiteboard.json["participant"]["hostControls"]["whiteboardRevoked"] is True

    present = client.post(f"/api/v1/meetings/{meeting_id}/participants/{pid}/action", headers={"Authorization": f"Bearer {token}"}, json={"action": "change_presenter"})
    assert present.status_code == 200, present.json
    assert present.json["participant"]["hostControls"]["presenter"] is True

    spotlight = client.post(f"/api/v1/meetings/{meeting_id}/participants/{pid}/action", headers={"Authorization": f"Bearer {token}"}, json={"action": "spotlight"})
    assert spotlight.status_code == 200, spotlight.json
    assert spotlight.json["participant"]["hostControls"]["spotlighted"] is True

    ban = client.post(f"/api/v1/meetings/{meeting_id}/participants/{pid}/action", headers={"Authorization": f"Bearer {token}"}, json={"action": "ban"})
    assert ban.status_code == 200, ban.json
    assert ban.json["participant"]["removedReason"] == "banned_by_host"

    blocked = client.post(f"/api/v1/meetings/invitations/{invite}/join", json={"displayName": "Presenter Again"})
    assert blocked.status_code == 403
    assert blocked.json["error"]["code"] == "participant_banned"


def test_cohost_participant_controls_require_explicit_grant(client, monkeypatch):
    muted_tracks = []
    monkeypatch.setattr("app.routes.meetings.update_permissions", lambda *args, **kwargs: True)
    monkeypatch.setattr("app.routes.meetings.mute_tracks", lambda room, identity, sources, muted=True: muted_tracks.append((identity, tuple(sources), muted)) or True)
    token = admin_token(client)
    created, _host = create_running_meeting(client, token, waiting=False)
    meeting_id = created["meeting"]["id"]
    invite = created["invitation"]["token"]
    cohost = join_participant(client, invite, "Co Host")
    target = join_participant(client, invite, "Target User")
    cohost_id = cohost["participant"]["id"]
    target_id = target["participant"]["id"]

    promoted = client.post(f"/api/v1/meetings/{meeting_id}/participants/{cohost_id}/action", headers={"Authorization": f"Bearer {token}"}, json={"action": "promote_cohost"})
    assert promoted.status_code == 200, promoted.json
    assert promoted.json["participant"]["role"] == "cohost"
    assert "waiting.admit" in promoted.json["participant"]["hostControls"]["cohostPermissions"]
    assert "participants.mute" in promoted.json["participant"]["hostControls"]["cohostPermissions"]

    allowed = client.post(
        f"/api/v1/meetings/invitations/{invite}/participants/{target_id}/action",
        headers={"Authorization": f"Bearer {cohost['participantToken']}"},
        json={"action": "mute"},
    )
    assert allowed.status_code == 200, allowed.json
    assert allowed.json["participant"]["muted"] is True
    assert muted_tracks[-1][0] == target_id


def test_meeting_role_assignments_permissions_dashboard_and_attendance(client, monkeypatch):
    monkeypatch.setattr("app.routes.meetings.update_permissions", lambda *args, **kwargs: True)
    token = admin_token(client)
    created, _host = create_running_meeting(client, token, waiting=False)
    meeting_id = created["meeting"]["id"]
    invite = created["invitation"]["token"]
    participant = join_participant(client, invite, "Moderator User")
    pid = participant["participant"]["id"]

    candidates = client.get(f"/api/v1/meetings/{meeting_id}/role-candidates?q=Moderator", headers={"Authorization": f"Bearer {token}"})
    assert candidates.status_code == 200
    assert any(item["id"] == pid for item in candidates.json["items"])

    assigned = client.post(
        f"/api/v1/meetings/{meeting_id}/roles",
        headers={"Authorization": f"Bearer {token}"},
        json={"subjectType": "participant", "participantId": pid, "role": "cohost", "permissions": ["waiting.admit", "participants.mute", "cohosts.manage"]},
    )
    assert assigned.status_code == 201, assigned.json
    assignment_id = assigned.json["assignment"]["id"]
    assert assigned.json["assignment"]["role"] == "cohost"
    assert "participants.mute" in assigned.json["assignment"]["permissions"]

    roles = client.get(f"/api/v1/meetings/{meeting_id}/roles", headers={"Authorization": f"Bearer {token}"})
    assert roles.status_code == 200
    assert roles.json["total"] == 1
    assert "recording.start" in roles.json["permissions"]

    updated = client.patch(
        f"/api/v1/meetings/{meeting_id}/roles/{assignment_id}",
        headers={"Authorization": f"Bearer {token}"},
        json={"permissions": ["waiting.admit", "recording.start", "attendance.view"]},
    )
    assert updated.status_code == 200
    assert updated.json["assignment"]["permissions"] == ["attendance.view", "recording.start", "waiting.admit"]

    dashboard = client.get(f"/api/v1/meetings/{meeting_id}/admin-dashboard", headers={"Authorization": f"Bearer {token}"})
    assert dashboard.status_code == 200
    assert dashboard.json["participants"]["admitted"] >= 2
    assert "recording" in dashboard.json

    attendance = client.get(f"/api/v1/meetings/{meeting_id}/attendance", headers={"Authorization": f"Bearer {token}"})
    assert attendance.status_code == 200
    assert any(row["participantId"] == pid for row in attendance.json["items"])
    csv = client.get(f"/api/v1/meetings/{meeting_id}/attendance.csv", headers={"Authorization": f"Bearer {token}"})
    assert csv.status_code == 200
    assert csv.mimetype == "text/csv"

    deleted = client.delete(f"/api/v1/meetings/{meeting_id}/roles/{assignment_id}", headers={"Authorization": f"Bearer {token}"})
    assert deleted.status_code == 200
    assert deleted.json["assignment"]["active"] is False


def test_cohost_can_admit_waiting_users_with_waiting_permission(client, monkeypatch):
    monkeypatch.setattr("app.routes.meetings.update_permissions", lambda *args, **kwargs: True)
    token = admin_token(client)
    created, _host = create_running_meeting(client, token, waiting=False)
    meeting_id = created["meeting"]["id"]
    invite = created["invitation"]["token"]
    cohost = join_participant(client, invite, "Waiting Manager")
    cohost_id = cohost["participant"]["id"]

    enabled_waiting = client.patch(f"/api/v1/meetings/{meeting_id}/controls", headers={"Authorization": f"Bearer {token}"}, json={"waitingRoomEnabled": True})
    assert enabled_waiting.status_code == 200, enabled_waiting.json
    waiting = join_participant(client, invite, "Needs Approval")
    waiting_id = waiting["participant"]["id"]
    assert waiting["participant"]["status"] == "waiting"

    assigned = client.post(
        f"/api/v1/meetings/{meeting_id}/roles",
        headers={"Authorization": f"Bearer {token}"},
        json={"subjectType": "participant", "participantId": cohost_id, "role": "cohost", "permissions": ["waiting.admit", "waiting.reject"]},
    )
    assert assigned.status_code == 201, assigned.json

    visible = client.get(f"/api/v1/meetings/invitations/{invite}/participants", headers={"Authorization": f"Bearer {cohost['participantToken']}"})
    assert visible.status_code == 200, visible.json
    assert any(item["id"] == waiting_id and item["status"] == "waiting" for item in visible.json["items"])

    admitted = client.post(
        f"/api/v1/meetings/invitations/{invite}/participants/{waiting_id}/action",
        headers={"Authorization": f"Bearer {cohost['participantToken']}"},
        json={"action": "admit"},
    )
    assert admitted.status_code == 200, admitted.json
    assert admitted.json["participant"]["status"] == "admitted"
