import pytest

from app import create_app, seed_database
from app.config import TestingConfig
from app.extensions import db
from app.models import AdminAccount, AdminSession, AppSetting


@pytest.fixture()
def app():
    app = create_app(TestingConfig)
    with app.app_context():
        db.drop_all()
        db.create_all()
        seed_database(app)
    yield app


@pytest.fixture()
def client(app):
    return app.test_client()


def login(client, email="web@defensiqsecurity.com", password="Nullbyte69"):
    return client.post("/api/v1/auth/login", json={"email": email, "password": password})


def super_token(client):
    logged = login(client)
    changed = client.post(
        "/api/v1/auth/change-password",
        headers={"Authorization": f"Bearer {logged.json['accessToken']}"},
        json={"currentPassword": "Nullbyte69", "newPassword": "NewStrong123", "confirmPassword": "NewStrong123"},
    )
    return changed.json["accessToken"]


def test_default_admin_is_super_admin_with_all_permissions(client):
    token = super_token(client)
    listed = client.get("/api/v1/admin/admins", headers={"Authorization": f"Bearer {token}"})
    assert listed.status_code == 200
    admin = listed.json["items"][0]
    assert admin["role"] == "super_admin"
    assert "admins.manage" in admin["effectivePermissions"]
    assert "settings.manage" in admin["effectivePermissions"]


def test_super_admin_create_update_reset_disable_and_delete_admin(client):
    token = super_token(client)
    created = client.post(
        "/api/v1/admin/admins",
        headers={"Authorization": f"Bearer {token}"},
        json={"email": "ops@example.com", "displayName": "Ops Admin", "password": "OpsStrong123", "role": "meeting_admin", "permissions": ["meetings.manage", "analytics.view"]},
    )
    assert created.status_code == 201, created.json
    admin_id = created.json["admin"]["id"]
    assert created.json["admin"]["role"] == "meeting_admin"

    ops_login = login(client, "ops@example.com", "OpsStrong123")
    assert ops_login.status_code == 200
    blocked = client.get("/api/v1/admin/admins", headers={"Authorization": f"Bearer {ops_login.json['accessToken']}"})
    assert blocked.status_code == 403

    updated = client.patch(f"/api/v1/admin/admins/{admin_id}", headers={"Authorization": f"Bearer {token}"}, json={"role": "admin", "status": "disabled"})
    assert updated.status_code == 200
    assert updated.json["admin"]["status"] == "disabled"
    assert AdminSession.query.filter_by(admin_id=admin_id).first().revoked_reason == "admin_disabled"

    reset = client.post(f"/api/v1/admin/admins/{admin_id}/reset-password", headers={"Authorization": f"Bearer {token}"}, json={"password": "ResetStrong123"})
    assert reset.status_code == 200
    reenable = client.patch(f"/api/v1/admin/admins/{admin_id}", headers={"Authorization": f"Bearer {token}"}, json={"status": "active"})
    assert reenable.status_code == 200
    relogin = login(client, "ops@example.com", "ResetStrong123")
    assert relogin.status_code == 200
    assert relogin.json["forceChangePassword"] is True

    deleted = client.delete(f"/api/v1/admin/admins/{admin_id}", headers={"Authorization": f"Bearer {token}"})
    assert deleted.status_code == 200
    assert deleted.json["admin"]["status"] == "disabled"


def test_super_admin_cannot_disable_or_delete_self(client):
    token = super_token(client)
    admin = AdminAccount.query.filter_by(email="web@defensiqsecurity.com").first()
    disabled = client.patch(f"/api/v1/admin/admins/{admin.id}", headers={"Authorization": f"Bearer {token}"}, json={"status": "disabled"})
    assert disabled.status_code == 400
    deleted = client.delete(f"/api/v1/admin/admins/{admin.id}", headers={"Authorization": f"Bearer {token}"})
    assert deleted.status_code == 400


def test_settings_list_update_validation_and_permissions(client):
    token = super_token(client)
    settings = client.get("/api/v1/admin/settings", headers={"Authorization": f"Bearer {token}"})
    assert settings.status_code == 200
    assert "meeting_settings" in settings.json["settings"]

    updated = client.patch("/api/v1/admin/settings/meeting_settings", headers={"Authorization": f"Bearer {token}"}, json={"maximumParticipants": 250, "allowChat": False})
    assert updated.status_code == 200
    assert updated.json["value"]["maximumParticipants"] == 250
    assert updated.json["value"]["allowChat"] is False
    assert db.session.get(AppSetting, "meeting_settings").value["maximumParticipants"] == 250

    bad = client.patch("/api/v1/admin/settings/security_settings", headers={"Authorization": f"Bearer {token}"}, json={"passwordMinLength": 3})
    assert bad.status_code == 400

    created = client.post("/api/v1/admin/admins", headers={"Authorization": f"Bearer {token}"}, json={"email": "limited@example.com", "displayName": "Limited", "password": "Limited123A", "role": "meeting_admin", "permissions": ["meetings.manage"]})
    limited_login = login(client, "limited@example.com", "Limited123A")
    denied = client.get("/api/v1/admin/settings", headers={"Authorization": f"Bearer {limited_login.json['accessToken']}"})
    assert denied.status_code == 403


def test_admin_activity_endpoint(client):
    token = super_token(client)
    created = client.post("/api/v1/admin/admins", headers={"Authorization": f"Bearer {token}"}, json={"email": "activity@example.com", "displayName": "Activity", "password": "Activity123A", "role": "admin"})
    admin_id = created.json["admin"]["id"]
    activity = client.get(f"/api/v1/admin/admins/{admin_id}/activity", headers={"Authorization": f"Bearer {token}"})
    assert activity.status_code == 200
    assert activity.json["admin"]["email"] == "activity@example.com"
    assert "auditLogs" in activity.json
    assert "sessions" in activity.json
