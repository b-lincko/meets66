import pytest

from app import create_app, seed_database
from app.config import TestingConfig
from app.extensions import db


@pytest.fixture()
def app():
    app = create_app(TestingConfig)
    with app.app_context():
        db.drop_all()
        db.create_all()
        seed_database(app)
    yield app


@pytest.fixture()
def client(app):
    return app.test_client()


def login_default(client):
    response = client.post("/api/v1/auth/login", json={"email": "web@defensiqsecurity.com", "password": "Nullbyte69"})
    assert response.status_code == 200, response.json
    return response.json


def test_health_uses_database(client):
    response = client.get("/api/v1/health")
    assert response.status_code == 200
    assert response.json["checks"]["database"] == "ok"


def test_admin_login_creates_session_and_requires_password_change(client):
    data = login_default(client)
    assert data["admin"]["email"] == "web@defensiqsecurity.com"
    assert data["forceChangePassword"] is True
    assert data["accessToken"]
    assert data["refreshToken"]
    assert data["session"]["active"] is True

    blocked = client.get("/api/v1/auth/sessions", headers={"Authorization": f"Bearer {data['accessToken']}"})
    assert blocked.status_code == 403
    assert blocked.json["error"]["code"] == "password_change_required"


def test_change_password_unlocks_console_and_revokes_other_sessions(client):
    first = login_default(client)
    second = login_default(client)
    changed = client.post(
        "/api/v1/auth/change-password",
        headers={"Authorization": f"Bearer {first['accessToken']}"},
        json={"currentPassword": "Nullbyte69", "newPassword": "NewStrong123", "confirmPassword": "NewStrong123"},
    )
    assert changed.status_code == 200, changed.json
    assert changed.json["forceChangePassword"] is False

    sessions = client.get("/api/v1/auth/sessions", headers={"Authorization": f"Bearer {changed.json['accessToken']}"})
    assert sessions.status_code == 200
    assert sessions.json["total"] >= 2
    revoked = [item for item in sessions.json["items"] if item["id"] == second["session"]["id"]][0]
    assert revoked["active"] is False
    assert revoked["revokedReason"] == "password_changed"


def test_refresh_rotates_token_and_supersedes_old_access_token(client):
    first = login_default(client)
    changed = client.post(
        "/api/v1/auth/change-password",
        headers={"Authorization": f"Bearer {first['accessToken']}"},
        json={"currentPassword": "Nullbyte69", "newPassword": "NewStrong123", "confirmPassword": "NewStrong123"},
    ).json

    refreshed = client.post("/api/v1/auth/refresh", json={"refreshToken": changed["refreshToken"]})
    assert refreshed.status_code == 200, refreshed.json
    assert refreshed.json["refreshToken"] != changed["refreshToken"]

    old_access = client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {changed['accessToken']}"})
    assert old_access.status_code == 401
    assert old_access.json["error"]["code"] == "token_superseded"

    new_access = client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {refreshed.json['accessToken']}"})
    assert new_access.status_code == 200


def test_logout_revokes_current_session(client):
    data = login_default(client)
    changed = client.post(
        "/api/v1/auth/change-password",
        headers={"Authorization": f"Bearer {data['accessToken']}"},
        json={"currentPassword": "Nullbyte69", "newPassword": "NewStrong123", "confirmPassword": "NewStrong123"},
    ).json
    logout = client.post("/api/v1/auth/logout", headers={"Authorization": f"Bearer {changed['accessToken']}"})
    assert logout.status_code == 200
    me = client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {changed['accessToken']}"})
    assert me.status_code == 401


def test_audit_log_records_security_events(client):
    data = login_default(client)
    changed = client.post(
        "/api/v1/auth/change-password",
        headers={"Authorization": f"Bearer {data['accessToken']}"},
        json={"currentPassword": "Nullbyte69", "newPassword": "NewStrong123", "confirmPassword": "NewStrong123"},
    ).json
    logs = client.get("/api/v1/auth/audit-logs", headers={"Authorization": f"Bearer {changed['accessToken']}"})
    assert logs.status_code == 200
    actions = {item["action"] for item in logs.json["items"]}
    assert "auth.login" in actions
    assert "auth.password_changed" in actions
