from datetime import datetime, timedelta, timezone

import pytest

from app import create_app, seed_database
from app.config import TestingConfig
from app.extensions import db
from app.models import WhiteboardElement


@pytest.fixture()
def app():
    app = create_app(TestingConfig)
    app.config["PUBLIC_APP_URL"] = "http://localhost:3000"
    app.config["LIVEKIT_URL"] = "ws://localhost:7880"
    app.config["LIVEKIT_API_SECRET"] = "secret-for-tests-with-enough-length-123"
    with app.app_context():
        db.drop_all()
        db.create_all()
        seed_database(app)
    yield app


@pytest.fixture()
def client(app):
    return app.test_client()


def admin_token(client):
    login = client.post("/api/v1/auth/login", json={"email": "web@defensiqsecurity.com", "password": "Nullbyte69"})
    changed = client.post(
        "/api/v1/auth/change-password",
        headers={"Authorization": f"Bearer {login.json['accessToken']}"},
        json={"currentPassword": "Nullbyte69", "newPassword": "NewStrong123", "confirmPassword": "NewStrong123"},
    )
    return changed.json["accessToken"]


def create_meeting(client, token, waiting=False):
    start = datetime.now(timezone.utc) + timedelta(hours=1)
    end = start + timedelta(hours=1)
    meeting = client.post(
        "/api/v1/meetings",
        headers={"Authorization": f"Bearer {token}"},
        json={"title": "Whiteboard Meeting", "scheduledStartAt": start.isoformat(), "scheduledEndAt": end.isoformat(), "timezone": "UTC", "waitingRoomEnabled": waiting},
    )
    assert meeting.status_code == 201, meeting.json
    host = client.post(f"/api/v1/meetings/{meeting.json['meeting']['id']}/host-token", headers={"Authorization": f"Bearer {token}"})
    assert host.status_code == 200, host.json
    return meeting.json


def join(client, invite, name="Whiteboard User"):
    joined = client.post(f"/api/v1/meetings/invitations/{invite}/join", json={"displayName": name})
    assert joined.status_code == 201, joined.json
    return joined.json


def test_admin_and_participant_create_list_undo_redo_and_socket_emit(client, monkeypatch):
    emitted = []
    monkeypatch.setattr("app.routes.whiteboard.socketio.emit", lambda name, payload=None, **kwargs: emitted.append({"name": name, "payload": payload, "kwargs": kwargs}))
    token = admin_token(client)
    created = create_meeting(client, token)
    meeting_id = created["meeting"]["id"]
    invite = created["invitation"]["token"]
    participant = join(client, invite)
    ptoken = participant["participantToken"]

    admin_element = client.post(
        f"/api/v1/meetings/{meeting_id}/whiteboard/elements",
        headers={"Authorization": f"Bearer {token}"},
        json={"elementType": "pen", "payload": {"points": [{"x": 10, "y": 10}, {"x": 40, "y": 40}], "color": "#000000", "width": 4}},
    )
    assert admin_element.status_code == 201, admin_element.json
    participant_element = client.post(
        f"/api/v1/meetings/invitations/{invite}/whiteboard/elements",
        headers={"Authorization": f"Bearer {ptoken}"},
        json={"elementType": "sticky", "payload": {"x": 80, "y": 90, "w": 200, "h": 100, "text": "Action item", "fill": "#fef08a"}},
    )
    assert participant_element.status_code == 201, participant_element.json
    assert WhiteboardElement.query.count() == 2
    assert [event["name"] for event in emitted].count("whiteboard:element") == 2

    listed = client.get(f"/api/v1/meetings/{meeting_id}/whiteboard/elements", headers={"Authorization": f"Bearer {token}"})
    assert listed.status_code == 200
    assert listed.json["total"] == 2

    undo = client.post(f"/api/v1/meetings/invitations/{invite}/whiteboard/undo", headers={"Authorization": f"Bearer {ptoken}"})
    assert undo.status_code == 200
    assert undo.json["element"]["active"] is False
    after_undo = client.get(f"/api/v1/meetings/{meeting_id}/whiteboard/elements", headers={"Authorization": f"Bearer {token}"})
    assert after_undo.json["total"] == 1

    redo = client.post(f"/api/v1/meetings/invitations/{invite}/whiteboard/redo", headers={"Authorization": f"Bearer {ptoken}"})
    assert redo.status_code == 200
    assert redo.json["element"]["active"] is True


def test_whiteboard_validation_and_permission(client):
    token = admin_token(client)
    created = create_meeting(client, token)
    meeting_id = created["meeting"]["id"]
    invite = created["invitation"]["token"]
    participant = join(client, invite)
    ptoken = participant["participantToken"]

    invalid = client.post(f"/api/v1/meetings/{meeting_id}/whiteboard/elements", headers={"Authorization": f"Bearer {token}"}, json={"elementType": "pen", "payload": {"points": []}})
    assert invalid.status_code == 400

    disabled = client.patch(f"/api/v1/meetings/{meeting_id}/controls", headers={"Authorization": f"Bearer {token}"}, json={"allowWhiteboard": False})
    assert disabled.status_code == 200
    denied = client.post(f"/api/v1/meetings/invitations/{invite}/whiteboard/elements", headers={"Authorization": f"Bearer {ptoken}"}, json={"elementType": "text", "payload": {"x": 1, "y": 1, "text": "Denied"}})
    assert denied.status_code == 403
    assert denied.json["error"]["code"] == "whiteboard_disabled"


def test_whiteboard_export_png_and_pdf(client):
    token = admin_token(client)
    created = create_meeting(client, token)
    meeting_id = created["meeting"]["id"]
    client.post(f"/api/v1/meetings/{meeting_id}/whiteboard/elements", headers={"Authorization": f"Bearer {token}"}, json={"elementType": "rect", "payload": {"x": 10, "y": 10, "w": 100, "h": 60, "color": "#ff0000", "width": 3}})
    png = client.get(f"/api/v1/meetings/{meeting_id}/whiteboard/export.png", headers={"Authorization": f"Bearer {token}"})
    assert png.status_code == 200
    assert png.mimetype == "image/png"
    assert png.data.startswith(b"\x89PNG")
    pdf = client.get(f"/api/v1/meetings/{meeting_id}/whiteboard/export.pdf", headers={"Authorization": f"Bearer {token}"})
    assert pdf.status_code == 200
    assert pdf.mimetype == "application/pdf"
    assert pdf.data.startswith(b"%PDF")


def test_laser_pointer_socket_event(client, app, monkeypatch):
    from flask import request
    from app import socket_handlers
    emitted = []
    monkeypatch.setattr("app.socket_handlers.emit", lambda name, payload=None, **kwargs: emitted.append({"name": name, "payload": payload, "kwargs": kwargs}))
    token = admin_token(client)
    created = create_meeting(client, token)
    meeting_id = created["meeting"]["id"]
    invite = created["invitation"]["token"]
    participant = join(client, invite, "Laser User")
    participant_id = participant["participant"]["id"]
    with app.test_request_context("/socket.io"):
        request.sid = "participant-sid"
        socket_handlers.SID_PARTICIPANTS["participant-sid"] = participant_id
        socket_handlers.whiteboard_laser({"meetingId": meeting_id, "x": 100, "y": 150})
    events = [event for event in emitted if event["name"] == "whiteboard:laser"]
    assert events
    assert events[-1]["payload"]["displayName"] == "Laser User"
    assert events[-1]["payload"]["x"] == 100
    assert events[-1]["kwargs"]["room"] == meeting_id


def test_whiteboard_flow_uml_mindmap_history_and_svg_export(client):
    token = admin_token(client)
    created = create_meeting(client, token)
    meeting_id = created["meeting"]["id"]
    for element_type in ["flow_rect", "flow_diamond", "uml_class", "mind_node"]:
        res = client.post(
            f"/api/v1/meetings/{meeting_id}/whiteboard/elements",
            headers={"Authorization": f"Bearer {token}"},
            json={"elementType": element_type, "payload": {"x": 80, "y": 80, "w": 180, "h": 100, "text": element_type, "color": "#0ea5e9", "width": 3}},
        )
        assert res.status_code == 201, res.json
    undo = client.post(f"/api/v1/meetings/{meeting_id}/whiteboard/undo", headers={"Authorization": f"Bearer {token}"})
    assert undo.status_code == 200
    history = client.get(f"/api/v1/meetings/{meeting_id}/whiteboard/history", headers={"Authorization": f"Bearer {token}"})
    assert history.status_code == 200
    assert history.json["total"] == 4
    assert any(item["active"] is False for item in history.json["items"])
    svg = client.get(f"/api/v1/meetings/{meeting_id}/whiteboard/export.svg", headers={"Authorization": f"Bearer {token}"})
    assert svg.status_code == 200
    assert svg.mimetype == "image/svg+xml"
    assert b"<svg" in svg.data
