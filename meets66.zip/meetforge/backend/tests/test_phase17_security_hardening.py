from datetime import datetime, timedelta, timezone

import pytest

from app import create_app, seed_database
from app.config import TestingConfig
from app.extensions import db
from app.models import AdminDevice, AdminSession, IPBlock


class CsrfTestingConfig(TestingConfig):
    CSRF_ENFORCED = True


@pytest.fixture()
def app():
    app = create_app(TestingConfig)
    with app.app_context():
        db.drop_all()
        db.create_all()
        seed_database(app)
    yield app


@pytest.fixture()
def csrf_app():
    app = create_app(CsrfTestingConfig)
    with app.app_context():
        db.drop_all()
        db.create_all()
        seed_database(app)
    yield app


@pytest.fixture()
def client(app):
    return app.test_client()


def login(client, email="web@defensiqsecurity.com", password="Nullbyte69", device_id="device-a"):
    return client.post("/api/v1/auth/login", json={"email": email, "password": password}, headers={"X-Device-Id": device_id, "User-Agent": "SecurityTest/1"})


def change_password(client, token, csrf=None):
    headers = {"Authorization": f"Bearer {token}"}
    if csrf:
        headers["X-CSRF-Token"] = csrf
    return client.post("/api/v1/auth/change-password", headers=headers, json={"currentPassword": "Nullbyte69", "newPassword": "NewStrong123", "confirmPassword": "NewStrong123"})


def admin_token(client):
    logged = login(client)
    assert logged.status_code == 200, logged.json
    changed = change_password(client, logged.json["accessToken"], logged.json.get("csrfToken"))
    assert changed.status_code == 200, changed.json
    return changed.json


def test_csrf_required_for_unsafe_admin_requests(csrf_app):
    client = csrf_app.test_client()
    logged = login(client)
    assert logged.status_code == 200
    without = change_password(client, logged.json["accessToken"])
    assert without.status_code == 403
    assert without.json["error"]["code"] == "csrf_invalid"
    with_token = change_password(client, logged.json["accessToken"], logged.json["csrfToken"])
    assert with_token.status_code == 200
    logout_without = client.post("/api/v1/auth/logout", headers={"Authorization": f"Bearer {with_token.json['accessToken']}"})
    assert logout_without.status_code == 403
    logout_with = client.post("/api/v1/auth/logout", headers={"Authorization": f"Bearer {with_token.json['accessToken']}", "X-CSRF-Token": with_token.json["csrfToken"]})
    assert logout_with.status_code == 200


def test_login_creates_admin_device_and_device_management(client):
    auth = admin_token(client)
    devices = client.get("/api/v1/security/devices", headers={"Authorization": f"Bearer {auth['accessToken']}"})
    assert devices.status_code == 200
    assert devices.json["total"] == 1
    device = devices.json["items"][0]
    assert device["active"] is True
    assert AdminDevice.query.count() == 1
    trusted = client.post(f"/api/v1/security/devices/{device['id']}/trust", headers={"Authorization": f"Bearer {auth['accessToken']}"})
    assert trusted.status_code == 200
    assert trusted.json["device"]["trusted"] is True


def test_revoke_other_device_revokes_sessions(client):
    auth_a = admin_token(client)
    # Need current password after first change for second login.
    auth_b_login = login(client, password="NewStrong123", device_id="device-b")
    assert auth_b_login.status_code == 200
    devices = client.get("/api/v1/security/devices", headers={"Authorization": f"Bearer {auth_a['accessToken']}"})
    other = [d for d in devices.json["items"] if d["id"] != auth_a["session"]["deviceId"]][0]
    revoked = client.post(f"/api/v1/security/devices/{other['id']}/revoke", headers={"Authorization": f"Bearer {auth_a['accessToken']}"})
    assert revoked.status_code == 200
    assert revoked.json["device"]["active"] is False
    session = AdminSession.query.filter_by(device_id=other["id"]).first()
    assert session.revoked_reason == "device_revoked"


def test_ip_blocking_blocks_requests_and_can_be_revoked(client):
    auth = admin_token(client)
    created = client.post("/api/v1/security/ip-blocks", headers={"Authorization": f"Bearer {auth['accessToken']}"}, json={"ipAddress": "203.0.113.10", "reason": "test"})
    assert created.status_code == 201, created.json
    assert IPBlock.query.count() == 1
    blocked = client.get("/api/v1/health", headers={"X-Forwarded-For": "203.0.113.10"})
    assert blocked.status_code == 403
    assert blocked.json["error"]["code"] == "ip_blocked"
    revoked = client.delete(f"/api/v1/security/ip-blocks/{created.json['ipBlock']['id']}", headers={"Authorization": f"Bearer {auth['accessToken']}"})
    assert revoked.status_code == 200
    allowed = client.get("/api/v1/health", headers={"X-Forwarded-For": "203.0.113.10"})
    assert allowed.status_code == 200


def test_self_ip_block_requires_force(client):
    auth = admin_token(client)
    denied = client.post("/api/v1/security/ip-blocks", headers={"Authorization": f"Bearer {auth['accessToken']}", "X-Forwarded-For": "127.0.0.1"}, json={"ipAddress": "127.0.0.1"})
    assert denied.status_code == 400
    assert denied.json["error"]["code"] == "self_block_prevented"


def test_e2ee_policy_admin_and_public(client):
    auth = admin_token(client)
    initial = client.get("/api/v1/security/e2ee", headers={"Authorization": f"Bearer {auth['accessToken']}"})
    assert initial.status_code == 200
    assert initial.json["e2ee"]["mode"] == "off"
    updated = client.patch("/api/v1/security/e2ee", headers={"Authorization": f"Bearer {auth['accessToken']}"}, json={"enabled": True, "requirePassphrase": True, "mode": "required"})
    assert updated.status_code == 200
    assert updated.json["e2ee"]["enabled"] is True
    public = client.get("/api/v1/security/public/e2ee")
    assert public.status_code == 200
    assert public.json["e2ee"]["mode"] == "required"
