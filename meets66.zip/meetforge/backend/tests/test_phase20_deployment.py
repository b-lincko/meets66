from pathlib import Path

import pytest
import yaml

from app import create_app, seed_database
from app.config import TestingConfig
from app.config_validation import validate_config
from app.extensions import db


@pytest.fixture()
def app():
    app = create_app(TestingConfig)
    with app.app_context():
        db.drop_all()
        db.create_all()
        seed_database(app)
    yield app


@pytest.fixture()
def client(app):
    return app.test_client()


def test_health_live_ready_metrics_and_config(client):
    live = client.get('/api/v1/health/live')
    assert live.status_code == 200
    assert live.json['status'] == 'alive'
    ready = client.get('/api/v1/health/ready')
    assert ready.status_code == 200
    assert ready.json['ready'] is True
    config = client.get('/api/v1/health/config')
    assert config.status_code == 200
    assert config.json['valid'] is True
    metrics = client.get('/api/v1/health/metrics')
    assert metrics.status_code == 200
    text = metrics.get_data(as_text=True)
    assert 'defensiq_api_up 1' in text
    assert 'defensiq_database_up 1' in text


def test_production_config_validation_rejects_insecure_defaults():
    class BadProd(TestingConfig):
        FLASK_ENV = 'production'
        SECRET_KEY = 'change-this-secret'
        JWT_SECRET = 'change-this-jwt-secret'
        LIVEKIT_API_SECRET = 'secret'
        DEFAULT_ADMIN_PASSWORD = 'Nullbyte69'
        PUBLIC_APP_URL = 'http://localhost:3000'
        SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'
        CORS_ORIGINS = ['http://localhost:3000']
        CSRF_ENFORCED = False

    app = create_app(BadProd)
    result = validate_config(app.config)
    assert result['valid'] is False
    assert any('SECRET_KEY' in item for item in result['errors'])
    assert any('PUBLIC_APP_URL' in item for item in result['errors'])
    assert any('PostgreSQL' in item for item in result['errors'])
    assert any('CSRF_ENFORCED' in item for item in result['errors'])


def test_production_config_validation_accepts_secure_values():
    class GoodProd(TestingConfig):
        FLASK_ENV = 'production'
        SECRET_KEY = 's' * 64
        JWT_SECRET = 'j' * 64
        LIVEKIT_API_SECRET = 'l' * 64
        DEFAULT_ADMIN_PASSWORD = 'StrongDefault123'
        PUBLIC_APP_URL = 'https://meet.defensiqsecurity.com'
        SQLALCHEMY_DATABASE_URI = 'postgresql+psycopg://user:pass@db:5432/app'
        CORS_ORIGINS = ['https://meet.defensiqsecurity.com']
        CSRF_ENFORCED = True
        TURN_URLS = ['turns:turn.defensiqsecurity.com:5349']

    app = create_app(GoodProd)
    result = validate_config(app.config)
    assert result['valid'] is True
    assert result['errors'] == []


def test_validate_config_cli_exits_nonzero_for_bad_production():
    class BadProd(TestingConfig):
        FLASK_ENV = 'production'
        SECRET_KEY = 'bad'
        JWT_SECRET = 'bad'
        LIVEKIT_API_SECRET = 'bad'
        DEFAULT_ADMIN_PASSWORD = 'Nullbyte69'
        PUBLIC_APP_URL = 'http://localhost:3000'
        SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'
        CSRF_ENFORCED = False

    app = create_app(BadProd)
    result = app.test_cli_runner().invoke(args=['validate-config'])
    assert result.exit_code == 1
    assert 'errors' in result.output


def test_docker_compose_healthchecks_and_prod_nginx_exist():
    root = Path(__file__).resolve().parents[2]
    compose = yaml.safe_load((root / 'docker-compose.yml').read_text())
    assert 'healthcheck' in compose['services']['backend']
    assert '/api/v1/health/ready' in ' '.join(compose['services']['backend']['healthcheck']['test'])
    assert 'healthcheck' in compose['services']['frontend']
    assert 'healthcheck' in compose['services']['nginx']
    prod_nginx = (root / 'nginx' / 'nginx.prod.conf').read_text()
    assert 'listen 443 ssl http2' in prod_nginx
    assert 'Strict-Transport-Security' in prod_nginx
    assert 'location /socket.io/' in prod_nginx


def test_backup_restore_scripts_are_present_and_functional_shells():
    root = Path(__file__).resolve().parents[2]
    backup_sh = root / 'scripts' / 'backup_postgres.sh'
    restore_sh = root / 'scripts' / 'restore_postgres.sh'
    backup_bat = root / 'scripts' / 'backup_postgres.bat'
    restore_bat = root / 'scripts' / 'restore_postgres.bat'
    for path in [backup_sh, restore_sh, backup_bat, restore_bat]:
        assert path.exists(), path
    assert 'pg_dump' in backup_sh.read_text()
    assert 'sha256sum' in backup_sh.read_text()
    assert 'psql' in restore_sh.read_text()
    assert 'pg_dump' in backup_bat.read_text()
    assert 'psql' in restore_bat.read_text()


def test_production_deployment_documentation_exists():
    root = Path(__file__).resolve().parents[2]
    doc = (root / 'docs' / 'PRODUCTION_DEPLOYMENT.md').read_text()
    assert 'flask validate-config' in doc
    assert '/api/v1/health/ready' in doc
    assert 'backup_postgres' in doc
    assert 'TURN_URLS' in doc
