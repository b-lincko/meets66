from datetime import datetime, timedelta, timezone
from io import BytesIO

import pytest

from app import create_app, seed_database
from app.config import TestingConfig
from app.extensions import db
from app.models import ChatMessage, MeetingFile


@pytest.fixture()
def app():
    app = create_app(TestingConfig)
    app.config["PUBLIC_APP_URL"] = "http://localhost:3000"
    app.config["LIVEKIT_URL"] = "ws://localhost:7880"
    app.config["LIVEKIT_API_SECRET"] = "secret-for-tests-with-enough-length-123"
    app.config["MAX_CHAT_FILE_MB"] = 1
    with app.app_context():
        db.drop_all()
        db.create_all()
        seed_database(app)
    yield app


@pytest.fixture()
def client(app):
    return app.test_client()


def admin_token(client):
    login = client.post("/api/v1/auth/login", json={"email": "web@defensiqsecurity.com", "password": "Nullbyte69"})
    changed = client.post(
        "/api/v1/auth/change-password",
        headers={"Authorization": f"Bearer {login.json['accessToken']}"},
        json={"currentPassword": "Nullbyte69", "newPassword": "NewStrong123", "confirmPassword": "NewStrong123"},
    )
    return changed.json["accessToken"]


def create_meeting(client, token, waiting=False):
    start = datetime.now(timezone.utc) + timedelta(hours=1)
    end = start + timedelta(hours=1)
    res = client.post(
        "/api/v1/meetings",
        headers={"Authorization": f"Bearer {token}"},
        json={"title": "Chat Meeting", "scheduledStartAt": start.isoformat(), "scheduledEndAt": end.isoformat(), "timezone": "UTC", "waitingRoomEnabled": waiting},
    )
    assert res.status_code == 201, res.json
    return res.json


def join(client, invite, name="Chat User"):
    res = client.post(f"/api/v1/meetings/invitations/{invite}/join", json={"displayName": name})
    assert res.status_code == 201, res.json
    return res.json


def test_admin_and_participant_chat_messages_persist_and_emit(client, app, monkeypatch):
    emitted = []
    monkeypatch.setattr("app.routes.chat.socketio.emit", lambda name, payload=None, **kwargs: emitted.append({"name": name, "payload": payload, "kwargs": kwargs}))
    token = admin_token(client)
    created = create_meeting(client, token, waiting=False)
    meeting_id = created["meeting"]["id"]
    invite = created["invitation"]["token"]
    participant = join(client, invite, "Analyst")
    ptoken = participant["participantToken"]

    admin_msg = client.post(f"/api/v1/meetings/{meeting_id}/chat/messages", headers={"Authorization": f"Bearer {token}"}, json={"body": "Welcome 👋"})
    assert admin_msg.status_code == 201, admin_msg.json
    participant_msg = client.post(f"/api/v1/meetings/invitations/{invite}/chat/messages", headers={"Authorization": f"Bearer {ptoken}"}, json={"body": "Ready ✅"})
    assert participant_msg.status_code == 201, participant_msg.json

    history = client.get(f"/api/v1/meetings/{meeting_id}/chat/messages", headers={"Authorization": f"Bearer {token}"})
    assert history.status_code == 200
    assert [m["body"] for m in history.json["items"]] == ["Welcome 👋", "Ready ✅"]
    assert history.json["items"][1]["senderDisplayName"] == "Analyst"
    assert ChatMessage.query.count() == 2
    assert [event["name"] for event in emitted].count("chat:message") == 2


def test_attachment_upload_download_and_message_history(client, app):
    token = admin_token(client)
    created = create_meeting(client, token, waiting=False)
    meeting_id = created["meeting"]["id"]
    invite = created["invitation"]["token"]
    participant = join(client, invite, "Uploader")
    ptoken = participant["participantToken"]

    upload = client.post(
        f"/api/v1/meetings/invitations/{invite}/chat/messages",
        headers={"Authorization": f"Bearer {ptoken}"},
        data={"body": "see attached", "file": (BytesIO(b"incident report"), "incident.txt")},
        content_type="multipart/form-data",
    )
    assert upload.status_code == 201, upload.json
    file_meta = upload.json["message"]["file"]
    assert file_meta["filename"] == "incident.txt"
    assert file_meta["sizeBytes"] == len(b"incident report")
    assert MeetingFile.query.count() == 1

    download = client.get(f"/api/v1/meetings/{meeting_id}/chat/files/{file_meta['id']}/download", headers={"Authorization": f"Bearer {token}"})
    assert download.status_code == 200
    assert download.data == b"incident report"
    assert "incident.txt" in download.headers["Content-Disposition"]

    history = client.get(f"/api/v1/meetings/{meeting_id}/chat/messages", headers={"Authorization": f"Bearer {token}"})
    assert history.json["items"][0]["messageType"] == "file"
    assert history.json["items"][0]["file"]["sha256"] == file_meta["sha256"]


def test_chat_policy_blocks_participant_but_allows_admin(client):
    token = admin_token(client)
    created = create_meeting(client, token, waiting=False)
    meeting_id = created["meeting"]["id"]
    invite = created["invitation"]["token"]
    participant = join(client, invite, "Blocked")
    ptoken = participant["participantToken"]

    disabled = client.patch(f"/api/v1/meetings/{meeting_id}/controls", headers={"Authorization": f"Bearer {token}"}, json={"allowChat": False})
    assert disabled.status_code == 200
    blocked = client.post(f"/api/v1/meetings/invitations/{invite}/chat/messages", headers={"Authorization": f"Bearer {ptoken}"}, json={"body": "blocked"})
    assert blocked.status_code == 403
    assert blocked.json["error"]["code"] == "chat_disabled"
    admin = client.post(f"/api/v1/meetings/{meeting_id}/chat/messages", headers={"Authorization": f"Bearer {token}"}, json={"body": "Host announcement"})
    assert admin.status_code == 201


def test_chat_validation_and_file_size_limit(client):
    token = admin_token(client)
    created = create_meeting(client, token, waiting=False)
    meeting_id = created["meeting"]["id"]
    empty = client.post(f"/api/v1/meetings/{meeting_id}/chat/messages", headers={"Authorization": f"Bearer {token}"}, json={"body": ""})
    assert empty.status_code == 400
    too_large = client.post(
        f"/api/v1/meetings/{meeting_id}/chat/messages",
        headers={"Authorization": f"Bearer {token}"},
        data={"file": (BytesIO(b"x" * (1024 * 1024 + 1)), "big.bin")},
        content_type="multipart/form-data",
    )
    assert too_large.status_code == 400


def test_typing_indicator_websocket_event(client, app, monkeypatch):
    from flask import request
    from app import socket_handlers
    emitted = []
    monkeypatch.setattr("app.socket_handlers.emit", lambda name, payload=None, **kwargs: emitted.append({"name": name, "payload": payload, "kwargs": kwargs}))
    token = admin_token(client)
    created = create_meeting(client, token, waiting=False)
    meeting_id = created["meeting"]["id"]
    invite = created["invitation"]["token"]
    participant = join(client, invite, "Typing User")
    participant_id = participant["participant"]["id"]

    with app.test_request_context("/socket.io"):
        request.sid = "participant-sid"
        socket_handlers.SID_PARTICIPANTS["participant-sid"] = participant_id
        socket_handlers.chat_typing({"meetingId": meeting_id, "isTyping": True})

    typing_events = [event for event in emitted if event["name"] == "chat:typing"]
    assert typing_events
    assert typing_events[-1]["payload"]["displayName"] == "Typing User"
    assert typing_events[-1]["payload"]["isTyping"] is True
    assert typing_events[-1]["kwargs"]["room"] == meeting_id
    assert typing_events[-1]["kwargs"]["include_self"] is False


def test_chat_replies_reactions_pin_and_save(client, monkeypatch):
    monkeypatch.setattr("app.routes.chat.socketio.emit", lambda *args, **kwargs: None)
    token = admin_token(client)
    created = create_meeting(client, token)
    meeting_id = created["meeting"]["id"]
    invite = created["invitation"]["token"]
    participant = join(client, invite, "Thread User")
    ptoken = participant["participantToken"]

    root = client.post(f"/api/v1/meetings/{meeting_id}/chat/messages", headers={"Authorization": f"Bearer {token}"}, json={"body": "Review this `code` @ThreadUser"})
    assert root.status_code == 201, root.json
    root_id = root.json["message"]["id"]
    assert root.json["message"]["metadata"]["mentions"] == ["ThreadUser"]

    reply = client.post(f"/api/v1/meetings/invitations/{invite}/chat/messages", headers={"Authorization": f"Bearer {ptoken}"}, json={"body": "```python\nprint('ok')\n```", "replyToId": root_id})
    assert reply.status_code == 201, reply.json
    assert reply.json["message"]["replyToId"] == root_id
    assert reply.json["message"]["threadRootId"] == root_id

    reacted = client.post(f"/api/v1/meetings/invitations/{invite}/chat/messages/{root_id}/actions", headers={"Authorization": f"Bearer {ptoken}"}, json={"action": "react", "emoji": "👍"})
    assert reacted.status_code == 200, reacted.json
    assert len(reacted.json["message"]["metadata"]["reactions"]["👍"]) == 1

    saved = client.post(f"/api/v1/meetings/invitations/{invite}/chat/messages/{root_id}/actions", headers={"Authorization": f"Bearer {ptoken}"}, json={"action": "save"})
    assert saved.status_code == 200
    assert saved.json["message"]["metadata"]["savedBy"]

    pinned = client.post(f"/api/v1/meetings/{meeting_id}/chat/messages/{root_id}/actions", headers={"Authorization": f"Bearer {token}"}, json={"action": "pin", "pinned": True})
    assert pinned.status_code == 200
    assert pinned.json["message"]["pinned"] is True
