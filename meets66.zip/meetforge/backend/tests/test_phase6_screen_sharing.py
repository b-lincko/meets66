from datetime import datetime, timedelta, timezone

import jwt
import pytest

from app import create_app, seed_database
from app.config import TestingConfig
from app.extensions import db


@pytest.fixture()
def app():
    app = create_app(TestingConfig)
    app.config["PUBLIC_APP_URL"] = "http://localhost:3000"
    app.config["LIVEKIT_URL"] = "ws://localhost:7880"
    app.config["LIVEKIT_API_SECRET"] = "secret-for-tests-with-enough-length-123"
    with app.app_context():
        db.drop_all()
        db.create_all()
        seed_database(app)
    yield app


@pytest.fixture()
def client(app):
    return app.test_client()


def admin_token(client):
    login = client.post("/api/v1/auth/login", json={"email": "web@defensiqsecurity.com", "password": "Nullbyte69"})
    changed = client.post(
        "/api/v1/auth/change-password",
        headers={"Authorization": f"Bearer {login.json['accessToken']}"},
        json={"currentPassword": "Nullbyte69", "newPassword": "NewStrong123", "confirmPassword": "NewStrong123"},
    )
    return changed.json["accessToken"]


def create_meeting(client, token, waiting=False):
    start = datetime.now(timezone.utc) + timedelta(hours=1)
    end = start + timedelta(hours=1)
    res = client.post(
        "/api/v1/meetings",
        headers={"Authorization": f"Bearer {token}"},
        json={"title": "Screen Share", "scheduledStartAt": start.isoformat(), "scheduledEndAt": end.isoformat(), "timezone": "UTC", "waitingRoomEnabled": waiting},
    )
    assert res.status_code == 201, res.json
    return res.json


def join(client, invite, name="Sharer"):
    res = client.post(f"/api/v1/meetings/invitations/{invite}/join", json={"displayName": name})
    assert res.status_code == 201, res.json
    return res.json


def test_screen_share_policy_controls_livekit_sources(client, monkeypatch):
    permission_calls = []
    monkeypatch.setattr("app.routes.meetings.update_permissions", lambda room, identity, sources, room_admin=False: permission_calls.append((identity, tuple(sources), room_admin)) or True)
    token = admin_token(client)
    created = create_meeting(client, token, waiting=False)
    meeting_id = created["meeting"]["id"]
    invite = created["invitation"]["token"]
    participant = join(client, invite)
    participant_token = participant["participantToken"]
    participant_id = participant["participant"]["id"]

    host_only = client.patch(f"/api/v1/meetings/{meeting_id}/controls", headers={"Authorization": f"Bearer {token}"}, json={"screenSharePolicy": "host"})
    assert host_only.status_code == 200, host_only.json
    status = client.get(f"/api/v1/meetings/invitations/{invite}/status", headers={"Authorization": f"Bearer {participant_token}"})
    claims = jwt.decode(status.json["livekit"]["token"], options={"verify_signature": False})
    assert "screen_share" not in claims["video"].get("canPublishSources", [])

    promoted = client.post(f"/api/v1/meetings/{meeting_id}/participants/{participant_id}/action", headers={"Authorization": f"Bearer {token}"}, json={"action": "promote_cohost"})
    assert promoted.status_code == 200
    cohost_policy = client.patch(f"/api/v1/meetings/{meeting_id}/controls", headers={"Authorization": f"Bearer {token}"}, json={"screenSharePolicy": "cohosts"})
    assert cohost_policy.status_code == 200
    status = client.get(f"/api/v1/meetings/invitations/{invite}/status", headers={"Authorization": f"Bearer {participant_token}"})
    claims = jwt.decode(status.json["livekit"]["token"], options={"verify_signature": False})
    assert "screen_share" in claims["video"].get("canPublishSources", [])


def test_participant_screen_share_state_start_pause_resume_stop(client, monkeypatch):
    emitted = []
    monkeypatch.setattr("app.routes.meetings.socketio.emit", lambda name, payload=None, **kwargs: emitted.append({"name": name, "payload": payload, "kwargs": kwargs}))
    token = admin_token(client)
    created = create_meeting(client, token, waiting=False)
    meeting_id = created["meeting"]["id"]
    invite = created["invitation"]["token"]
    participant = join(client, invite)
    participant_id = participant["participant"]["id"]
    participant_token = participant["participantToken"]

    start = client.post(f"/api/v1/meetings/invitations/{invite}/screen-share", headers={"Authorization": f"Bearer {participant_token}"}, json={"sharing": True, "paused": False, "source": "browser"})
    assert start.status_code == 200, start.json
    assert start.json["participant"]["screenSharing"] is True
    assert start.json["participant"]["screenShareSource"] == "browser"
    assert start.json["meeting"]["activeScreenShareParticipantId"] == participant_id

    pause = client.post(f"/api/v1/meetings/invitations/{invite}/screen-share", headers={"Authorization": f"Bearer {participant_token}"}, json={"sharing": True, "paused": True, "source": "browser"})
    assert pause.status_code == 200
    assert pause.json["participant"]["screenSharePaused"] is True

    stop = client.post(f"/api/v1/meetings/invitations/{invite}/screen-share", headers={"Authorization": f"Bearer {participant_token}"}, json={"sharing": False, "source": "browser"})
    assert stop.status_code == 200
    assert stop.json["participant"]["screenSharing"] is False
    assert stop.json["meeting"]["activeScreenShareParticipantId"] is None
    assert "screen:state" in [event["name"] for event in emitted]


def test_screen_share_state_enforces_host_policy(client):
    token = admin_token(client)
    created = create_meeting(client, token, waiting=False)
    meeting_id = created["meeting"]["id"]
    invite = created["invitation"]["token"]
    participant = join(client, invite)
    participant_token = participant["participantToken"]

    disabled = client.patch(f"/api/v1/meetings/{meeting_id}/controls", headers={"Authorization": f"Bearer {token}"}, json={"screenSharePolicy": "host"})
    assert disabled.status_code == 200
    denied = client.post(f"/api/v1/meetings/invitations/{invite}/screen-share", headers={"Authorization": f"Bearer {participant_token}"}, json={"sharing": True, "source": "screen"})
    assert denied.status_code == 403
    assert denied.json["error"]["code"] == "screen_share_forbidden"


def test_host_can_stop_participant_screen_share(client, monkeypatch):
    muted = []
    def record_mute(room, identity, sources, muted_flag=True):
        muted.append((identity, tuple(sources), muted_flag))
        return True
    monkeypatch.setattr("app.routes.meetings.mute_tracks", record_mute)
    token = admin_token(client)
    created = create_meeting(client, token, waiting=False)
    meeting_id = created["meeting"]["id"]
    invite = created["invitation"]["token"]
    participant = join(client, invite)
    participant_id = participant["participant"]["id"]
    participant_token = participant["participantToken"]
    client.post(f"/api/v1/meetings/invitations/{invite}/screen-share", headers={"Authorization": f"Bearer {participant_token}"}, json={"sharing": True, "source": "screen"})

    stopped = client.post(f"/api/v1/meetings/{meeting_id}/participants/{participant_id}/action", headers={"Authorization": f"Bearer {token}"}, json={"action": "stop_screen_share"})
    assert stopped.status_code == 200, stopped.json
    assert stopped.json["participant"]["screenSharing"] is False
    assert stopped.json["meeting"]["activeScreenShareParticipantId"] is None
    assert muted[-1][0] == participant_id
    assert "screen_share" in muted[-1][1]


def test_admin_can_set_presentation_layout_and_cursor_policy(client):
    token = admin_token(client)
    created = create_meeting(client, token, waiting=False)
    meeting_id = created["meeting"]["id"]
    updated = client.patch(f"/api/v1/meetings/{meeting_id}/controls", headers={"Authorization": f"Bearer {token}"}, json={"presenterLayout": "side_by_side", "sharedCursorEnabled": False})
    assert updated.status_code == 200, updated.json
    assert updated.json["meeting"]["presenterLayout"] == "side_by_side"
    assert updated.json["meeting"]["sharedCursorEnabled"] is False
