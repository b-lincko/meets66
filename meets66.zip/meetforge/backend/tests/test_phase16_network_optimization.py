from datetime import datetime, timedelta, timezone

import pytest

from app import create_app, seed_database
from app.config import TestingConfig
from app.extensions import db
from app.models import MediaRegion, NetworkDiagnostic


@pytest.fixture()
def app():
    app = create_app(TestingConfig)
    app.config["PUBLIC_APP_URL"] = "http://localhost:3000"
    app.config["LIVEKIT_URL"] = "ws://localhost:7880"
    app.config["LIVEKIT_API_SECRET"] = "secret-for-tests-with-enough-length-123"
    app.config["STUN_SERVERS"] = ["stun:stun.example.com:19302"]
    app.config["TURN_URLS"] = ["turn:turn.example.com:3478"]
    app.config["TURN_USERNAME"] = "turn-user"
    app.config["TURN_CREDENTIAL"] = "turn-pass"
    app.config["MEDIA_REGIONS"] = ["local|Local|ws://localhost:7880|1", "eu|Europe|wss://eu.example.com|2"]
    with app.app_context():
        db.drop_all()
        db.create_all()
        seed_database(app)
    yield app


@pytest.fixture()
def client(app):
    return app.test_client()


def admin_token(client):
    login = client.post("/api/v1/auth/login", json={"email": "web@defensiqsecurity.com", "password": "Nullbyte69"})
    changed = client.post(
        "/api/v1/auth/change-password",
        headers={"Authorization": f"Bearer {login.json['accessToken']}"},
        json={"currentPassword": "Nullbyte69", "newPassword": "NewStrong123", "confirmPassword": "NewStrong123"},
    )
    return changed.json["accessToken"]


def create_meeting(client, token):
    start = datetime.now(timezone.utc) + timedelta(hours=1)
    end = start + timedelta(hours=1)
    response = client.post(
        "/api/v1/meetings",
        headers={"Authorization": f"Bearer {token}"},
        json={"title": "Network Meeting", "scheduledStartAt": start.isoformat(), "scheduledEndAt": end.isoformat(), "timezone": "UTC", "waitingRoomEnabled": False},
    )
    assert response.status_code == 201, response.json
    return response.json


def join(client, invite, selected_region="eu"):
    response = client.post(
        f"/api/v1/meetings/invitations/{invite}/join",
        json={"displayName": "Network User", "deviceInfo": {"selectedRegion": selected_region}, "networkType": "4g"},
    )
    assert response.status_code == 201, response.json
    return response.json


def test_public_ice_servers_and_regions(client):
    ice = client.get("/api/v1/network/ice-servers")
    assert ice.status_code == 200
    assert ice.json["iceServers"][0]["urls"] == ["stun:stun.example.com:19302"]
    assert ice.json["iceServers"][1]["username"] == "turn-user"
    regions = client.get("/api/v1/network/regions")
    assert regions.status_code == 200
    assert regions.json["total"] == 2
    assert regions.json["items"][0]["code"] == "local"


def test_selected_region_changes_livekit_url(client):
    token = admin_token(client)
    created = create_meeting(client, token)
    joined = join(client, created["invitation"]["token"], selected_region="eu")
    assert joined["livekit"]["url"] == "wss://eu.example.com"


def test_participant_network_diagnostics_persist_and_admin_summary_export(client):
    token = admin_token(client)
    created = create_meeting(client, token)
    joined = join(client, created["invitation"]["token"])
    ptoken = joined["participantToken"]
    invite = created["invitation"]["token"]
    report = client.post(
        f"/api/v1/meetings/invitations/{invite}/network-diagnostics",
        headers={"Authorization": f"Bearer {ptoken}"},
        json={"quality": "good", "rttMs": 42, "jitterMs": 5, "packetLoss": 0.01, "downlinkMbps": 5.5, "effectiveType": "4g", "saveData": False, "online": True, "iceState": "connected", "roomState": "connected", "selectedRegion": "eu"},
    )
    assert report.status_code == 200, report.json
    assert report.json["diagnostic"]["quality"] == "good"
    assert NetworkDiagnostic.query.count() == 1

    history = client.get(f"/api/v1/meetings/invitations/{invite}/network-diagnostics", headers={"Authorization": f"Bearer {ptoken}"})
    assert history.status_code == 200
    assert history.json["total"] == 1

    summary = client.get("/api/v1/admin/network/summary", headers={"Authorization": f"Bearer {token}"})
    assert summary.status_code == 200
    assert summary.json["totalReports"] == 1
    assert summary.json["qualities"]["good"] == 1
    assert summary.json["regions"]["eu"] == 1

    diagnostics = client.get("/api/v1/admin/network/diagnostics", headers={"Authorization": f"Bearer {token}"})
    assert diagnostics.status_code == 200
    assert diagnostics.json["items"][0]["rttMs"] == 42

    csv_res = client.get("/api/v1/admin/network/diagnostics.csv", headers={"Authorization": f"Bearer {token}"})
    assert csv_res.status_code == 200
    assert "Network User" in csv_res.get_data(as_text=True)
    assert "good" in csv_res.get_data(as_text=True)


def test_admin_region_crud(client):
    token = admin_token(client)
    created = client.post("/api/v1/admin/network/regions", headers={"Authorization": f"Bearer {token}"}, json={"code": "us", "name": "United States", "livekitUrl": "wss://us.example.com", "priority": 3})
    assert created.status_code == 201, created.json
    region_id = created.json["region"]["id"]
    assert MediaRegion.query.filter_by(code="us").first() is not None
    updated = client.patch(f"/api/v1/admin/network/regions/{region_id}", headers={"Authorization": f"Bearer {token}"}, json={"enabled": False, "priority": 9})
    assert updated.status_code == 200
    assert updated.json["region"]["enabled"] is False
    deleted = client.delete(f"/api/v1/admin/network/regions/{region_id}", headers={"Authorization": f"Bearer {token}"})
    assert deleted.status_code == 200
    assert MediaRegion.query.filter_by(code="us").first() is None


def test_network_diagnostic_validation(client):
    token = admin_token(client)
    created = create_meeting(client, token)
    joined = join(client, created["invitation"]["token"])
    bad = client.post(f"/api/v1/meetings/invitations/{created['invitation']['token']}/network-diagnostics", headers={"Authorization": f"Bearer {joined['participantToken']}"}, json={"rttMs": "not-a-number"})
    assert bad.status_code == 400
