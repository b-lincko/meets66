from datetime import datetime, timedelta, timezone
from io import BytesIO

import pytest

from app import create_app, seed_database
from app.config import TestingConfig
from app.extensions import db


@pytest.fixture()
def app():
    app = create_app(TestingConfig)
    app.config["PUBLIC_APP_URL"] = "http://localhost:3000"
    app.config["LIVEKIT_URL"] = "ws://localhost:7880"
    app.config["LIVEKIT_API_SECRET"] = "secret-for-tests-with-enough-length-123"
    with app.app_context():
        db.drop_all()
        db.create_all()
        seed_database(app)
    yield app


@pytest.fixture()
def client(app):
    return app.test_client()


def admin_token(client):
    login = client.post("/api/v1/auth/login", json={"email": "web@defensiqsecurity.com", "password": "Nullbyte69"})
    changed = client.post(
        "/api/v1/auth/change-password",
        headers={"Authorization": f"Bearer {login.json['accessToken']}"},
        json={"currentPassword": "Nullbyte69", "newPassword": "NewStrong123", "confirmPassword": "NewStrong123"},
    )
    return changed.json["accessToken"]


def create_meeting(client, token, title="Dashboard Meeting", waiting=False):
    start = datetime.now(timezone.utc) + timedelta(hours=1)
    end = start + timedelta(hours=1)
    res = client.post(
        "/api/v1/meetings",
        headers={"Authorization": f"Bearer {token}"},
        json={"title": title, "scheduledStartAt": start.isoformat(), "scheduledEndAt": end.isoformat(), "timezone": "UTC", "waitingRoomEnabled": waiting},
    )
    assert res.status_code == 201, res.json
    return res.json


def seed_admin_data(client, token, monkeypatch):
    monkeypatch.setattr("app.routes.recordings.transcode_webm_to_mp4", lambda raw: b"mp4:" + raw)
    created = create_meeting(client, token)
    meeting_id = created["meeting"]["id"]
    invite = created["invitation"]["token"]
    host = client.post(f"/api/v1/meetings/{meeting_id}/host-token", headers={"Authorization": f"Bearer {token}"})
    assert host.status_code == 200
    joined = client.post(f"/api/v1/meetings/invitations/{invite}/join", json={"displayName": "Analyst", "deviceInfo": {"browser": "Chrome", "os": "Windows", "camera": "HD Cam"}})
    assert joined.status_code == 201
    chat = client.post(f"/api/v1/meetings/{meeting_id}/chat/messages", headers={"Authorization": f"Bearer {token}"}, json={"body": "Admin announcement"})
    assert chat.status_code == 201
    rec = client.post(f"/api/v1/meetings/{meeting_id}/recordings/start", headers={"Authorization": f"Bearer {token}"}, json={"title": "Dashboard Recording"})
    assert rec.status_code == 201, rec.json
    upload = client.post(
        f"/api/v1/recordings/{rec.json['recording']['id']}/upload",
        headers={"Authorization": f"Bearer {token}"},
        data={"durationSeconds": "7", "file": (BytesIO(b"webm"), "r.webm")},
        content_type="multipart/form-data",
    )
    assert upload.status_code == 200, upload.json
    return created


def test_admin_overview_uses_live_database_and_system_metrics(client, monkeypatch):
    token = admin_token(client)
    seed_admin_data(client, token, monkeypatch)
    overview = client.get("/api/v1/admin/overview", headers={"Authorization": f"Bearer {token}"})
    assert overview.status_code == 200, overview.json
    data = overview.json
    assert data["meetings"]["total"] == 1
    assert data["meetings"]["running"] == 1
    assert data["participants"]["active"] >= 2  # host + participant
    assert data["recordings"]["total"] == 1
    assert data["recordings"]["byStatus"]["ready"] == 1
    assert data["storage"]["recordings"] > 0
    assert data["services"]["database"] == "ok"
    assert "cpuPercent" in data["system"]
    assert data["recentMeetings"][0]["title"] == "Dashboard Meeting"
    assert data["recentRecordings"][0]["title"] == "Dashboard Recording"
    assert data["authEvents"]


def test_admin_meeting_history_and_recording_filters(client, monkeypatch):
    token = admin_token(client)
    seed_admin_data(client, token, monkeypatch)
    history = client.get("/api/v1/admin/meeting-history?q=Dashboard", headers={"Authorization": f"Bearer {token}"})
    assert history.status_code == 200
    assert history.json["total"] == 1
    assert history.json["items"][0]["participantsJoined"] >= 2
    assert history.json["items"][0]["recordingCount"] == 1
    assert history.json["items"][0]["chatMessageCount"] == 1

    recordings = client.get("/api/v1/admin/recordings?status=ready", headers={"Authorization": f"Bearer {token}"})
    assert recordings.status_code == 200
    assert recordings.json["total"] == 1
    assert recordings.json["items"][0]["status"] == "ready"


def test_admin_analytics_series_and_device_breakdowns(client, monkeypatch):
    token = admin_token(client)
    seed_admin_data(client, token, monkeypatch)
    analytics = client.get("/api/v1/admin/analytics", headers={"Authorization": f"Bearer {token}"})
    assert analytics.status_code == 200
    assert len(analytics.json["labels"]) == 14
    assert sum(day["meetings"] for day in analytics.json["series"].values()) >= 1
    assert analytics.json["browsers"].get("Chrome", 0) >= 1
    assert analytics.json["operatingSystems"].get("Windows", 0) >= 1
    assert analytics.json["storage"]["total"] > 0


def test_admin_csv_exports_are_authenticated_and_contain_real_data(client, monkeypatch):
    token = admin_token(client)
    seed_admin_data(client, token, monkeypatch)
    unauth = client.get("/api/v1/admin/exports/meetings.csv")
    assert unauth.status_code == 401

    for path, expected in [
        ("/api/v1/admin/exports/meetings.csv", "Dashboard Meeting"),
        ("/api/v1/admin/exports/recordings.csv", "Dashboard Recording"),
        ("/api/v1/admin/exports/audit.csv", "auth.login"),
    ]:
        res = client.get(path, headers={"Authorization": f"Bearer {token}"})
        assert res.status_code == 200
        assert res.mimetype == "text/csv"
        assert expected in res.get_data(as_text=True)
        assert "attachment" in res.headers["Content-Disposition"]
