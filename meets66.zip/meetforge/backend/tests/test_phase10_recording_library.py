from datetime import datetime, timedelta, timezone
from io import BytesIO

import pytest

from app import create_app, seed_database
from app.config import TestingConfig
from app.extensions import db
from app.models import RecordingAccessEvent, RecordingShare


@pytest.fixture()
def app():
    app = create_app(TestingConfig)
    app.config["PUBLIC_APP_URL"] = "http://localhost:3000"
    app.config["LIVEKIT_URL"] = "ws://localhost:7880"
    app.config["LIVEKIT_API_SECRET"] = "secret-for-tests-with-enough-length-123"
    with app.app_context():
        db.drop_all()
        db.create_all()
        seed_database(app)
    yield app


@pytest.fixture()
def client(app):
    return app.test_client()


def admin_token(client):
    login = client.post("/api/v1/auth/login", json={"email": "web@defensiqsecurity.com", "password": "Nullbyte69"})
    changed = client.post(
        "/api/v1/auth/change-password",
        headers={"Authorization": f"Bearer {login.json['accessToken']}"},
        json={"currentPassword": "Nullbyte69", "newPassword": "NewStrong123", "confirmPassword": "NewStrong123"},
    )
    return changed.json["accessToken"]


def create_ready_recording(client, token, monkeypatch):
    monkeypatch.setattr("app.routes.recordings.transcode_webm_to_mp4", lambda raw: b"mp4:" + raw)
    start = datetime.now(timezone.utc) + timedelta(hours=1)
    end = start + timedelta(hours=1)
    meeting = client.post(
        "/api/v1/meetings",
        headers={"Authorization": f"Bearer {token}"},
        json={"title": "Library Meeting", "scheduledStartAt": start.isoformat(), "scheduledEndAt": end.isoformat(), "timezone": "UTC", "waitingRoomEnabled": False},
    ).json
    meeting_id = meeting["meeting"]["id"]
    client.post(f"/api/v1/meetings/{meeting_id}/host-token", headers={"Authorization": f"Bearer {token}"})
    recording = client.post(f"/api/v1/meetings/{meeting_id}/recordings/start", headers={"Authorization": f"Bearer {token}"}, json={"title": "Library Recording"}).json["recording"]
    upload = client.post(
        f"/api/v1/recordings/{recording['id']}/upload",
        headers={"Authorization": f"Bearer {token}"},
        data={"durationSeconds": "10", "file": (BytesIO(b"webm"), "r.webm")},
        content_type="multipart/form-data",
    )
    assert upload.status_code == 200, upload.json
    return upload.json["recording"]


def test_recording_metadata_category_transcript_summary_and_search(client, monkeypatch):
    token = admin_token(client)
    recording = create_ready_recording(client, token, monkeypatch)
    updated = client.patch(
        f"/api/v1/recordings/{recording['id']}",
        headers={"Authorization": f"Bearer {token}"},
        json={"category": "Incident", "transcriptText": "alpha bravo transcript", "summaryText": "Incident summary", "expiresAt": (datetime.now(timezone.utc) + timedelta(days=7)).isoformat()},
    )
    assert updated.status_code == 200, updated.json
    assert updated.json["recording"]["category"] == "Incident"
    assert "alpha bravo" in updated.json["recording"]["transcriptText"]
    search = client.get("/api/v1/recordings?q=bravo", headers={"Authorization": f"Bearer {token}"})
    assert search.status_code == 200
    assert search.json["total"] == 1


def test_create_password_protected_share_and_public_playback_download_analytics(client, monkeypatch):
    token = admin_token(client)
    recording = create_ready_recording(client, token, monkeypatch)
    expires = (datetime.now(timezone.utc) + timedelta(days=1)).isoformat()
    share = client.post(
        f"/api/v1/recordings/{recording['id']}/shares",
        headers={"Authorization": f"Bearer {token}"},
        json={"password": "Share123", "expiresAt": expires, "allowDownload": True, "watermarkText": "Defensiq Confidential"},
    )
    assert share.status_code == 201, share.json
    share_url = share.json["share"]["url"]
    raw_token = share_url.rsplit("/", 1)[-1]
    assert share.json["share"]["passwordRequired"] is True
    assert share.json["share"]["allowDownload"] is True

    public = client.get(f"/api/v1/recording-shares/{raw_token}")
    assert public.status_code == 200
    assert public.json["share"]["watermarkText"] == "Defensiq Confidential"
    assert public.json["recording"]["title"] == "Library Recording"

    denied = client.get(f"/api/v1/recording-shares/{raw_token}/playback")
    assert denied.status_code == 401
    wrong = client.post(f"/api/v1/recording-shares/{raw_token}/access", json={"password": "bad"})
    assert wrong.status_code == 401
    access = client.post(f"/api/v1/recording-shares/{raw_token}/access", json={"password": "Share123"})
    assert access.status_code == 200, access.json
    access_token = access.json["accessToken"]

    playback = client.get(f"/api/v1/recording-shares/{raw_token}/playback?accessToken={access_token}")
    assert playback.status_code == 200
    assert playback.data == b"mp4:webm"
    download = client.get(f"/api/v1/recording-shares/{raw_token}/download?accessToken={access_token}")
    assert download.status_code == 200
    assert download.headers["Content-Disposition"].startswith("attachment")
    assert RecordingAccessEvent.query.count() == 2

    analytics = client.get(f"/api/v1/recordings/{recording['id']}/analytics", headers={"Authorization": f"Bearer {token}"})
    assert analytics.status_code == 200
    assert analytics.json["byAction"]["playback"] == 1
    assert analytics.json["byAction"]["download"] == 1


def test_share_expiration_revocation_and_download_permission(client, monkeypatch):
    token = admin_token(client)
    recording = create_ready_recording(client, token, monkeypatch)
    no_download = client.post(f"/api/v1/recordings/{recording['id']}/shares", headers={"Authorization": f"Bearer {token}"}, json={"allowDownload": False})
    raw = no_download.json["share"]["url"].rsplit("/", 1)[-1]
    access = client.post(f"/api/v1/recording-shares/{raw}/access", json={})
    assert access.status_code == 200
    download = client.get(f"/api/v1/recording-shares/{raw}/download?accessToken={access.json['accessToken']}")
    assert download.status_code == 403

    share_id = no_download.json["share"]["id"]
    revoked = client.delete(f"/api/v1/recording-shares/{share_id}", headers={"Authorization": f"Bearer {token}"})
    assert revoked.status_code == 200
    assert revoked.json["share"]["active"] is False
    public = client.get(f"/api/v1/recording-shares/{raw}")
    assert public.status_code == 404

    expired = client.post(f"/api/v1/recordings/{recording['id']}/shares", headers={"Authorization": f"Bearer {token}"}, json={"expiresAt": (datetime.now(timezone.utc) - timedelta(minutes=1)).isoformat()})
    assert expired.status_code == 400


def test_share_update_and_list(client, monkeypatch):
    token = admin_token(client)
    recording = create_ready_recording(client, token, monkeypatch)
    created = client.post(f"/api/v1/recordings/{recording['id']}/shares", headers={"Authorization": f"Bearer {token}"}, json={"allowDownload": False})
    share_id = created.json["share"]["id"]
    updated = client.patch(f"/api/v1/recording-shares/{share_id}", headers={"Authorization": f"Bearer {token}"}, json={"allowDownload": True, "watermarkText": "Updated", "password": "NewPass123"})
    assert updated.status_code == 200
    assert updated.json["share"]["allowDownload"] is True
    assert updated.json["share"]["watermarkText"] == "Updated"
    assert updated.json["share"]["passwordRequired"] is True
    listing = client.get(f"/api/v1/recordings/{recording['id']}/shares", headers={"Authorization": f"Bearer {token}"})
    assert listing.status_code == 200
    assert listing.json["total"] == 1


def test_recording_generates_timeline_chapters_and_clip_share(client, monkeypatch):
    token = admin_token(client)
    recording = create_ready_recording(client, token, monkeypatch)
    assert recording["metadata"]["chapters"]
    assert recording["metadata"]["timelineEvents"]

    updated = client.patch(
        f"/api/v1/recordings/{recording['id']}",
        headers={"Authorization": f"Bearer {token}"},
        json={"transcriptText": "00:00 Intro\n00:05 Demo section\n00:09 Wrap up"},
    )
    assert updated.status_code == 200
    # Create a clip share. Downloads must remain disabled to avoid exposing the full source video.
    clip = client.post(
        f"/api/v1/recordings/{recording['id']}/shares",
        headers={"Authorization": f"Bearer {token}"},
        json={"clipStartSeconds": 2, "clipEndSeconds": 8, "allowDownload": False, "watermarkText": "Clip"},
    )
    assert clip.status_code == 201, clip.json
    assert clip.json["share"]["clipStartSeconds"] == 2
    assert clip.json["share"]["clipEndSeconds"] == 8
    assert clip.json["share"]["allowDownload"] is False
    raw = clip.json["share"]["url"].rsplit("/", 1)[-1]
    public = client.get(f"/api/v1/recording-shares/{raw}")
    assert public.status_code == 200
    assert public.json["share"]["clipStartSeconds"] == 2
    assert "chapters" in public.json["recording"]["metadata"]

    forbidden = client.post(
        f"/api/v1/recordings/{recording['id']}/shares",
        headers={"Authorization": f"Bearer {token}"},
        json={"clipStartSeconds": 1, "clipEndSeconds": 4, "allowDownload": True},
    )
    assert forbidden.status_code == 400
    assert forbidden.json["error"]["code"] == "clip_download_forbidden"
