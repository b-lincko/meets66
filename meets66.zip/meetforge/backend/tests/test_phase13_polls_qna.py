from datetime import datetime, timedelta, timezone

import pytest

from app import create_app, seed_database
from app.config import TestingConfig
from app.extensions import db
from app.models import Poll, PollVote, Question, QuestionUpvote


@pytest.fixture()
def app():
    app = create_app(TestingConfig)
    app.config["PUBLIC_APP_URL"] = "http://localhost:3000"
    app.config["LIVEKIT_URL"] = "ws://localhost:7880"
    app.config["LIVEKIT_API_SECRET"] = "secret-for-tests-with-enough-length-123"
    with app.app_context():
        db.drop_all()
        db.create_all()
        seed_database(app)
    yield app


@pytest.fixture()
def client(app):
    return app.test_client()


def admin_token(client):
    login = client.post("/api/v1/auth/login", json={"email": "web@defensiqsecurity.com", "password": "Nullbyte69"})
    changed = client.post(
        "/api/v1/auth/change-password",
        headers={"Authorization": f"Bearer {login.json['accessToken']}"},
        json={"currentPassword": "Nullbyte69", "newPassword": "NewStrong123", "confirmPassword": "NewStrong123"},
    )
    return changed.json["accessToken"]


def create_meeting(client, token):
    start = datetime.now(timezone.utc) + timedelta(hours=1)
    end = start + timedelta(hours=1)
    meeting = client.post(
        "/api/v1/meetings",
        headers={"Authorization": f"Bearer {token}"},
        json={"title": "Poll Meeting", "scheduledStartAt": start.isoformat(), "scheduledEndAt": end.isoformat(), "timezone": "UTC", "waitingRoomEnabled": False},
    )
    assert meeting.status_code == 201, meeting.json
    host = client.post(f"/api/v1/meetings/{meeting.json['meeting']['id']}/host-token", headers={"Authorization": f"Bearer {token}"})
    assert host.status_code == 200
    return meeting.json


def join(client, invite, name="Poll User"):
    res = client.post(f"/api/v1/meetings/invitations/{invite}/join", json={"displayName": name})
    assert res.status_code == 201, res.json
    return res.json


def test_admin_create_poll_participant_vote_results_export_and_realtime(client, monkeypatch):
    emitted = []
    monkeypatch.setattr("app.routes.polls.socketio.emit", lambda name, payload=None, **kwargs: emitted.append({"name": name, "payload": payload, "kwargs": kwargs}))
    token = admin_token(client)
    created = create_meeting(client, token)
    meeting_id = created["meeting"]["id"]
    invite = created["invitation"]["token"]
    participant = join(client, invite)
    ptoken = participant["participantToken"]

    poll = client.post(f"/api/v1/meetings/{meeting_id}/polls", headers={"Authorization": f"Bearer {token}"}, json={"title": "Choose option", "options": ["A", "B"], "anonymous": False})
    assert poll.status_code == 201, poll.json
    poll_id = poll.json["poll"]["id"]
    option_id = poll.json["poll"]["options"][0]["id"]
    assert Poll.query.count() == 1

    vote = client.post(f"/api/v1/meetings/invitations/{invite}/polls/{poll_id}/vote", headers={"Authorization": f"Bearer {ptoken}"}, json={"optionIds": [option_id]})
    assert vote.status_code == 200, vote.json
    assert vote.json["poll"]["results"]["totalVotes"] == 1
    assert PollVote.query.count() == 1
    assert "poll:updated" in [event["name"] for event in emitted]

    results = client.get(f"/api/v1/meetings/{meeting_id}/polls/{poll_id}/results", headers={"Authorization": f"Bearer {token}"})
    assert results.status_code == 200
    assert results.json["poll"]["results"]["options"][0]["voters"] == ["Poll User"]

    export = client.get(f"/api/v1/meetings/{meeting_id}/polls/{poll_id}/export.csv", headers={"Authorization": f"Bearer {token}"})
    assert export.status_code == 200
    assert "Choose option" in export.get_data(as_text=True)


def test_anonymous_timed_multiple_choice_poll_and_close(client):
    token = admin_token(client)
    created = create_meeting(client, token)
    meeting_id = created["meeting"]["id"]
    invite = created["invitation"]["token"]
    participant = join(client, invite, "Anonymous Voter")
    ptoken = participant["participantToken"]

    poll = client.post(f"/api/v1/meetings/{meeting_id}/polls", headers={"Authorization": f"Bearer {token}"}, json={"title": "Select all", "options": ["A", "B", "C"], "anonymous": True, "multipleChoice": True, "durationSeconds": 30})
    assert poll.status_code == 201
    poll_id = poll.json["poll"]["id"]
    option_ids = [o["id"] for o in poll.json["poll"]["options"][:2]]
    vote = client.post(f"/api/v1/meetings/invitations/{invite}/polls/{poll_id}/vote", headers={"Authorization": f"Bearer {ptoken}"}, json={"optionIds": option_ids})
    assert vote.status_code == 200
    results = client.get(f"/api/v1/meetings/{meeting_id}/polls/{poll_id}/results", headers={"Authorization": f"Bearer {token}"})
    assert results.json["poll"]["results"]["totalVotes"] == 2
    assert results.json["poll"]["results"]["options"][0]["voters"] == []
    close = client.post(f"/api/v1/meetings/{meeting_id}/polls/{poll_id}/close", headers={"Authorization": f"Bearer {token}"})
    assert close.status_code == 200
    denied = client.post(f"/api/v1/meetings/invitations/{invite}/polls/{poll_id}/vote", headers={"Authorization": f"Bearer {ptoken}"}, json={"optionIds": [option_ids[0]]})
    assert denied.status_code == 409


def test_poll_validation_and_participant_cannot_create_poll(client):
    token = admin_token(client)
    created = create_meeting(client, token)
    meeting_id = created["meeting"]["id"]
    invite = created["invitation"]["token"]
    participant = join(client, invite)
    ptoken = participant["participantToken"]
    bad = client.post(f"/api/v1/meetings/{meeting_id}/polls", headers={"Authorization": f"Bearer {token}"}, json={"title": "x", "options": ["A"]})
    assert bad.status_code == 400
    denied = client.post(f"/api/v1/meetings/invitations/{invite}/polls", headers={"Authorization": f"Bearer {ptoken}"}, json={"title": "No", "options": ["A", "B"]})
    assert denied.status_code == 403


def test_qna_create_upvote_answer_dismiss_export(client, monkeypatch):
    emitted = []
    monkeypatch.setattr("app.routes.polls.socketio.emit", lambda name, payload=None, **kwargs: emitted.append({"name": name, "payload": payload, "kwargs": kwargs}))
    token = admin_token(client)
    created = create_meeting(client, token)
    meeting_id = created["meeting"]["id"]
    invite = created["invitation"]["token"]
    participant = join(client, invite, "Questioner")
    ptoken = participant["participantToken"]

    question = client.post(f"/api/v1/meetings/invitations/{invite}/questions", headers={"Authorization": f"Bearer {ptoken}"}, json={"text": "What is the timeline?"})
    assert question.status_code == 201, question.json
    qid = question.json["question"]["id"]
    upvote = client.post(f"/api/v1/meetings/{meeting_id}/questions/{qid}/upvote", headers={"Authorization": f"Bearer {token}"})
    assert upvote.status_code == 200
    assert upvote.json["question"]["upvotes"] == 1
    assert Question.query.count() == 1
    assert QuestionUpvote.query.count() == 1
    answer = client.patch(f"/api/v1/meetings/{meeting_id}/questions/{qid}", headers={"Authorization": f"Bearer {token}"}, json={"answerText": "Tomorrow", "status": "answered"})
    assert answer.status_code == 200
    assert answer.json["question"]["status"] == "answered"
    assert answer.json["question"]["answerText"] == "Tomorrow"
    assert "question:updated" in [event["name"] for event in emitted]
    listing = client.get(f"/api/v1/meetings/invitations/{invite}/questions", headers={"Authorization": f"Bearer {ptoken}"})
    assert listing.status_code == 200
    assert listing.json["items"][0]["answerText"] == "Tomorrow"
    export = client.get(f"/api/v1/meetings/{meeting_id}/questions/export.csv", headers={"Authorization": f"Bearer {token}"})
    assert export.status_code == 200
    assert "What is the timeline?" in export.get_data(as_text=True)


def test_cohost_can_create_poll_and_moderate_qna(client):
    token = admin_token(client)
    created = create_meeting(client, token)
    meeting_id = created["meeting"]["id"]
    invite = created["invitation"]["token"]
    cohost = join(client, invite, "Co Host")
    ptoken = cohost["participantToken"]
    promote = client.post(f"/api/v1/meetings/{meeting_id}/participants/{cohost['participant']['id']}/action", headers={"Authorization": f"Bearer {token}"}, json={"action": "promote_cohost"})
    assert promote.status_code == 200
    poll = client.post(f"/api/v1/meetings/invitations/{invite}/polls", headers={"Authorization": f"Bearer {ptoken}"}, json={"title": "Co poll", "options": ["Yes", "No"]})
    assert poll.status_code == 201
    question = client.post(f"/api/v1/meetings/invitations/{invite}/questions", headers={"Authorization": f"Bearer {ptoken}"}, json={"text": "Can I answer?"})
    qid = question.json["question"]["id"]
    answered = client.patch(f"/api/v1/meetings/invitations/{invite}/questions/{qid}", headers={"Authorization": f"Bearer {ptoken}"}, json={"answerText": "Yes"})
    assert answered.status_code == 200
    assert answered.json["question"]["status"] == "answered"
