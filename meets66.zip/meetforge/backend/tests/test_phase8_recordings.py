from datetime import datetime, timedelta, timezone
from io import BytesIO

import pytest

from app import create_app, seed_database
from app.config import TestingConfig
from app.extensions import db
from app.models import Recording


@pytest.fixture()
def app():
    app = create_app(TestingConfig)
    app.config["PUBLIC_APP_URL"] = "http://localhost:3000"
    app.config["LIVEKIT_URL"] = "ws://localhost:7880"
    app.config["LIVEKIT_API_SECRET"] = "secret-for-tests-with-enough-length-123"
    app.config["MAX_RECORDING_UPLOAD_MB"] = 1
    with app.app_context():
        db.drop_all()
        db.create_all()
        seed_database(app)
    yield app


@pytest.fixture()
def client(app):
    return app.test_client()


def admin_token(client):
    login = client.post("/api/v1/auth/login", json={"email": "web@defensiqsecurity.com", "password": "Nullbyte69"})
    changed = client.post(
        "/api/v1/auth/change-password",
        headers={"Authorization": f"Bearer {login.json['accessToken']}"},
        json={"currentPassword": "Nullbyte69", "newPassword": "NewStrong123", "confirmPassword": "NewStrong123"},
    )
    return changed.json["accessToken"]


def create_running_meeting(client, token):
    start = datetime.now(timezone.utc) + timedelta(hours=1)
    end = start + timedelta(hours=1)
    meeting = client.post(
        "/api/v1/meetings",
        headers={"Authorization": f"Bearer {token}"},
        json={"title": "Recording Meeting", "scheduledStartAt": start.isoformat(), "scheduledEndAt": end.isoformat(), "timezone": "UTC", "waitingRoomEnabled": False},
    )
    assert meeting.status_code == 201, meeting.json
    host = client.post(f"/api/v1/meetings/{meeting.json['meeting']['id']}/host-token", headers={"Authorization": f"Bearer {token}"})
    assert host.status_code == 200, host.json
    return meeting.json


def test_start_recording_requires_running_meeting(client):
    token = admin_token(client)
    start = datetime.now(timezone.utc) + timedelta(hours=1)
    end = start + timedelta(hours=1)
    meeting = client.post(
        "/api/v1/meetings",
        headers={"Authorization": f"Bearer {token}"},
        json={"title": "Not Running", "scheduledStartAt": start.isoformat(), "scheduledEndAt": end.isoformat(), "timezone": "UTC"},
    ).json
    denied = client.post(f"/api/v1/meetings/{meeting['meeting']['id']}/recordings/start", headers={"Authorization": f"Bearer {token}"})
    assert denied.status_code == 409
    assert denied.json["error"]["code"] == "meeting_not_running"


def test_start_upload_download_playback_and_history(client, monkeypatch):
    emitted = []
    monkeypatch.setattr("app.routes.recordings.socketio.emit", lambda name, payload=None, **kwargs: emitted.append({"name": name, "payload": payload, "kwargs": kwargs}))
    monkeypatch.setattr("app.routes.recordings.transcode_webm_to_mp4", lambda raw: b"mp4:" + raw)
    token = admin_token(client)
    meeting = create_running_meeting(client, token)
    meeting_id = meeting["meeting"]["id"]

    start = client.post(f"/api/v1/meetings/{meeting_id}/recordings/start", headers={"Authorization": f"Bearer {token}"}, json={"title": "Critical Briefing", "metadata": {"recordingMode": "presentation", "pipPosition": "bottom_right", "resolution": "1080p", "cleanPresentationRecording": True}})
    assert start.status_code == 201, start.json
    recording_id = start.json["recording"]["id"]
    assert start.json["recording"]["status"] == "recording"
    assert start.json["recording"]["metadata"]["recordingMode"] == "presentation"
    assert start.json["recording"]["metadata"]["recordingLayout"] == "presenter_screen_only"
    assert "participant_sidebar" in start.json["recording"]["metadata"]["excludedFromRecording"]
    assert "recording:started" in [event["name"] for event in emitted]

    duplicate = client.post(f"/api/v1/meetings/{meeting_id}/recordings/start", headers={"Authorization": f"Bearer {token}"})
    assert duplicate.status_code == 409

    upload = client.post(
        f"/api/v1/recordings/{recording_id}/upload",
        headers={"Authorization": f"Bearer {token}"},
        data={"durationSeconds": "9", "metadata": '{"presenterName":"John Smith","recordingMode":"screen_only","thumbnailGenerated":true}', "thumbnailDataUrl": "data:image/jpeg;base64,abc", "file": (BytesIO(b"webmdata"), "recording.webm")},
        content_type="multipart/form-data",
    )
    assert upload.status_code == 200, upload.json
    rec = upload.json["recording"]
    assert rec["status"] == "ready"
    assert rec["durationSeconds"] == 9
    assert rec["metadata"]["presenterName"] == "John Smith"
    assert rec["metadata"]["recordingMode"] == "screen_only"
    assert rec["metadata"]["thumbnailDataUrl"].startswith("data:image/jpeg")
    assert rec["sizeBytes"] == len(b"mp4:webmdata")
    assert rec["filename"].endswith(".mp4")
    assert "recording:ready" in [event["name"] for event in emitted]

    listing = client.get(f"/api/v1/meetings/{meeting_id}/recordings", headers={"Authorization": f"Bearer {token}"})
    assert listing.status_code == 200
    assert listing.json["total"] == 1

    all_listing = client.get("/api/v1/recordings", headers={"Authorization": f"Bearer {token}"})
    assert all_listing.status_code == 200
    assert all_listing.json["items"][0]["title"] == "Critical Briefing"

    playback = client.get(f"/api/v1/recordings/{recording_id}/playback", headers={"Authorization": f"Bearer {token}"})
    assert playback.status_code == 200
    assert playback.mimetype == "video/mp4"
    assert playback.data == b"mp4:webmdata"
    assert playback.headers["Content-Disposition"].startswith("inline")

    download = client.get(f"/api/v1/recordings/{recording_id}/download", headers={"Authorization": f"Bearer {token}"})
    assert download.status_code == 200
    assert download.data == b"mp4:webmdata"
    assert download.headers["Content-Disposition"].startswith("attachment")


def test_rename_archive_restore_delete_recording(client, monkeypatch):
    monkeypatch.setattr("app.routes.recordings.transcode_webm_to_mp4", lambda raw: b"mp4")
    token = admin_token(client)
    meeting = create_running_meeting(client, token)
    meeting_id = meeting["meeting"]["id"]
    recording = client.post(f"/api/v1/meetings/{meeting_id}/recordings/start", headers={"Authorization": f"Bearer {token}"}).json["recording"]
    client.post(f"/api/v1/recordings/{recording['id']}/upload", headers={"Authorization": f"Bearer {token}"}, data={"file": (BytesIO(b"x"), "x.webm")}, content_type="multipart/form-data")

    renamed = client.patch(f"/api/v1/recordings/{recording['id']}", headers={"Authorization": f"Bearer {token}"}, json={"title": "Renamed Recording"})
    assert renamed.status_code == 200
    assert renamed.json["recording"]["title"] == "Renamed Recording"
    assert renamed.json["recording"]["filename"] == "Renamed Recording.mp4"

    archived = client.patch(f"/api/v1/recordings/{recording['id']}", headers={"Authorization": f"Bearer {token}"}, json={"status": "archived"})
    assert archived.status_code == 200
    assert archived.json["recording"]["status"] == "archived"
    archived_download = client.get(f"/api/v1/recordings/{recording['id']}/download", headers={"Authorization": f"Bearer {token}"})
    assert archived_download.status_code == 200
    assert archived_download.data == b"mp4"
    restored = client.patch(f"/api/v1/recordings/{recording['id']}", headers={"Authorization": f"Bearer {token}"}, json={"status": "ready"})
    assert restored.status_code == 200
    assert restored.json["recording"]["status"] == "ready"

    deleted = client.delete(f"/api/v1/recordings/{recording['id']}", headers={"Authorization": f"Bearer {token}"})
    assert deleted.status_code == 200
    assert Recording.query.count() == 0


def test_upload_validation_and_transcode_failure(client, monkeypatch):
    token = admin_token(client)
    meeting = create_running_meeting(client, token)
    meeting_id = meeting["meeting"]["id"]
    recording = client.post(f"/api/v1/meetings/{meeting_id}/recordings/start", headers={"Authorization": f"Bearer {token}"}).json["recording"]

    empty = client.post(f"/api/v1/recordings/{recording['id']}/upload", headers={"Authorization": f"Bearer {token}"}, data={"file": (BytesIO(b""), "x.webm")}, content_type="multipart/form-data")
    assert empty.status_code == 400

    def fail(_raw):
        raise RuntimeError("bad media")
    monkeypatch.setattr("app.routes.recordings.transcode_webm_to_mp4", fail)
    failed = client.post(f"/api/v1/recordings/{recording['id']}/upload", headers={"Authorization": f"Bearer {token}"}, data={"file": (BytesIO(b"webm"), "x.webm")}, content_type="multipart/form-data")
    assert failed.status_code == 500
    with client.application.app_context():
        row = db.session.get(Recording, recording["id"])
        assert row.status == "failed"
        assert "bad media" in row.error_message


def test_mp4_upload_skips_server_transcode(client, monkeypatch):
    def should_not_transcode(_raw):
        raise AssertionError("MP4 uploads should not be server transcoded")
    monkeypatch.setattr("app.routes.recordings.transcode_webm_to_mp4", should_not_transcode)
    token = admin_token(client)
    meeting = create_running_meeting(client, token)
    meeting_id = meeting["meeting"]["id"]
    recording = client.post(f"/api/v1/meetings/{meeting_id}/recordings/start", headers={"Authorization": f"Bearer {token}"}).json["recording"]
    upload = client.post(
        f"/api/v1/recordings/{recording['id']}/upload",
        headers={"Authorization": f"Bearer {token}"},
        data={"durationSeconds": "3", "file": (BytesIO(b"mp4-direct"), "direct.mp4")},
        content_type="multipart/form-data",
    )
    assert upload.status_code == 200, upload.json
    assert upload.json["recording"]["metadata"]["clientEncodedMp4"] is True
    assert upload.json["recording"]["metadata"]["serverTranscoded"] is False
    playback = client.get(f"/api/v1/recordings/{recording['id']}/playback", headers={"Authorization": f"Bearer {token}"})
    assert playback.data == b"mp4-direct"


def test_recording_playback_supports_http_range_requests(client, monkeypatch):
    monkeypatch.setattr("app.routes.recordings.transcode_webm_to_mp4", lambda raw: b"0123456789")
    token = admin_token(client)
    meeting = create_running_meeting(client, token)
    meeting_id = meeting["meeting"]["id"]
    recording = client.post(f"/api/v1/meetings/{meeting_id}/recordings/start", headers={"Authorization": f"Bearer {token}"}).json["recording"]
    upload = client.post(f"/api/v1/recordings/{recording['id']}/upload", headers={"Authorization": f"Bearer {token}"}, data={"file": (BytesIO(b"webm"), "x.webm")}, content_type="multipart/form-data")
    assert upload.status_code == 200

    ranged = client.get(f"/api/v1/recordings/{recording['id']}/playback", headers={"Authorization": f"Bearer {token}", "Range": "bytes=2-5"})
    assert ranged.status_code == 206
    assert ranged.data == b"2345"
    assert ranged.headers["Content-Range"] == "bytes 2-5/10"
    assert ranged.headers["Accept-Ranges"] == "bytes"

    suffix = client.get(f"/api/v1/recordings/{recording['id']}/playback", headers={"Authorization": f"Bearer {token}", "Range": "bytes=-3"})
    assert suffix.status_code == 206
    assert suffix.data == b"789"

    invalid = client.get(f"/api/v1/recordings/{recording['id']}/playback", headers={"Authorization": f"Bearer {token}", "Range": "bytes=99-100"})
    assert invalid.status_code == 416


def test_cohost_with_recording_permission_can_start_and_upload_recording(client, monkeypatch):
    monkeypatch.setattr("app.routes.recordings.transcode_webm_to_mp4", lambda raw: b"mp4:" + raw)
    monkeypatch.setattr("app.routes.meetings.update_permissions", lambda *args, **kwargs: True)
    token = admin_token(client)
    meeting = create_running_meeting(client, token)
    meeting_id = meeting["meeting"]["id"]
    invite = meeting["invitation"]["token"]
    joined = client.post(f"/api/v1/meetings/invitations/{invite}/join", json={"displayName": "Recording CoHost"})
    assert joined.status_code == 201, joined.json
    cohost_id = joined.json["participant"]["id"]
    cohost_token = joined.json["participantToken"]
    assigned = client.post(
        f"/api/v1/meetings/{meeting_id}/roles",
        headers={"Authorization": f"Bearer {token}"},
        json={"subjectType": "participant", "participantId": cohost_id, "role": "cohost", "permissions": ["recording.start", "recording.stop"]},
    )
    assert assigned.status_code == 201, assigned.json
    started = client.post(
        f"/api/v1/meetings/invitations/{invite}/recordings/start",
        headers={"Authorization": f"Bearer {cohost_token}"},
        json={"title": "Co-host Recording"},
    )
    assert started.status_code == 201, started.json
    rec_id = started.json["recording"]["id"]
    assert started.json["recording"]["adminId"] == meeting["meeting"]["adminId"]
    upload = client.post(
        f"/api/v1/meetings/invitations/{invite}/recordings/{rec_id}/upload",
        headers={"Authorization": f"Bearer {cohost_token}"},
        data={"durationSeconds": "5", "file": (BytesIO(b"cohost"), "cohost.webm")},
        content_type="multipart/form-data",
    )
    assert upload.status_code == 200, upload.json
    assert upload.json["recording"]["status"] == "ready"
    assert upload.json["recording"]["metadata"]["actorParticipantId"] == cohost_id
