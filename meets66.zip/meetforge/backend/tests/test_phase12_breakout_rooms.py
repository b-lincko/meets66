from datetime import datetime, timedelta, timezone

import pytest

from app import create_app, seed_database
from app.config import TestingConfig
from app.extensions import db
from app.models import BreakoutAssignment, BreakoutRoom, MeetingParticipant


@pytest.fixture()
def app():
    app = create_app(TestingConfig)
    app.config["PUBLIC_APP_URL"] = "http://localhost:3000"
    app.config["LIVEKIT_URL"] = "ws://localhost:7880"
    app.config["LIVEKIT_API_SECRET"] = "secret-for-tests-with-enough-length-123"
    with app.app_context():
        db.drop_all()
        db.create_all()
        seed_database(app)
    yield app


@pytest.fixture()
def client(app):
    return app.test_client()


def admin_token(client):
    login = client.post("/api/v1/auth/login", json={"email": "web@defensiqsecurity.com", "password": "Nullbyte69"})
    changed = client.post(
        "/api/v1/auth/change-password",
        headers={"Authorization": f"Bearer {login.json['accessToken']}"},
        json={"currentPassword": "Nullbyte69", "newPassword": "NewStrong123", "confirmPassword": "NewStrong123"},
    )
    return changed.json["accessToken"]


def create_running_meeting(client, token):
    start = datetime.now(timezone.utc) + timedelta(hours=1)
    end = start + timedelta(hours=1)
    meeting = client.post(
        "/api/v1/meetings",
        headers={"Authorization": f"Bearer {token}"},
        json={"title": "Breakout Meeting", "scheduledStartAt": start.isoformat(), "scheduledEndAt": end.isoformat(), "timezone": "UTC", "waitingRoomEnabled": False},
    )
    assert meeting.status_code == 201, meeting.json
    host = client.post(f"/api/v1/meetings/{meeting.json['meeting']['id']}/host-token", headers={"Authorization": f"Bearer {token}"})
    assert host.status_code == 200
    return meeting.json


def join(client, invite, name):
    res = client.post(f"/api/v1/meetings/invitations/{invite}/join", json={"displayName": name})
    assert res.status_code == 201, res.json
    return res.json


def test_create_breakout_rooms_and_auto_assign(client, monkeypatch):
    emitted = []
    monkeypatch.setattr("app.routes.breakouts.socketio.emit", lambda name, payload=None, **kwargs: emitted.append({"name": name, "payload": payload, "kwargs": kwargs}))
    token = admin_token(client)
    created = create_running_meeting(client, token)
    meeting_id = created["meeting"]["id"]
    invite = created["invitation"]["token"]
    join(client, invite, "One")
    join(client, invite, "Two")
    join(client, invite, "Three")

    rooms = client.post(f"/api/v1/meetings/{meeting_id}/breakout-rooms", headers={"Authorization": f"Bearer {token}"}, json={"count": 2, "timerMinutes": 10})
    assert rooms.status_code == 201, rooms.json
    assert rooms.json["total"] == 2
    assert all(room["timerEndsAt"] for room in rooms.json["items"])
    assert BreakoutRoom.query.count() == 2

    assigned = client.post(f"/api/v1/meetings/{meeting_id}/breakout-rooms/auto-assign", headers={"Authorization": f"Bearer {token}"})
    assert assigned.status_code == 200, assigned.json
    assert len(assigned.json["assignments"]) == 3
    assert BreakoutAssignment.query.count() == 3
    assert "breakout:updated" in [event["name"] for event in emitted]


def test_manual_assign_move_broadcast_close_and_return_all(client, monkeypatch):
    emitted = []
    monkeypatch.setattr("app.routes.breakouts.socketio.emit", lambda name, payload=None, **kwargs: emitted.append({"name": name, "payload": payload, "kwargs": kwargs}))
    token = admin_token(client)
    created = create_running_meeting(client, token)
    meeting_id = created["meeting"]["id"]
    invite = created["invitation"]["token"]
    p1 = join(client, invite, "Move Me")
    p2 = join(client, invite, "Return Me")
    room = client.post(f"/api/v1/meetings/{meeting_id}/breakout-rooms", headers={"Authorization": f"Bearer {token}"}, json={"names": ["Room A"]}).json["items"][0]

    assign = client.post(f"/api/v1/meetings/{meeting_id}/breakout-rooms/{room['id']}/assign", headers={"Authorization": f"Bearer {token}"}, json={"participantIds": [p1['participant']['id']]})
    assert assign.status_code == 200
    assert assign.json["assignments"][0]["status"] == "assigned"

    move = client.post(f"/api/v1/meetings/{meeting_id}/breakout-rooms/{room['id']}/move", headers={"Authorization": f"Bearer {token}"}, json={"participantIds": [p1['participant']['id'], p2['participant']['id']]})
    assert move.status_code == 200, move.json
    assert all(a["status"] == "active" for a in move.json["assignments"])
    moved_events = [event for event in emitted if event["name"] == "breakout:moved"]
    assert len(moved_events) == 2
    assert moved_events[0]["payload"]["livekit"]["roomName"] == room["livekitRoomName"]

    broadcast = client.post(f"/api/v1/meetings/{meeting_id}/breakout-rooms/{room['id']}/broadcast", headers={"Authorization": f"Bearer {token}"}, json={"message": "Two minutes left"})
    assert broadcast.status_code == 200
    assert "breakout:broadcast" in [event["name"] for event in emitted]

    close = client.post(f"/api/v1/meetings/{meeting_id}/breakout-rooms/{room['id']}/close", headers={"Authorization": f"Bearer {token}"})
    assert close.status_code == 200
    assert close.json["room"]["status"] == "closed"
    assert all(a["status"] == "returned" for a in close.json["assignments"])
    assert "breakout:return" in [event["name"] for event in emitted]

    room2 = client.post(f"/api/v1/meetings/{meeting_id}/breakout-rooms", headers={"Authorization": f"Bearer {token}"}, json={"names": ["Room B"]}).json["items"][-1]
    client.post(f"/api/v1/meetings/{meeting_id}/breakout-rooms/{room2['id']}/move", headers={"Authorization": f"Bearer {token}"}, json={"participantIds": [p1['participant']['id']]})
    returned = client.post(f"/api/v1/meetings/{meeting_id}/breakout-rooms/return-all", headers={"Authorization": f"Bearer {token}"})
    assert returned.status_code == 200
    assert any(a["status"] == "returned" for a in returned.json["assignments"])


def test_cohost_can_manage_breakouts_but_participant_cannot(client):
    token = admin_token(client)
    created = create_running_meeting(client, token)
    meeting_id = created["meeting"]["id"]
    invite = created["invitation"]["token"]
    cohost = join(client, invite, "Co Host")
    regular = join(client, invite, "Regular")
    promote = client.post(f"/api/v1/meetings/{meeting_id}/participants/{cohost['participant']['id']}/action", headers={"Authorization": f"Bearer {token}"}, json={"action": "promote_cohost"})
    assert promote.status_code == 200

    allowed = client.post(f"/api/v1/meetings/invitations/{invite}/breakout-rooms", headers={"Authorization": f"Bearer {cohost['participantToken']}"}, json={"count": 1})
    assert allowed.status_code == 201, allowed.json
    denied = client.post(f"/api/v1/meetings/invitations/{invite}/breakout-rooms", headers={"Authorization": f"Bearer {regular['participantToken']}"}, json={"count": 1})
    assert denied.status_code == 403
    assert denied.json["error"]["code"] == "cohost_required"


def test_breakout_status_endpoint_returns_active_room_and_livekit(client):
    token = admin_token(client)
    created = create_running_meeting(client, token)
    meeting_id = created["meeting"]["id"]
    invite = created["invitation"]["token"]
    participant = join(client, invite, "Status User")
    room = client.post(f"/api/v1/meetings/{meeting_id}/breakout-rooms", headers={"Authorization": f"Bearer {token}"}, json={"count": 1}).json["items"][0]
    client.post(f"/api/v1/meetings/{meeting_id}/breakout-rooms/{room['id']}/move", headers={"Authorization": f"Bearer {token}"}, json={"participantIds": [participant['participant']['id']]})

    status = client.get(f"/api/v1/meetings/invitations/{invite}/breakout-status", headers={"Authorization": f"Bearer {participant['participantToken']}"})
    assert status.status_code == 200, status.json
    assert status.json["room"]["id"] == room["id"]
    assert status.json["assignment"]["status"] == "active"
    assert status.json["livekit"]["roomName"] == room["livekitRoomName"]


def test_breakout_validation(client):
    token = admin_token(client)
    created = create_running_meeting(client, token)
    meeting_id = created["meeting"]["id"]
    bad_count = client.post(f"/api/v1/meetings/{meeting_id}/breakout-rooms", headers={"Authorization": f"Bearer {token}"}, json={"count": 0})
    assert bad_count.status_code == 400
    no_rooms = client.post(f"/api/v1/meetings/{meeting_id}/breakout-rooms/auto-assign", headers={"Authorization": f"Bearer {token}"})
    assert no_rooms.status_code == 409
