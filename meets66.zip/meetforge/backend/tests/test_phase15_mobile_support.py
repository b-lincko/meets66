from datetime import datetime, timedelta, timezone

import jwt
import pytest

from app import create_app, seed_database
from app.config import TestingConfig
from app.extensions import db


@pytest.fixture()
def app():
    app = create_app(TestingConfig)
    app.config["PUBLIC_APP_URL"] = "http://localhost:3000"
    app.config["LIVEKIT_URL"] = "ws://localhost:7880"
    app.config["LIVEKIT_API_SECRET"] = "secret-for-tests-with-enough-length-123"
    with app.app_context():
        db.drop_all()
        db.create_all()
        seed_database(app)
    yield app


@pytest.fixture()
def client(app):
    return app.test_client()


def admin_token(client):
    login = client.post("/api/v1/auth/login", json={"email": "web@defensiqsecurity.com", "password": "Nullbyte69"})
    changed = client.post(
        "/api/v1/auth/change-password",
        headers={"Authorization": f"Bearer {login.json['accessToken']}"},
        json={"currentPassword": "Nullbyte69", "newPassword": "NewStrong123", "confirmPassword": "NewStrong123"},
    )
    return changed.json["accessToken"]


def create_meeting(client, token, waiting=False):
    start = datetime.now(timezone.utc) + timedelta(hours=1)
    end = start + timedelta(hours=1)
    response = client.post(
        "/api/v1/meetings",
        headers={"Authorization": f"Bearer {token}"},
        json={"title": "Mobile Meeting", "scheduledStartAt": start.isoformat(), "scheduledEndAt": end.isoformat(), "timezone": "UTC", "waitingRoomEnabled": waiting},
    )
    assert response.status_code == 201, response.json
    return response.json


def test_mobile_join_stores_preferences_and_audio_only_limits_livekit_sources(client):
    token = admin_token(client)
    created = create_meeting(client, token, waiting=False)
    invite = created["invitation"]["token"]
    joined = client.post(
        f"/api/v1/meetings/invitations/{invite}/join",
        json={
            "displayName": "Mobile User",
            "cameraEnabled": False,
            "microphoneEnabled": True,
            "lowBandwidthMode": True,
            "audioOnlyMode": True,
            "preferredLayout": "mobile",
            "mobileClient": True,
            "networkType": "4g",
            "deviceInfo": {"userAgent": "Mobile Safari", "mobileClient": True, "networkType": "4g"},
        },
    )
    assert joined.status_code == 201, joined.json
    p = joined.json["participant"]
    assert p["lowBandwidthMode"] is True
    assert p["audioOnlyMode"] is True
    assert p["mobileClient"] is True
    assert p["preferredLayout"] == "mobile"
    assert p["networkType"] == "4g"
    claims = jwt.decode(joined.json["livekit"]["token"], options={"verify_signature": False})
    assert claims["video"]["canPublishSources"] == ["microphone"]


def test_participant_can_update_mobile_preferences_and_quality_report(client):
    token = admin_token(client)
    created = create_meeting(client, token, waiting=False)
    invite = created["invitation"]["token"]
    joined = client.post(f"/api/v1/meetings/invitations/{invite}/join", json={"displayName": "Updater"})
    ptoken = joined.json["participantToken"]
    update = client.patch(
        f"/api/v1/meetings/invitations/{invite}/preferences",
        headers={"Authorization": f"Bearer {ptoken}"},
        json={"lowBandwidthMode": True, "audioOnlyMode": True, "preferredLayout": "speaker", "networkType": "3g", "deviceInfo": {"screen": "390x844"}},
    )
    assert update.status_code == 200, update.json
    assert update.json["participant"]["preferredLayout"] == "speaker"
    assert update.json["participant"]["deviceInfo"]["screen"] == "390x844"
    claims = jwt.decode(update.json["livekit"]["token"], options={"verify_signature": False})
    assert claims["video"]["canPublishSources"] == ["microphone"]

    quality = client.post(
        f"/api/v1/meetings/invitations/{invite}/quality",
        headers={"Authorization": f"Bearer {ptoken}"},
        json={"online": True, "networkType": "3g", "downlink": 0.8, "rtt": 300, "saveData": True},
    )
    assert quality.status_code == 200
    assert quality.json["participant"]["lastQualityReport"]["rtt"] == 300
    assert quality.json["participant"]["networkType"] == "3g"


def test_admin_can_update_participant_mobile_preferences(client):
    token = admin_token(client)
    created = create_meeting(client, token, waiting=False)
    meeting_id = created["meeting"]["id"]
    invite = created["invitation"]["token"]
    joined = client.post(f"/api/v1/meetings/invitations/{invite}/join", json={"displayName": "Admin Managed"})
    participant_id = joined.json["participant"]["id"]
    update = client.patch(
        f"/api/v1/meetings/{meeting_id}/participants/{participant_id}/preferences",
        headers={"Authorization": f"Bearer {token}"},
        json={"audioOnlyMode": True, "preferredLayout": "mobile", "mobileClient": True},
    )
    assert update.status_code == 200, update.json
    assert update.json["participant"]["audioOnlyMode"] is True
    assert update.json["participant"]["cameraEnabled"] is False
    assert update.json["participant"]["mobileClient"] is True


def test_mobile_preference_validation(client):
    token = admin_token(client)
    created = create_meeting(client, token, waiting=False)
    invite = created["invitation"]["token"]
    joined = client.post(f"/api/v1/meetings/invitations/{invite}/join", json={"displayName": "Bad Pref"})
    ptoken = joined.json["participantToken"]
    bad = client.patch(f"/api/v1/meetings/invitations/{invite}/preferences", headers={"Authorization": f"Bearer {ptoken}"}, json={"preferredLayout": "invalid"})
    assert bad.status_code == 400
    assert bad.json["error"]["code"] == "validation_error"
