from datetime import datetime, timedelta, timezone

import pytest

from app import create_app, seed_database
from app.config import TestingConfig
from app.extensions import db
from app.models import Meeting, MeetingInvitation


@pytest.fixture()
def app():
    app = create_app(TestingConfig)
    app.config["PUBLIC_APP_URL"] = "http://localhost:3000"
    with app.app_context():
        db.drop_all()
        db.create_all()
        seed_database(app)
    yield app


@pytest.fixture()
def client(app):
    return app.test_client()


def admin_token(client):
    login = client.post("/api/v1/auth/login", json={"email": "web@defensiqsecurity.com", "password": "Nullbyte69"})
    assert login.status_code == 200, login.json
    changed = client.post(
        "/api/v1/auth/change-password",
        headers={"Authorization": f"Bearer {login.json['accessToken']}"},
        json={"currentPassword": "Nullbyte69", "newPassword": "NewStrong123", "confirmPassword": "NewStrong123"},
    )
    assert changed.status_code == 200, changed.json
    return changed.json["accessToken"]


def meeting_payload(**overrides):
    start = datetime.now(timezone.utc) + timedelta(days=1)
    end = start + timedelta(hours=1)
    data = {
        "title": "Incident Response Sync",
        "description": "Daily internal response coordination.",
        "scheduledStartAt": start.isoformat(),
        "scheduledEndAt": end.isoformat(),
        "timezone": "Asia/Qatar",
        "password": "Secure123",
        "linkExpiresAt": (end + timedelta(hours=1)).isoformat(),
    }
    data.update(overrides)
    return data


def test_create_meeting_generates_id_password_hash_and_secure_invitation(client, app):
    token = admin_token(client)
    response = client.post("/api/v1/meetings", headers={"Authorization": f"Bearer {token}"}, json=meeting_payload())
    assert response.status_code == 201, response.json
    meeting = response.json["meeting"]
    invitation = response.json["invitation"]
    assert meeting["meetingId"].count("-") == 2
    assert meeting["hasPassword"] is True
    assert invitation["url"].startswith("http://localhost:3000/invite/")
    assert len(invitation["token"]) >= 32

    with app.app_context():
        row = Meeting.query.filter_by(id=meeting["id"]).first()
        assert row is not None
        assert row.password_hash != "Secure123"
        assert row.check_password("Secure123") is True
        assert MeetingInvitation.query.filter_by(token=invitation["token"]).first() is not None


def test_create_meeting_validation_errors(client):
    token = admin_token(client)
    bad_title = client.post("/api/v1/meetings", headers={"Authorization": f"Bearer {token}"}, json=meeting_payload(title="x"))
    assert bad_title.status_code == 400
    assert bad_title.json["error"]["code"] == "validation_error"

    start = datetime.now(timezone.utc) + timedelta(days=1)
    bad_time = client.post("/api/v1/meetings", headers={"Authorization": f"Bearer {token}"}, json=meeting_payload(scheduledStartAt=start.isoformat(), scheduledEndAt=(start - timedelta(minutes=1)).isoformat()))
    assert bad_time.status_code == 400

    bad_password = client.post("/api/v1/meetings", headers={"Authorization": f"Bearer {token}"}, json=meeting_payload(password="123"))
    assert bad_password.status_code == 400


def test_list_get_update_and_regenerate_link(client):
    token = admin_token(client)
    created = client.post("/api/v1/meetings", headers={"Authorization": f"Bearer {token}"}, json=meeting_payload()).json
    meeting_id = created["meeting"]["meetingId"]
    old_token = created["invitation"]["token"]

    listing = client.get("/api/v1/meetings", headers={"Authorization": f"Bearer {token}"})
    assert listing.status_code == 200
    assert listing.json["total"] == 1

    fetched = client.get(f"/api/v1/meetings/{meeting_id}", headers={"Authorization": f"Bearer {token}"})
    assert fetched.status_code == 200
    assert fetched.json["meeting"]["meetingId"] == meeting_id

    updated = client.patch(f"/api/v1/meetings/{meeting_id}", headers={"Authorization": f"Bearer {token}"}, json={"title": "Updated Sync", "password": "NewSecure123"})
    assert updated.status_code == 200
    assert updated.json["meeting"]["title"] == "Updated Sync"

    regenerated = client.post(f"/api/v1/meetings/{meeting_id}/regenerate-link", headers={"Authorization": f"Bearer {token}"})
    assert regenerated.status_code == 200
    assert regenerated.json["invitation"]["token"] != old_token

    old_public = client.get(f"/api/v1/meetings/invitations/{old_token}")
    assert old_public.status_code == 404
    new_public = client.get(f"/api/v1/meetings/invitations/{regenerated.json['invitation']['token']}")
    assert new_public.status_code == 200


def test_public_invitation_and_password_verification(client):
    token = admin_token(client)
    created = client.post("/api/v1/meetings", headers={"Authorization": f"Bearer {token}"}, json=meeting_payload()).json
    invitation_token = created["invitation"]["token"]

    public = client.get(f"/api/v1/meetings/invitations/{invitation_token}")
    assert public.status_code == 200
    assert public.json["meeting"]["title"] == "Incident Response Sync"
    assert public.json["meeting"]["hasPassword"] is True
    assert "invitationToken" not in public.json["meeting"]

    by_code = client.get(f"/api/v1/meetings/code/{created['meeting']['meetingId']}")
    assert by_code.status_code == 200
    assert by_code.json["invitation"]["url"].endswith(invitation_token)

    wrong = client.post(f"/api/v1/meetings/invitations/{invitation_token}/verify-password", json={"password": "bad"})
    assert wrong.status_code == 401
    correct = client.post(f"/api/v1/meetings/invitations/{invitation_token}/verify-password", json={"password": "Secure123"})
    assert correct.status_code == 200
    assert correct.json["valid"] is True


def test_meeting_creation_requires_authenticated_admin_with_changed_password(client):
    unauth = client.post("/api/v1/meetings", json=meeting_payload())
    assert unauth.status_code == 401

    login = client.post("/api/v1/auth/login", json={"email": "web@defensiqsecurity.com", "password": "Nullbyte69"}).json
    blocked = client.post("/api/v1/meetings", headers={"Authorization": f"Bearer {login['accessToken']}"}, json=meeting_payload())
    assert blocked.status_code == 403
    assert blocked.json["error"]["code"] == "password_change_required"


def test_expired_invitation_is_rejected(client):
    token = admin_token(client)
    start = datetime.now(timezone.utc) + timedelta(days=1)
    end = start + timedelta(hours=1)
    created = client.post(
        "/api/v1/meetings",
        headers={"Authorization": f"Bearer {token}"},
        json=meeting_payload(scheduledStartAt=start.isoformat(), scheduledEndAt=end.isoformat(), linkExpiresAt=None),
    ).json
    invitation_token = created["invitation"]["token"]
    with client.application.app_context():
        row = Meeting.query.filter_by(id=created["meeting"]["id"]).first()
        row.link_expires_at = datetime.now(timezone.utc) - timedelta(minutes=1)
        db.session.commit()
    expired = client.get(f"/api/v1/meetings/invitations/{invitation_token}")
    assert expired.status_code == 410


def test_delete_past_meeting_and_reject_running_delete(client, app):
    token = admin_token(client)
    created = client.post("/api/v1/meetings", headers={"Authorization": f"Bearer {token}"}, json=meeting_payload()).json
    meeting_id = created["meeting"]["id"]
    with app.app_context():
      row = db.session.get(Meeting, meeting_id)
      row.status = "completed"
      row.ended_at = datetime.now(timezone.utc)
      db.session.commit()

    deleted = client.delete(f"/api/v1/meetings/{meeting_id}", headers={"Authorization": f"Bearer {token}"})
    assert deleted.status_code == 200, deleted.json
    assert deleted.json["deleted"] is True
    assert db.session.get(Meeting, meeting_id) is None

    running = client.post("/api/v1/meetings", headers={"Authorization": f"Bearer {token}"}, json=meeting_payload(title="Running Delete Blocked")).json
    running_id = running["meeting"]["id"]
    host = client.post(f"/api/v1/meetings/{running_id}/host-token", headers={"Authorization": f"Bearer {token}"})
    assert host.status_code == 200
    blocked = client.delete(f"/api/v1/meetings/{running_id}", headers={"Authorization": f"Bearer {token}"})
    assert blocked.status_code == 409
    assert blocked.json["error"]["code"] == "meeting_running"


def test_advanced_create_meeting_persists_settings_drafts_conflicts_and_custom_id(client):
    token = admin_token(client)
    start = datetime.now(timezone.utc) + timedelta(days=2)
    end = start + timedelta(hours=2)
    draft_payload = {"title": "Enterprise Strategy Draft", "scheduledStartAt": start.isoformat(), "scheduledEndAt": end.isoformat(), "timezone": "UTC"}
    draft = client.post("/api/v1/meetings/drafts", headers={"Authorization": f"Bearer {token}"}, json={"payload": draft_payload})
    assert draft.status_code == 201, draft.json
    draft_id = draft.json["draft"]["id"]
    patched = client.patch(f"/api/v1/meetings/drafts/{draft_id}", headers={"Authorization": f"Bearer {token}"}, json={"payload": {**draft_payload, "title": "Updated Enterprise Draft"}})
    assert patched.status_code == 200
    assert patched.json["draft"]["title"] == "Updated Enterprise Draft"

    payload = meeting_payload(
        title="Enterprise Strategy",
        scheduledStartAt=start.isoformat(),
        scheduledEndAt=end.isoformat(),
            password="AutoPass123",
            linkExpiresAt=(end + timedelta(hours=1)).isoformat(),
        )
    payload.update({
        "meetingIdMode": "custom",
        "customMeetingId": "strategy-2026",
        "maxParticipants": 250,
        "allowChat": True,
        "allowWhiteboard": True,
        "screenSharePolicy": "cohosts",
        "advancedSettings": {
            "basic": {"meetingType": "training", "category": "Leadership", "tags": ["q2", "strategy"], "color": "#2563eb"},
            "recording": {"permission": "host_cohost", "mode": "presentation", "storage": "server", "retentionDays": 90, "autoRecord": True},
            "screenSharing": {"whoCanShare": "cohosts", "participantRequests": True, "hostApprovalRequired": True},
            "whiteboard": {"enabled": True, "whoCanUse": "cohosts"},
            "chat": {"whoCanChat": "everyone", "maxUploadMb": 25},
            "notifications": {"emailInvitations": False, "calendarInvitations": True},
            "invitees": {"emails": ["person@example.com"]},
        },
    })
    created = client.post("/api/v1/meetings", headers={"Authorization": f"Bearer {token}"}, json=payload)
    assert created.status_code == 201, created.json
    meeting = created.json["meeting"]
    assert meeting["meetingId"] == "strategy-2026"
    assert meeting["maxParticipants"] == 250
    assert meeting["screenSharePolicy"] == "cohosts"
    assert meeting["advancedSettings"]["basic"]["meetingType"] == "training"
    assert meeting["advancedSettings"]["recording"]["autoRecord"] is True

    check = client.get("/api/v1/meetings/check-id/strategy-2026", headers={"Authorization": f"Bearer {token}"})
    assert check.status_code == 200
    assert check.json["available"] is False

    conflict = client.post("/api/v1/meetings/conflicts", headers={"Authorization": f"Bearer {token}"}, json={"scheduledStartAt": (start + timedelta(minutes=15)).isoformat(), "scheduledEndAt": (end - timedelta(minutes=15)).isoformat()})
    assert conflict.status_code == 200
    assert conflict.json["hasConflicts"] is True
    assert conflict.json["total"] >= 1

    deleted = client.delete(f"/api/v1/meetings/drafts/{draft_id}", headers={"Authorization": f"Bearer {token}"})
    assert deleted.status_code == 200


def test_personal_meeting_id_mode_updates_reusable_personal_room(client):
    token = admin_token(client)
    first = client.post("/api/v1/meetings", headers={"Authorization": f"Bearer {token}"}, json=meeting_payload(title="Personal Strategy", meetingIdMode="personal", linkExpiresAt=None))
    assert first.status_code == 201, first.json
    assert first.json["meeting"]["personalMeeting"] is True
    meeting_id = first.json["meeting"]["meetingId"]
    room_id = first.json["meeting"]["id"]
    second = client.post("/api/v1/meetings", headers={"Authorization": f"Bearer {token}"}, json=meeting_payload(title="Personal Strategy Updated", meetingIdMode="personal", linkExpiresAt=None))
    assert second.status_code == 201, second.json
    assert second.json["meeting"]["id"] == room_id
    assert second.json["meeting"]["meetingId"] == meeting_id
    assert second.json["meeting"]["title"] == "Personal Strategy Updated"
