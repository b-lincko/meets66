'use client';

import { useRoomContext } from '@livekit/components-react';
import { CheckCircle2, ChevronDown, CirclePause, CirclePlay, Radio, Settings2, Square, XCircle } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Track } from 'livekit-client';
import { toast } from 'sonner';
import { Meeting, Participant, Recording, api } from '@/lib/api';

type RecordingMode = 'presentation' | 'screen_only' | 'camera_only' | 'gallery';
type PipPosition = 'top_left' | 'top_right' | 'bottom_left' | 'bottom_right';
type PipSize = 'small' | 'medium' | 'large';
type ResolutionKey = '720p' | '1080p' | '4k';
type ShareSource = 'screen' | 'window' | 'browser';

type RecordingSettings = {
  mode: RecordingMode;
  pipPosition: PipPosition;
  pipSize: PipSize;
  resolution: ResolutionKey;
  presenterCamera: boolean;
  watermark: boolean;
  directSource: boolean;
};

type VideoEntry = { video: HTMLVideoElement; track: MediaStreamTrack };
type AudioEntry = { source: MediaStreamAudioSourceNode; track: MediaStreamTrack };

const RESOLUTIONS: Record<ResolutionKey, { width: number; height: number; label: string }> = {
  '720p': { width: 1280, height: 720, label: '720p HD' },
  '1080p': { width: 1920, height: 1080, label: '1080p Full HD' },
  '4k': { width: 3840, height: 2160, label: '4K Ultra HD' },
};

const MODE_LABELS: Record<RecordingMode, string> = {
  presentation: 'Presenter + Screen',
  screen_only: 'Screen Only',
  camera_only: 'Presenter Camera Only',
  gallery: 'Gallery View',
};

function defaultRecordingResolution(): ResolutionKey {
  if (typeof navigator !== 'undefined' && (/Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent) || (navigator.hardwareConcurrency || 8) <= 4)) return '720p';
  return '1080p';
}

function preferredRecordingMimeType() {
  const candidates = [
    'video/mp4;codecs=avc1.42E01E,mp4a.40.2',
    'video/mp4;codecs=h264,aac',
    'video/mp4',
    'video/webm;codecs=vp9,opus',
    'video/webm;codecs=vp8,opus',
    'video/webm',
  ];
  return candidates.find((candidate) => typeof MediaRecorder !== 'undefined' && MediaRecorder.isTypeSupported(candidate)) || 'video/webm';
}

export function RecordingControls({ meeting, participant, participantToken, inviteToken, onRecordingChange }: { meeting: Meeting; participant: Participant; participantToken?: string; inviteToken?: string; onRecordingChange?: (recording: boolean) => void }) {
  const room = useRoomContext();
  const [recording, setRecording] = useState<Recording | null>(null);
  const [busy, setBusy] = useState(false);
  const [paused, setPaused] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [portalReady, setPortalReady] = useState(false);
  const [presenterName, setPresenterName] = useState('Presenter');
  const [settings, setSettings] = useState<RecordingSettings>({ mode: 'screen_only', pipPosition: 'bottom_right', pipSize: 'medium', resolution: defaultRecordingResolution(), presenterCamera: false, watermark: false, directSource: true });
  const settingsRef = useRef(settings);
  const presenterNameRef = useRef('Presenter');
  const displaySurfaceRef = useRef<'screen' | 'window' | 'browser' | 'none'>('none');
  const lastScreenTrackIdRef = useRef('');
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<BlobPart[]>([]);
  const cleanupRef = useRef<(() => void)[]>([]);
  const videoCacheRef = useRef<Map<string, VideoEntry>>(new Map());
  const audioSourcesRef = useRef<Map<string, AudioEntry>>(new Map());
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const activeScreenVideoRef = useRef<HTMLVideoElement | null>(null);
  const activeCameraVideoRef = useRef<HTMLVideoElement | null>(null);
  const startedAtRef = useRef<number>(0);
  const pausedStartedAtRef = useRef<number | null>(null);
  const pausedMsRef = useRef<number>(0);

  useEffect(() => { settingsRef.current = settings; }, [settings]);
  useEffect(() => { setPortalReady(true); }, []);

  function allRoomParticipants() {
    return [room.localParticipant, ...Array.from(room.remoteParticipants.values())] as any[];
  }

  function publicationFor(participant: any, source: Track.Source) {
    const direct = participant?.getTrackPublication?.(source);
    if (direct) return direct;
    const publications = participant?.trackPublications ? Array.from(participant.trackPublications.values()) as any[] : [];
    return publications.find((publication) => publication.source === source);
  }

  function mediaTrackFor(participant: any, source: Track.Source): MediaStreamTrack | undefined {
    const publication = publicationFor(participant, source);
    return (publication?.track as any)?.mediaStreamTrack as MediaStreamTrack | undefined;
  }

  function participantByIdentity(identity?: string | null) {
    if (!identity) return undefined;
    if (room.localParticipant.identity === identity) return room.localParticipant as any;
    return room.remoteParticipants.get(identity) as any;
  }

  function currentPresenter() {
    const active = participantByIdentity(meeting.activeScreenShareParticipantId);
    const activeScreen = active ? mediaTrackFor(active, Track.Source.ScreenShare) : undefined;
    if (active && activeScreen && activeScreen.readyState === 'live') return active;
    const sharing = allRoomParticipants().find((participant) => {
      const track = mediaTrackFor(participant, Track.Source.ScreenShare);
      return track && track.readyState === 'live';
    });
    if (sharing) return sharing;
    return active || room.localParticipant;
  }

  function trackKey(track: MediaStreamTrack) {
    return `${track.kind}:${track.id}`;
  }

  function detectDisplaySurface(track?: MediaStreamTrack): 'screen' | 'window' | 'browser' | 'none' {
    const surface = String(track?.getSettings?.().displaySurface || '').toLowerCase();
    if (surface === 'browser') return 'browser';
    if (surface === 'window' || surface === 'application') return 'window';
    if (track && track.readyState === 'live') return 'screen';
    return 'none';
  }

  function sourceLabel(source: string) {
    if (source === 'screen') return 'Entire screen / desktop';
    if (source === 'window') return 'Application window';
    if (source === 'browser') return 'Browser tab';
    return 'No active shared source';
  }

  function currentLocalScreenTrack() {
    return mediaTrackFor(room.localParticipant, Track.Source.ScreenShare);
  }

  async function waitForLocalScreenTrack(timeoutMs = 6000) {
    const started = Date.now();
    let track = currentLocalScreenTrack();
    while ((!track || track.readyState !== 'live') && Date.now() - started < timeoutMs) {
      await new Promise((resolve) => window.setTimeout(resolve, 100));
      track = currentLocalScreenTrack();
    }
    return track;
  }

  async function reportScreenShareState(track: MediaStreamTrack) {
    const detected = detectDisplaySurface(track);
    const source: ShareSource = detected === 'none' ? 'screen' : detected;
    const body = JSON.stringify({ sharing: true, paused: false, source });
    if (participantToken && inviteToken) {
      await api(`/meetings/invitations/${inviteToken}/screen-share`, { method: 'POST', auth: false, headers: { Authorization: `Bearer ${participantToken}` }, body }).catch(() => undefined);
    } else {
      await api(`/meetings/${meeting.id}/participants/${participant.id}/screen-share`, { method: 'POST', body }).catch(() => undefined);
    }
  }

  async function ensureScreenShareForSmoothRecording() {
    if (!settingsRef.current.directSource || !['presentation', 'screen_only'].includes(settingsRef.current.mode)) return;
    const existing = currentLocalScreenTrack();
    if (existing && existing.readyState === 'live') return;
    toast.info('Choose Entire Screen for the smoothest recording. Window and Tab choices intentionally record only that selected source.');
    await room.localParticipant.setScreenShareEnabled(true, { audio: true, video: { frameRate: { ideal: 24, max: 30 } } as any, surfaceSwitching: 'include', systemAudio: 'include', selfBrowserSurface: 'include', contentHint: 'detail' });
    const track = await waitForLocalScreenTrack();
    if (!track || track.readyState !== 'live') throw new Error('Screen sharing was not started. Select a screen, window, or tab to record.');
    logRecordingTrackDiagnostics('smooth recording selected shared source', track);
    await reportScreenShareState(track);
  }

  function logRecordingTrackDiagnostics(label: string, track?: MediaStreamTrack) {
    if (!track) {
      console.info('[Defensiq recording]', label, { present: false });
      return;
    }
    console.info('[Defensiq recording]', label, {
      trackId: track.id,
      kind: track.kind,
      label: track.label,
      readyState: track.readyState,
      muted: track.muted,
      settings: track.getSettings?.(),
      constraints: track.getConstraints?.(),
      displaySurface: (track.getSettings?.() as any)?.displaySurface || 'unknown',
    });
  }

  function attachTrackDiagnostics(track: MediaStreamTrack | undefined, label: string) {
    if (!track) return;
    const onMute = () => logRecordingTrackDiagnostics(`${label}: mute`, track);
    const onUnmute = () => logRecordingTrackDiagnostics(`${label}: unmute`, track);
    const onEnded = () => logRecordingTrackDiagnostics(`${label}: ended`, track);
    track.addEventListener('mute', onMute);
    track.addEventListener('unmute', onUnmute);
    track.addEventListener('ended', onEnded);
    cleanupRef.current.push(() => {
      track.removeEventListener('mute', onMute);
      track.removeEventListener('unmute', onUnmute);
      track.removeEventListener('ended', onEnded);
    });
  }

  function ensureVideo(track?: MediaStreamTrack) {
    if (!track || track.readyState !== 'live') return undefined;
    const key = trackKey(track);
    const cached = videoCacheRef.current.get(key);
    if (cached && cached.track === track) return cached.video;
    const video = document.createElement('video');
    video.srcObject = new MediaStream([track]);
    video.muted = true;
    video.playsInline = true;
    video.autoplay = true;
    video.play().catch(() => undefined);
    videoCacheRef.current.set(key, { video, track });
    return video;
  }

  function drawContain(ctx: CanvasRenderingContext2D, video: HTMLVideoElement, x: number, y: number, w: number, h: number) {
    const vw = video.videoWidth || w;
    const vh = video.videoHeight || h;
    const scale = Math.min(w / vw, h / vh);
    const dw = vw * scale;
    const dh = vh * scale;
    ctx.drawImage(video, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh);
  }

  function roundedRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, radius: number) {
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + w - radius, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
    ctx.lineTo(x + w, y + h - radius);
    ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h);
    ctx.lineTo(x + radius, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - radius);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.closePath();
  }

  function drawPlaceholder(ctx: CanvasRenderingContext2D, width: number, height: number, label: string) {
    ctx.save();
    ctx.fillStyle = '#020617';
    ctx.fillRect(0, 0, width, height);
    ctx.strokeStyle = 'rgba(148,163,184,0.35)';
    ctx.lineWidth = Math.max(2, width / 700);
    roundedRect(ctx, width * 0.08, height * 0.18, width * 0.84, height * 0.64, 28);
    ctx.stroke();
    ctx.fillStyle = '#e2e8f0';
    ctx.textAlign = 'center';
    ctx.font = `700 ${Math.max(24, Math.round(width / 45))}px system-ui, sans-serif`;
    ctx.fillText(label, width / 2, height / 2);
    ctx.restore();
  }

  function drawPip(ctx: CanvasRenderingContext2D, cameraVideo: HTMLVideoElement, width: number, height: number, position: PipPosition, size: PipSize, label: string) {
    const ratio = size === 'small' ? 0.18 : size === 'large' ? 0.30 : 0.24;
    const pipW = Math.round(width * ratio);
    const pipH = Math.round(pipW * 9 / 16);
    const pad = Math.round(width * 0.025);
    const x = position.endsWith('right') ? width - pipW - pad : pad;
    const y = position.startsWith('bottom') ? height - pipH - pad : pad;
    ctx.save();
    ctx.shadowColor = 'rgba(0,0,0,0.55)';
    ctx.shadowBlur = Math.round(width * 0.012);
    ctx.shadowOffsetY = Math.round(width * 0.004);
    roundedRect(ctx, x, y, pipW, pipH, Math.round(pipW * 0.06));
    ctx.fillStyle = '#020617';
    ctx.fill();
    ctx.clip();
    drawContain(ctx, cameraVideo, x, y, pipW, pipH);
    ctx.restore();
    ctx.save();
    ctx.strokeStyle = 'rgba(255,255,255,0.85)';
    ctx.lineWidth = Math.max(2, Math.round(width * 0.0018));
    roundedRect(ctx, x, y, pipW, pipH, Math.round(pipW * 0.06));
    ctx.stroke();
    ctx.fillStyle = 'rgba(2,6,23,0.72)';
    roundedRect(ctx, x + 10, y + pipH - Math.round(pipH * 0.22), Math.min(pipW - 20, Math.round(width * 0.18)), Math.round(pipH * 0.16), 10);
    ctx.fill();
    ctx.fillStyle = 'white';
    ctx.font = `700 ${Math.max(12, Math.round(width / 95))}px system-ui, sans-serif`;
    ctx.textAlign = 'left';
    ctx.fillText(label, x + 20, y + pipH - Math.round(pipH * 0.10));
    ctx.restore();
  }

  function drawWatermark(ctx: CanvasRenderingContext2D, width: number, height: number) {
    ctx.save();
    ctx.globalAlpha = 0.35;
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'right';
    ctx.font = `700 ${Math.max(14, Math.round(width / 85))}px system-ui, sans-serif`;
    ctx.fillText('Defensiq Security', width - Math.round(width * 0.025), height - Math.round(width * 0.018));
    ctx.restore();
  }

  function drawGallery(ctx: CanvasRenderingContext2D, width: number, height: number) {
    const activeSpeakerIds = new Set(room.activeSpeakers.map((speaker: any) => speaker.identity));
    const cameras = allRoomParticipants().map((participant) => ({ participant, track: mediaTrackFor(participant, Track.Source.Camera), active: activeSpeakerIds.has(participant.identity) })).filter((item) => item.track && item.track.readyState === 'live').sort((a, b) => Number(b.active) - Number(a.active)).slice(0, 16);
    if (!cameras.length) return drawPlaceholder(ctx, width, height, 'No cameras available');
    const cols = Math.ceil(Math.sqrt(cameras.length));
    const rows = Math.ceil(cameras.length / cols);
    const gap = Math.round(width * 0.012);
    const cellW = (width - gap * (cols + 1)) / cols;
    const cellH = (height - gap * (rows + 1)) / rows;
    cameras.forEach((item, index) => {
      const col = index % cols;
      const row = Math.floor(index / cols);
      const x = gap + col * (cellW + gap);
      const y = gap + row * (cellH + gap);
      const video = ensureVideo(item.track);
      ctx.save();
      roundedRect(ctx, x, y, cellW, cellH, 18);
      ctx.fillStyle = '#0f172a';
      ctx.fill();
      ctx.clip();
      if (video && video.readyState >= 2) drawContain(ctx, video, x, y, cellW, cellH);
      ctx.restore();
      ctx.fillStyle = 'rgba(2,6,23,0.72)';
      roundedRect(ctx, x + 10, y + cellH - 38, Math.min(cellW - 20, 220), 28, 10);
      ctx.fill();
      ctx.fillStyle = 'white';
      ctx.font = '700 14px system-ui, sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText(item.participant.name || item.participant.identity || 'Participant', x + 20, y + cellH - 19);
    });
  }

  function renderFrame(ctx: CanvasRenderingContext2D, width: number, height: number) {
    const current = settingsRef.current;
    const presenter = currentPresenter() as any;
    const name = presenter?.name || (presenter?.identity === room.localParticipant.identity ? 'Host' : presenter?.identity) || 'Presenter';
    if (presenterNameRef.current !== name) {
      presenterNameRef.current = name;
      setPresenterName(name);
    }
    const screenTrack = mediaTrackFor(presenter, Track.Source.ScreenShare);
    displaySurfaceRef.current = detectDisplaySurface(screenTrack);
    if (screenTrack && screenTrack.id !== lastScreenTrackIdRef.current) {
      lastScreenTrackIdRef.current = screenTrack.id;
      logRecordingTrackDiagnostics('active screen source changed', screenTrack);
      attachTrackDiagnostics(screenTrack, 'screen track');
    }
    const cameraTrack = mediaTrackFor(presenter, Track.Source.Camera);
    const screenVideo = ensureVideo(screenTrack);
    const cameraVideo = ensureVideo(cameraTrack);
    activeScreenVideoRef.current = screenVideo || null;
    activeCameraVideoRef.current = cameraVideo || null;

    ctx.fillStyle = '#020617';
    ctx.fillRect(0, 0, width, height);

    if (current.mode === 'gallery') {
      drawGallery(ctx, width, height);
    } else if (current.mode === 'camera_only') {
      if (cameraVideo && cameraVideo.readyState >= 2) drawContain(ctx, cameraVideo, 0, 0, width, height);
      else drawPlaceholder(ctx, width, height, 'Presenter camera unavailable');
    } else {
      if (screenVideo && screenVideo.readyState >= 2) drawContain(ctx, screenVideo, 0, 0, width, height);
      else drawPlaceholder(ctx, width, height, 'No shared presentation');
      if (current.mode === 'presentation' && current.presenterCamera && cameraVideo && cameraVideo.readyState >= 2) {
        drawPip(ctx, cameraVideo, width, height, current.pipPosition, current.pipSize, name);
      }
    }
    if (current.watermark) drawWatermark(ctx, width, height);
  }

  function wantedAudioTracks() {
    const presenter = currentPresenter() as any;
    const tracks: MediaStreamTrack[] = [];
    for (const participant of allRoomParticipants()) {
      const mic = mediaTrackFor(participant, Track.Source.Microphone);
      if (mic && mic.readyState === 'live' && !tracks.includes(mic)) tracks.push(mic);
    }
    const screenAudio = mediaTrackFor(presenter, Track.Source.ScreenShareAudio as Track.Source);
    if (screenAudio && screenAudio.readyState === 'live' && !tracks.includes(screenAudio)) tracks.push(screenAudio);
    return tracks;
  }

  function syncAudioMixer(audioContext: AudioContext, destination: MediaStreamAudioDestinationNode) {
    const wanted = new Set(wantedAudioTracks().map(trackKey));
    for (const [key, entry] of Array.from(audioSourcesRef.current.entries())) {
      if (!wanted.has(key) || entry.track.readyState !== 'live') {
        entry.source.disconnect();
        audioSourcesRef.current.delete(key);
      }
    }
    for (const track of wantedAudioTracks()) {
      const key = trackKey(track);
      if (!audioSourcesRef.current.has(key)) {
        const source = audioContext.createMediaStreamSource(new MediaStream([track]));
        source.connect(destination);
        audioSourcesRef.current.set(key, { source, track });
      }
    }
  }

  async function buildRecordingStream() {
    cleanupRecordingResources();
    const initialPresenter = currentPresenter() as any;
    const initialScreenTrack = mediaTrackFor(initialPresenter, Track.Source.ScreenShare);
    const initialSource = detectDisplaySurface(initialScreenTrack);
    displaySurfaceRef.current = initialSource;

    if (initialScreenTrack) {
      logRecordingTrackDiagnostics('initial shared display track', initialScreenTrack);
      attachTrackDiagnostics(initialScreenTrack, 'initial screen track');
    }

    // For Screen Only mode, record the exact original display MediaStreamTrack directly.
    // This is the most faithful pipeline for desktop/window/tab capture:
    // Display MediaStreamTrack -> MediaRecorder. No canvas, no second capture.
    if (settingsRef.current.directSource && initialScreenTrack && ['presentation', 'screen_only'].includes(settingsRef.current.mode) && !settingsRef.current.watermark) {
      if (settingsRef.current.presenterCamera) {
        toast.info('Smooth desktop recording uses the original shared screen track directly, so PiP overlay is disabled for this recording.');
      }
      const output = new MediaStream([initialScreenTrack]);
      const audioContext = new AudioContext();
      const destination = audioContext.createMediaStreamDestination();
      syncAudioMixer(audioContext, destination);
      const audioInterval = window.setInterval(() => syncAudioMixer(audioContext, destination), 1000);
      for (const track of destination.stream.getAudioTracks()) output.addTrack(track);
      cleanupRef.current.push(() => {
        window.clearInterval(audioInterval);
        for (const entry of Array.from(audioSourcesRef.current.values())) entry.source.disconnect();
        audioSourcesRef.current.clear();
        destination.stream.getAudioTracks().forEach((track) => track.stop());
        audioContext.close().catch(() => undefined);
      });
      console.info('[Defensiq recording] using direct original display stream', { trackId: initialScreenTrack.id, displaySurface: initialSource, settings: initialScreenTrack.getSettings?.() });
      return output;
    }

    const size = RESOLUTIONS[settingsRef.current.resolution];
    const canvas = document.createElement('canvas');
    canvas.width = size.width;
    canvas.height = size.height;
    canvasRef.current = canvas;
    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) throw new Error('Canvas recording is not supported in this browser.');

    if (settingsRef.current.mode !== 'camera_only' && settingsRef.current.mode !== 'gallery' && !initialScreenTrack) {
      toast.info('Recording started without an active screen share. It will record a clean waiting canvas and automatically switch to the exact source you choose when you start sharing.');
    }

    const targetFps = settingsRef.current.resolution === '4k' ? 15 : settingsRef.current.mode === 'gallery' ? 20 : 24;
    let canvasStream: MediaStream;
    try {
      canvasStream = canvas.captureStream(0);
    } catch {
      canvasStream = canvas.captureStream(targetFps);
    }
    const canvasTrack = canvasStream.getVideoTracks()[0] as MediaStreamTrack & { requestFrame?: () => void };
    const render = () => {
      renderFrame(ctx, size.width, size.height);
      canvasTrack.requestFrame?.();
    };
    render();

    const frameInterval = Math.max(33, Math.round(1000 / targetFps));
    const renderInterval = window.setInterval(render, frameInterval);

    const boundVideos = new WeakSet<HTMLVideoElement>();
    let stopped = false;
    const bindVideoFramePump = (video?: HTMLVideoElement | null) => {
      const requestFrameCallback = video?.requestVideoFrameCallback?.bind(video);
      if (!video || !requestFrameCallback || boundVideos.has(video)) return;
      boundVideos.add(video);
      const pump = () => {
        if (stopped) return;
        render();
        video.requestVideoFrameCallback?.(pump);
      };
      requestFrameCallback(pump);
    };
    bindVideoFramePump(activeScreenVideoRef.current);
    bindVideoFramePump(activeCameraVideoRef.current);
    const bindInterval = window.setInterval(() => {
      bindVideoFramePump(activeScreenVideoRef.current);
      bindVideoFramePump(activeCameraVideoRef.current);
    }, 750);

    const output = new MediaStream(canvasStream.getVideoTracks());
    const audioContext = new AudioContext();
    const destination = audioContext.createMediaStreamDestination();
    syncAudioMixer(audioContext, destination);
    const audioInterval = window.setInterval(() => syncAudioMixer(audioContext, destination), 1000);
    for (const track of destination.stream.getAudioTracks()) output.addTrack(track);

    cleanupRef.current.push(() => {
      stopped = true;
      window.clearInterval(renderInterval);
      window.clearInterval(bindInterval);
      window.clearInterval(audioInterval);
      for (const entry of Array.from(audioSourcesRef.current.values())) entry.source.disconnect();
      audioSourcesRef.current.clear();
      videoCacheRef.current.forEach((entry) => entry.video.pause());
      videoCacheRef.current.clear();
      canvasStream.getTracks().forEach((track) => track.stop());
      output.getTracks().forEach((track) => track.stop());
      audioContext.close().catch(() => undefined);
      activeScreenVideoRef.current = null;
      activeCameraVideoRef.current = null;
      canvasRef.current = null;
    });

    return output;
  }

  function cleanupRecordingResources() {
    cleanupRef.current.forEach((cleanup) => cleanup());
    cleanupRef.current = [];
    for (const entry of Array.from(audioSourcesRef.current.values())) entry.source.disconnect();
    audioSourcesRef.current.clear();
    videoCacheRef.current.forEach((entry) => entry.video.pause());
    videoCacheRef.current.clear();
    lastScreenTrackIdRef.current = '';
  }

  async function start() {
    if (recording || busy) return;
    setBusy(true);
    try {
      await ensureScreenShareForSmoothRecording();
      const stream = await buildRecordingStream();
      logRecordingTrackDiagnostics('recording output video track', stream.getVideoTracks()[0]);
      const startPath = participantToken && inviteToken ? `/meetings/invitations/${inviteToken}/recordings/start` : `/meetings/${meeting.id}/recordings/start`;
      const initialSource = detectDisplaySurface(mediaTrackFor(currentPresenter(), Track.Source.ScreenShare));
      const startResponse = await api<{ recording: Recording }>(startPath, {
        method: 'POST',
        auth: !(participantToken && inviteToken),
        headers: participantToken && inviteToken ? { Authorization: `Bearer ${participantToken}` } : undefined,
        body: JSON.stringify({
          title: `${meeting.title} recording`,
          metadata: {
            presenterName: presenterNameRef.current,
            displaySurface: initialSource,
            displaySurfaceLabel: sourceLabel(initialSource),
            recordingMode: settings.mode,
            pipPosition: settings.pipPosition,
            pipSize: settings.pipSize,
            resolution: settings.resolution,
            presenterCameraEnabled: settings.presenterCamera,
            watermarkEnabled: settings.watermark,
            directSource: settings.directSource,
            output: settings.directSource ? 'direct_original_display_stream' : 'clean_canvas_presenter_and_screen_only',
          },
        }),
      });
      const mimeType = preferredRecordingMimeType();
      const clientEncodedMp4 = mimeType.includes('mp4');
      const recorder = new MediaRecorder(stream, { mimeType });
      console.info('[Defensiq recording] MediaRecorder created', { mimeType, state: recorder.state, source: displaySurfaceRef.current });
      chunksRef.current = [];
      startedAtRef.current = Date.now();
      pausedMsRef.current = 0;
      pausedStartedAtRef.current = null;
      recorderRef.current = recorder;
      setRecording(startResponse.recording);
      setPaused(false);
      onRecordingChange?.(true);
      recorder.ondataavailable = (event) => { if (event.data.size) chunksRef.current.push(event.data); };
      recorder.onpause = () => { console.info('[Defensiq recording] paused'); setPaused(true); };
      recorder.onresume = () => { console.info('[Defensiq recording] resumed'); setPaused(false); };
      recorder.onstop = async () => {
        console.info('[Defensiq recording] stopped', { chunks: chunksRef.current.length, source: displaySurfaceRef.current });
        const active = startResponse.recording;
        setBusy(true);
        try {
          if (pausedStartedAtRef.current) {
            pausedMsRef.current += Date.now() - pausedStartedAtRef.current;
            pausedStartedAtRef.current = null;
          }
          const blob = new Blob(chunksRef.current, { type: mimeType });
          const form = new FormData();
          const durationSeconds = Math.max(1, Math.round((Date.now() - startedAtRef.current - pausedMsRef.current) / 1000));
          form.append('durationSeconds', String(durationSeconds));
          form.append('metadata', JSON.stringify({
            presenterName: presenterNameRef.current,
            displaySurface: displaySurfaceRef.current,
            displaySurfaceLabel: sourceLabel(displaySurfaceRef.current),
            recordingMode: settingsRef.current.mode,
            pipPosition: settingsRef.current.pipPosition,
            pipSize: settingsRef.current.pipSize,
            resolution: settingsRef.current.resolution,
            presenterCameraEnabled: settingsRef.current.presenterCamera,
            watermarkEnabled: settingsRef.current.watermark,
            cleanPresentationRecording: true,
            directSource: settingsRef.current.directSource,
            clientEncodedMp4,
            targetFps: settingsRef.current.resolution === '4k' ? 15 : settingsRef.current.mode === 'gallery' ? 20 : 24,
            excludedUi: ['participants', 'chat', 'waiting_room', 'controls', 'top_bar', 'side_panels', 'menus', 'notifications', 'browser_ui'], 
          }));
          const thumbnail = canvasRef.current?.toDataURL('image/jpeg', 0.72);
          if (thumbnail) form.append('thumbnailDataUrl', thumbnail);
          form.append('file', blob, `${active.id}.${clientEncodedMp4 ? 'mp4' : 'webm'}`);
          const uploadPath = participantToken && inviteToken ? `/meetings/invitations/${inviteToken}/recordings/${active.id}/upload` : `/recordings/${active.id}/upload`;
          const uploaded = await api<{ recording: Recording }>(uploadPath, { method: 'POST', auth: !(participantToken && inviteToken), headers: participantToken && inviteToken ? { Authorization: `Bearer ${participantToken}` } : undefined, body: form });
          toast.success('Recording saved as MP4');
          setRecording(null);
          onRecordingChange?.(false);
          window.dispatchEvent(new CustomEvent('recording:ready', { detail: uploaded.recording }));
        } catch (err) {
          toast.error(err instanceof Error ? err.message : 'Recording upload failed');
          setRecording(null);
          onRecordingChange?.(false);
        } finally {
          cleanupRecordingResources();
          setBusy(false);
          setPaused(false);
        }
      };
      recorder.start(1000);
      toast.info('Recording started. It uses the active shared source. If you chose Entire Screen, desktop and app switching will be captured; meeting UI remains excluded.');
    } catch (err) {
      cleanupRecordingResources();
      onRecordingChange?.(false);
      toast.error(err instanceof Error ? err.message : 'Could not start recording');
    } finally {
      setBusy(false);
    }
  }

  function pause() {
    const recorder = recorderRef.current;
    if (recorder && recorder.state === 'recording') {
      pausedStartedAtRef.current = Date.now();
      recorder.pause();
    }
  }

  function resume() {
    const recorder = recorderRef.current;
    if (recorder && recorder.state === 'paused') {
      if (pausedStartedAtRef.current) pausedMsRef.current += Date.now() - pausedStartedAtRef.current;
      pausedStartedAtRef.current = null;
      recorder.resume();
    }
  }

  function stop() {
    const recorder = recorderRef.current;
    if (recorder && recorder.state !== 'inactive') recorder.stop();
  }

  function updateSetting<K extends keyof RecordingSettings>(key: K, value: RecordingSettings[K]) {
    setSettings((prev) => ({ ...prev, [key]: value }));
  }

  const settingsPanel = portalReady && settingsOpen ? createPortal(
    <div className="fixed inset-0 z-[9999]" onClick={() => setSettingsOpen(false)}>
      <div className="absolute bottom-24 right-4 w-80 max-w-[calc(100vw-2rem)] rounded-3xl border border-white/10 bg-slate-950 p-4 text-sm text-white shadow-2xl" onClick={(event) => event.stopPropagation()}>
        <div className="mb-3 flex items-center justify-between"><div><h3 className="font-black">Recording Settings</h3><p className="text-xs text-slate-400">Clean presenter and screen recording</p></div><button onClick={()=>setSettingsOpen(false)} className="rounded-xl bg-white/10 p-1"><ChevronDown size={16}/></button></div>
        {recording && <div className="mb-3 rounded-2xl bg-rose-500/10 p-3 text-xs text-rose-100"><span className="mr-2 inline-block h-2 w-2 animate-pulse rounded-full bg-rose-500"/>Recording in progress. Changes apply immediately to the clean canvas output.</div>}
        {!recording && <div className="mb-3 rounded-2xl bg-emerald-500/10 p-3 text-xs leading-relaxed text-emerald-100"><p className="font-bold">Choose mode and PiP settings before pressing Record.</p><p className="mt-1">For the smoothest desktop recording, enable Direct Source and start Share Screen with <b>Entire Screen</b>. This records the original browser-granted display track, so PowerPoint, PDF, Excel, VS Code, File Explorer, and app switching are captured.</p><p className="mt-1 font-bold">Current source: {sourceLabel(displaySurfaceRef.current)}</p></div>}
        <ToggleSetting label="Smooth Direct Source Recording" enabled={settings.directSource} onClick={()=>updateSetting('directSource', !settings.directSource)} />
        <ControlSelect label="Mode" value={settings.mode} onChange={(value)=>updateSetting('mode', value as RecordingMode)} options={Object.entries(MODE_LABELS)} />
        <ControlSelect label="Resolution" value={settings.resolution} onChange={(value)=>updateSetting('resolution', value as ResolutionKey)} disabled={Boolean(recording)} options={Object.entries(RESOLUTIONS).map(([key, value]) => [key, value.label])} />
        <ControlSelect label="PiP Position" value={settings.pipPosition} onChange={(value)=>updateSetting('pipPosition', value as PipPosition)} options={[["top_left", "Top left"], ["top_right", "Top right"], ["bottom_left", "Bottom left"], ["bottom_right", "Bottom right"]]} />
        <ControlSelect label="PiP Size" value={settings.pipSize} onChange={(value)=>updateSetting('pipSize', value as PipSize)} options={[["small", "Small"], ["medium", "Medium"], ["large", "Large"]]} />
        <ToggleSetting label="Presenter camera" enabled={settings.presenterCamera} onClick={()=>updateSetting('presenterCamera', !settings.presenterCamera)} />
        <ToggleSetting label="Watermark" enabled={settings.watermark} onClick={()=>updateSetting('watermark', !settings.watermark)} />
        <div className="mt-3 rounded-2xl bg-white/5 p-3 text-xs leading-relaxed text-slate-300">
          <p className="font-bold text-slate-100">Recording includes</p>
          <p className="mt-1 flex items-center gap-1"><CheckCircle2 size={13} className="text-emerald-400"/>Shared presentation or selected clean mode</p>
          <p className="flex items-center gap-1"><CheckCircle2 size={13} className="text-emerald-400"/>Active presenter camera and meeting audio</p>
          <p className="mt-2 font-bold text-slate-100">Not included</p>
          <p className="mt-1 flex items-center gap-1"><XCircle size={13} className="text-rose-400"/>Chat, participants, controls, popups, sidebars, browser UI</p>
        </div>
      </div>
    </div>, document.body) : null;

  return (
    <div className="relative flex gap-2">
      {recording ? <>
        {paused ? <RecordingToolbarButton label="Resume" icon={<CirclePlay size={21}/>} onClick={resume} /> : <RecordingToolbarButton label="Pause" icon={<CirclePause size={21}/>} onClick={pause} />}
        <RecordingToolbarButton label="Stop Rec" icon={<Square size={21}/>} onClick={stop} danger />
      </> : <RecordingToolbarButton label="Record" icon={<Radio size={21}/>} onClick={start} disabled={busy} />}
      <RecordingToolbarButton label="Rec Settings" icon={<Settings2 size={21}/>} onClick={() => setSettingsOpen((value)=>!value)} active={settingsOpen} />
      {settingsPanel}
    </div>
  );
}

function RecordingToolbarButton({ label, icon, onClick, danger = false, active = false, disabled = false }: { label: string; icon: React.ReactNode; onClick: () => void; danger?: boolean; active?: boolean; disabled?: boolean }) {
  return <button type="button" onClick={onClick} disabled={disabled} className={`relative inline-flex min-w-[86px] flex-col items-center justify-center gap-1 rounded-2xl px-3 py-2 text-xs font-black transition disabled:opacity-60 ${danger ? 'bg-rose-600 text-white hover:bg-rose-500' : active ? 'bg-brand-600 text-white' : 'bg-white/10 text-slate-100 hover:bg-white/15'}`} title={label} aria-label={label}>{icon}<span className="whitespace-nowrap">{label}</span></button>;
}

function ControlSelect({ label, value, onChange, options, disabled = false }: { label: string; value: string; onChange: (value: string) => void; options: [string, string][]; disabled?: boolean }) {
  return <label className="mb-2 block"><span className="text-xs font-bold text-slate-400">{label}</span><select disabled={disabled} value={value} onChange={(e)=>onChange(e.target.value)} className="mt-1 w-full rounded-2xl border border-white/10 bg-slate-900 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-brand-500 disabled:opacity-50">{options.map(([key, name]) => <option key={key} value={key}>{name}</option>)}</select></label>;
}

function ToggleSetting({ label, enabled, onClick }: { label: string; enabled: boolean; onClick: () => void }) {
  return <div className="mb-2 flex items-center justify-between rounded-2xl bg-white/5 px-3 py-2"><span className="font-semibold">{label}</span><button type="button" onClick={onClick} className={`relative h-7 w-12 rounded-full transition ${enabled ? 'bg-emerald-500' : 'bg-slate-700'}`}><span className={`absolute top-1 h-5 w-5 rounded-full bg-white transition ${enabled ? 'left-6' : 'left-1'}`} /></button></div>;
}
