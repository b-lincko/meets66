'use client';

import { Bookmark, Download, Image as ImageIcon, MessageSquareReply, Paperclip, Pin, SendHorizonal, Smile } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { toast } from 'sonner';
import { API_URL, ChatFile, ChatMessage, Meeting, Participant, api, getAccessToken } from '@/lib/api';
import { getSocket } from '@/lib/socket';

const emojiSet = ['👍', '✅', '🎉', '👏', '🔥', '❤️'];

export function ChatPanel({ meeting, participant, participantToken, inviteToken }: { meeting: Meeting; participant: Participant; participantToken?: string; inviteToken?: string }) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [body, setBody] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [typing, setTyping] = useState<string[]>([]);
  const [sending, setSending] = useState(false);
  const [replyTo, setReplyTo] = useState<ChatMessage | null>(null);
  const [imagePreview, setImagePreview] = useState<{ url: string; title: string } | null>(null);
  const typingTimer = useRef<number | null>(null);
  const typingActiveRef = useRef(false);
  const isParticipant = Boolean(participantToken && inviteToken);
  const canSend = meeting.allowChat || participant.role === 'host' || participant.role === 'cohost';
  const base = isParticipant ? `/meetings/invitations/${inviteToken}/chat` : `/meetings/${meeting.id}/chat`;
  const authHeaders = participantToken ? { Authorization: `Bearer ${participantToken}` } : undefined;

  useEffect(() => {
    api<{ items: ChatMessage[]; total: number }>(`${base}/messages`, { auth: !isParticipant, headers: authHeaders }).then((data) => setMessages(data.items)).catch(() => {});
    const socket = getSocket(participantToken);
    socket.emit('meeting:watch', { meetingId: meeting.id });
    const onMessage = (message: ChatMessage) => setMessages((prev) => prev.some((item) => item.id === message.id) ? prev.map((item) => item.id === message.id ? message : item) : [...prev, message]);
    const onTyping = (event: { displayName: string; isTyping: boolean }) => setTyping((prev) => event.isTyping ? Array.from(new Set([...prev, event.displayName])) : prev.filter((name) => name !== event.displayName));
    socket.on('chat:message', onMessage);
    socket.on('chat:typing', onTyping);
    return () => { socket.off('chat:message', onMessage); socket.off('chat:typing', onTyping); };
  }, [meeting.id, participantToken, inviteToken]);

  function notifyTyping(value: string) {
    setBody(value);
    const socket = getSocket(participantToken);
    if (!typingActiveRef.current) {
      typingActiveRef.current = true;
      socket.emit('chat:typing', { meetingId: meeting.id, isTyping: true });
    }
    if (typingTimer.current) window.clearTimeout(typingTimer.current);
    typingTimer.current = window.setTimeout(() => { typingActiveRef.current = false; socket.emit('chat:typing', { meetingId: meeting.id, isTyping: false }); }, 900);
  }

  async function send(e?: React.FormEvent) {
    e?.preventDefault();
    if (!canSend) return toast.error('Chat is disabled by host');
    if (!body.trim() && !file) return;
    setSending(true);
    try {
      let payload: BodyInit;
      let headers = authHeaders;
      if (file) {
        const form = new FormData();
        form.append('body', body.trim());
        form.append('file', file);
        if (replyTo) form.append('replyToId', replyTo.id);
        payload = form;
      } else {
        payload = JSON.stringify({ body: body.trim(), replyToId: replyTo?.id, threadRootId: replyTo?.threadRootId || replyTo?.id });
      }
      const data = await api<{ message: ChatMessage }>(`${base}/messages`, { method: 'POST', auth: !isParticipant, headers, body: payload });
      setMessages((prev) => prev.some((item) => item.id === data.message.id) ? prev.map((item) => item.id === data.message.id ? data.message : item) : [...prev, data.message]);
      setBody(''); setFile(null); setReplyTo(null);
      typingActiveRef.current = false;
      getSocket(participantToken).emit('chat:typing', { meetingId: meeting.id, isTyping: false });
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Message failed'); }
    finally { setSending(false); }
  }

  async function download(file: ChatFile, preview = false) {
    const path = isParticipant ? `/meetings/invitations/${inviteToken}/chat/files/${file.id}/download` : `/meetings/${meeting.id}/chat/files/${file.id}/download`;
    const headers: Record<string, string> = {};
    if (participantToken) headers.Authorization = `Bearer ${participantToken}`;
    else if (getAccessToken()) headers.Authorization = `Bearer ${getAccessToken()}`;
    const res = await fetch(`${API_URL}${path}`, { headers });
    if (!res.ok) return toast.error('Download failed');
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    if (preview) { setImagePreview({ url, title: file.filename }); return; }
    const a = document.createElement('a'); a.href = url; a.download = file.filename; a.click(); URL.revokeObjectURL(url);
  }

  async function messageAction(message: ChatMessage, action: string, extra: Record<string, unknown> = {}) {
    try {
      const data = await api<{ message: ChatMessage }>(`${base}/messages/${message.id}/actions`, { method: 'POST', auth: !isParticipant, headers: authHeaders, body: JSON.stringify({ action, ...extra }) });
      setMessages((prev) => prev.map((item) => item.id === message.id ? data.message : item));
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Chat action failed'); }
  }

  function replyPreview(message: ChatMessage) { return messages.find((item) => item.id === message.replyToId); }
  const pinned = messages.filter((message) => message.pinned);

  return (
    <aside className="flex h-full min-h-0 flex-col rounded-4xl border border-white/10 bg-slate-950/90 p-4 text-white shadow-2xl backdrop-blur-xl">
      <div className="border-b border-white/10 pb-3"><h3 className="font-bold">Meeting chat</h3><p className="text-xs text-slate-400">Threads, replies, reactions, markdown, attachments, pins, and saved messages</p></div>
      {pinned.length > 0 && <div className="mt-3 rounded-2xl bg-amber-400/10 p-3"><p className="mb-2 text-xs font-black uppercase text-amber-200">Pinned</p>{pinned.slice(0,3).map((message)=><button key={message.id} onClick={()=>setReplyTo(message)} className="mb-1 block w-full truncate rounded-xl bg-white/10 px-2 py-1 text-left text-xs">{message.senderDisplayName}: {message.body || message.file?.filename}</button>)}</div>}
      <div className="min-h-0 flex-1 space-y-3 overflow-y-auto py-4">
        {messages.map((message) => <div key={message.id} className={`rounded-2xl p-3 ${message.pinned ? 'bg-amber-400/10 ring-1 ring-amber-300/30' : 'bg-white/10'}`}><div className="mb-1 flex justify-between gap-2 text-xs text-slate-400"><span>{message.senderDisplayName}{message.metadata?.mentions?.length ? <span className="ml-1 text-brand-200">@{message.metadata.mentions.join(' @')}</span> : null}</span><span>{new Date(message.createdAt).toLocaleTimeString()}</span></div>{message.replyToId && replyPreview(message) && <div className="mb-2 rounded-xl border-l-2 border-brand-400 bg-black/20 px-2 py-1 text-xs text-slate-300">Reply to {replyPreview(message)?.senderDisplayName}: {replyPreview(message)?.body || replyPreview(message)?.file?.filename}</div>}{message.body && <MessageBody body={message.body} />}{message.file && <div className="mt-2 rounded-xl bg-white/10 p-2 text-xs"><button onClick={() => download(message.file!)} className="flex w-full items-center justify-between text-left hover:text-white"><span className="truncate"><Paperclip className="mr-1 inline" size={14}/>{message.file.filename} · {(message.file.sizeBytes / 1024).toFixed(1)} KB</span><Download size={14}/></button>{message.file.contentType.startsWith('image/') && <button onClick={() => download(message.file!, true)} className="mt-2 inline-flex items-center gap-1 rounded-lg bg-white/10 px-2 py-1"><ImageIcon size={13}/>Preview image</button>}</div>}<div className="mt-2 flex flex-wrap items-center gap-1 text-xs"><button onClick={()=>setReplyTo(message)} className="rounded-lg bg-white/10 px-2 py-1"><MessageSquareReply size={13} className="mr-1 inline"/>Reply</button><button onClick={()=>messageAction(message,'pin',{pinned:!message.pinned})} className="rounded-lg bg-white/10 px-2 py-1"><Pin size={13} className="mr-1 inline"/>{message.pinned?'Unpin':'Pin'}</button><button onClick={()=>messageAction(message,'save')} className="rounded-lg bg-white/10 px-2 py-1"><Bookmark size={13} className="mr-1 inline"/>Save</button>{emojiSet.map((emoji)=><button key={emoji} onClick={()=>messageAction(message,'react',{emoji})} className="rounded-lg bg-white/10 px-2 py-1">{emoji} {(message.metadata?.reactions?.[emoji] || []).length || ''}</button>)}</div></div>)}
        {!messages.length && <p className="pt-10 text-center text-sm text-slate-500">No messages yet.</p>}
      </div>
      {typing.length > 0 && <p className="mb-2 text-xs text-slate-400">{typing.join(', ')} typing…</p>}
      <div className="mb-2 flex flex-wrap gap-1">{emojiSet.map((emoji) => <button key={emoji} onClick={() => notifyTyping(`${body}${emoji}`)} className="rounded-xl bg-white/10 px-2 py-1 text-sm hover:bg-white/15"><Smile className="mr-1 inline" size={13}/>{emoji}</button>)}</div>
      {replyTo && <div className="mb-2 flex items-center justify-between rounded-xl bg-brand-600/20 px-3 py-2 text-xs"><span className="truncate">Replying to {replyTo.senderDisplayName}: {replyTo.body || replyTo.file?.filename}</span><button onClick={()=>setReplyTo(null)}>Cancel</button></div>}
      <form onSubmit={send} className="space-y-2">
        {file && <div className="flex items-center justify-between rounded-xl bg-white/10 px-3 py-2 text-xs"><span className="truncate">{file.name}</span><button type="button" onClick={() => setFile(null)}>Remove</button></div>}
        <div className="flex gap-2"><label className="grid h-12 w-12 cursor-pointer place-items-center rounded-2xl bg-white/10 hover:bg-white/15"><Paperclip size={18}/><input type="file" className="hidden" onChange={(e) => setFile(e.target.files?.[0] || null)} /></label><input disabled={!canSend} value={body} onChange={(e) => notifyTyping(e.target.value)} placeholder={canSend ? 'Markdown, code blocks, @mentions' : 'Chat disabled by host'} className="min-w-0 flex-1 rounded-2xl border border-white/10 bg-white/10 px-4 py-3 text-sm outline-none placeholder:text-slate-500"/><button disabled={sending || !canSend || (!body.trim() && !file)} className="grid h-12 w-12 place-items-center rounded-2xl bg-brand-600 disabled:opacity-50"><SendHorizonal size={18}/></button></div>
      </form>
      {imagePreview && <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4"><div className="max-w-3xl rounded-4xl bg-slate-950 p-4"><h4 className="mb-3 font-black">{imagePreview.title}</h4><img src={imagePreview.url} alt={imagePreview.title} className="max-h-[70dvh] rounded-3xl"/><button onClick={()=>{ URL.revokeObjectURL(imagePreview.url); setImagePreview(null); }} className="mt-4 rounded-2xl bg-white/10 px-4 py-2 font-bold">Close</button></div></div>}
    </aside>
  );
}

function MessageBody({ body }: { body: string }) {
  const segments = body.split(/```/g);
  return <div className="text-sm">{segments.map((segment, index) => index % 2 === 1 ? <pre key={index} className="my-2 overflow-auto rounded-xl bg-black/40 p-3 text-xs"><code>{segment}</code></pre> : <p key={index} className="whitespace-pre-wrap">{segment.split(/(@[\w.-]+)/g).map((part, i) => part.startsWith('@') ? <span key={i} className="font-bold text-brand-200">{part}</span> : part)}</p>)}</div>;
}
