'use client';

import { useEffect, useState } from 'react';
import { Admin, cachedAdmin } from '@/lib/api';

function hasPermission(admin: Admin, permission?: string) {
  if (!permission) return true;
  if (admin.role === 'super_admin') return true;
  return (admin.effectivePermissions || admin.permissions || []).includes(permission);
}

export function NotFoundScreen() {
  return (
    <main className="grid min-h-screen place-items-center bg-slate-950 p-4 text-white">
      <section className="max-w-md rounded-4xl border border-white/10 bg-white/10 p-8 text-center shadow-2xl backdrop-blur-xl">
        <p className="text-sm font-black uppercase tracking-widest text-slate-500">404</p>
        <h1 className="mt-2 text-3xl font-black">Page not found</h1>
        <p className="mt-3 text-sm text-slate-400">This page is not available.</p>
      </section>
    </main>
  );
}

export function AdminGuard({ children, permission }: { children: React.ReactNode; permission?: string }) {
  const [allowed, setAllowed] = useState<boolean | null>(null);
  useEffect(() => {
    const admin = cachedAdmin();
    setAllowed(Boolean(admin && hasPermission(admin, permission)));
  }, [permission]);
  if (allowed === null) return <main className="grid min-h-screen place-items-center bg-slate-950 text-white">Loading...</main>;
  if (!allowed) return <NotFoundScreen />;
  return <>{children}</>;
}
