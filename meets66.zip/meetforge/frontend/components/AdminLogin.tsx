'use client';

import { ShieldCheck } from 'lucide-react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useState } from 'react';
import { toast } from 'sonner';
import { Button } from '@/components/Button';
import { ThemeToggle } from '@/components/ThemeToggle';
import { Admin, api, saveAuth } from '@/lib/api';

type LoginResponse = { admin: Admin; accessToken: string; refreshToken: string; csrfToken?: string; forceChangePassword: boolean };

export function AdminLogin() {
  const router = useRouter();
  const search = useSearchParams();
  const rawNext = search.get('next') || '/dashboard';
  const next = rawNext.startsWith('/') && !rawNext.startsWith('//') && rawNext !== '/admin' ? rawNext : '/dashboard';
  const [form, setForm] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      const data = await api<LoginResponse>('/auth/login', { method: 'POST', auth: false, body: JSON.stringify(form) });
      saveAuth(data.accessToken, data.refreshToken, data.admin, data.csrfToken);
      toast.success('Administrator authenticated');
      router.push(data.forceChangePassword ? '/change-password' : next);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Login failed');
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="grid min-h-screen place-items-center bg-mesh p-4 dark:bg-slate-950">
      <div className="absolute right-4 top-4"><ThemeToggle /></div>
      <form onSubmit={submit} className="glass w-full max-w-md rounded-4xl p-8">
        <div className="mb-8 text-center">
          <span className="mx-auto grid h-14 w-14 place-items-center rounded-3xl bg-brand-600 text-white"><ShieldCheck /></span>
          <h1 className="mt-4 text-3xl font-black text-slate-950 dark:text-white">Admin login</h1>
          <p className="mt-2 text-slate-500 dark:text-slate-400">Authenticate to manage the private Defensiq Meet platform.</p>
        </div>
        <label className="block"><span className="text-sm font-semibold">Email</span><input type="email" required autoComplete="username" value={form.email} onChange={(e)=>setForm({...form,email:e.target.value})} className="mt-2 w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 outline-none focus:ring-2 focus:ring-brand-500 dark:border-slate-700 dark:bg-slate-900" /></label>
        <label className="mt-4 block"><span className="text-sm font-semibold">Password</span><input type="password" required autoComplete="current-password" value={form.password} onChange={(e)=>setForm({...form,password:e.target.value})} className="mt-2 w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 outline-none focus:ring-2 focus:ring-brand-500 dark:border-slate-700 dark:bg-slate-900" /></label>
        <Button className="mt-6 w-full" disabled={loading}>{loading ? 'Signing in...' : 'Sign in'}</Button>
      </form>
    </main>
  );
}
