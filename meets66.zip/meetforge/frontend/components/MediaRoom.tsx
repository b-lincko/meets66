'use client';

import { LiveKitRoom, ParticipantTile, RoomAudioRenderer, StartAudio, TrackLoop, useRoomContext, useTracks } from '@livekit/components-react';
import { ChevronDown, ChevronUp, Clock, Columns2, Expand, Grid2X2, Hand, Lock, LogOut, Maximize2, MessageSquare, Mic, MicOff, Minus, MonitorUp, MoreHorizontal, PanelRightClose, PanelRightOpen, Pause, PhoneOff, Play, Plus, RotateCcw, ScreenShare, ShieldCheck, UserCheck, Users, Video, VideoOff, Volume2 } from 'lucide-react';
import dynamic from 'next/dynamic';
import { createPortal } from 'react-dom';
import type { PointerEvent as ReactPointerEvent, ReactNode, WheelEvent as ReactWheelEvent } from 'react';
import { useEffect, useRef, useState } from 'react';
import { RoomEvent, Track, VideoQuality } from 'livekit-client';
import { toast } from 'sonner';
import { Meeting, Participant, api } from '@/lib/api';
import { getSocket } from '@/lib/socket';

const BreakoutPanel = dynamic(() => import('@/components/BreakoutPanel').then((module) => module.BreakoutPanel), { ssr: false });
const ChatPanel = dynamic(() => import('@/components/ChatPanel').then((module) => module.ChatPanel), { ssr: false });
const PollsQAPanel = dynamic(() => import('@/components/PollsQAPanel').then((module) => module.PollsQAPanel), { ssr: false });
const NetworkPanel = dynamic(() => import('@/components/NetworkPanel').then((module) => module.NetworkPanel), { ssr: false });
const MeetingPeoplePanel = dynamic(() => import('@/components/MeetingPeoplePanel').then((module) => module.MeetingPeoplePanel), { ssr: false });
const RecordingControls = dynamic(() => import('@/components/RecordingControls').then((module) => module.RecordingControls), { ssr: false });
const WhiteboardPanel = dynamic(() => import('@/components/WhiteboardPanel').then((module) => module.WhiteboardPanel), { ssr: false });

type DeviceChoice = { audioDeviceId?: string; videoDeviceId?: string; startAudio: boolean; startVideo: boolean; lowBandwidthMode: boolean; audioOnlyMode: boolean; preferredLayout: 'auto' | 'mobile' | 'gallery' | 'speaker'; mobileClient: boolean; networkType?: string; deviceInfo: Record<string, unknown> };
type DisplaySurface = 'monitor' | 'window' | 'browser';
type ShareSource = 'screen' | 'window' | 'browser';
type Layout = 'presenter' | 'side_by_side' | 'gallery';
type SidePanel = 'chat' | 'whiteboard' | 'polls' | 'network' | 'breakouts' | 'participants' | 'requests';

type Props = {
  title: string;
  meeting: Meeting;
  livekit: { url: string; token: string; roomName: string };
  devices: DeviceChoice;
  participant: Participant;
  participantToken?: string;
  inviteToken?: string;
  onLeave: () => void;
  onMeetingUpdate?: (meeting: Meeting) => void;
};

export function MediaRoom({ title, meeting, livekit, devices, participant, participantToken, inviteToken, onLeave, onMeetingUpdate }: Props) {
  const [currentMeeting, setCurrentMeeting] = useState(meeting);
  const [currentParticipant, setCurrentParticipant] = useState(participant);
  const [activeLivekit, setActiveLivekit] = useState(livekit);
  const [sidePanel, setSidePanel] = useState<SidePanel>('chat');
  const [panelOpen, setPanelOpen] = useState(true);
  const [topBarOpen, setTopBarOpen] = useState(true);
  const [controlsVisible, setControlsVisible] = useState(true);
  const controlsHideTimerRef = useRef<number | null>(null);
  const [recordingActive, setRecordingActive] = useState(false);
  const [participants, setParticipants] = useState<Participant[]>([participant]);
  const currentParticipantRef = useRef(participant);
  const pendingRequests = participants.filter((p) => p.status === 'waiting').length;
  const admittedCount = participants.filter((p) => p.status === 'admitted').length;
  const isParticipantSession = Boolean(participantToken && inviteToken);

  function updateMeeting(next: Meeting) { setCurrentMeeting(next); onMeetingUpdate?.(next); }
  function updateParticipantList(items: Participant[]) { setParticipants(sortParticipants(items)); }
  function mergeParticipant(next: Participant) {
    setParticipants((prev) => sortParticipants(prev.some((item) => item.id === next.id) ? prev.map((item) => item.id === next.id ? next : item) : [...prev, next]));
    if (next.id === currentParticipant.id) setCurrentParticipant(next);
  }
  function openPanel(panel: SidePanel) { setSidePanel(panel); setPanelOpen(true); }
  function togglePanel() { setPanelOpen((value) => !value); }

  async function loadParticipants() {
    const path = isParticipantSession ? `/meetings/invitations/${inviteToken}/participants` : `/meetings/${currentMeeting.id}/participants`;
    const data = await api<{ items: Participant[]; total: number }>(path, { auth: !isParticipantSession, headers: participantToken ? { Authorization: `Bearer ${participantToken}` } : undefined });
    updateParticipantList(data.items);
  }

  useEffect(() => { setCurrentMeeting(meeting); }, [meeting]);
  useEffect(() => { currentParticipantRef.current = currentParticipant; }, [currentParticipant]);
  useEffect(() => { setCurrentParticipant(participant); currentParticipantRef.current = participant; mergeParticipant(participant); }, [participant.id]);
  useEffect(() => {
    const key = `defensiq.meeting.${currentMeeting.id}.panelOpen`;
    const saved = sessionStorage.getItem(key);
    if (saved !== null) setPanelOpen(saved === 'true');
  }, [currentMeeting.id]);
  useEffect(() => {
    sessionStorage.setItem(`defensiq.meeting.${currentMeeting.id}.panelOpen`, String(panelOpen));
  }, [currentMeeting.id, panelOpen]);
  useEffect(() => {
    const key = `defensiq.meeting.${currentMeeting.id}.topBarOpen`;
    const saved = sessionStorage.getItem(key);
    if (saved !== null) setTopBarOpen(saved === 'true');
  }, [currentMeeting.id]);
  useEffect(() => {
    sessionStorage.setItem(`defensiq.meeting.${currentMeeting.id}.topBarOpen`, String(topBarOpen));
  }, [currentMeeting.id, topBarOpen]);
  function revealControls() {
    setControlsVisible(true);
    if (controlsHideTimerRef.current) window.clearTimeout(controlsHideTimerRef.current);
    controlsHideTimerRef.current = window.setTimeout(() => setControlsVisible(false), currentMeeting.activeScreenShareParticipantId ? 3200 : 6500);
  }
  useEffect(() => {
    revealControls();
    return () => { if (controlsHideTimerRef.current) window.clearTimeout(controlsHideTimerRef.current); };
  }, [currentMeeting.activeScreenShareParticipantId]);
  useEffect(() => {
    loadParticipants().catch(() => {});
    const socket = getSocket(participantToken);
    const watchMeeting = () => socket.emit('meeting:watch', { meetingId: currentMeeting.id });
    watchMeeting();
    const participantUpdated = (next: Participant) => { if (next.meetingId === currentMeeting.id) mergeParticipant(next); };
    const joinRequested = (event: { meetingId: string; participant: Participant; meeting?: Meeting }) => {
      if (event.meetingId !== currentMeeting.id || !event.participant) return;
      mergeParticipant(event.participant);
      if (event.meeting) updateMeeting(event.meeting);
      if (event.participant.status === 'waiting' && hasWaitingRoomManagement(currentParticipantRef.current)) toast.info(`${event.participant.displayName} is waiting to join`);
    };
    const recordingStarted = (event: any) => { if (event.meetingId === currentMeeting.id) setRecordingActive(true); };
    const recordingEnded = (event: any) => { if (event.meetingId === currentMeeting.id) setRecordingActive(false); };
    socket.on('connect', watchMeeting);
    socket.on('meeting:watching', loadParticipants);
    socket.on('participant:updated', participantUpdated);
    socket.on('participant:join_requested', joinRequested);
    socket.on('recording:started', recordingStarted);
    socket.on('recording:ready', recordingEnded);
    socket.on('recording:failed', recordingEnded);
    return () => { socket.off('connect', watchMeeting); socket.off('meeting:watching', loadParticipants); socket.off('participant:updated', participantUpdated); socket.off('participant:join_requested', joinRequested); socket.off('recording:started', recordingStarted); socket.off('recording:ready', recordingEnded); socket.off('recording:failed', recordingEnded); };
  }, [currentMeeting.id, participantToken, inviteToken]);
  useEffect(() => {
    const canUseWhiteboardPanel = canAccessWhiteboardPanel(currentMeeting, currentParticipant);
    const canUseAdminPanels = canAccessAdminSidePanels(currentParticipant);
    if (
      (sidePanel === 'requests' && !hasWaitingRoomManagement(currentParticipant)) ||
      (sidePanel === 'breakouts' && !canUseAdminPanels) ||
      (sidePanel === 'network' && !canUseAdminPanels) ||
      (sidePanel === 'whiteboard' && !canUseWhiteboardPanel)
    ) setSidePanel('chat');
  }, [currentMeeting, currentParticipant, sidePanel]);
  useEffect(() => {
    if (currentMeeting.activeScreenShareParticipantId && (sidePanel === 'participants' || sidePanel === 'requests')) setPanelOpen(false);
  }, [currentMeeting.activeScreenShareParticipantId, sidePanel]);
  useEffect(() => {
    if (!hasWaitingRoomManagement(currentParticipant)) return;
    const refresh = () => loadParticipants().catch(() => {});
    const interval = window.setInterval(refresh, 3000);
    window.addEventListener('focus', refresh);
    return () => { window.clearInterval(interval); window.removeEventListener('focus', refresh); };
  }, [currentMeeting.id, currentParticipant.id, currentParticipant.role, currentParticipant.hostControls?.cohostPermissions?.join('|')]);

  const canManageParticipants = hasParticipantManagement(currentParticipant);
  const canManageRequests = hasWaitingRoomManagement(currentParticipant);
  const canUseAdminPanels = canAccessAdminSidePanels(currentParticipant);
  const canUseWhiteboardPanel = canAccessWhiteboardPanel(currentMeeting, currentParticipant);
  const panels: { id: SidePanel; label: string; adminOnly?: boolean; manageOnly?: boolean; requiresWhiteboard?: boolean }[] = [
    { id: 'chat', label: 'Chat' },
    { id: 'whiteboard', label: 'Whiteboard', requiresWhiteboard: true },
    { id: 'polls', label: 'Polls' },
    { id: 'participants', label: `Participants (${admittedCount})` },
    { id: 'requests', label: `Requests (${pendingRequests})`, manageOnly: true },
    { id: 'breakouts', label: 'Breakouts', adminOnly: true },
    { id: 'network', label: 'Network', adminOnly: true },
  ];
  const visiblePanels = panels.filter((item) => (!item.adminOnly || canUseAdminPanels) && (!item.requiresWhiteboard || canUseWhiteboardPanel) && (!item.manageOnly || (item.id === 'requests' ? canManageRequests : canManageParticipants)));

  function renderSidePanel() {
    if (sidePanel === 'participants' || sidePanel === 'requests') {
      return <MeetingPeoplePanel meeting={currentMeeting} currentParticipant={currentParticipant} participants={participants} participantToken={participantToken} inviteToken={inviteToken} activeView={sidePanel === 'requests' ? 'requests' : 'participants'} onViewChange={(view) => setSidePanel(view)} onParticipantsChange={updateParticipantList} onMeetingUpdate={updateMeeting} onReload={() => loadParticipants().catch(() => toast.error('Could not reload participants'))} onClose={() => setPanelOpen(false)} />;
    }
    if (sidePanel === 'chat') return <ChatPanel meeting={currentMeeting} participant={currentParticipant} participantToken={participantToken} inviteToken={inviteToken} />;
    if (sidePanel === 'whiteboard' && canAccessWhiteboardPanel(currentMeeting, currentParticipant)) return <WhiteboardPanel meeting={currentMeeting} participant={currentParticipant} participantToken={participantToken} inviteToken={inviteToken} />;
    if (sidePanel === 'polls') return <PollsQAPanel meeting={currentMeeting} participant={currentParticipant} participantToken={participantToken} inviteToken={inviteToken} />;
    if (sidePanel === 'network' && canAccessAdminSidePanels(currentParticipant)) return <NetworkPanel meeting={currentMeeting} participant={currentParticipant} participantToken={participantToken} inviteToken={inviteToken} />;
    if (sidePanel === 'breakouts' && canAccessAdminSidePanels(currentParticipant)) return <BreakoutPanel meeting={currentMeeting} participant={currentParticipant} participantToken={participantToken} inviteToken={inviteToken} />;
    return <ChatPanel meeting={currentMeeting} participant={currentParticipant} participantToken={participantToken} inviteToken={inviteToken} />;
  }

  return (
    <LiveKitRoom
      key={activeLivekit.roomName}
      token={activeLivekit.token}
      serverUrl={activeLivekit.url}
      connect
      audio={devices.startAudio ? { deviceId: devices.audioDeviceId ? { exact: devices.audioDeviceId } : undefined, echoCancellation: true, noiseSuppression: true } : false}
      video={devices.startVideo ? ({ deviceId: devices.videoDeviceId ? { exact: devices.videoDeviceId } : undefined, width: { ideal: devices.lowBandwidthMode || devices.mobileClient ? 426 : 1280 }, height: { ideal: devices.lowBandwidthMode || devices.mobileClient ? 240 : 720 }, frameRate: { ideal: devices.lowBandwidthMode || devices.mobileClient ? 15 : 24, max: devices.lowBandwidthMode || devices.mobileClient ? 15 : 30 } } as any) : false}
      options={{ adaptiveStream: true, dynacast: true }}
      connectOptions={{ autoSubscribe: true }}
      onConnected={() => toast.success('Connected to meeting media')}
      onMediaDeviceFailure={(_failure, kind) => toast.error(`${kind || 'Media device'} permission or device failure`)}
      onError={(err) => toast.error(err.message)}
      className="h-[100dvh] bg-slate-950 text-white"
    >
      <ControlEnforcer meeting={currentMeeting} participantId={currentParticipant.id} participantToken={participantToken} inviteToken={inviteToken} onLeave={onLeave} onMeetingUpdate={updateMeeting} onParticipantUpdate={setCurrentParticipant} onLivekitMove={setActiveLivekit} />
      <MediaSubscriptionOptimizer activeScreenShareParticipantId={currentMeeting.activeScreenShareParticipantId} maxGalleryCameras={16} />
      <div onMouseMove={revealControls} onKeyDown={revealControls} className="grid h-full grid-rows-[auto_minmax(0,1fr)_auto] gap-2 p-2 sm:gap-3 sm:p-3">
        <div className={`transition-opacity duration-300 ${controlsVisible ? 'opacity-100' : 'pointer-events-none opacity-0'}`}>{topBarOpen ? <MeetingTopBar title={title} meeting={currentMeeting} participant={currentParticipant} panelOpen={panelOpen} recordingActive={recordingActive} onTogglePanel={togglePanel} onToggleTopBar={() => setTopBarOpen(false)} /> : <div className="flex justify-center"><button type="button" onClick={() => setTopBarOpen(true)} className="inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-white/10 px-4 py-2 text-xs font-black text-white shadow-lg transition hover:bg-white/15" aria-label="Show top bar" title="Show top bar"><ChevronDown size={16}/>Show Top Bar</button></div>}</div>
        <div className="flex min-h-0 flex-col gap-2 lg:flex-row">
          <main className="relative min-h-0 min-w-0 flex-1 overflow-hidden rounded-4xl border border-white/10 bg-black transition-all duration-300">
            {recordingActive && <RecordingNotice />}
            <PresentationStage meetingId={currentMeeting.id} layout={currentMeeting.presenterLayout || 'presenter'} participants={participants} currentParticipant={currentParticipant} participantToken={participantToken} activeScreenShareParticipantId={currentMeeting.activeScreenShareParticipantId} />
          </main>
          <section className={`min-h-0 overflow-hidden transition-all duration-300 ease-in-out ${panelOpen ? 'h-[42dvh] opacity-100 lg:h-auto lg:w-[420px]' : 'h-0 opacity-0 lg:h-auto lg:w-0'}`} aria-hidden={!panelOpen}>
            <div className="flex h-full min-h-0 w-full flex-col">
              <div className="mb-2 flex items-center gap-2">
                <div className="flex min-w-0 flex-1 gap-2 overflow-x-auto rounded-2xl border border-white/10 bg-white/5 p-1">
                  {visiblePanels.map((item) => <button key={item.id} onClick={() => openPanel(item.id)} className={`shrink-0 rounded-xl px-3 py-2 text-sm font-semibold transition ${sidePanel === item.id ? 'bg-brand-600 text-white' : 'bg-transparent text-slate-200 hover:bg-white/10'}`}>{item.label}</button>)}
                </div>
                <button onClick={() => setPanelOpen(false)} className="rounded-2xl bg-white/10 p-3 transition hover:bg-white/15" aria-label="Hide side panel" title="Hide side panel"><PanelRightClose size={18}/></button>
              </div>
              <div className="min-h-0 flex-1">{renderSidePanel()}</div>
            </div>
          </section>
        </div>
        <div className={`transition-all duration-300 ${controlsVisible ? 'translate-y-0 opacity-100' : 'pointer-events-none translate-y-4 opacity-0'}`}><RoomControls meeting={currentMeeting} participant={currentParticipant} participantToken={participantToken} inviteToken={inviteToken} pendingRequests={pendingRequests} participantCount={admittedCount} panelOpen={panelOpen} activePanel={sidePanel} onOpenPanel={openPanel} onTogglePanel={togglePanel} onLeave={onLeave} onMeetingUpdate={updateMeeting} onParticipantUpdate={setCurrentParticipant} onLivekitMove={setActiveLivekit} onRecordingChange={setRecordingActive} /></div>
      </div>
      <RoomAudioRenderer />
    </LiveKitRoom>
  );
}

function MeetingTopBar({ title, meeting, participant, panelOpen, recordingActive, onTogglePanel, onToggleTopBar }: { title: string; meeting: Meeting; participant: Participant; panelOpen: boolean; recordingActive: boolean; onTogglePanel: () => void; onToggleTopBar: () => void }) {
  const startAt = participant.admittedAt || participant.joinedAt || meeting.scheduledStartAt;
  return (
    <header className="flex flex-wrap items-center justify-between gap-3 rounded-3xl border border-white/10 bg-[#0b0f17]/95 px-4 py-3 shadow-2xl backdrop-blur-xl">
      <div className="flex min-w-0 items-center gap-3">
        <span className={`grid h-9 w-9 shrink-0 place-items-center rounded-2xl ${meeting.isLocked ? 'bg-amber-500/20 text-amber-200' : 'bg-emerald-500/20 text-emerald-200'}`}>{meeting.isLocked ? <Lock size={19}/> : <ShieldCheck size={19}/>}</span>
        <div className="min-w-0"><p className="text-xs uppercase tracking-widest text-slate-400">Live meeting</p><h1 className="truncate text-base font-black sm:text-lg">{title}</h1></div>
      </div>
      <div className="flex flex-wrap items-center justify-end gap-2 text-xs font-bold">
        <span className="rounded-full bg-white/10 px-3 py-2">{roleLabel(participant)}</span>
        <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-2"><Clock size={15}/><MeetingTimer startAt={startAt}/></span>
        {recordingActive && <span className="inline-flex items-center gap-2 rounded-full bg-rose-600/20 px-3 py-2 text-rose-100"><span className="h-2 w-2 animate-pulse rounded-full bg-rose-500"/>REC</span>}
        <ConnectionBadge />
        <button onClick={onToggleTopBar} className="inline-flex items-center gap-2 rounded-2xl bg-white/10 px-3 py-2 transition hover:bg-white/15" aria-label="Hide top bar" title="Hide top bar"><ChevronUp size={16}/><span>Hide Top Bar</span></button>
        <button onClick={onTogglePanel} className="inline-flex items-center gap-2 rounded-2xl bg-white/10 px-3 py-2 transition hover:bg-white/15" aria-label={panelOpen ? 'Hide side panel' : 'Show side panel'} title={panelOpen ? 'Hide side panel' : 'Show side panel'}>{panelOpen ? <PanelRightClose size={16}/> : <PanelRightOpen size={16}/>}<span>{panelOpen ? 'Hide Panel' : 'Show Panel'}</span></button>
      </div>
    </header>
  );
}

function MeetingTimer({ startAt }: { startAt?: string | null }) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => { const id = window.setInterval(() => setNow(Date.now()), 1000); return () => window.clearInterval(id); }, []);
  const start = startAt ? new Date(startAt).getTime() : now;
  const seconds = Math.max(0, Math.floor((now - start) / 1000));
  return <span>{formatDuration(seconds)}</span>;
}

function formatDuration(totalSeconds: number) {
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

const ZOOM_LEVELS = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 2, 3, 4];

function PresentationStage({ meetingId, layout, participants, currentParticipant, participantToken, activeScreenShareParticipantId }: { meetingId: string; layout: Layout; participants: Participant[]; currentParticipant: Participant; participantToken?: string; activeScreenShareParticipantId?: string | null }) {
  const tracks = useTracks([
    { source: Track.Source.Camera, withPlaceholder: true },
    { source: Track.Source.ScreenShare, withPlaceholder: false },
  ], { onlySubscribed: false });
  const [tileOrder, setTileOrder] = useState<string[]>([]);
  useEffect(() => {
    try { setTileOrder(JSON.parse(localStorage.getItem(`defensiq.meeting.${meetingId}.tileOrder`) || '[]')); } catch { setTileOrder([]); }
  }, [meetingId]);
  function saveTileOrder(next: string[]) { setTileOrder(next); localStorage.setItem(`defensiq.meeting.${meetingId}.tileOrder`, JSON.stringify(next)); }
  const priority = new Map(participants.map((person) => [person.id, participantPriority(person)]));
  const orderIndex = new Map(tileOrder.map((id, index) => [id, index]));
  const sortedTracks = [...tracks].sort((a, b) => {
    const ap = priority.get(trackParticipantId(a)) || 0;
    const bp = priority.get(trackParticipantId(b)) || 0;
    if (ap !== bp) return bp - ap;
    return (orderIndex.get(trackParticipantId(a)) ?? 9999) - (orderIndex.get(trackParticipantId(b)) ?? 9999);
  });
  const screenTracks = sortedTracks.filter((track) => track.source === Track.Source.ScreenShare);
  const cameraTracks = sortedTracks.filter((track) => track.source !== Track.Source.ScreenShare);
  if (!screenTracks.length) {
    const maxRenderedTiles = 24;
    const renderedTracks = sortedTracks.slice(0, maxRenderedTiles);
    const hiddenCount = Math.max(0, sortedTracks.length - renderedTracks.length);
    const tileMin = cameraTracks.length <= 2 ? 360 : cameraTracks.length <= 6 ? 280 : 220;
    return <div className="relative grid h-full auto-rows-fr gap-2 p-2" style={{ gridTemplateColumns: `repeat(auto-fit, minmax(${tileMin}px, 1fr))` }}>{renderedTracks.map((track) => {
      const id = trackParticipantId(track);
      return <div key={`${id}-${track.source}`} draggable onDragStart={(event)=>event.dataTransfer.setData('text/plain', id)} onDragOver={(event)=>event.preventDefault()} onDrop={(event)=>{ const from = event.dataTransfer.getData('text/plain'); const to = id; const ids = sortedTracks.map(trackParticipantId).filter(Boolean); const next = tileOrder.length ? tileOrder.filter((item)=>ids.includes(item)) : ids; const fromIndex = next.indexOf(from); const toIndex = next.indexOf(to); if (fromIndex >= 0 && toIndex >= 0) { next.splice(toIndex, 0, next.splice(fromIndex, 1)[0]); saveTileOrder([...next]); } }} className="min-h-0 cursor-grab active:cursor-grabbing"><ParticipantTile trackRef={track} className="h-full" /></div>;
    })}{hiddenCount > 0 && <div className="absolute bottom-3 left-1/2 -translate-x-1/2 rounded-2xl bg-slate-950/85 px-4 py-2 text-xs font-bold text-white shadow-xl">{hiddenCount} additional participants are audio/list-only to preserve performance</div>}</div>;
  }
  const selectedScreen = (activeScreenShareParticipantId ? screenTracks.find((track) => trackParticipantId(track) === activeScreenShareParticipantId) : undefined) || screenTracks[0];
  const presenterId = trackParticipantId(selectedScreen);
  const pipTrack = cameraTracks.find((track) => trackParticipantId(track) === presenterId);
  const presenter = participants.find((person) => person.id === presenterId);
  return <SharedScreenStage meetingId={meetingId} presenterId={presenterId} currentParticipant={currentParticipant} participantToken={participantToken} screenTrack={selectedScreen} pipTrack={pipTrack} presenterName={presenter?.displayName || 'Presenter'} />;
}

function SharedScreenStage({ meetingId, presenterId, currentParticipant, participantToken, screenTrack, pipTrack, presenterName }: { meetingId: string; presenterId: string; currentParticipant: Participant; participantToken?: string; screenTrack: any; pipTrack?: any; presenterName: string }) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const hideTimerRef = useRef<number | null>(null);
  const dragRef = useRef<{ x: number; y: number; panX: number; panY: number } | null>(null);
  const pointersRef = useRef<Map<number, { x: number; y: number }>>(new Map());
  const pinchRef = useRef<{ distance: number; zoom: number } | null>(null);
  const lastLaserEmitRef = useRef(0);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [toolbarVisible, setToolbarVisible] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [laserMode, setLaserMode] = useState(false);
  const [annotationMode, setAnnotationMode] = useState(false);
  const [annotations, setAnnotations] = useState<{ id: string; points: { x: number; y: number }[]; color: string; width: number }[]>([]);
  const [activeAnnotation, setActiveAnnotation] = useState<{ id: string; points: { x: number; y: number }[]; color: string; width: number } | null>(null);
  const [laserPointers, setLaserPointers] = useState<Record<string, { x: number; y: number; name: string; until: number }>>({});
  const [notesOpen, setNotesOpen] = useState(false);
  const [presenterNotes, setPresenterNotes] = useState('');
  const [presentationStartedAt, setPresentationStartedAt] = useState(Date.now());
  const isPresenter = currentParticipant.id === presenterId;

  const clampZoom = (value: number) => Math.min(4, Math.max(0.25, value));
  const applyZoom = (value: number, resetPan = false) => {
    const next = clampZoom(value);
    setZoom(next);
    if (resetPan || next <= 1) setPan({ x: 0, y: 0 });
    showToolbar();
  };
  const zoomToStep = (direction: 1 | -1) => {
    const index = direction > 0 ? ZOOM_LEVELS.findIndex((level) => level > zoom + 0.001) : [...ZOOM_LEVELS].reverse().findIndex((level) => level < zoom - 0.001);
    if (direction > 0) applyZoom(index === -1 ? 4 : ZOOM_LEVELS[index]);
    else applyZoom(index === -1 ? 0.25 : [...ZOOM_LEVELS].reverse()[index]);
  };
  function showToolbar() {
    setToolbarVisible(true);
    if (hideTimerRef.current) window.clearTimeout(hideTimerRef.current);
    hideTimerRef.current = window.setTimeout(() => setToolbarVisible(false), 3200);
  }

  useEffect(() => {
    showToolbar();
    return () => { if (hideTimerRef.current) window.clearTimeout(hideTimerRef.current); };
  }, []);
  useEffect(() => {
    setPresentationStartedAt(Date.now());
    setAnnotations([]);
    setActiveAnnotation(null);
  }, [presenterId]);
  useEffect(() => {
    if (!isPresenter) return;
    setPresenterNotes(localStorage.getItem(`defensiq.meeting.${meetingId}.presenterNotes`) || '');
  }, [meetingId, isPresenter]);
  useEffect(() => {
    if (isPresenter) localStorage.setItem(`defensiq.meeting.${meetingId}.presenterNotes`, presenterNotes);
  }, [meetingId, presenterNotes, isPresenter]);
  useEffect(() => {
    const socket = getSocket(participantToken);
    const onLaser = (event: { meetingId: string; displayName: string; x: number; y: number }) => {
      if (event.meetingId !== meetingId) return;
      const id = event.displayName || 'Presenter';
      setLaserPointers((prev) => ({ ...prev, [id]: { x: Number(event.x) || 0, y: Number(event.y) || 0, name: id, until: Date.now() + 900 } }));
    };
    const onAnnotation = (event: { meetingId: string; annotationId?: string; points?: {x:number;y:number}[]; color?: string; width?: number; clear?: boolean }) => {
      if (event.meetingId !== meetingId) return;
      if (event.clear) { setAnnotations([]); return; }
      if (event.annotationId && Array.isArray(event.points)) setAnnotations((prev) => [...prev.filter((item) => item.id !== event.annotationId), { id: event.annotationId!, points: event.points!, color: event.color || '#f59e0b', width: event.width || 4 }]);
    };
    const cleanupLasers = window.setInterval(() => setLaserPointers((prev) => Object.fromEntries(Object.entries(prev).filter(([, value]) => value.until > Date.now()))), 500);
    socket.on('presentation:laser', onLaser);
    socket.on('presentation:annotation', onAnnotation);
    return () => { window.clearInterval(cleanupLasers); socket.off('presentation:laser', onLaser); socket.off('presentation:annotation', onAnnotation); };
  }, [meetingId, participantToken]);

  useEffect(() => {
    const keyHandler = (event: KeyboardEvent) => {
      if (!containerRef.current) return;
      const active = document.activeElement;
      if (active && ['INPUT', 'TEXTAREA', 'SELECT'].includes(active.tagName)) return;
      if ((event.ctrlKey || event.metaKey) && ['+', '='].includes(event.key)) { event.preventDefault(); zoomToStep(1); }
      if ((event.ctrlKey || event.metaKey) && event.key === '-') { event.preventDefault(); zoomToStep(-1); }
      if ((event.ctrlKey || event.metaKey) && event.key === '0') { event.preventDefault(); applyZoom(1, true); }
    };
    const fullscreenHandler = () => setIsFullscreen(Boolean(document.fullscreenElement));
    window.addEventListener('keydown', keyHandler);
    document.addEventListener('fullscreenchange', fullscreenHandler);
    return () => { window.removeEventListener('keydown', keyHandler); document.removeEventListener('fullscreenchange', fullscreenHandler); };
  }, [zoom]);

  function pointerDistance() {
    const values = Array.from(pointersRef.current.values());
    if (values.length < 2) return 0;
    return Math.hypot(values[0].x - values[1].x, values[0].y - values[1].y);
  }
  function relativePoint(event: ReactPointerEvent<HTMLDivElement>) {
    const rect = event.currentTarget.getBoundingClientRect();
    return { x: Math.max(0, Math.min(1, (event.clientX - rect.left) / rect.width)), y: Math.max(0, Math.min(1, (event.clientY - rect.top) / rect.height)) };
  }
  function emitLaser(point: { x: number; y: number }) {
    const now = performance.now();
    if (now - lastLaserEmitRef.current < 50) return;
    lastLaserEmitRef.current = now;
    getSocket(participantToken).emit('presentation:laser', { meetingId, x: point.x, y: point.y });
    setLaserPointers((prev) => ({ ...prev, [currentParticipant.displayName]: { x: point.x, y: point.y, name: currentParticipant.displayName, until: Date.now() + 900 } }));
  }
  function emitAnnotation(annotation: { id: string; points: { x: number; y: number }[]; color: string; width: number }) {
    getSocket(participantToken).emit('presentation:annotation', { meetingId, annotationId: annotation.id, points: annotation.points, color: annotation.color, width: annotation.width });
  }

  function onPointerDown(event: ReactPointerEvent<HTMLDivElement>) {
    showToolbar();
    if (laserMode && isPresenter) { emitLaser(relativePoint(event)); return; }
    if (annotationMode && isPresenter) {
      const annotation = { id: `${Date.now()}-${Math.random()}`, points: [relativePoint(event)], color: '#f59e0b', width: 4 };
      setActiveAnnotation(annotation);
      return;
    }
    pointersRef.current.set(event.pointerId, { x: event.clientX, y: event.clientY });
    event.currentTarget.setPointerCapture(event.pointerId);
    if (pointersRef.current.size === 2) {
      pinchRef.current = { distance: pointerDistance(), zoom };
      dragRef.current = null;
      return;
    }
    if (zoom > 1 && event.button === 0) dragRef.current = { x: event.clientX, y: event.clientY, panX: pan.x, panY: pan.y };
  }

  function onPointerMove(event: ReactPointerEvent<HTMLDivElement>) {
    showToolbar();
    if (laserMode && isPresenter) { emitLaser(relativePoint(event)); return; }
    if (annotationMode && activeAnnotation && isPresenter) {
      setActiveAnnotation((prev) => prev ? { ...prev, points: [...prev.points, relativePoint(event)] } : prev);
      return;
    }
    if (pointersRef.current.has(event.pointerId)) pointersRef.current.set(event.pointerId, { x: event.clientX, y: event.clientY });
    if (pinchRef.current && pointersRef.current.size >= 2) {
      const distance = pointerDistance();
      if (distance > 0) applyZoom(pinchRef.current.zoom * (distance / pinchRef.current.distance));
      return;
    }
    if (!dragRef.current || zoom <= 1) return;
    setPan({ x: dragRef.current.panX + event.clientX - dragRef.current.x, y: dragRef.current.panY + event.clientY - dragRef.current.y });
  }

  function onPointerUp(event: ReactPointerEvent<HTMLDivElement>) {
    if (annotationMode && activeAnnotation && isPresenter) {
      const finished = { ...activeAnnotation, points: [...activeAnnotation.points, relativePoint(event)] };
      setAnnotations((prev) => [...prev, finished]);
      emitAnnotation(finished);
      setActiveAnnotation(null);
      return;
    }
    pointersRef.current.delete(event.pointerId);
    if (pointersRef.current.size < 2) pinchRef.current = null;
    dragRef.current = null;
  }

  function onWheel(event: ReactWheelEvent<HTMLDivElement>) {
    if (!event.ctrlKey && !event.metaKey) return;
    event.preventDefault();
    zoomToStep(event.deltaY < 0 ? 1 : -1);
  }

  function onDoubleClick() { applyZoom(zoom > 1 ? 1 : 2, true); }
  async function toggleFullscreen() {
    if (!containerRef.current) return;
    if (document.fullscreenElement) await document.exitFullscreen().catch(() => undefined);
    else await containerRef.current.requestFullscreen().catch(() => undefined);
    showToolbar();
  }

  return (
    <div ref={containerRef} onMouseMove={showToolbar} onWheel={onWheel} className="relative h-full overflow-hidden rounded-3xl bg-black touch-none">
      <div
        className={`absolute inset-0 ${zoom > 1 ? 'cursor-grab active:cursor-grabbing' : 'cursor-default'}`}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerUp}
        onDoubleClick={onDoubleClick}
      >
        <div className="h-full w-full will-change-transform" style={{ transform: `translate3d(${pan.x}px, ${pan.y}px, 0) scale(${zoom})`, transformOrigin: 'center center' }}>
          <ParticipantTile trackRef={screenTrack} className="h-full" />
        </div>
      </div>
      <svg className="pointer-events-none absolute inset-0 z-10 h-full w-full" viewBox="0 0 1 1" preserveAspectRatio="none">
        {[...annotations, ...(activeAnnotation ? [activeAnnotation] : [])].map((annotation) => <polyline key={annotation.id} points={annotation.points.map((point) => `${point.x},${point.y}`).join(' ')} fill="none" stroke={annotation.color} strokeWidth={annotation.width / 900} strokeLinecap="round" strokeLinejoin="round" />)}
      </svg>
      {Object.entries(laserPointers).map(([id, pointer]) => <div key={id} className="pointer-events-none absolute z-20 -translate-x-1/2 -translate-y-1/2" style={{ left: `${pointer.x * 100}%`, top: `${pointer.y * 100}%` }}><span className="block h-5 w-5 rounded-full bg-rose-500/80 shadow-[0_0_20px_rgba(244,63,94,.95)]"/><span className="ml-4 rounded-lg bg-black/60 px-2 py-1 text-xs font-bold text-white">{pointer.name}</span></div>)}
      {pipTrack && <div className="absolute bottom-4 right-4 z-20 hidden w-[260px] overflow-hidden rounded-3xl border border-white/30 bg-black shadow-2xl md:block"><ParticipantTile trackRef={pipTrack} className="aspect-video" /><div className="absolute bottom-2 left-2 rounded-xl bg-black/60 px-2 py-1 text-xs font-bold">{presenterName}</div></div>}
      <div className="pointer-events-none absolute left-1/2 top-3 z-20 -translate-x-1/2 rounded-2xl bg-emerald-600/90 px-4 py-2 text-xs font-black shadow-lg">Screen sharing · {Math.round(zoom * 100)}% · <PresentationElapsed startedAt={presentationStartedAt}/></div>
      <div className={`absolute left-1/2 top-14 z-30 flex -translate-x-1/2 items-center gap-1 rounded-2xl border border-white/10 bg-slate-950/90 p-1 text-xs font-black text-white shadow-2xl backdrop-blur-xl transition-opacity duration-300 ${toolbarVisible ? 'opacity-100' : 'pointer-events-none opacity-0'}`}>
        <ZoomButton label="Zoom out" onClick={() => zoomToStep(-1)}><Minus size={16}/></ZoomButton>
        <span className="min-w-16 px-2 text-center">🔍 {Math.round(zoom * 100)}%</span>
        <ZoomButton label="Zoom in" onClick={() => zoomToStep(1)}><Plus size={16}/></ZoomButton>
        <ZoomButton label="Fit to screen" onClick={() => applyZoom(1, true)}>Fit</ZoomButton>
        <ZoomButton label="Actual size" onClick={() => applyZoom(1, true)}>100%</ZoomButton>
        <ZoomButton label="Reset zoom" onClick={() => applyZoom(1, true)}><RotateCcw size={15}/></ZoomButton>
        <ZoomButton label={isFullscreen ? 'Exit full screen' : 'Full screen'} onClick={toggleFullscreen}><Maximize2 size={15}/></ZoomButton>
        {isPresenter && <ZoomButton label={laserMode ? 'Disable laser pointer' : 'Enable laser pointer'} onClick={() => { setLaserMode((value) => !value); setAnnotationMode(false); }}>{laserMode ? 'Laser On' : 'Laser'}</ZoomButton>}
        {isPresenter && <ZoomButton label={annotationMode ? 'Disable annotation' : 'Annotate shared content'} onClick={() => { setAnnotationMode((value) => !value); setLaserMode(false); }}>{annotationMode ? 'Pen On' : 'Pen'}</ZoomButton>}
        {isPresenter && <ZoomButton label="Clear annotations" onClick={() => { setAnnotations([]); getSocket(participantToken).emit('presentation:annotation', { meetingId, clear: true }); }}>Clear</ZoomButton>}
        {isPresenter && <ZoomButton label="Presenter notes" onClick={() => setNotesOpen((value) => !value)}>Notes</ZoomButton>}
      </div>
      {isPresenter && notesOpen && <div className="absolute right-4 top-28 z-40 w-80 rounded-3xl border border-white/10 bg-slate-950/95 p-4 text-white shadow-2xl backdrop-blur-xl"><div className="mb-2 flex items-center justify-between"><h3 className="font-black">Presenter Notes</h3><button onClick={() => setNotesOpen(false)} className="rounded-xl bg-white/10 px-2 py-1 text-xs">Hide</button></div><textarea value={presenterNotes} onChange={(event) => setPresenterNotes(event.target.value)} rows={8} className="w-full resize-none rounded-2xl border border-white/10 bg-white/10 p-3 text-sm outline-none focus:ring-2 focus:ring-brand-500" placeholder="Private notes only visible to you" /></div>}
    </div>
  );
}

function PresentationElapsed({ startedAt }: { startedAt: number }) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => { const id = window.setInterval(() => setNow(Date.now()), 1000); return () => window.clearInterval(id); }, []);
  return <span>{formatDuration(Math.max(0, Math.floor((now - startedAt) / 1000)))}</span>;
}

function ZoomButton({ label, onClick, children }: { label: string; onClick: () => void; children: ReactNode }) {
  return <button type="button" title={label} aria-label={label} onClick={onClick} className="inline-flex h-9 min-w-9 items-center justify-center rounded-xl bg-white/10 px-2 transition hover:bg-white/20">{children}</button>;
}

function RecordingNotice() {
  return <div className="pointer-events-none absolute left-4 top-4 z-20 max-w-sm rounded-3xl border border-white/10 bg-slate-950/85 p-4 text-sm shadow-2xl backdrop-blur-xl"><p className="flex items-center gap-2 font-black text-white"><span className="h-3 w-3 animate-pulse rounded-full bg-rose-500"/>Recording in Progress</p><p className="mt-2 text-slate-300">Only the active presenter's camera and shared presentation are included in the recording.</p></div>;
}

function trackParticipantId(trackRef: any) {
  return String(trackRef?.participant?.identity || trackRef?.publication?.participant?.identity || '');
}

function participantPriority(participant: Participant) {
  const controls = participant.hostControls || {};
  if (controls.spotlighted) return 400;
  if (controls.presenter) return 300;
  if (controls.pinned) return 200;
  if (participant.role === 'host') return 100;
  if (participant.role === 'cohost') return 50;
  return 0;
}

function sortParticipants(items: Participant[]) {
  return [...items].sort((a, b) => {
    const statusOrder = (value: Participant['status']) => value === 'admitted' ? 0 : value === 'waiting' ? 1 : 2;
    const statusDiff = statusOrder(a.status) - statusOrder(b.status);
    if (statusDiff !== 0) return statusDiff;
    const roleOrder = (value: Participant['role']) => value === 'host' ? 0 : value === 'cohost' ? 1 : value === 'moderator' ? 2 : value === 'presenter' ? 3 : 4;
    const roleDiff = roleOrder(a.role) - roleOrder(b.role);
    if (roleDiff !== 0) return roleDiff;
    return (a.displayName || '').localeCompare(b.displayName || '');
  });
}

function roleLabel(participant: Participant) {
  if (participant.role === 'host') return 'Host';
  if (participant.role === 'cohost') return 'Co-host';
  if (participant.role === 'moderator') return 'Moderator';
  if (participant.role === 'presenter') return 'Presenter';
  if (participant.role === 'guest') return 'Guest';
  return 'Participant';
}

function hasParticipantManagement(participant: Participant) {
  if (participant.role === 'host') return true;
  if (participant.role !== 'cohost') return false;
  const permissions = participant.hostControls?.cohostPermissions || [];
  return permissions.includes('participants.manage');
}

function canAccessAdminSidePanels(participant: Participant) {
  if (participant.role === 'host') return true;
  if (participant.role !== 'cohost') return false;
  const permissions = participant.hostControls?.cohostPermissions || [];
  return permissions.includes('participants.manage') || permissions.includes('analytics.view') || permissions.includes('breakouts.manage');
}

function canAccessWhiteboardPanel(meeting: Meeting, participant: Participant) {
  if (participant.role === 'host' || participant.role === 'cohost') return true;
  if (participant.hostControls?.whiteboardRevoked) return false;
  return Boolean(meeting.allowWhiteboard || participant.hostControls?.whiteboardGranted);
}

function canRecordMeeting(participant: Participant) {
  if (participant.role === 'host') return true;
  if (participant.role !== 'cohost') return false;
  const permissions = participant.hostControls?.cohostPermissions || [];
  return permissions.includes('participants.manage') || permissions.includes('recording.start');
}

function canMeetingControl(participant: Participant, permission: string) {
  if (participant.role === 'host') return true;
  if (participant.role !== 'cohost') return false;
  const permissions = participant.hostControls?.cohostPermissions || [];
  return permissions.includes('participants.manage') || permissions.includes(permission);
}

function hasWaitingRoomManagement(participant: Participant) {
  if (participant.role === 'host') return true;
  if (participant.role !== 'cohost') return false;
  const permissions = participant.hostControls?.cohostPermissions || [];
  return permissions.includes('participants.manage') || permissions.includes('waiting.admit') || permissions.includes('waiting.reject') || permissions.includes('waiting.ban');
}

function ConnectionBadge() {
  const room = useRoomContext();
  return <span className="rounded-full bg-emerald-500/20 px-3 py-1 text-xs font-bold text-emerald-200">{room.state}</span>;
}

function MediaSubscriptionOptimizer({ activeScreenShareParticipantId, maxGalleryCameras }: { activeScreenShareParticipantId?: string | null; maxGalleryCameras: number }) {
  const room = useRoomContext();
  useEffect(() => {
    const apply = () => {
      const remotes = Array.from(room.remoteParticipants.values()) as any[];
      const activeSpeakers = new Set(room.activeSpeakers.map((speaker: any) => speaker.identity));
      remotes.forEach((participant: any, index: number) => {
        const publications = participant.trackPublications ? Array.from(participant.trackPublications.values()) as any[] : [];
        for (const publication of publications) {
          if (publication.source !== Track.Source.Camera) continue;
          let shouldSubscribe = true;
          if (activeScreenShareParticipantId) shouldSubscribe = participant.identity === activeScreenShareParticipantId;
          else if (remotes.length > maxGalleryCameras) shouldSubscribe = index < maxGalleryCameras || activeSpeakers.has(participant.identity);
          if (typeof publication.setVideoQuality === 'function') publication.setVideoQuality(shouldSubscribe && (activeScreenShareParticipantId ? participant.identity === activeScreenShareParticipantId : activeSpeakers.has(participant.identity)) ? VideoQuality.HIGH : VideoQuality.LOW);
          if (typeof publication.setSubscribed === 'function' && publication.isSubscribed !== shouldSubscribe) publication.setSubscribed(shouldSubscribe);
        }
      });
    };
    apply();
    const activeSpeakersEvent = (RoomEvent as any).ActiveSpeakersChanged;
    room.on(RoomEvent.ParticipantConnected, apply);
    room.on(RoomEvent.TrackPublished, apply);
    room.on(RoomEvent.TrackUnpublished, apply);
    room.on(RoomEvent.ParticipantDisconnected, apply);
    if (activeSpeakersEvent) room.on(activeSpeakersEvent, apply);
    return () => {
      room.off(RoomEvent.ParticipantConnected, apply);
      room.off(RoomEvent.TrackPublished, apply);
      room.off(RoomEvent.TrackUnpublished, apply);
      room.off(RoomEvent.ParticipantDisconnected, apply);
      if (activeSpeakersEvent) room.off(activeSpeakersEvent, apply);
      room.remoteParticipants.forEach((participant: any) => {
        const publications = participant.trackPublications ? Array.from(participant.trackPublications.values()) as any[] : [];
        publications.forEach((publication) => { if (publication.source === Track.Source.Camera && typeof publication.setSubscribed === 'function') publication.setSubscribed(true); });
      });
    };
  }, [room, activeScreenShareParticipantId, maxGalleryCameras]);
  return null;
}

function ControlEnforcer({ meeting, participantId, participantToken, inviteToken, onLeave, onMeetingUpdate, onParticipantUpdate, onLivekitMove }: { meeting: Meeting; participantId: string; participantToken?: string; inviteToken?: string; onLeave: () => void; onMeetingUpdate?: (meeting: Meeting) => void; onParticipantUpdate?: (participant: Participant) => void; onLivekitMove?: (livekit: { url: string; token: string; roomName: string }) => void }) {
  const room = useRoomContext();
  const lastQualityPayloadRef = useRef('');
  useEffect(() => {
    const report = () => {
      const connection = (navigator as any).connection;
      const payload = {
        quality: room.localParticipant.connectionQuality || 'unknown',
        online: navigator.onLine,
        networkType: connection?.effectiveType || connection?.type,
        effectiveType: connection?.effectiveType || connection?.type,
        downlink: connection?.downlink,
        downlinkMbps: connection?.downlink,
        rtt: connection?.rtt,
        rttMs: connection?.rtt,
        saveData: connection?.saveData,
        roomState: room.state,
        iceState: (room as any).engine?.pcManager?.currentState || undefined,
        selectedRegion: (participantToken ? undefined : 'admin'),
      };
      const signature = JSON.stringify(payload);
      if (signature === lastQualityPayloadRef.current) return;
      lastQualityPayloadRef.current = signature;
      if (participantToken && inviteToken) {
        api<{ participant: Participant }>(`/meetings/invitations/${inviteToken}/quality`, {
          method: 'POST', auth: false, headers: { Authorization: `Bearer ${participantToken}` }, body: JSON.stringify(payload),
        }).then((data) => onParticipantUpdate?.(data.participant)).catch(() => {});
        api(`/meetings/invitations/${inviteToken}/network-diagnostics`, {
          method: 'POST', auth: false, headers: { Authorization: `Bearer ${participantToken}` }, body: JSON.stringify(payload),
        }).catch(() => {});
      } else {
        api<{ participant: Participant }>(`/meetings/${meeting.id}/participants/${participantId}/preferences`, {
          method: 'PATCH', body: JSON.stringify({ qualityReport: payload }),
        }).then((data) => onParticipantUpdate?.(data.participant)).catch(() => {});
      }
    };
    report();
    const interval = window.setInterval(report, 30000);
    window.addEventListener('online', report);
    window.addEventListener('offline', report);
    return () => { window.clearInterval(interval); window.removeEventListener('online', report); window.removeEventListener('offline', report); };
  }, [meeting.id, participantId, participantToken, inviteToken, room, onParticipantUpdate]);
  useEffect(() => {
    const socket = getSocket(participantToken);
    socket.emit('meeting:watch', { meetingId: meeting.id });
    const controls = async (data: any) => {
      if (data.allowParticipantAudio === false) await room.localParticipant.setMicrophoneEnabled(false).catch(() => {});
      if (data.allowParticipantVideo === false) await room.localParticipant.setCameraEnabled(false).catch(() => {});
      if (data.allowScreenShare === false || data.screenSharePolicy) await room.localParticipant.setScreenShareEnabled(false).catch(() => {});
      if (data.meeting) onMeetingUpdate?.(data.meeting);
    };
    const hostControl = async (data: any) => {
      if (data.targetParticipantId && data.targetParticipantId !== participantId) return;
      if (['mute', 'disable_audio', 'disable_microphone'].includes(data.action)) await room.localParticipant.setMicrophoneEnabled(false).catch(() => {});
      if (data.action === 'ask_unmute') toast.info('The host is asking you to unmute your microphone.');
      if (['disable_video', 'disable_camera'].includes(data.action)) await room.localParticipant.setCameraEnabled(false).catch(() => {});
      if (['stop_screen_share', 'revoke_screen_share'].includes(data.action)) await room.localParticipant.setScreenShareEnabled(false).catch(() => {});
      if (data.action === 'grant_screen_share') toast.success('Screen sharing permission granted.');
      if (data.action === 'grant_whiteboard') toast.success('Whiteboard permission granted.');
      if (data.action === 'revoke_whiteboard') toast.info('Whiteboard permission revoked by host.');
      if (data.action === 'rename' && data.displayName) toast.info(`Your display name is now ${data.displayName}`);
      if (['remove', 'ban', 'move_waiting'].includes(data.action)) { room.disconnect(); onLeave(); }
    };
    const ended = () => { room.disconnect(); toast.info('Meeting ended by host'); onLeave(); };
    const updated = (next: Meeting) => { if (next.id === meeting.id) onMeetingUpdate?.(next); };
    const participantUpdated = (next: Participant) => { if (next.id === participantId) onParticipantUpdate?.(next); };
    const breakoutMove = (event: any) => { if (event.livekit) { toast.info(`Moving to ${event.room?.name || 'breakout room'}`); onLivekitMove?.(event.livekit); } };
    const breakoutReturn = (event: any) => { if (event.livekit) { toast.info('Returning to main room'); onLivekitMove?.(event.livekit); } };
    const breakoutBroadcast = (event: any) => { if (event.message) toast.info(event.message); };
    socket.on('meeting:controls', controls);
    socket.on('meeting:updated', updated);
    socket.on('participant:updated', participantUpdated);
    socket.on('host:control', hostControl);
    socket.on('meeting:ended', ended);
    socket.on('breakout:moved', breakoutMove);
    socket.on('breakout:return', breakoutReturn);
    socket.on('breakout:broadcast', breakoutBroadcast);
    return () => { socket.off('meeting:controls', controls); socket.off('meeting:updated', updated); socket.off('participant:updated', participantUpdated); socket.off('host:control', hostControl); socket.off('meeting:ended', ended); socket.off('breakout:moved', breakoutMove); socket.off('breakout:return', breakoutReturn); socket.off('breakout:broadcast', breakoutBroadcast); };
  }, [meeting.id, participantId, participantToken, room, onLeave, onMeetingUpdate, onParticipantUpdate, onLivekitMove]);
  return null;
}

function RoomControls({ meeting, participant, participantToken, inviteToken, pendingRequests, participantCount, panelOpen, activePanel, onOpenPanel, onTogglePanel, onLeave, onMeetingUpdate, onParticipantUpdate, onLivekitMove, onRecordingChange }: { meeting: Meeting; participant: Participant; participantToken?: string; inviteToken?: string; pendingRequests: number; participantCount: number; panelOpen: boolean; activePanel: SidePanel; onOpenPanel: (panel: SidePanel) => void; onTogglePanel: () => void; onLeave: () => void; onMeetingUpdate?: (meeting: Meeting) => void; onParticipantUpdate?: (participant: Participant) => void; onLivekitMove?: (livekit: { url: string; token: string; roomName: string }) => void; onRecordingChange?: (recording: boolean) => void }) {
  const room = useRoomContext();
  const [mic, setMic] = useState(room.localParticipant.isMicrophoneEnabled);
  const [camera, setCamera] = useState(room.localParticipant.isCameraEnabled);
  const [screen, setScreen] = useState(room.localParticipant.isScreenShareEnabled);
  const [lowBandwidth, setLowBandwidth] = useState(participant.lowBandwidthMode);
  const [audioOnly, setAudioOnly] = useState(participant.audioOnlyMode);
  const [handRaised, setHandRaised] = useState(Boolean(participant.hostControls?.handRaised));
  const [moreOpen, setMoreOpen] = useState(false);
  const [confirmEnd, setConfirmEnd] = useState(false);
  const [portalReady, setPortalReady] = useState(false);
  const pushToTalkRef = useRef(false);
  useEffect(() => { setHandRaised(Boolean(participant.hostControls?.handRaised)); }, [participant.hostControls?.handRaised]);
  useEffect(() => { setPortalReady(true); }, []);
  useEffect(() => {
    const syncLocalMediaState = () => {
      setMic(room.localParticipant.isMicrophoneEnabled);
      setCamera(room.localParticipant.isCameraEnabled);
      setScreen(room.localParticipant.isScreenShareEnabled);
    };
    syncLocalMediaState();
    room.on(RoomEvent.LocalTrackPublished, syncLocalMediaState);
    room.on(RoomEvent.LocalTrackUnpublished, syncLocalMediaState);
    room.on(RoomEvent.TrackMuted, syncLocalMediaState);
    room.on(RoomEvent.TrackUnmuted, syncLocalMediaState);
    room.on(RoomEvent.MediaDevicesChanged, syncLocalMediaState);
    return () => {
      room.off(RoomEvent.LocalTrackPublished, syncLocalMediaState);
      room.off(RoomEvent.LocalTrackUnpublished, syncLocalMediaState);
      room.off(RoomEvent.TrackMuted, syncLocalMediaState);
      room.off(RoomEvent.TrackUnmuted, syncLocalMediaState);
      room.off(RoomEvent.MediaDevicesChanged, syncLocalMediaState);
    };
  }, [room]);
  const [paused, setPaused] = useState(false);
  const [surface, setSurface] = useState<DisplaySurface>('monitor');
  function currentScreenShareSource(): ShareSource {
    const publication = room.localParticipant.getTrackPublication(Track.Source.ScreenShare);
    const track = (publication?.track as any)?.mediaStreamTrack as MediaStreamTrack | undefined;
    const displaySurface = String(track?.getSettings?.().displaySurface || '').toLowerCase();
    if (displaySurface === 'browser') return 'browser';
    if (displaySurface === 'window' || displaySurface === 'application') return 'window';
    return 'screen';
  }
  function sourceLabel(source: ShareSource) {
    if (source === 'screen') return 'entire screen/desktop';
    if (source === 'window') return 'application window';
    return 'browser tab';
  }
  async function sendScreenState(sharing: boolean, isPaused = false, src: ShareSource = 'screen') {
    const body = JSON.stringify({ sharing, paused: isPaused, source: src });
    if (participantToken && inviteToken) {
      const data = await api<{ meeting: Meeting }>(`/meetings/invitations/${inviteToken}/screen-share`, { method: 'POST', auth: false, headers: { Authorization: `Bearer ${participantToken}` }, body });
      onMeetingUpdate?.(data.meeting);
    } else {
      const data = await api<{ meeting: Meeting }>(`/meetings/${meeting.id}/participants/${participant.id}/screen-share`, { method: 'POST', body });
      onMeetingUpdate?.(data.meeting);
    }
  }
  function canStartScreen() {
    if (participant.screenShareDisabled || participant.hostControls?.screenShareRevoked) return false;
    if (participant.hostControls?.screenShareGranted) return true;
    if (!meeting.allowScreenShare) return false;
    if (meeting.screenSharePolicy === 'host') return participant.role === 'host';
    if (meeting.screenSharePolicy === 'cohosts') return participant.role === 'host' || participant.role === 'cohost';
    return true;
  }
  async function toggleMic() {
    if (!mic && !meeting.allowParticipantAudio && participant.role === 'participant') return toast.error('Microphones are disabled by host');
    try {
      const next = !mic;
      await room.localParticipant.setMicrophoneEnabled(next, { deviceId: undefined, echoCancellation: true, noiseSuppression: true });
      const enabled = room.localParticipant.isMicrophoneEnabled;
      setMic(enabled);
      updatePreferences({ microphoneEnabled: enabled }).catch(() => {});
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Microphone could not be changed');
    }
  }
  async function toggleCamera() {
    if (!camera && !meeting.allowParticipantVideo && participant.role === 'participant') return toast.error('Cameras are disabled by host');
    try {
      const next = !camera;
      await room.localParticipant.setCameraEnabled(next);
      const enabled = room.localParticipant.isCameraEnabled;
      setCamera(enabled);
      updatePreferences({ cameraEnabled: enabled }).catch(() => {});
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Camera could not be changed');
    }
  }
  async function startShare(_selected: DisplaySurface = surface) {
    if (!canStartScreen()) return toast.error('Screen sharing is not allowed by host policy');
    toast.info('Choose Entire Screen in the browser picker if you want the recording to include PowerPoint, PDF, Excel, VS Code, File Explorer, other tabs, and app switching.');
    await room.localParticipant.setScreenShareEnabled(true, { audio: true, video: { frameRate: { ideal: 24, max: 30 } } as any, surfaceSwitching: 'include', systemAudio: 'include', selfBrowserSurface: 'include', contentHint: 'detail' });
    const actualSource = currentScreenShareSource();
    setScreen(true); setPaused(false); setSurface(actualSource === 'screen' ? 'monitor' : actualSource);
    toast.success(`Sharing ${sourceLabel(actualSource)}. Recording will use this exact shared source.`);
    await sendScreenState(true, false, actualSource);
  }
  async function stopShare() {
    const actualSource = currentScreenShareSource();
    await room.localParticipant.setScreenShareEnabled(false);
    setScreen(false); setPaused(false);
    await sendScreenState(false, false, actualSource);
  }
  async function pauseShare() {
    const publication = room.localParticipant.getTrackPublication(Track.Source.ScreenShare);
    const track = publication?.track as any;
    if (track?.mute) await track.mute();
    setPaused(true);
    await sendScreenState(true, true, currentScreenShareSource());
  }
  async function resumeShare() {
    const publication = room.localParticipant.getTrackPublication(Track.Source.ScreenShare);
    const track = publication?.track as any;
    if (track?.unmute) await track.unmute();
    setPaused(false);
    await sendScreenState(true, false, currentScreenShareSource());
  }
  async function switchShare(nextSurface?: DisplaySurface) {
    if (nextSurface) setSurface(nextSurface);
    if (screen) await room.localParticipant.setScreenShareEnabled(false);
    await startShare(nextSurface || surface);
  }
  async function changeLayout(layout: Layout) {
    if (!canMeetingControl(participant, 'presenter.change')) return toast.error('Layout control permission has not been granted');
    const path = participantToken && inviteToken ? `/meetings/invitations/${inviteToken}/controls` : `/meetings/${meeting.id}/controls`;
    const data = await api<{ meeting: Meeting }>(path, { method: 'PATCH', auth: !(participantToken && inviteToken), headers: participantToken && inviteToken ? { Authorization: `Bearer ${participantToken}` } : undefined, body: JSON.stringify({ presenterLayout: layout }) });
    onMeetingUpdate?.(data.meeting);
  }
  async function updatePreferences(next: { lowBandwidthMode?: boolean; audioOnlyMode?: boolean; preferredLayout?: 'auto' | 'mobile' | 'gallery' | 'speaker'; microphoneEnabled?: boolean; cameraEnabled?: boolean; handRaised?: boolean }) {
    const body = JSON.stringify(next);
    const path = participantToken && inviteToken ? `/meetings/invitations/${inviteToken}/preferences` : `/meetings/${meeting.id}/participants/${participant.id}/preferences`;
    const data = await api<{ participant: Participant; livekit?: { url: string; token: string; roomName: string } }>(path, { method: 'PATCH', auth: !(participantToken && inviteToken), headers: participantToken && inviteToken ? { Authorization: `Bearer ${participantToken}` } : undefined, body });
    onParticipantUpdate?.(data.participant);
    setLowBandwidth(data.participant.lowBandwidthMode);
    setAudioOnly(data.participant.audioOnlyMode);
    if (data.participant.audioOnlyMode) {
      await room.localParticipant.setCameraEnabled(false).catch(() => {});
      await room.localParticipant.setScreenShareEnabled(false).catch(() => {});
      setCamera(false); setScreen(false);
    }
    if (typeof data.participant.hostControls?.handRaised === 'boolean') setHandRaised(data.participant.hostControls.handRaised);
    if (data.livekit) onLivekitMove?.(data.livekit);
  }
  async function toggleHand() {
    const next = !handRaised;
    setHandRaised(next);
    try {
      await updatePreferences({ handRaised: next });
      toast.success(next ? 'Hand raised' : 'Hand lowered');
    } catch (err) {
      setHandRaised(!next);
      toast.error(err instanceof Error ? err.message : 'Could not update hand status');
    }
  }
  async function toggleLockMeeting() {
    if (!canMeetingControl(participant, 'meeting.lock')) return toast.error('Lock meeting permission has not been granted');
    try {
      const path = participantToken && inviteToken ? `/meetings/invitations/${inviteToken}/controls` : `/meetings/${meeting.id}/controls`;
      const data = await api<{ meeting: Meeting }>(path, { method: 'PATCH', auth: !(participantToken && inviteToken), headers: participantToken && inviteToken ? { Authorization: `Bearer ${participantToken}` } : undefined, body: JSON.stringify({ isLocked: !meeting.isLocked }) });
      onMeetingUpdate?.(data.meeting);
      toast.success(data.meeting.isLocked ? 'Meeting locked' : 'Meeting unlocked');
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Meeting lock failed');
    }
  }
  async function endMeetingForEveryone() {
    if (!canMeetingControl(participant, 'meeting.end')) return leave();
    try {
      const path = participantToken && inviteToken ? `/meetings/invitations/${inviteToken}/end` : `/meetings/${meeting.id}/end`;
      const data = await api<{ meeting: Meeting }>(path, { method: 'POST', auth: !(participantToken && inviteToken), headers: participantToken && inviteToken ? { Authorization: `Bearer ${participantToken}` } : undefined });
      onMeetingUpdate?.(data.meeting);
      setConfirmEnd(false);
      room.disconnect();
      onLeave();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Could not end meeting');
    }
  }
  function leave() { room.disconnect(); onLeave(); }
  const canOpenRequests = hasWaitingRoomManagement(participant);
  const canLockMeeting = canMeetingControl(participant, 'meeting.lock');
  const canEndMeeting = canMeetingControl(participant, 'meeting.end');
  const canHostControlMeeting = canLockMeeting || canEndMeeting;
  useEffect(() => {
    const editable = () => {
      const active = document.activeElement;
      return Boolean(active && ['INPUT', 'TEXTAREA', 'SELECT'].includes(active.tagName));
    };
    const down = async (event: KeyboardEvent) => {
      if (editable() || event.repeat) return;
      const key = event.key.toLowerCase();
      if (event.code === 'Space' && !mic) {
        event.preventDefault();
        pushToTalkRef.current = true;
        await room.localParticipant.setMicrophoneEnabled(true, { echoCancellation: true, noiseSuppression: true }).catch(() => undefined);
        setMic(room.localParticipant.isMicrophoneEnabled);
        return;
      }
      if (key === 'm') toggleMic();
      if (key === 'v') toggleCamera();
      if (key === 'h') toggleHand();
      if (key === 'c') onOpenPanel('chat');
      if (key === 'p') onOpenPanel('participants');
      if (key === 's') screen ? stopShare() : startShare(surface);
    };
    const up = async (event: KeyboardEvent) => {
      if (event.code === 'Space' && pushToTalkRef.current) {
        event.preventDefault();
        pushToTalkRef.current = false;
        await room.localParticipant.setMicrophoneEnabled(false).catch(() => undefined);
        setMic(room.localParticipant.isMicrophoneEnabled);
      }
    };
    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    return () => { window.removeEventListener('keydown', down); window.removeEventListener('keyup', up); };
  }, [mic, screen, surface, room, onOpenPanel]);
  return (
    <footer className="relative flex items-stretch justify-center gap-2 overflow-x-auto rounded-3xl border border-white/10 bg-[#0b0f17]/95 p-2 shadow-2xl backdrop-blur-xl sm:p-3">
      <StartAudio label="Enable audio" className="inline-flex min-w-[86px] flex-col items-center justify-center gap-1 rounded-2xl bg-emerald-600 px-3 py-2 text-xs font-black text-white"><Volume2 size={20}/>Audio</StartAudio>
      <ToolbarButton active={!mic} danger={!mic} icon={mic ? <Mic size={21}/> : <MicOff size={21}/>} label={mic ? 'Mute' : 'Unmute'} onClick={toggleMic} />
      <ToolbarButton active={!camera} danger={!camera} icon={camera ? <Video size={21}/> : <VideoOff size={21}/>} label={camera ? 'Stop Video' : 'Start Video'} onClick={toggleCamera} />
      {canLockMeeting && <ToolbarButton active={meeting.isLocked} icon={<ShieldCheck size={21}/>} label={meeting.isLocked ? 'Unlock' : 'Security'} onClick={toggleLockMeeting} />}
      <ToolbarButton active={panelOpen && activePanel === 'participants'} icon={<Users size={21}/>} label="Participants" badge={participantCount} onClick={() => onOpenPanel('participants')} />
      {canOpenRequests && <ToolbarButton active={panelOpen && activePanel === 'requests'} icon={<UserCheck size={21}/>} label="Requests" badge={pendingRequests} urgent={pendingRequests > 0} onClick={() => onOpenPanel('requests')} />}
      <ToolbarButton active={panelOpen && activePanel === 'chat'} icon={<MessageSquare size={21}/>} label="Chat" onClick={() => onOpenPanel('chat')} />
      {!screen ? <ToolbarButton active={screen} icon={<MonitorUp size={21}/>} label="Share Screen" onClick={() => startShare(surface)} /> : <ToolbarButton active danger icon={<ScreenShare size={21}/>} label="Stop Share" onClick={stopShare} />}
      {screen && (!paused ? <ToolbarButton icon={<Pause size={21}/>} label="Pause" onClick={pauseShare} /> : <ToolbarButton icon={<Play size={21}/>} label="Resume" onClick={resumeShare} />)}
      {canRecordMeeting(participant) && <RecordingControls meeting={meeting} participant={participant} participantToken={participantToken} inviteToken={inviteToken} onRecordingChange={onRecordingChange} />}
      <ToolbarButton active={handRaised} icon={<Hand size={21}/>} label={handRaised ? 'Lower Hand' : 'Raise Hand'} onClick={toggleHand} />
      <ToolbarButton icon={<MoreHorizontal size={21}/>} label="More" onClick={() => setMoreOpen((value) => !value)} />
      <ToolbarButton danger icon={canEndMeeting ? <PhoneOff size={21}/> : <LogOut size={21}/>} label={canEndMeeting ? 'End Meeting' : 'Leave'} onClick={() => canEndMeeting ? setConfirmEnd(true) : leave()} />

      {portalReady && moreOpen && createPortal(<div className="fixed inset-0 z-[9999]" onClick={() => setMoreOpen(false)}>
        <div className="absolute bottom-24 right-4 w-80 max-w-[calc(100vw-2rem)] rounded-3xl border border-white/10 bg-slate-950 p-3 text-sm text-white shadow-2xl" onClick={(event) => event.stopPropagation()}>
          <div className="mb-2 flex items-center justify-between"><p className="font-black">More options</p><button onClick={() => setMoreOpen(false)} className="rounded-xl bg-white/10 p-1"><ChevronDown size={15}/></button></div>
          <div className="rounded-2xl bg-amber-500/10 p-3 text-xs leading-relaxed text-amber-100"><p className="font-black">Screen recording source</p><p className="mt-1">The browser's native picker controls what is shared and recorded. Choose <b>Entire Screen</b> to record desktop/app switching. Choose Window or Tab only if you want to limit recording to that source.</p></div>
          <button onClick={() => switchShare(surface)} className="mt-2 inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-white/10 px-3 py-2 font-bold"><RotateCcw size={16}/>{screen ? 'Switch shared source' : 'Choose screen/window/tab'}</button>
          <div className="mt-3 grid grid-cols-2 gap-2"><button onClick={() => updatePreferences({ lowBandwidthMode: !lowBandwidth, audioOnlyMode: !lowBandwidth ? true : audioOnly })} className={`rounded-2xl px-3 py-3 text-sm font-semibold ${lowBandwidth ? 'bg-amber-600' : 'bg-white/10'}`}>Low data {lowBandwidth ? 'on' : 'off'}</button><button onClick={() => updatePreferences({ audioOnlyMode: !audioOnly })} className={`rounded-2xl px-3 py-3 text-sm font-semibold ${audioOnly ? 'bg-amber-600' : 'bg-white/10'}`}>Audio only {audioOnly ? 'on' : 'off'}</button></div>
          {(participant.role === 'host' || participant.role === 'cohost') && <div className="mt-3 grid gap-2"><p className="text-xs font-bold text-slate-400">Layout</p><button onClick={() => changeLayout('presenter')} className="inline-flex items-center gap-2 rounded-2xl bg-white/10 px-3 py-2 font-bold"><Expand size={16}/>Presenter</button><button onClick={() => changeLayout('side_by_side')} className="inline-flex items-center gap-2 rounded-2xl bg-white/10 px-3 py-2 font-bold"><Columns2 size={16}/>Side by side</button><button onClick={() => changeLayout('gallery')} className="inline-flex items-center gap-2 rounded-2xl bg-white/10 px-3 py-2 font-bold"><Grid2X2 size={16}/>Gallery</button></div>}
          <button onClick={onTogglePanel} className="mt-3 inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-white/10 px-3 py-2 font-bold">{panelOpen ? <PanelRightClose size={16}/> : <PanelRightOpen size={16}/>} {panelOpen ? 'Hide side panel' : 'Show side panel'}</button>
        </div>
      </div>, document.body)}

      {confirmEnd && <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4">
        <div className="w-full max-w-md rounded-4xl border border-white/10 bg-slate-950 p-5 shadow-2xl">
          <h3 className="text-lg font-black text-rose-100">End meeting for everyone?</h3>
          <p className="mt-2 text-sm text-slate-400">All participants and waiting-room requests will be disconnected or marked left.</p>
          <div className="mt-5 flex justify-end gap-2"><button type="button" onClick={() => setConfirmEnd(false)} className="rounded-2xl bg-white/10 px-4 py-2 font-bold">Cancel</button><button type="button" onClick={endMeetingForEveryone} className="rounded-2xl bg-rose-600 px-4 py-2 font-bold">End meeting</button></div>
        </div>
      </div>}
    </footer>
  );
}

function ToolbarButton({ icon, label, onClick, active = false, danger = false, badge, urgent = false }: { icon: ReactNode; label: string; onClick: () => void; active?: boolean; danger?: boolean; badge?: number; urgent?: boolean }) {
  return (
    <button type="button" onClick={onClick} className={`relative inline-flex min-w-[86px] flex-col items-center justify-center gap-1 rounded-2xl px-3 py-2 text-xs font-black transition ${danger ? 'bg-rose-600 text-white hover:bg-rose-500' : active ? 'bg-brand-600 text-white' : 'bg-white/10 text-slate-100 hover:bg-white/15'}`} title={label} aria-label={label}>
      {icon}
      <span className="whitespace-nowrap">{label}</span>
      {typeof badge === 'number' && <span className={`absolute -right-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full px-1 text-[11px] font-black ${urgent ? 'bg-rose-500 text-white' : 'bg-white/20 text-white'}`}>{badge}</span>}
    </button>
  );
}
