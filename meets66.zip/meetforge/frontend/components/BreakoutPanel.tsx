'use client';

import { Megaphone, Plus, RefreshCcw, Send, Shuffle, Undo2, Users, XCircle } from 'lucide-react';
import { useEffect, useState } from 'react';
import { toast } from 'sonner';
import { BreakoutRoom, Meeting, Participant, api } from '@/lib/api';
import { getSocket } from '@/lib/socket';

type Props = {
  meeting: Meeting;
  participant: Participant;
  participantToken?: string;
  inviteToken?: string;
};

type BreakoutList = { items: BreakoutRoom[]; participants: Participant[]; total: number };

export function BreakoutPanel({ meeting, participant, participantToken, inviteToken }: Props) {
  const [rooms, setRooms] = useState<BreakoutRoom[]>([]);
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [count, setCount] = useState(2);
  const [timerMinutes, setTimerMinutes] = useState(15);
  const [selected, setSelected] = useState<Record<string, string>>({});
  const [messages, setMessages] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const canManage = participant.role === 'host' || participant.role === 'cohost';
  const isCohostRoute = Boolean(participantToken && inviteToken && participant.role !== 'host');
  const base = isCohostRoute ? `/meetings/invitations/${inviteToken}/breakout-rooms` : `/meetings/${meeting.id}/breakout-rooms`;
  const authHeaders = participantToken && isCohostRoute ? { Authorization: `Bearer ${participantToken}` } : undefined;

  async function load() {
    if (!canManage) return;
    const data = await api<BreakoutList>(base, { auth: !isCohostRoute, headers: authHeaders });
    setRooms(data.items);
    setParticipants(data.participants.filter((p) => p.status === 'admitted' && p.role !== 'host'));
  }

  useEffect(() => {
    load().catch(() => {});
    const socket = getSocket(participantToken);
    socket.emit('meeting:watch', { meetingId: meeting.id });
    const update = (data: BreakoutList) => { setRooms(data.items || []); if (data.participants) setParticipants(data.participants.filter((p) => p.status === 'admitted' && p.role !== 'host')); };
    socket.on('breakout:updated', update);
    return () => { socket.off('breakout:updated', update); };
  }, [meeting.id, participantToken, inviteToken, participant.role]);

  async function post(path: string, body: Record<string, unknown> = {}) {
    setLoading(true);
    try {
      const data = await api<any>(`${base}${path}`, { method: 'POST', auth: !isCohostRoute, headers: authHeaders, body: JSON.stringify(body) });
      if (data.items) setRooms(data.items);
      else await load();
      toast.success('Breakout rooms updated');
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Breakout action failed');
    } finally {
      setLoading(false);
    }
  }

  if (!canManage) return <aside className="flex h-full min-h-0 flex-col rounded-4xl border border-white/10 bg-slate-950/90 p-4 text-white"><h3 className="font-bold">Breakout rooms</h3><p className="mt-3 text-sm text-slate-400">Only host and co-hosts can manage breakout rooms.</p></aside>;

  return (
    <aside className="flex h-full min-h-0 flex-col rounded-4xl border border-white/10 bg-slate-950/90 p-4 text-white shadow-2xl backdrop-blur-xl">
      <div className="mb-3 flex items-center justify-between"><div><h3 className="font-bold">Breakout rooms</h3><p className="text-xs text-slate-400">Create, assign, move, broadcast, close, and return participants</p></div><button onClick={() => load().catch(()=>{})} className="rounded-xl bg-white/10 p-2"><RefreshCcw size={16}/></button></div>
      <div className="mb-3 grid grid-cols-2 gap-2 text-xs">
        <label className="rounded-xl bg-white/10 p-2">Rooms<input type="number" min={1} max={20} value={count} onChange={(e)=>setCount(Number(e.target.value))} className="mt-1 w-full rounded-lg bg-slate-900 px-2 py-1"/></label>
        <label className="rounded-xl bg-white/10 p-2">Timer min<input type="number" min={0} max={240} value={timerMinutes} onChange={(e)=>setTimerMinutes(Number(e.target.value))} className="mt-1 w-full rounded-lg bg-slate-900 px-2 py-1"/></label>
        <button disabled={loading} onClick={()=>post('', { count, timerMinutes })} className="rounded-xl bg-brand-600 px-3 py-2 font-bold"><Plus className="mr-1 inline" size={14}/>Create</button>
        <button disabled={loading || !rooms.length} onClick={()=>post('/auto-assign')} className="rounded-xl bg-white/10 px-3 py-2 font-bold"><Shuffle className="mr-1 inline" size={14}/>Auto assign</button>
        <button disabled={loading || !rooms.length} onClick={()=>post('/return-all')} className="col-span-2 rounded-xl bg-amber-600 px-3 py-2 font-bold"><Undo2 className="mr-1 inline" size={14}/>Return all to main room</button>
      </div>
      <div className="min-h-0 flex-1 space-y-3 overflow-auto">
        {rooms.map((room) => (
          <div key={room.id} className="rounded-2xl bg-white/10 p-3">
            <div className="mb-2 flex items-start justify-between gap-2"><div><p className="font-semibold">{room.name}</p><p className="text-xs text-slate-400">{room.status} · {room.assignedCount} assigned · {room.activeCount} active{room.timerEndsAt ? ` · ends ${new Date(room.timerEndsAt).toLocaleTimeString()}` : ''}</p></div><button onClick={()=>post(`/${room.id}/close`)} className="rounded-lg bg-rose-700 p-2"><XCircle size={14}/></button></div>
            <div className="mb-2 flex gap-2"><select value={selected[room.id] || ''} onChange={(e)=>setSelected({...selected, [room.id]: e.target.value})} className="min-w-0 flex-1 rounded-xl bg-slate-900 px-2 py-2 text-xs"><option value="">Select participant</option>{participants.map((p)=><option key={p.id} value={p.id}>{p.displayName} ({p.role})</option>)}</select><button disabled={!selected[room.id]} onClick={()=>post(`/${room.id}/assign`, { participantIds: [selected[room.id]] })} className="rounded-xl bg-white/10 px-3 py-2 text-xs"><Users size={13}/></button><button disabled={!selected[room.id]} onClick={()=>post(`/${room.id}/move`, { participantIds: [selected[room.id]] })} className="rounded-xl bg-brand-600 px-3 py-2 text-xs"><Send size={13}/></button></div>
            <div className="mb-2 flex gap-2"><input value={messages[room.id] || ''} onChange={(e)=>setMessages({...messages, [room.id]: e.target.value})} placeholder="Broadcast message" className="min-w-0 flex-1 rounded-xl bg-slate-900 px-3 py-2 text-xs"/><button disabled={!messages[room.id]?.trim()} onClick={()=>post(`/${room.id}/broadcast`, { message: messages[room.id] })} className="rounded-xl bg-white/10 px-3 py-2 text-xs"><Megaphone size={13}/></button></div>
            <div className="space-y-1">{room.assignments.map((a)=><div key={a.id} className="rounded-lg bg-slate-900/70 px-2 py-1 text-xs">{a.participant?.displayName || a.participantId} · {a.status}</div>)}</div>
          </div>
        ))}
        {!rooms.length && <p className="py-8 text-center text-sm text-slate-500">No breakout rooms yet.</p>}
      </div>
    </aside>
  );
}
