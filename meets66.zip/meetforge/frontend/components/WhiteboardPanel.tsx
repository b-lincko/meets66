'use client';

import { Download, Eraser, Highlighter, Image as ImageIcon, MousePointer2, Pencil, Redo2, Shapes, StickyNote, Type, Undo2 } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { toast } from 'sonner';
import { API_URL, Meeting, Participant, WhiteboardElement, api, getAccessToken } from '@/lib/api';
import { getSocket } from '@/lib/socket';

type Tool = 'pen' | 'highlighter' | 'line' | 'rect' | 'ellipse' | 'text' | 'sticky' | 'flow_rect' | 'flow_diamond' | 'uml_class' | 'mind_node' | 'image' | 'laser';

type Props = {
  meeting: Meeting;
  participant: Participant;
  participantToken?: string;
  inviteToken?: string;
};

const width = 1280;
const height = 720;

export function WhiteboardPanel({ meeting, participant, participantToken, inviteToken }: Props) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [elements, setElements] = useState<WhiteboardElement[]>([]);
  const [tool, setTool] = useState<Tool>('pen');
  const [color, setColor] = useState('#0ea5e9');
  const [lineWidth, setLineWidth] = useState(4);
  const [drawing, setDrawing] = useState(false);
  const [textDraft, setTextDraft] = useState<{ tool: 'text' | 'sticky' | 'flow_rect' | 'flow_diamond' | 'uml_class' | 'mind_node'; x: number; y: number; text: string } | null>(null);
  const pointsRef = useRef<{x:number;y:number}[]>([]);
  const startRef = useRef<{x:number;y:number} | null>(null);
  const isParticipant = Boolean(participantToken && inviteToken);
  const base = isParticipant ? `/meetings/invitations/${inviteToken}/whiteboard` : `/meetings/${meeting.id}/whiteboard`;
  const authHeaders = participantToken ? { Authorization: `Bearer ${participantToken}` } : undefined;
  const whiteboardGranted = Boolean(participant.hostControls?.whiteboardGranted);
  const whiteboardRevoked = Boolean(participant.hostControls?.whiteboardRevoked);
  const allowed = participant.role === 'host' || participant.role === 'cohost' || (!whiteboardRevoked && (meeting.allowWhiteboard || whiteboardGranted));

  useEffect(() => {
    api<{items: WhiteboardElement[]; total: number}>(`${base}/elements`, { auth: !isParticipant, headers: authHeaders }).then((data) => setElements(data.items)).catch(() => {});
    const socket = getSocket(participantToken);
    socket.emit('meeting:watch', { meetingId: meeting.id });
    const onElement = (element: WhiteboardElement) => setElements((prev) => {
      const next = prev.some((item) => item.id === element.id) ? prev.map((item) => item.id === element.id ? element : item) : [...prev, element];
      return next.filter((item) => item.active).sort((a,b) => a.zIndex - b.zIndex);
    });
    const onLaser = (event: {x: number; y: number; displayName: string}) => drawLaser(event.x, event.y, event.displayName);
    socket.on('whiteboard:element', onElement);
    socket.on('whiteboard:laser', onLaser);
    return () => { socket.off('whiteboard:element', onElement); socket.off('whiteboard:laser', onLaser); };
  }, [meeting.id, participantToken, inviteToken]);

  useEffect(() => { redraw(); }, [elements]);

  function ctx() { return canvasRef.current?.getContext('2d'); }
  function pos(e: React.PointerEvent<HTMLCanvasElement>) {
    const rect = e.currentTarget.getBoundingClientRect();
    return { x: Math.round((e.clientX - rect.left) * width / rect.width), y: Math.round((e.clientY - rect.top) * height / rect.height) };
  }
  function drawElement(context: CanvasRenderingContext2D, element: WhiteboardElement) {
    const p = element.payload;
    context.save();
    context.strokeStyle = p.color || '#0ea5e9';
    context.fillStyle = p.color || '#0ea5e9';
    context.lineWidth = p.width || 4;
    context.lineCap = 'round';
    context.lineJoin = 'round';
    if (element.elementType === 'highlighter') { context.globalAlpha = 0.35; context.lineWidth = p.width || 14; }
    if (['pen','highlighter'].includes(element.elementType)) {
      const pts = p.points || [];
      context.beginPath(); pts.forEach((pt: any, i: number) => i ? context.lineTo(pt.x, pt.y) : context.moveTo(pt.x, pt.y)); context.stroke();
    } else if (element.elementType === 'line') { context.beginPath(); context.moveTo(p.x,p.y); context.lineTo(p.x+p.w,p.y+p.h); context.stroke(); }
    else if (element.elementType === 'rect') context.strokeRect(p.x,p.y,p.w,p.h);
    else if (element.elementType === 'ellipse') { context.beginPath(); context.ellipse(p.x+p.w/2,p.y+p.h/2,Math.abs(p.w/2),Math.abs(p.h/2),0,0,Math.PI*2); context.stroke(); }
    else if (element.elementType === 'text') { context.font = `${p.size || 24}px sans-serif`; context.fillText(p.text || '', p.x, p.y); }
    else if (element.elementType === 'sticky') { context.fillStyle = p.fill || '#fef08a'; roundRect(context,p.x,p.y,p.w||180,p.h||120,12,true); context.fillStyle = '#1e293b'; context.font = '18px sans-serif'; wrapText(context, p.text || '', p.x+12, p.y+28, (p.w||180)-24, 22); }
    else if (element.elementType === 'flow_rect') { roundRect(context,p.x,p.y,p.w||180,p.h||90,10,false); context.font='18px sans-serif'; context.fillText(p.text || 'Process', p.x+12, p.y+(p.h||90)/2); }
    else if (element.elementType === 'flow_diamond') { const x=p.x,y=p.y,w=p.w||160,h=p.h||100; context.beginPath(); context.moveTo(x+w/2,y); context.lineTo(x+w,y+h/2); context.lineTo(x+w/2,y+h); context.lineTo(x,y+h/2); context.closePath(); context.stroke(); context.font='16px sans-serif'; context.fillText(p.text || 'Decision', x+24, y+h/2); }
    else if (element.elementType === 'uml_class') { const x=p.x,y=p.y,w=p.w||220,h=p.h||150; context.strokeRect(x,y,w,h); context.beginPath(); context.moveTo(x,y+40); context.lineTo(x+w,y+40); context.moveTo(x,y+85); context.lineTo(x+w,y+85); context.stroke(); context.font='18px sans-serif'; context.fillText(p.text || 'Class', x+10, y+25); }
    else if (element.elementType === 'mind_node') { const x=p.x,y=p.y,w=p.w||180,h=p.h||80; context.beginPath(); context.ellipse(x+w/2,y+h/2,Math.abs(w/2),Math.abs(h/2),0,0,Math.PI*2); context.stroke(); context.font='18px sans-serif'; context.fillText(p.text || 'Idea', x+25, y+h/2); }
    else if (element.elementType === 'image') { const img = new Image(); img.onload = () => { context.drawImage(img,p.x,p.y,p.w||320,p.h||240); }; img.src = p.dataUrl; }
    context.restore();
  }
  function redraw() {
    const context = ctx(); if (!context) return;
    context.clearRect(0,0,width,height); context.fillStyle = '#fff'; context.fillRect(0,0,width,height);
    elements.filter(e => e.active).sort((a,b) => a.zIndex - b.zIndex).forEach((e) => drawElement(context, e));
  }
  function drawLaser(x: number, y: number, name: string) {
    redraw(); const context = ctx(); if (!context) return;
    context.save(); context.fillStyle = '#ef4444'; context.beginPath(); context.arc(x,y,10,0,Math.PI*2); context.fill(); context.font='16px sans-serif'; context.fillText(name, x+14, y+4); context.restore();
    window.setTimeout(redraw, 500);
  }
  async function save(elementType: Tool, payload: Record<string, any>) {
    if (!allowed || elementType === 'laser') return;
    try {
      const data = await api<{element: WhiteboardElement}>(`${base}/elements`, { method: 'POST', auth: !isParticipant, headers: authHeaders, body: JSON.stringify({ elementType, payload }) });
      setElements((prev) => [...prev, data.element].filter((item) => item.active).sort((a,b) => a.zIndex - b.zIndex));
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Whiteboard update failed'); }
  }
  function down(e: React.PointerEvent<HTMLCanvasElement>) {
    if (!allowed) return;
    const p = pos(e);
    if (['text','sticky','flow_rect','flow_diamond','uml_class','mind_node'].includes(tool)) {
      setTextDraft({ tool: tool as any, x: p.x, y: p.y, text: '' });
      return;
    }
    if (tool === 'laser') { getSocket(participantToken).emit('whiteboard:laser', { meetingId: meeting.id, x:p.x, y:p.y }); drawLaser(p.x,p.y,participant.displayName); return; }
    pointsRef.current = [p]; startRef.current = p; setDrawing(true);
  }
  function move(e: React.PointerEvent<HTMLCanvasElement>) {
    if (!drawing || !allowed) return;
    const p = pos(e); const context = ctx(); if (!context) return;
    if (tool === 'pen' || tool === 'highlighter') { pointsRef.current.push(p); redraw(); drawElement(context, { id:'preview', meetingId:meeting.id, actorDisplayName:participant.displayName, elementType:tool, payload:{ points:pointsRef.current, color, width: lineWidth }, zIndex:999999, active:true, createdAt:'', updatedAt:'' } as WhiteboardElement); }
    else if (startRef.current && ['line','rect','ellipse'].includes(tool)) { const s=startRef.current; redraw(); drawElement(context, { id:'preview', meetingId:meeting.id, actorDisplayName:participant.displayName, elementType:tool, payload:{ x:s.x, y:s.y, w:p.x-s.x, h:p.y-s.y, color, width:lineWidth }, zIndex:999999, active:true, createdAt:'', updatedAt:'' } as WhiteboardElement); }
  }
  function up(e: React.PointerEvent<HTMLCanvasElement>) {
    if (!drawing || !allowed) return;
    setDrawing(false); const p = pos(e); const s = startRef.current;
    if (tool === 'pen' || tool === 'highlighter') save(tool, { points: pointsRef.current, color, width: lineWidth });
    else if (s && ['line','rect','ellipse'].includes(tool)) save(tool, { x:s.x, y:s.y, w:p.x-s.x, h:p.y-s.y, color, width: lineWidth });
    startRef.current = null; pointsRef.current = [];
  }
  async function undoRedo(kind: 'undo' | 'redo') {
    const data = await api<{element: WhiteboardElement | null}>(`${base}/${kind}`, { method:'POST', auth: !isParticipant, headers: authHeaders });
    if (data.element) setElements((prev) => kind === 'undo' ? prev.filter((item) => item.id !== data.element!.id) : [...prev, data.element!].filter((item) => item.active).sort((a,b)=>a.zIndex-b.zIndex));
  }
  async function exportFile(kind: 'png' | 'pdf' | 'svg') {
    const res = await fetch(`${API_URL}/meetings/${meeting.id}/whiteboard/export.${kind}`, { headers: { Authorization: `Bearer ${getAccessToken()}` } });
    if (!res.ok) return toast.error('Export failed');
    const url = URL.createObjectURL(await res.blob()); const a=document.createElement('a'); a.href=url; a.download=`whiteboard.${kind}`; a.click(); URL.revokeObjectURL(url);
  }
  async function imageSelected(file?: File) {
    if (!file) return; const reader = new FileReader(); reader.onload = () => save('image', { x:80, y:80, w:320, h:240, dataUrl: reader.result }); reader.readAsDataURL(file);
  }
  async function submitTextDraft(e: React.FormEvent) {
    e.preventDefault();
    if (!textDraft || textDraft.text.trim().length < 1) return;
    const sizes: Record<string, {w:number;h:number}> = { sticky:{w:220,h:140}, flow_rect:{w:200,h:90}, flow_diamond:{w:180,h:110}, uml_class:{w:240,h:160}, mind_node:{w:190,h:90}, text:{w:0,h:0} };
    await save(textDraft.tool, { x:textDraft.x, y:textDraft.y, text:textDraft.text.trim(), color, fill:'#fef08a', w:sizes[textDraft.tool].w, h:sizes[textDraft.tool].h, size:24 });
    setTextDraft(null);
  }
  return (
    <aside className="flex h-full min-h-0 flex-col rounded-4xl border border-white/10 bg-slate-950/90 p-4 text-white shadow-2xl backdrop-blur-xl">
      <div className="mb-3"><h3 className="font-bold">Whiteboard</h3><p className="text-xs text-slate-400">Collaborative drawing, shapes, text, notes, images, undo/redo, export</p></div>
      <div className="mb-3 flex flex-wrap gap-1">{(['pen','highlighter','line','rect','ellipse','text','sticky','flow_rect','flow_diamond','uml_class','mind_node','laser'] as Tool[]).map(t => <button key={t} onClick={()=>setTool(t)} className={`rounded-xl px-2 py-1 text-xs ${tool===t?'bg-brand-600':'bg-white/10'}`}>{label(t)}</button>)}<label className="rounded-xl bg-white/10 px-2 py-1 text-xs"><ImageIcon className="mr-1 inline" size={12}/>Image<input type="file" accept="image/*" className="hidden" onChange={(e)=>imageSelected(e.target.files?.[0])}/></label></div>
      <div className="mb-3 flex items-center gap-2"><input type="color" value={color} onChange={(e)=>setColor(e.target.value)} /><input type="range" min="1" max="24" value={lineWidth} onChange={(e)=>setLineWidth(Number(e.target.value))} /><button onClick={()=>undoRedo('undo')} className="rounded-xl bg-white/10 p-2"><Undo2 size={16}/></button><button onClick={()=>undoRedo('redo')} className="rounded-xl bg-white/10 p-2"><Redo2 size={16}/></button><button onClick={()=>exportFile('png')} className="rounded-xl bg-white/10 p-2"><Download size={16}/>PNG</button><button onClick={()=>exportFile('pdf')} className="rounded-xl bg-white/10 p-2"><Download size={16}/>PDF</button><button onClick={()=>exportFile('svg')} className="rounded-xl bg-white/10 p-2"><Download size={16}/>SVG</button></div>
      {!allowed && <p className="mb-3 rounded-2xl bg-rose-500/20 p-3 text-sm text-rose-200">Whiteboard editing is disabled by host.</p>}
      <canvas ref={canvasRef} width={width} height={height} onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerLeave={up} className="aspect-video w-full touch-none rounded-3xl bg-white" />
      {textDraft && <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4">
        <form onSubmit={submitTextDraft} className="w-full max-w-md rounded-4xl border border-white/10 bg-slate-950 p-5 text-white shadow-2xl">
          <h4 className="text-lg font-black">Add {textDraft.tool === 'text' ? 'text' : 'sticky note'}</h4>
          <p className="mt-1 text-sm text-slate-400">The item will be placed where you clicked on the whiteboard.</p>
          <textarea autoFocus required value={textDraft.text} onChange={(e)=>setTextDraft({ ...textDraft, text: e.target.value })} rows={4} maxLength={2000} className="mt-4 w-full resize-none rounded-2xl border border-white/10 bg-white/10 px-4 py-3 outline-none focus:ring-2 focus:ring-brand-500" />
          <div className="mt-4 flex justify-end gap-2"><button type="button" onClick={()=>setTextDraft(null)} className="rounded-2xl bg-white/10 px-4 py-2 font-bold">Cancel</button><button disabled={textDraft.text.trim().length < 1} className="rounded-2xl bg-brand-600 px-4 py-2 font-bold disabled:opacity-50">Place item</button></div>
        </form>
      </div>}
    </aside>
  );
}

function label(tool: Tool) { const map: Record<Tool,string> = { pen:'Pen', highlighter:'Highlighter', line:'Line', rect:'Rect', ellipse:'Ellipse', text:'Text', sticky:'Note', flow_rect:'Flow', flow_diamond:'Decision', uml_class:'UML', mind_node:'Mind', image:'Image', laser:'Laser' }; return map[tool]; }
function roundRect(ctx: CanvasRenderingContext2D, x:number,y:number,w:number,h:number,r:number,fill:boolean) { ctx.beginPath(); ctx.roundRect(x,y,w,h,r); if(fill) ctx.fill(); else ctx.stroke(); }
function wrapText(ctx: CanvasRenderingContext2D, text:string, x:number, y:number, maxWidth:number, lineHeight:number) { const words=text.split(' '); let line=''; for (const word of words) { const test=line+word+' '; if (ctx.measureText(test).width > maxWidth && line) { ctx.fillText(line,x,y); line=word+' '; y+=lineHeight; } else line=test; } ctx.fillText(line,x,y); }
