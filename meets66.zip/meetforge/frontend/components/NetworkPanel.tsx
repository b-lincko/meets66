'use client';

import { Download, RefreshCcw, Wifi } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { toast } from 'sonner';
import { API_URL, MediaRegion, Meeting, NetworkDiagnostic, Participant, api, getAccessToken } from '@/lib/api';

export function NetworkPanel({ meeting, participant, participantToken, inviteToken }: { meeting: Meeting; participant: Participant; participantToken?: string; inviteToken?: string }) {
  const [regions, setRegions] = useState<MediaRegion[]>([]);
  const [iceServers, setIceServers] = useState<any[]>([]);
  const [history, setHistory] = useState<NetworkDiagnostic[]>([]);
  const [summary, setSummary] = useState<any | null>(null);
  const [clientStats, setClientStats] = useState({ fps: 0, memoryMb: 0, downlink: 0, rtt: 0 });
  const frameCounterRef = useRef(0);
  const isParticipant = Boolean(participantToken && inviteToken);

  async function load() {
    const [regionData, iceData] = await Promise.all([
      api<{items: MediaRegion[]; total: number}>('/network/regions', { auth: false }),
      api<{iceServers: any[]}>('/network/ice-servers', { auth: false }),
    ]);
    setRegions(regionData.items);
    setIceServers(iceData.iceServers);
    if (isParticipant) {
      const data = await api<{items: NetworkDiagnostic[]; total: number}>(`/meetings/invitations/${inviteToken}/network-diagnostics`, { auth: false, headers: { Authorization: `Bearer ${participantToken}` } });
      setHistory(data.items);
    } else {
      const [diagData, summaryData] = await Promise.all([
        api<{items: NetworkDiagnostic[]; total: number}>(`/admin/network/diagnostics?meetingId=${meeting.id}&participantId=${participant.id}`),
        api<any>('/admin/network/summary'),
      ]);
      setHistory(diagData.items);
      setSummary(summaryData);
    }
  }

  async function sendManualReport() {
    if (!participantToken || !inviteToken) return;
    const connection = (navigator as any).connection;
    try {
      const data = await api<{diagnostic: NetworkDiagnostic}>(`/meetings/invitations/${inviteToken}/network-diagnostics`, { method: 'POST', auth: false, headers: { Authorization: `Bearer ${participantToken}` }, body: JSON.stringify({ quality: 'manual', online: navigator.onLine, effectiveType: connection?.effectiveType, downlinkMbps: connection?.downlink, rttMs: connection?.rtt, saveData: connection?.saveData, roomState: 'connected' }) });
      setHistory((prev) => [data.diagnostic, ...prev]);
      toast.success('Network diagnostic sent');
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Diagnostic failed'); }
  }

  async function downloadCsv() {
    const res = await fetch(`${API_URL}/admin/network/diagnostics.csv`, { headers: { Authorization: `Bearer ${getAccessToken()}` } });
    if (!res.ok) return toast.error('Export failed');
    const url = URL.createObjectURL(await res.blob()); const a=document.createElement('a'); a.href=url; a.download='network-diagnostics.csv'; a.click(); URL.revokeObjectURL(url);
  }

  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    const count = () => { frameCounterRef.current += 1; raf = requestAnimationFrame(count); };
    raf = requestAnimationFrame(count);
    const interval = window.setInterval(() => {
      const now = performance.now();
      const fps = Math.round((frameCounterRef.current * 1000) / Math.max(1, now - last));
      frameCounterRef.current = 0;
      last = now;
      const memory = (performance as any).memory;
      const connection = (navigator as any).connection;
      setClientStats({ fps, memoryMb: memory?.usedJSHeapSize ? Math.round(memory.usedJSHeapSize / 1024 / 1024) : 0, downlink: connection?.downlink || 0, rtt: connection?.rtt || 0 });
    }, 2000);
    return () => { cancelAnimationFrame(raf); window.clearInterval(interval); };
  }, []);

  useEffect(() => { load().catch(() => {}); }, [meeting.id, participant.id, participantToken, inviteToken]);

  const latest = history[0];
  return <aside className="flex h-full min-h-0 flex-col rounded-4xl border border-white/10 bg-slate-950/90 p-4 text-white shadow-2xl backdrop-blur-xl"><div className="mb-3 flex items-center justify-between"><div><h3 className="font-bold"><Wifi className="mr-2 inline" size={18}/>Network</h3><p className="text-xs text-slate-400">ICE, regions, quality, RTT, packet loss, and bandwidth</p></div><button onClick={()=>load().catch(()=>{})} className="rounded-xl bg-white/10 p-2"><RefreshCcw size={16}/></button></div><div className="min-h-0 flex-1 space-y-4 overflow-y-auto"><section className="rounded-2xl bg-white/10 p-3"><h4 className="font-semibold">Current quality</h4><p className="mt-2 text-sm text-slate-300">Quality: {latest?.quality || 'No reports yet'}</p><p className="text-sm text-slate-300">RTT: {latest?.rttMs ?? '—'} ms · Downlink: {latest?.downlinkMbps ?? '—'} Mbps</p><p className="text-sm text-slate-300">Packet loss: {latest?.packetLoss ?? '—'} · Network: {latest?.effectiveType || participant.networkType || 'unknown'}</p><p className="mt-2 rounded-xl bg-slate-900 px-3 py-2 text-xs text-slate-300">Client FPS: {clientStats.fps || '—'} · JS memory: {clientStats.memoryMb || '—'} MB · Link: {clientStats.downlink || '—'} Mbps · RTT: {clientStats.rtt || '—'} ms</p></section><section className="rounded-2xl bg-white/10 p-3"><h4 className="font-semibold">ICE servers</h4><pre className="mt-2 max-h-32 overflow-auto whitespace-pre-wrap text-xs text-slate-300">{JSON.stringify(iceServers, null, 2)}</pre></section><section className="rounded-2xl bg-white/10 p-3"><h4 className="font-semibold">Media regions</h4><div className="mt-2 space-y-1">{regions.map((region)=><div key={region.id || region.code} className="rounded-xl bg-slate-900 px-3 py-2 text-xs">{region.name} · {region.code} · {region.livekitUrl}</div>)}</div></section>{summary && <section className="rounded-2xl bg-white/10 p-3"><h4 className="font-semibold">Admin summary</h4><p className="mt-2 text-sm text-slate-300">Reports: {summary.totalReports} · Avg RTT: {summary.averageRttMs} ms · Packet loss: {summary.averagePacketLoss}</p><button onClick={downloadCsv} className="mt-2 rounded-xl bg-white/10 px-3 py-2 text-xs"><Download className="mr-1 inline" size={13}/>Export CSV</button></section>}<section className="space-y-2"><h4 className="font-semibold">Recent reports</h4>{history.slice(0,8).map((item)=><div key={item.id} className="rounded-2xl bg-white/10 p-3 text-xs"><p>{new Date(item.createdAt).toLocaleString()} · {item.quality || 'unknown'}</p><p className="text-slate-400">RTT {item.rttMs ?? '—'} ms · jitter {item.jitterMs ?? '—'} · loss {item.packetLoss ?? '—'} · {item.effectiveType || 'network unknown'}</p></div>)}</section></div>{isParticipant && <button onClick={sendManualReport} className="mt-3 rounded-2xl bg-brand-600 px-4 py-3 text-sm font-semibold">Send diagnostic now</button>}</aside>;
}
