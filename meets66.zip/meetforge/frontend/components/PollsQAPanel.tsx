'use client';

import { BarChart3, CheckCircle2, Download, HelpCircle, MessageSquarePlus, Plus, Send, ThumbsUp, XCircle } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { toast } from 'sonner';
import { API_URL, Meeting, Participant, Poll, Question, api, getAccessToken } from '@/lib/api';
import { getSocket } from '@/lib/socket';

type Props = { meeting: Meeting; participant: Participant; participantToken?: string; inviteToken?: string };

export function PollsQAPanel({ meeting, participant, participantToken, inviteToken }: Props) {
  const [polls, setPolls] = useState<Poll[]>([]);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [pollTitle, setPollTitle] = useState('');
  const [pollOptions, setPollOptions] = useState('Yes\nNo');
  const [anonymous, setAnonymous] = useState(false);
  const [multipleChoice, setMultipleChoice] = useState(false);
  const [durationSeconds, setDurationSeconds] = useState('');
  const [selected, setSelected] = useState<Record<string, string[]>>({});
  const [questionText, setQuestionText] = useState('');
  const [answerText, setAnswerText] = useState<Record<string, string>>({});
  const isParticipantRoute = Boolean(participantToken && inviteToken && participant.role !== 'host');
  const moderator = participant.role === 'host' || participant.role === 'cohost';
  const base = isParticipantRoute ? `/meetings/invitations/${inviteToken}` : `/meetings/${meeting.id}`;
  const authHeaders = participantToken && isParticipantRoute ? { Authorization: `Bearer ${participantToken}` } : undefined;

  async function load() {
    const [pollData, questionData] = await Promise.all([
      api<{ items: Poll[]; total: number }>(`${base}/polls`, { auth: !isParticipantRoute, headers: authHeaders }),
      api<{ items: Question[]; total: number }>(`${base}/questions`, { auth: !isParticipantRoute, headers: authHeaders }),
    ]);
    setPolls(pollData.items);
    setQuestions(questionData.items);
  }

  useEffect(() => {
    load().catch(() => {});
    const socket = getSocket(participantToken);
    socket.emit('meeting:watch', { meetingId: meeting.id });
    const pollUpdated = (poll: Poll) => setPolls((prev) => prev.some((p) => p.id === poll.id) ? prev.map((p) => p.id === poll.id ? poll : p) : [poll, ...prev]);
    const questionUpdated = (question: Question) => setQuestions((prev) => prev.some((q) => q.id === question.id) ? prev.map((q) => q.id === question.id ? question : q) : [question, ...prev]);
    socket.on('poll:updated', pollUpdated);
    socket.on('question:updated', questionUpdated);
    return () => { socket.off('poll:updated', pollUpdated); socket.off('question:updated', questionUpdated); };
  }, [meeting.id, participantToken, inviteToken, participant.role]);

  async function createPoll(e: React.FormEvent) {
    e.preventDefault();
    const options = pollOptions.split('\n').map((o) => o.trim()).filter(Boolean);
    try {
      const data = await api<{ poll: Poll }>(`${base}/polls`, { method: 'POST', auth: !isParticipantRoute, headers: authHeaders, body: JSON.stringify({ title: pollTitle, options, anonymous, multipleChoice, durationSeconds: durationSeconds ? Number(durationSeconds) : undefined }) });
      setPolls((prev) => [data.poll, ...prev.filter((p) => p.id !== data.poll.id)]);
      setPollTitle(''); setPollOptions('Yes\nNo'); setDurationSeconds('');
      toast.success('Poll created');
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Poll creation failed'); }
  }

  async function vote(poll: Poll) {
    const optionIds = selected[poll.id] || [];
    if (!optionIds.length) return toast.error('Select an option');
    try {
      const data = await api<{ poll: Poll }>(`${base}/polls/${poll.id}/vote`, { method: 'POST', auth: !isParticipantRoute, headers: authHeaders, body: JSON.stringify({ optionIds }) });
      setPolls((prev) => prev.map((p) => p.id === poll.id ? data.poll : p));
      toast.success('Vote submitted');
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Vote failed'); }
  }

  async function closePoll(poll: Poll) {
    const data = await api<{ poll: Poll }>(`${base}/polls/${poll.id}/close`, { method: 'POST', auth: !isParticipantRoute, headers: authHeaders });
    setPolls((prev) => prev.map((p) => p.id === poll.id ? data.poll : p));
  }

  async function askQuestion(e: React.FormEvent) {
    e.preventDefault();
    try {
      const data = await api<{ question: Question }>(`${base}/questions`, { method: 'POST', auth: !isParticipantRoute, headers: authHeaders, body: JSON.stringify({ text: questionText }) });
      setQuestions((prev) => [data.question, ...prev.filter((q) => q.id !== data.question.id)]);
      setQuestionText(''); toast.success('Question posted');
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Question failed'); }
  }

  async function upvote(q: Question) {
    const data = await api<{ question: Question; upvoted: boolean }>(`${base}/questions/${q.id}/upvote`, { method: 'POST', auth: !isParticipantRoute, headers: authHeaders });
    setQuestions((prev) => prev.map((item) => item.id === q.id ? data.question : item));
  }

  async function moderate(q: Question, action: 'answered' | 'dismissed') {
    try {
      const data = await api<{ question: Question }>(`${base}/questions/${q.id}`, { method: 'PATCH', auth: !isParticipantRoute, headers: authHeaders, body: JSON.stringify(action === 'answered' ? { answerText: answerText[q.id] || 'Answered live' } : { status: 'dismissed' }) });
      setQuestions((prev) => prev.map((item) => item.id === q.id ? data.question : item));
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Moderation failed'); }
  }

  async function exportPoll(poll: Poll) {
    const res = await fetch(`${API_URL}/meetings/${meeting.id}/polls/${poll.id}/export.csv`, { headers: { Authorization: `Bearer ${getAccessToken()}` } });
    if (!res.ok) return toast.error('Export failed');
    const url = URL.createObjectURL(await res.blob()); const a=document.createElement('a'); a.href=url; a.download=`poll-${poll.id}.csv`; a.click(); URL.revokeObjectURL(url);
  }

  async function exportQna() {
    const res = await fetch(`${API_URL}/meetings/${meeting.id}/questions/export.csv`, { headers: { Authorization: `Bearer ${getAccessToken()}` } });
    if (!res.ok) return toast.error('Export failed');
    const url = URL.createObjectURL(await res.blob()); const a=document.createElement('a'); a.href=url; a.download='qna.csv'; a.click(); URL.revokeObjectURL(url);
  }

  function selectOption(poll: Poll, optionId: string) {
    setSelected((prev) => {
      const existing = prev[poll.id] || [];
      const next = poll.multipleChoice ? (existing.includes(optionId) ? existing.filter((id) => id !== optionId) : [...existing, optionId]) : [optionId];
      return { ...prev, [poll.id]: next };
    });
  }

  return (
    <aside className="flex h-full min-h-0 flex-col rounded-4xl border border-white/10 bg-slate-950/90 p-4 text-white shadow-2xl backdrop-blur-xl">
      <div className="mb-3"><h3 className="font-bold">Polls & Q&A</h3><p className="text-xs text-slate-400">Live polls, statistics, exports, upvoting, and moderation</p></div>
      <div className="min-h-0 flex-1 space-y-4 overflow-y-auto pr-1">
        {moderator && <form onSubmit={createPoll} className="rounded-2xl bg-white/10 p-3"><h4 className="mb-2 flex items-center gap-2 font-semibold"><BarChart3 size={16}/>Create poll</h4><input value={pollTitle} onChange={(e)=>setPollTitle(e.target.value)} placeholder="Poll question" className="mb-2 w-full rounded-xl bg-slate-900 px-3 py-2 text-sm"/><textarea value={pollOptions} onChange={(e)=>setPollOptions(e.target.value)} rows={3} className="mb-2 w-full rounded-xl bg-slate-900 px-3 py-2 text-sm"/><div className="mb-2 grid grid-cols-2 gap-2 text-xs"><label><input type="checkbox" checked={anonymous} onChange={(e)=>setAnonymous(e.target.checked)}/> Anonymous</label><label><input type="checkbox" checked={multipleChoice} onChange={(e)=>setMultipleChoice(e.target.checked)}/> Multiple choice</label><input value={durationSeconds} onChange={(e)=>setDurationSeconds(e.target.value)} placeholder="Timer seconds" className="col-span-2 rounded-xl bg-slate-900 px-3 py-2"/></div><button className="rounded-xl bg-brand-600 px-3 py-2 text-sm font-bold"><Plus size={14} className="mr-1 inline"/>Create</button></form>}
        <section className="space-y-2"><h4 className="font-semibold">Polls</h4>{polls.map((poll)=><div key={poll.id} className="rounded-2xl bg-white/10 p-3"><div className="flex justify-between gap-2"><p className="font-semibold">{poll.title}</p><span className="text-xs text-slate-400">{poll.status}</span></div>{poll.options.map((option)=><label key={option.id} className="mt-2 block rounded-xl bg-slate-900 p-2 text-sm"><input type={poll.multipleChoice?'checkbox':'radio'} name={poll.id} checked={(selected[poll.id]||[]).includes(option.id)} onChange={()=>selectOption(poll, option.id)} disabled={!poll.isOpen}/> {option.text}<div className="mt-1 h-1 rounded bg-slate-700"><div className="h-1 rounded bg-brand-500" style={{width:`${poll.results?.options.find((o)=>o.id===option.id)?.percent || 0}%`}} /></div><span className="text-xs text-slate-500">{poll.results?.options.find((o)=>o.id===option.id)?.votes || 0} votes</span></label>)}<div className="mt-2 flex flex-wrap gap-2"><button onClick={()=>vote(poll)} disabled={!poll.isOpen} className="rounded-xl bg-brand-600 px-3 py-2 text-xs font-bold disabled:opacity-50"><Send size={13} className="mr-1 inline"/>Vote</button>{moderator && poll.isOpen && <button onClick={()=>closePoll(poll)} className="rounded-xl bg-rose-700 px-3 py-2 text-xs font-bold"><XCircle size={13} className="mr-1 inline"/>Close</button>}{moderator && <button onClick={()=>exportPoll(poll)} className="rounded-xl bg-white/10 px-3 py-2 text-xs font-bold"><Download size={13} className="mr-1 inline"/>Export</button>}</div></div>)}</section>
        <section className="space-y-2"><div className="flex justify-between"><h4 className="font-semibold">Q&A</h4>{moderator && <button onClick={exportQna} className="text-xs text-brand-300"><Download size={13} className="mr-1 inline"/>Export</button>}</div><form onSubmit={askQuestion} className="flex gap-2"><input value={questionText} onChange={(e)=>setQuestionText(e.target.value)} placeholder="Ask a question" className="min-w-0 flex-1 rounded-xl bg-slate-900 px-3 py-2 text-sm"/><button className="rounded-xl bg-brand-600 px-3 py-2"><MessageSquarePlus size={15}/></button></form>{questions.map((q)=><div key={q.id} className="rounded-2xl bg-white/10 p-3"><div className="flex justify-between gap-2"><p className="font-semibold"><HelpCircle size={14} className="mr-1 inline"/>{q.text}</p><span className="text-xs text-slate-400">{q.status}</span></div><p className="text-xs text-slate-500">Asked by {q.authorDisplayName}</p>{q.answerText && <p className="mt-2 rounded-xl bg-emerald-500/10 p-2 text-sm text-emerald-200">{q.answerText} — {q.answeredByDisplayName}</p>}<div className="mt-2 flex flex-wrap gap-2"><button onClick={()=>upvote(q)} className="rounded-xl bg-white/10 px-3 py-2 text-xs"><ThumbsUp size={13} className="mr-1 inline"/>{q.upvotes}</button>{moderator && q.status !== 'answered' && <><input value={answerText[q.id] || ''} onChange={(e)=>setAnswerText({...answerText,[q.id]:e.target.value})} placeholder="Answer" className="min-w-0 flex-1 rounded-xl bg-slate-900 px-3 py-2 text-xs"/><button onClick={()=>moderate(q,'answered')} className="rounded-xl bg-emerald-700 px-3 py-2 text-xs"><CheckCircle2 size={13}/></button><button onClick={()=>moderate(q,'dismissed')} className="rounded-xl bg-rose-700 px-3 py-2 text-xs"><XCircle size={13}/></button></>}</div></div>)}</section>
      </div>
    </aside>
  );
}
