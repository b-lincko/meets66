'use client';

import { Camera, Mic, VideoOff } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { MediaRegion, api } from '@/lib/api';

type Device = { deviceId: string; label: string };
export type DeviceChoice = { audioDeviceId?: string; videoDeviceId?: string; startAudio: boolean; startVideo: boolean; lowBandwidthMode: boolean; audioOnlyMode: boolean; preferredLayout: 'auto' | 'mobile' | 'gallery' | 'speaker'; mobileClient: boolean; networkType?: string; deviceInfo: Record<string, unknown> };

export function PreJoin({ displayName, setDisplayName, requireName, onJoin, loading }: { displayName: string; setDisplayName: (value: string) => void; requireName: boolean; onJoin: (choice: DeviceChoice) => void; loading?: boolean }) {
  const [audioInputs, setAudioInputs] = useState<Device[]>([]);
  const [videoInputs, setVideoInputs] = useState<Device[]>([]);
  const [regions, setRegions] = useState<MediaRegion[]>([]);
  const [selectedRegion, setSelectedRegion] = useState('');
  const [audioDeviceId, setAudioDeviceId] = useState('');
  const [videoDeviceId, setVideoDeviceId] = useState('');
  const [startAudio, setStartAudio] = useState(true);
  const [startVideo, setStartVideo] = useState(true);
  const [lowBandwidthMode, setLowBandwidthMode] = useState(false);
  const [audioOnlyMode, setAudioOnlyMode] = useState(false);
  const [permissionError, setPermissionError] = useState('');
  const [deviceTest, setDeviceTest] = useState('Device test not run');
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    const savedStartAudio = localStorage.getItem('defensiq.preferredStartAudio');
    const savedStartVideo = localStorage.getItem('defensiq.preferredStartVideo');
    const constrainedDevice = /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent) || (navigator.hardwareConcurrency || 8) <= 4;
    if (constrainedDevice) setLowBandwidthMode(true);
    if (savedStartAudio !== null) setStartAudio(savedStartAudio === 'true');
    if (savedStartVideo !== null) setStartVideo(savedStartVideo === 'true');
    async function init() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: true });
        stream.getTracks().forEach((track) => track.stop());
        const devices = await navigator.mediaDevices.enumerateDevices();
        const audio = devices.filter((d) => d.kind === 'audioinput').map((d, i) => ({ deviceId: d.deviceId, label: d.label || `Microphone ${i + 1}` }));
        const video = devices.filter((d) => d.kind === 'videoinput').map((d, i) => ({ deviceId: d.deviceId, label: d.label || `Camera ${i + 1}` }));
        setAudioInputs(audio);
        setVideoInputs(video);
        const savedAudio = localStorage.getItem('defensiq.preferredAudioDeviceId') || '';
        const savedVideo = localStorage.getItem('defensiq.preferredVideoDeviceId') || '';
        if (savedAudio && audio.some((device) => device.deviceId === savedAudio)) setAudioDeviceId(savedAudio);
        else if (audio[0]) setAudioDeviceId(audio[0].deviceId);
        if (savedVideo && video.some((device) => device.deviceId === savedVideo)) setVideoDeviceId(savedVideo);
        else if (video[0]) setVideoDeviceId(video[0].deviceId);
      } catch (err) {
        setPermissionError(err instanceof Error ? err.message : 'Camera/microphone permission failed');
      }
    }
    init();
    api<{items: MediaRegion[]; total: number}>('/network/regions', { auth: false }).then((data) => { setRegions(data.items); if (data.items[0]) setSelectedRegion(data.items[0].code); }).catch(() => {});
  }, []);

  useEffect(() => {
    async function preview() {
      streamRef.current?.getTracks().forEach((track) => track.stop());
      if (!startVideo) {
        if (videoRef.current) videoRef.current.srcObject = null;
        return;
      }
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { deviceId: videoDeviceId ? { exact: videoDeviceId } : undefined, width: { ideal: 640 }, height: { ideal: 360 }, frameRate: { ideal: 15, max: 24 } }, audio: false });
        streamRef.current = stream;
        if (videoRef.current) videoRef.current.srcObject = stream;
      } catch (err) {
        setPermissionError(err instanceof Error ? err.message : 'Camera preview failed');
      }
    }
    preview();
    return () => streamRef.current?.getTracks().forEach((track) => track.stop());
  }, [videoDeviceId, startVideo]);

  function isMobileClient() {
    return typeof navigator !== 'undefined' && /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent);
  }
  function networkType() {
    const connection = (navigator as any).connection;
    return connection?.effectiveType || connection?.type || undefined;
  }
  function selectedDeviceInfo() {
    return {
      userAgent: navigator.userAgent,
      mobileClient: isMobileClient(),
      networkType: networkType(),
      selectedRegion,
      audioDevice: audioInputs.find((d) => d.deviceId === audioDeviceId)?.label || 'Default microphone',
      videoDevice: videoInputs.find((d) => d.deviceId === videoDeviceId)?.label || 'Default camera',
    };
  }
  async function runDeviceTest() {
    try {
      const started = performance.now();
      const stream = await navigator.mediaDevices.getUserMedia({ audio: audioDeviceId ? { deviceId: { exact: audioDeviceId }, echoCancellation: true, noiseSuppression: true } : true, video: videoDeviceId ? { deviceId: { exact: videoDeviceId }, width: { ideal: 320 }, height: { ideal: 180 }, frameRate: { ideal: 10, max: 15 } } : { width: { ideal: 320 }, height: { ideal: 180 }, frameRate: { ideal: 10, max: 15 } } });
      const elapsed = Math.round(performance.now() - started);
      const audioOk = stream.getAudioTracks().some((track) => track.readyState === 'live');
      const videoOk = stream.getVideoTracks().some((track) => track.readyState === 'live');
      stream.getTracks().forEach((track) => track.stop());
      setDeviceTest(`Ready in ${elapsed}ms · mic ${audioOk ? 'ok' : 'missing'} · camera ${videoOk ? 'ok' : 'missing'}`);
    } catch (err) {
      setDeviceTest(err instanceof Error ? err.message : 'Device test failed');
    }
  }
  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (requireName && displayName.trim().length < 2) return;
    if (audioDeviceId) localStorage.setItem('defensiq.preferredAudioDeviceId', audioDeviceId);
    if (videoDeviceId) localStorage.setItem('defensiq.preferredVideoDeviceId', videoDeviceId);
    localStorage.setItem('defensiq.preferredStartAudio', String(startAudio));
    localStorage.setItem('defensiq.preferredStartVideo', String(startVideo));
    streamRef.current?.getTracks().forEach((track) => track.stop());
    const mobile = isMobileClient();
    const audioOnly = audioOnlyMode || lowBandwidthMode;
    onJoin({ audioDeviceId, videoDeviceId, startAudio, startVideo: audioOnly ? false : startVideo, lowBandwidthMode, audioOnlyMode: audioOnly, preferredLayout: mobile ? 'mobile' : 'auto', mobileClient: mobile, networkType: networkType(), deviceInfo: selectedDeviceInfo() });
  }

  return (
    <form onSubmit={submit} className="glass mx-auto grid w-full max-w-5xl gap-6 rounded-4xl p-6 lg:grid-cols-[1.1fr_.9fr]">
      <div className="aspect-video overflow-hidden rounded-4xl bg-slate-950 shadow-2xl">
        {startVideo ? <video ref={videoRef} autoPlay muted playsInline className="h-full w-full bg-black object-contain" /> : <div className="grid h-full place-items-center text-slate-400"><VideoOff size={54}/></div>}
      </div>
      <div className="flex flex-col justify-center">
        <h2 className="text-3xl font-black text-slate-950 dark:text-white">Preview devices</h2>
        <p className="mt-2 text-sm text-slate-500">Choose your camera and microphone before entering the meeting.</p>
        {permissionError && <div className="mt-4 rounded-2xl bg-amber-500/10 p-3 text-sm text-amber-700 dark:text-amber-200">{permissionError}</div>}
        {requireName && <label className="mt-4 block"><span className="text-sm font-semibold">Display name</span><input required value={displayName} onChange={(e)=>setDisplayName(e.target.value)} className="mt-2 w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 outline-none focus:ring-2 focus:ring-brand-500 dark:border-slate-700 dark:bg-slate-900" /></label>}
        <label className="mt-4 block"><span className="text-sm font-semibold">Camera</span><select value={videoDeviceId} onChange={(e)=>setVideoDeviceId(e.target.value)} className="mt-2 w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900"><option value="">Default camera</option>{videoInputs.map((device)=><option key={device.deviceId} value={device.deviceId}>{device.label}</option>)}</select></label>
        <label className="mt-4 block"><span className="text-sm font-semibold">Microphone</span><select value={audioDeviceId} onChange={(e)=>setAudioDeviceId(e.target.value)} className="mt-2 w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900"><option value="">Default microphone</option>{audioInputs.map((device)=><option key={device.deviceId} value={device.deviceId}>{device.label}</option>)}</select></label>
        {regions.length > 0 && <label className="mt-4 block"><span className="text-sm font-semibold">Media region</span><select value={selectedRegion} onChange={(e)=>setSelectedRegion(e.target.value)} className="mt-2 w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900">{regions.map((region)=><option key={region.code} value={region.code}>{region.name}</option>)}</select></label>}
        <div className="mt-4 flex flex-wrap gap-2"><button type="button" onClick={()=>setStartAudio(!startAudio)} className={`rounded-2xl px-4 py-3 text-sm font-semibold ${startAudio ? 'bg-emerald-600 text-white' : 'bg-slate-200 dark:bg-slate-800'}`}><Mic className="mr-2 inline" size={16}/>Mic {startAudio ? 'on' : 'off'}</button><button type="button" onClick={()=>setStartVideo(!startVideo)} disabled={audioOnlyMode || lowBandwidthMode} className={`rounded-2xl px-4 py-3 text-sm font-semibold ${(startVideo && !audioOnlyMode && !lowBandwidthMode) ? 'bg-emerald-600 text-white' : 'bg-slate-200 dark:bg-slate-800'}`}><Camera className="mr-2 inline" size={16}/>Camera {(startVideo && !audioOnlyMode && !lowBandwidthMode) ? 'on' : 'off'}</button></div>
        <div className="mt-4 grid gap-2 text-sm sm:grid-cols-2"><label className="rounded-2xl bg-white/60 p-3 dark:bg-slate-900/60"><input type="checkbox" checked={lowBandwidthMode} onChange={(e)=>setLowBandwidthMode(e.target.checked)} className="mr-2"/>Low bandwidth mode</label><label className="rounded-2xl bg-white/60 p-3 dark:bg-slate-900/60"><input type="checkbox" checked={audioOnlyMode} onChange={(e)=>setAudioOnlyMode(e.target.checked)} className="mr-2"/>Audio only</label></div>
        <div className="mt-4 rounded-2xl bg-white/60 p-3 text-sm text-slate-600 dark:bg-slate-900/60 dark:text-slate-300"><div className="flex items-center justify-between gap-3"><span>{deviceTest}</span><button type="button" onClick={runDeviceTest} className="rounded-xl bg-brand-600 px-3 py-2 text-xs font-bold text-white">Test devices</button></div></div>
        <button disabled={loading || (requireName && displayName.trim().length < 2)} className="mt-6 min-h-12 rounded-2xl bg-brand-600 px-5 py-3 text-sm font-semibold text-white disabled:opacity-50">{loading ? 'Joining...' : 'Join meeting'}</button>
      </div>
    </form>
  );
}
