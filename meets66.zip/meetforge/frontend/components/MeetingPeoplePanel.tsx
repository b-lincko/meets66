'use client';

import { useRoomContext } from '@livekit/components-react';
import { Ban, Camera, CameraOff, ChevronDown, ChevronUp, Crown, Hand, Mic, MicOff, MonitorUp, MoreVertical, Pin, RefreshCcw, Search, Shield, ShieldCheck, ShieldOff, Star, UserCheck, UserMinus, UserRoundCog, UserX, Users, Video, Wifi, X } from 'lucide-react';
import type { ReactNode } from 'react';
import { useEffect, useMemo, useState } from 'react';
import { toast } from 'sonner';
import { Meeting, Participant, api } from '@/lib/api';

type View = 'participants' | 'requests';
type ActionResponse = { participant: Participant; meeting: Meeting; changedParticipants?: Participant[] };

type Props = {
  meeting: Meeting;
  currentParticipant: Participant;
  participants: Participant[];
  participantToken?: string;
  inviteToken?: string;
  activeView: View;
  onViewChange: (view: View) => void;
  onParticipantsChange: (participants: Participant[]) => void;
  onMeetingUpdate?: (meeting: Meeting) => void;
  onReload: () => void;
  onClose: () => void;
};

const managementActions = new Set([
  'mute', 'ask_unmute', 'disable_audio', 'enable_audio', 'disable_video', 'enable_video', 'grant_screen_share', 'revoke_screen_share', 'grant_whiteboard', 'revoke_whiteboard',
  'promote_cohost', 'demote_cohost', 'grant_cohost_controls', 'revoke_cohost_controls', 'change_presenter', 'clear_presenter', 'pin', 'unpin', 'spotlight', 'clear_spotlight', 'rename', 'remove', 'move_waiting', 'ban', 'admit', 'reject', 'view_quality',
]);

export function MeetingPeoplePanel({ meeting, currentParticipant, participants, participantToken, inviteToken, activeView, onViewChange, onParticipantsChange, onMeetingUpdate, onReload, onClose }: Props) {
  const [peopleOpen, setPeopleOpen] = useState(true);
  const [waitingOpen, setWaitingOpen] = useState(activeView === 'requests');
  const [controlsOpen, setControlsOpen] = useState(true);
  const [actionsFor, setActionsFor] = useState<string | null>(null);
  const [renaming, setRenaming] = useState<Participant | null>(null);
  const [renameValue, setRenameValue] = useState('');
  const [qualityTarget, setQualityTarget] = useState<Participant | null>(null);
  const [search, setSearch] = useState('');
  const [confirmEnd, setConfirmEnd] = useState(false);
  const [sortMode, setSortMode] = useState<'role' | 'speaking' | 'hand' | 'join' | 'name'>('role');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [visiblePeopleCount, setVisiblePeopleCount] = useState(80);
  const room = useRoomContext();
  const activeSpeakerIds = new Set(room.activeSpeakers.map((speaker) => speaker.identity));
  const admitted = useMemo(() => participants.filter((p) => p.status === 'admitted'), [participants]);
  const waiting = useMemo(() => participants.filter((p) => p.status === 'waiting'), [participants]);
  const isParticipantSession = Boolean(participantToken && inviteToken);
  const canManageParticipants = canManage(currentParticipant, 'mute') || canManage(currentParticipant, 'remove') || canManage(currentParticipant, 'participants.manage');
  const canManageWaiting = canManage(currentParticipant, 'admit') || canManage(currentParticipant, 'reject') || canManage(currentParticipant, 'ban');
  const canManageMeeting = currentParticipant.role === 'host' && !isParticipantSession;
  const query = search.trim().toLowerCase();
  const filteredAdmitted = sortPeople(admitted.filter((person) => person.displayName.toLowerCase().includes(query) || person.role.toLowerCase().includes(query)), sortMode, activeSpeakerIds);
  const filteredWaiting = waiting.filter((person) => person.displayName.toLowerCase().includes(query) || deviceLabel(person).toLowerCase().includes(query));

  useEffect(() => {
    if (activeView === 'requests') setWaitingOpen(true);
    if (activeView === 'participants') setPeopleOpen(true);
  }, [activeView]);
  useEffect(() => { setVisiblePeopleCount(80); }, [query, sortMode]);

  function mergeParticipants(items: Participant[]) {
    const map = new Map(participants.map((item) => [item.id, item]));
    items.forEach((item) => map.set(item.id, item));
    onParticipantsChange(sortParticipants(Array.from(map.values())));
  }

  async function runAction(target: Participant, action: string, extra: Record<string, unknown> = {}) {
    if (action === 'view_quality') {
      setQualityTarget(target);
      setActionsFor(null);
      return;
    }
    if (action === 'rename') {
      setRenaming(target);
      setRenameValue(target.displayName);
      setActionsFor(null);
      return;
    }
    try {
      const path = isParticipantSession
        ? `/meetings/invitations/${inviteToken}/participants/${target.id}/action`
        : `/meetings/${meeting.id}/participants/${target.id}/action`;
      const data = await api<ActionResponse>(path, {
        method: 'POST',
        auth: !isParticipantSession,
        headers: participantToken ? { Authorization: `Bearer ${participantToken}` } : undefined,
        body: JSON.stringify({ action, ...extra }),
      });
      mergeParticipants(data.changedParticipants?.length ? data.changedParticipants : [data.participant]);
      onMeetingUpdate?.(data.meeting);
      setActionsFor(null);
      toast.success(actionSuccess(action));
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Participant action failed');
    }
  }

  async function bulkAction(action: 'mute' | 'ask_unmute' | 'move_waiting' | 'remove') {
    const targets = admitted.filter((person) => selectedIds.includes(person.id) && person.id !== currentParticipant.id && person.role !== 'host');
    if (!targets.length) return toast.error('Select one or more manageable participants');
    for (const target of targets) await runAction(target, action);
    setSelectedIds([]);
    toast.success(`Bulk action applied to ${targets.length} participant${targets.length === 1 ? '' : 's'}`);
  }

  async function updateMeetingControls(patch: Partial<Meeting>) {
    if (!canManageMeeting) return;
    try {
      const data = await api<{ meeting: Meeting }>(`/meetings/${meeting.id}/controls`, { method: 'PATCH', body: JSON.stringify(patch) });
      onMeetingUpdate?.(data.meeting);
      toast.success('Meeting controls updated');
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Meeting control failed');
    }
  }

  async function endMeeting() {
    if (!canManageMeeting) return;
    try {
      const data = await api<{ meeting: Meeting }>(`/meetings/${meeting.id}/end`, { method: 'POST' });
      onMeetingUpdate?.(data.meeting);
      setConfirmEnd(false);
      toast.success('Meeting ended for everyone');
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Could not end meeting');
    }
  }

  async function submitRename(e: React.FormEvent) {
    e.preventDefault();
    if (!renaming) return;
    await runAction(renaming, 'rename', { displayName: renameValue.trim() });
    setRenaming(null);
  }

  return (
    <aside className="flex h-full min-h-0 flex-col rounded-3xl border border-white/10 bg-[#0b0f17]/95 p-4 text-white shadow-2xl backdrop-blur-xl">
      <header className="mb-3 flex items-start justify-between gap-3">
        <div>
          <h2 className="text-lg font-black">Participants ({admitted.length + waiting.length})</h2>
          <p className="text-xs text-slate-400">{admitted.length} in meeting · {waiting.length} waiting</p>
        </div>
        <div className="flex items-center gap-2 text-xs">
          <button type="button" onClick={onReload} className="rounded-xl bg-white/10 p-2 transition hover:bg-white/15" title="Refresh people" aria-label="Refresh people"><RefreshCcw size={16}/></button>
          <button type="button" onClick={onClose} className="inline-flex items-center gap-1 rounded-xl bg-white/10 px-2 py-2 transition hover:bg-white/15" title="Hide panel" aria-label="Hide panel"><span className="hidden sm:inline">Hide</span><X size={15}/></button>
        </div>
      </header>

      <label className="mb-3 flex items-center gap-2 rounded-2xl border border-white/10 bg-white/10 px-3 py-2 text-sm text-slate-300">
        <Search size={16}/>
        <input value={search} onChange={(e)=>setSearch(e.target.value)} placeholder="Search participants" className="min-w-0 flex-1 bg-transparent outline-none placeholder:text-slate-500" />
      </label>

      <div className="mb-3 grid grid-cols-2 gap-2 rounded-2xl border border-white/10 bg-white/5 p-1 text-sm font-bold">
        <button type="button" onClick={() => { onViewChange('participants'); setPeopleOpen(true); }} className={`relative rounded-xl px-3 py-2 transition ${activeView === 'participants' ? 'bg-brand-600 text-white' : 'text-slate-300 hover:bg-white/10'}`}>
          <Users className="mr-2 inline" size={16}/>Participants <span className="ml-1 text-xs">{admitted.length}</span>
        </button>
        {canManageWaiting ? <button type="button" onClick={() => { onViewChange('requests'); setWaitingOpen(true); }} className={`relative rounded-xl px-3 py-2 transition ${activeView === 'requests' ? 'bg-brand-600 text-white' : 'text-slate-300 hover:bg-white/10'}`}>
          <UserCheck className="mr-2 inline" size={16}/>Requests
          {waiting.length > 0 && <span className="absolute -right-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-amber-500 px-1 text-[11px] font-black text-slate-950">{waiting.length}</span>}
        </button> : <button type="button" onClick={() => setPeopleOpen((value)=>!value)} className="rounded-xl px-3 py-2 text-slate-300 hover:bg-white/10">Hide / Show</button>}
      </div>

      {activeView === 'participants' && <div className="mb-3 rounded-2xl border border-white/10 bg-white/5 p-2 text-xs">
        <div className="mb-2 flex items-center justify-between gap-2"><label className="font-bold text-slate-300">Sort participants</label><select value={sortMode} onChange={(e)=>setSortMode(e.target.value as any)} className="rounded-xl border border-white/10 bg-slate-900 px-2 py-2 outline-none"><option value="role">Role</option><option value="speaking">Speaking</option><option value="hand">Hand raised</option><option value="join">Join time</option><option value="name">Name</option></select></div>
        {canManageParticipants && <div className="flex flex-wrap gap-2"><button onClick={()=>setSelectedIds(filteredAdmitted.filter((p)=>p.role !== 'host' && p.id !== currentParticipant.id).map((p)=>p.id))} className="rounded-xl bg-white/10 px-2 py-1 font-bold">Select manageable</button><button onClick={()=>setSelectedIds([])} className="rounded-xl bg-white/10 px-2 py-1 font-bold">Clear</button><button onClick={()=>bulkAction('mute')} className="rounded-xl bg-white/10 px-2 py-1 font-bold">Bulk mute</button><button onClick={()=>bulkAction('ask_unmute')} className="rounded-xl bg-white/10 px-2 py-1 font-bold">Ask unmute</button><button onClick={()=>bulkAction('move_waiting')} className="rounded-xl bg-amber-600 px-2 py-1 font-bold">Move waiting</button><button onClick={()=>bulkAction('remove')} className="rounded-xl bg-rose-600 px-2 py-1 font-bold">Remove</button></div>}
      </div>}

      <div className="min-h-0 flex-1 space-y-3 overflow-auto pr-1">
        <section className="rounded-3xl border border-white/10 bg-white/[0.03] p-3">
          <SectionHeader title={`In Meeting (${filteredAdmitted.length})`} open={peopleOpen} onToggle={() => setPeopleOpen((value)=>!value)} />
          <div className={`grid transition-all duration-300 ease-in-out ${peopleOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}>
            <div className="min-h-0 overflow-hidden">
              <div className="mt-3 space-y-2">
                {groupPeople(filteredAdmitted.slice(0, visiblePeopleCount)).map((group) => <div key={group.role} className="space-y-2"><p className="px-1 text-xs font-black uppercase tracking-wider text-slate-500">{group.label}</p>{group.items.map((person) => <ParticipantCard key={person.id} person={person} currentParticipant={currentParticipant} selected={selectedIds.includes(person.id)} onSelectedChange={(checked) => setSelectedIds((prev) => checked ? Array.from(new Set([...prev, person.id])) : prev.filter((id) => id !== person.id))} menuOpen={actionsFor === person.id} onToggleMenu={() => setActionsFor(actionsFor === person.id ? null : person.id)} onAction={(action) => runAction(person, action)} />)}</div>)}
                {filteredAdmitted.length > visiblePeopleCount && <button onClick={() => setVisiblePeopleCount((count) => count + 80)} className="w-full rounded-2xl bg-white/10 px-3 py-2 text-sm font-bold hover:bg-white/15">Show {Math.min(80, filteredAdmitted.length - visiblePeopleCount)} more participants</button>}
                {filteredAdmitted.length === 0 && <EmptyState label={query ? 'No matching participants.' : 'No admitted participants yet.'} />}
              </div>
            </div>
          </div>
        </section>

        {canManageWaiting && <section className="rounded-3xl border border-amber-400/20 bg-amber-400/[0.05] p-3">
          <SectionHeader title={`Waiting Room (${filteredWaiting.length})`} open={waitingOpen} onToggle={() => setWaitingOpen((value)=>!value)} />
          <div className={`grid transition-all duration-300 ease-in-out ${waitingOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}>
            <div className="min-h-0 overflow-hidden">
              <div className="mt-3 space-y-2">
                {filteredWaiting.map((person) => <JoinRequestCard key={person.id} person={person} meeting={meeting} canManage={canManageWaiting} onAction={(action) => runAction(person, action)} />)}
                {filteredWaiting.length === 0 && <EmptyState label={query ? 'No matching join requests.' : 'No pending join requests.'} />}
              </div>
            </div>
          </div>
        </section>}

        {canManageMeeting && <section className="rounded-3xl border border-white/10 bg-white/[0.03] p-3">
          <SectionHeader title="Host Controls (Meeting)" open={controlsOpen} onToggle={() => setControlsOpen((value)=>!value)} />
          <div className={`grid transition-all duration-300 ease-in-out ${controlsOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}>
            <div className="min-h-0 overflow-hidden">
              <div className="mt-3 space-y-3 text-sm">
                <ToggleRow label="Lock Meeting" enabled={meeting.isLocked} onClick={() => updateMeetingControls({ isLocked: !meeting.isLocked })} />
                <ToggleRow label="Allow Microphones" enabled={meeting.allowParticipantAudio} onClick={() => updateMeetingControls({ allowParticipantAudio: !meeting.allowParticipantAudio })} />
                <ToggleRow label="Allow Cameras" enabled={meeting.allowParticipantVideo} onClick={() => updateMeetingControls({ allowParticipantVideo: !meeting.allowParticipantVideo })} />
                <ToggleRow label="Allow Screen Share" enabled={meeting.allowScreenShare} onClick={() => updateMeetingControls({ allowScreenShare: !meeting.allowScreenShare })} />
                <SelectRow label="Screen Share Policy" value={meeting.screenSharePolicy} onChange={(value) => updateMeetingControls({ screenSharePolicy: value as Meeting['screenSharePolicy'] })} options={[['host','Host only'], ['cohosts','Co-hosts only'], ['all','Everyone']]} />
                <SelectRow label="Allow Whiteboard" value={meeting.allowWhiteboard ? 'everyone' : 'hosts'} onChange={(value) => updateMeetingControls({ allowWhiteboard: value === 'everyone' })} options={[['everyone','Everyone'], ['hosts','Host/co-hosts only']]} />
                <SelectRow label="Allow Chat" value={meeting.allowChat ? 'everyone' : 'hosts'} onChange={(value) => updateMeetingControls({ allowChat: value === 'everyone' })} options={[['everyone','Everyone'], ['hosts','Host/co-hosts only']]} />
                <SelectRow label="Layout" value={meeting.presenterLayout} onChange={(value) => updateMeetingControls({ presenterLayout: value as Meeting['presenterLayout'] })} options={[['presenter','Presenter'], ['side_by_side','Side by side'], ['gallery','Gallery']]} />
                <button type="button" onClick={() => setConfirmEnd(true)} className="mt-2 w-full rounded-2xl bg-rose-600 px-4 py-3 text-sm font-black text-white transition hover:bg-rose-500">End Meeting for Everyone</button>
              </div>
            </div>
          </div>
        </section>}

        {!canManageParticipants && !canManageWaiting && <p className="rounded-2xl bg-white/5 p-3 text-xs text-slate-400">Host controls are hidden. Only admins, hosts, and co-hosts with explicitly granted permissions can manage participants.</p>}
      </div>

      {renaming && <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4">
        <form onSubmit={submitRename} className="w-full max-w-md rounded-4xl border border-white/10 bg-slate-950 p-5 shadow-2xl">
          <h3 className="text-lg font-black">Rename participant</h3>
          <p className="mt-1 text-sm text-slate-400">Update the display name visible to everyone in this meeting.</p>
          <input autoFocus value={renameValue} onChange={(e) => setRenameValue(e.target.value)} minLength={2} maxLength={120} className="mt-4 w-full rounded-2xl border border-white/10 bg-white/10 px-4 py-3 outline-none focus:ring-2 focus:ring-brand-500" />
          <div className="mt-4 flex justify-end gap-2"><button type="button" onClick={() => setRenaming(null)} className="rounded-2xl bg-white/10 px-4 py-2 font-bold">Cancel</button><button disabled={renameValue.trim().length < 2} className="rounded-2xl bg-brand-600 px-4 py-2 font-bold disabled:opacity-50">Save name</button></div>
        </form>
      </div>}

      {qualityTarget && <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4">
        <div className="w-full max-w-lg rounded-4xl border border-white/10 bg-slate-950 p-5 shadow-2xl">
          <div className="flex items-start justify-between gap-3"><div><h3 className="text-lg font-black">Connection quality</h3><p className="text-sm text-slate-400">{qualityTarget.displayName}</p></div><button onClick={() => setQualityTarget(null)} className="rounded-2xl bg-white/10 p-2"><X size={16}/></button></div>
          <div className="mt-4 grid gap-2 text-sm sm:grid-cols-2">
            {qualityRows(qualityTarget).map((row) => <div key={row.label} className="rounded-2xl bg-white/5 p-3"><p className="text-xs uppercase tracking-wider text-slate-500">{row.label}</p><p className="mt-1 font-bold text-slate-100">{row.value}</p></div>)}
          </div>
        </div>
      </div>}

      {confirmEnd && <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4">
        <div className="w-full max-w-md rounded-4xl border border-white/10 bg-slate-950 p-5 shadow-2xl">
          <h3 className="text-lg font-black text-rose-100">End meeting for everyone?</h3>
          <p className="mt-2 text-sm text-slate-400">All admitted and waiting participants will be disconnected or marked left. This action is immediate.</p>
          <div className="mt-5 flex justify-end gap-2"><button type="button" onClick={() => setConfirmEnd(false)} className="rounded-2xl bg-white/10 px-4 py-2 font-bold">Cancel</button><button type="button" onClick={endMeeting} className="rounded-2xl bg-rose-600 px-4 py-2 font-bold">End meeting</button></div>
        </div>
      </div>}
    </aside>
  );
}

function ParticipantCard({ person, currentParticipant, selected = false, onSelectedChange, menuOpen, onToggleMenu, onAction }: { person: Participant; currentParticipant: Participant; selected?: boolean; onSelectedChange?: (checked: boolean) => void; menuOpen: boolean; onToggleMenu: () => void; onAction: (action: string) => void }) {
  const controls = person.hostControls || {};
  const canManagePerson = person.id !== currentParticipant.id && person.role !== 'host' && canManage(currentParticipant, 'mute');
  const isHost = currentParticipant.role === 'host';
  const cohostHasManagement = Array.isArray(controls.cohostPermissions) && controls.cohostPermissions.includes('participants.manage');
  return (
    <article className={`rounded-2xl border p-3 transition ${controls.spotlighted ? 'border-amber-400/60 bg-amber-400/10' : controls.pinned ? 'border-brand-400/50 bg-brand-400/10' : 'border-white/10 bg-white/5'}`}>
      <div className="flex items-center justify-between gap-3">
        {onSelectedChange && person.role !== 'host' && person.id !== currentParticipant.id && <input type="checkbox" checked={selected} onChange={(e)=>onSelectedChange(e.target.checked)} className="h-4 w-4 accent-brand-600" aria-label={`Select ${person.displayName}`} />}
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2"><p className="truncate font-bold">{person.displayName}</p>{roleBadge(person)}{controls.handRaised && <span className="inline-flex items-center gap-1 rounded-full bg-amber-400/20 px-2 py-0.5 text-[11px] font-bold text-amber-200"><Hand size={12}/>Hand raised</span>}{controls.presenter && <span className="rounded-full bg-sky-400/20 px-2 py-0.5 text-[11px] font-bold text-sky-200">Presenter</span>}{controls.spotlighted && <span className="rounded-full bg-amber-400/20 px-2 py-0.5 text-[11px] font-bold text-amber-200">Spotlight</span>}{controls.pinned && <span className="rounded-full bg-brand-400/20 px-2 py-0.5 text-[11px] font-bold text-brand-100">Pinned</span>}</div>
          <div className="mt-2 flex flex-wrap gap-2 text-xs text-slate-300">
            <StatusPill icon={person.cameraEnabled && !person.videoDisabled ? <Camera size={13}/> : <CameraOff size={13}/>} label={person.cameraEnabled && !person.videoDisabled ? 'Camera on' : 'Camera off'} tone={person.cameraEnabled && !person.videoDisabled ? 'good' : 'muted'} />
            <StatusPill icon={!person.muted && !person.audioDisabled ? <Mic size={13}/> : <MicOff size={13}/>} label={!person.muted && !person.audioDisabled ? 'Mic on' : person.audioDisabled ? 'Mic disabled' : 'Muted'} tone={!person.muted && !person.audioDisabled ? 'good' : 'muted'} />
            <StatusPill icon={<Wifi size={13}/>} label={qualityLabel(person)} tone={qualityTone(person)} />
          </div>
        </div>
        {canManagePerson && <button type="button" onClick={onToggleMenu} className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-brand-400/60 bg-brand-600/20 text-brand-100 transition hover:bg-brand-600" title="Host controls and more options" aria-label={`Host controls for ${person.displayName}`}><MoreVertical size={18}/></button>}
      </div>
      {menuOpen && canManagePerson && <div className="mt-3 grid gap-2 rounded-2xl border border-white/10 bg-slate-900/95 p-2 text-xs font-bold sm:grid-cols-2">
        <ActionButton onClick={() => onAction('mute')} icon={<MicOff size={14}/>} label="Mute" />
        <ActionButton onClick={() => onAction('ask_unmute')} icon={<Mic size={14}/>} label="Ask to Unmute" />
        <ActionButton onClick={() => onAction(person.audioDisabled ? 'enable_audio' : 'disable_audio')} icon={<MicOff size={14}/>} label={person.audioDisabled ? 'Enable Mic' : 'Disable Mic'} />
        <ActionButton onClick={() => onAction(person.videoDisabled ? 'enable_video' : 'disable_video')} icon={<Video size={14}/>} label={person.videoDisabled ? 'Enable Camera' : 'Disable Camera'} />
        <ActionButton onClick={() => onAction(person.screenShareDisabled || controls.screenShareRevoked ? 'grant_screen_share' : 'revoke_screen_share')} icon={<MonitorUp size={14}/>} label={person.screenShareDisabled || controls.screenShareRevoked ? 'Grant Screen Share' : 'Revoke Screen Share'} />
        <ActionButton onClick={() => onAction(controls.whiteboardRevoked ? 'grant_whiteboard' : 'revoke_whiteboard')} icon={<ShieldCheck size={14}/>} label={controls.whiteboardRevoked ? 'Grant Whiteboard' : 'Revoke Whiteboard'} />
        {isHost && <ActionButton onClick={() => onAction(person.role === 'cohost' ? 'demote_cohost' : 'promote_cohost')} icon={person.role === 'cohost' ? <ShieldOff size={14}/> : <Shield size={14}/>} label={person.role === 'cohost' ? 'Remove Co-host' : 'Promote to Co-host'} />}
        {isHost && person.role === 'cohost' && <ActionButton onClick={() => onAction(cohostHasManagement ? 'revoke_cohost_controls' : 'grant_cohost_controls')} icon={<ShieldCheck size={14}/>} label={cohostHasManagement ? 'Revoke Co-host Controls' : 'Grant Co-host Controls'} />}
        <ActionButton onClick={() => onAction(controls.presenter ? 'clear_presenter' : 'change_presenter')} icon={<Crown size={14}/>} label={controls.presenter ? 'Clear Presenter' : 'Make Presenter'} />
        <ActionButton onClick={() => onAction(controls.pinned ? 'unpin' : 'pin')} icon={<Pin size={14}/>} label={controls.pinned ? 'Unpin' : 'Pin'} />
        <ActionButton onClick={() => onAction(controls.spotlighted ? 'clear_spotlight' : 'spotlight')} icon={<Star size={14}/>} label={controls.spotlighted ? 'Clear Spotlight' : 'Spotlight'} />
        <ActionButton onClick={() => onAction('rename')} icon={<UserRoundCog size={14}/>} label="Rename" />
        <ActionButton onClick={() => onAction('view_quality')} icon={<Wifi size={14}/>} label="View Connection Info" />
        <ActionButton danger onClick={() => onAction('move_waiting')} icon={<UserMinus size={14}/>} label="Move to Waiting Room" />
        <ActionButton danger onClick={() => onAction('remove')} icon={<UserX size={14}/>} label="Remove" />
        <ActionButton danger onClick={() => onAction('ban')} icon={<Ban size={14}/>} label="Ban from Meeting" />
      </div>}
    </article>
  );
}

function JoinRequestCard({ person, meeting, canManage, onAction }: { person: Participant; meeting: Meeting; canManage: boolean; onAction: (action: string) => void }) {
  return (
    <article className="rounded-2xl border border-amber-400/20 bg-amber-400/10 p-3">
      <div className="flex items-start justify-between gap-3"><div className="min-w-0"><p className="truncate font-bold">{person.displayName}</p><p className="mt-1 text-xs text-amber-100">Requested {formatTime(person.joinedAt || person.createdAt)} · {meeting.title}</p><p className="mt-1 text-xs text-slate-400">Meeting code {meeting.meetingId}</p><p className="mt-1 text-xs text-slate-400">{deviceLabel(person)}</p></div><span className="rounded-full bg-amber-400/20 px-2 py-1 text-[11px] font-black text-amber-100">Waiting</span></div>
      {canManage && <div className="mt-3 grid grid-cols-3 gap-2 text-xs font-bold"><button onClick={() => onAction('admit')} className="rounded-xl bg-emerald-600 px-2 py-2"><UserCheck className="mr-1 inline" size={14}/>Approve</button><button onClick={() => onAction('reject')} className="rounded-xl bg-rose-600 px-2 py-2"><UserX className="mr-1 inline" size={14}/>Reject</button><button onClick={() => onAction('ban')} className="rounded-xl bg-slate-800 px-2 py-2 text-rose-200"><Ban className="mr-1 inline" size={14}/>Ban</button></div>}
    </article>
  );
}

function SectionHeader({ title, open, onToggle }: { title: string; open: boolean; onToggle: () => void }) {
  return <button type="button" onClick={onToggle} className="flex w-full items-center justify-between gap-3 text-left"><span className="font-black">{title}</span><span className="rounded-xl bg-white/10 p-1">{open ? <ChevronUp size={15}/> : <ChevronDown size={15}/>}</span></button>;
}

function EmptyState({ label }: { label: string }) {
  return <div className="rounded-2xl border border-dashed border-white/10 p-5 text-center text-sm text-slate-500">{label}</div>;
}

function ToggleRow({ label, enabled, onClick }: { label: string; enabled: boolean; onClick: () => void }) {
  return <div className="flex items-center justify-between gap-3 rounded-2xl bg-white/5 px-3 py-2"><span className="font-semibold">{label}</span><button type="button" onClick={onClick} className={`relative h-7 w-12 rounded-full transition ${enabled ? 'bg-emerald-500' : 'bg-slate-700'}`} aria-label={label}><span className={`absolute top-1 h-5 w-5 rounded-full bg-white transition ${enabled ? 'left-6' : 'left-1'}`} /></button></div>;
}

function SelectRow({ label, value, onChange, options }: { label: string; value: string; onChange: (value: string) => void; options: [string, string][] }) {
  return <label className="flex items-center justify-between gap-3 rounded-2xl bg-white/5 px-3 py-2"><span className="font-semibold">{label}</span><select value={value} onChange={(e)=>onChange(e.target.value)} className="max-w-[170px] rounded-xl border border-white/10 bg-slate-900 px-2 py-2 text-xs font-bold outline-none focus:ring-2 focus:ring-brand-500">{options.map(([id, name]) => <option key={id} value={id}>{name}</option>)}</select></label>;
}

function ActionButton({ label, icon, onClick, danger = false }: { label: string; icon: ReactNode; onClick: () => void; danger?: boolean }) {
  return <button type="button" onClick={onClick} className={`inline-flex items-center justify-start gap-2 rounded-xl px-3 py-2 text-left transition ${danger ? 'bg-rose-600/85 text-white hover:bg-rose-600' : 'bg-white/10 text-slate-100 hover:bg-white/15'}`}>{icon}<span>{label}</span></button>;
}

function StatusPill({ icon, label, tone }: { icon: ReactNode; label: string; tone: 'good' | 'muted' | 'warn' }) {
  const cls = tone === 'good' ? 'bg-emerald-400/15 text-emerald-100' : tone === 'warn' ? 'bg-amber-400/15 text-amber-100' : 'bg-white/10 text-slate-300';
  return <span className={`inline-flex items-center gap-1 rounded-full px-2 py-1 ${cls}`}>{icon}{label}</span>;
}

function actionPermissions(action: string) {
  const map: Record<string, string[]> = {
    admit: ['participants.manage', 'waiting.admit'], reject: ['participants.manage', 'waiting.reject'], ban: ['participants.manage', 'waiting.ban'],
    mute: ['participants.manage', 'participants.mute'], ask_unmute: ['participants.manage', 'participants.mute'], disable_audio: ['participants.manage', 'participants.mute'], enable_audio: ['participants.manage', 'participants.mute'],
    disable_video: ['participants.manage', 'participants.camera.disable'], enable_video: ['participants.manage', 'participants.camera.disable'],
    grant_screen_share: ['participants.manage', 'sharing.grant'], revoke_screen_share: ['participants.manage', 'sharing.revoke'], grant_whiteboard: ['participants.manage', 'whiteboard.grant'], revoke_whiteboard: ['participants.manage', 'whiteboard.revoke'],
    change_presenter: ['participants.manage', 'presenter.change'], clear_presenter: ['participants.manage', 'presenter.change'], pin: ['participants.manage', 'participants.pin'], unpin: ['participants.manage', 'participants.pin'], spotlight: ['participants.manage', 'participants.pin'], clear_spotlight: ['participants.manage', 'participants.pin'],
    rename: ['participants.manage', 'participants.rename'], remove: ['participants.manage', 'participants.remove'], move_waiting: ['participants.manage', 'participants.remove'], 'participants.manage': ['participants.manage'],
  };
  return map[action] || [action, 'participants.manage'];
}

function canManage(participant: Participant, action: string) {
  if (!managementActions.has(action) && action !== 'participants.manage') return false;
  if (participant.role === 'host') return true;
  if (participant.role !== 'cohost') return false;
  const permissions = participant.hostControls?.cohostPermissions || [];
  return actionPermissions(action).some((permission) => permissions.includes(permission));
}

function roleBadge(person: Participant) {
  if (person.role === 'host') return <span className="inline-flex items-center gap-1 rounded-full bg-amber-400/20 px-2 py-0.5 text-[11px] font-bold text-amber-100"><Crown size={12}/>Host</span>;
  if (person.role === 'cohost') return <span className="inline-flex items-center gap-1 rounded-full bg-sky-400/20 px-2 py-0.5 text-[11px] font-bold text-sky-100"><Shield size={12}/>Co-host</span>;
  if (person.role === 'moderator') return <span className="rounded-full bg-violet-400/20 px-2 py-0.5 text-[11px] font-bold text-violet-100">Moderator</span>;
  if (person.role === 'presenter') return <span className="rounded-full bg-emerald-400/20 px-2 py-0.5 text-[11px] font-bold text-emerald-100">Presenter</span>;
  if (person.status === 'waiting' || person.role === 'guest') return <span className="rounded-full bg-white/10 px-2 py-0.5 text-[11px] font-bold text-slate-200">Guest</span>;
  return <span className="rounded-full bg-white/10 px-2 py-0.5 text-[11px] font-bold text-slate-200">Participant</span>;
}

function qualityLabel(person: Participant) {
  const report = person.lastQualityReport || {};
  const quality = String(report.quality || report.connectionQuality || report.roomState || 'unknown');
  return quality === 'unknown' ? 'Quality unknown' : `Quality ${quality}`;
}

function qualityTone(person: Participant): 'good' | 'muted' | 'warn' {
  const q = qualityLabel(person).toLowerCase();
  if (q.includes('excellent') || q.includes('good') || q.includes('connected')) return 'good';
  if (q.includes('poor') || q.includes('lost') || q.includes('offline')) return 'warn';
  return 'muted';
}

function qualityRows(person: Participant) {
  const report = person.lastQualityReport || {};
  return [
    { label: 'Quality', value: String(report.quality || report.connectionQuality || 'Unknown') },
    { label: 'Room state', value: String(report.roomState || 'Unknown') },
    { label: 'Network', value: String(report.networkType || report.effectiveType || person.networkType || 'Unknown') },
    { label: 'RTT', value: report.rttMs || report.rtt ? `${report.rttMs || report.rtt} ms` : 'Unknown' },
    { label: 'Downlink', value: report.downlinkMbps || report.downlink ? `${report.downlinkMbps || report.downlink} Mbps` : 'Unknown' },
    { label: 'ICE', value: String(report.iceState || 'Unknown') },
  ];
}

function deviceLabel(person: Participant) {
  const info = person.deviceInfo || {};
  const ua = String(person.userAgent || info.userAgent || '');
  const browser = ua.includes('Edg') ? 'Microsoft Edge' : ua.includes('Chrome') ? 'Chrome' : ua.includes('Firefox') ? 'Firefox' : ua.includes('Safari') ? 'Safari' : ua ? 'Browser available' : 'Browser unavailable';
  const device = info.mobileClient || person.mobileClient ? 'Mobile device' : 'Desktop/tablet';
  const camera = info.videoDevice ? ` · ${String(info.videoDevice)}` : '';
  const mic = info.audioDevice ? ` · ${String(info.audioDevice)}` : '';
  return `${device} · ${browser}${camera}${mic}`;
}

function formatTime(value?: string | null) {
  if (!value) return 'just now';
  try { return new Date(value).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); } catch { return 'just now'; }
}

function sortPeople(items: Participant[], mode: 'role' | 'speaking' | 'hand' | 'join' | 'name', activeSpeakerIds: Set<string>) {
  const roleOrder = (value: Participant['role']) => value === 'host' ? 0 : value === 'cohost' ? 1 : value === 'moderator' ? 2 : value === 'presenter' ? 3 : 4;
  return [...items].sort((a, b) => {
    if (mode === 'speaking') return Number(activeSpeakerIds.has(b.id)) - Number(activeSpeakerIds.has(a.id)) || a.displayName.localeCompare(b.displayName);
    if (mode === 'hand') return Number(Boolean(b.hostControls?.handRaised)) - Number(Boolean(a.hostControls?.handRaised)) || a.displayName.localeCompare(b.displayName);
    if (mode === 'join') return new Date(a.joinedAt || a.createdAt || 0).getTime() - new Date(b.joinedAt || b.createdAt || 0).getTime();
    if (mode === 'name') return a.displayName.localeCompare(b.displayName);
    return roleOrder(a.role) - roleOrder(b.role) || a.displayName.localeCompare(b.displayName);
  });
}

function groupPeople(items: Participant[]) {
  const groups = [
    { role: 'host', label: 'Hosts', items: items.filter((item) => item.role === 'host') },
    { role: 'cohost', label: 'Co-hosts', items: items.filter((item) => item.role === 'cohost') },
    { role: 'moderator', label: 'Moderators', items: items.filter((item) => item.role === 'moderator') },
    { role: 'presenter', label: 'Presenters', items: items.filter((item) => item.role === 'presenter') },
    { role: 'participant', label: 'Participants', items: items.filter((item) => item.role === 'participant' || item.role === 'guest') },
  ];
  return groups.filter((group) => group.items.length);
}

function sortParticipants(items: Participant[]) {
  return [...items].sort((a, b) => {
    const statusOrder = (value: Participant['status']) => value === 'admitted' ? 0 : value === 'waiting' ? 1 : 2;
    const statusDiff = statusOrder(a.status) - statusOrder(b.status);
    if (statusDiff !== 0) return statusDiff;
    const roleOrder = (value: Participant['role']) => value === 'host' ? 0 : value === 'cohost' ? 1 : value === 'moderator' ? 2 : value === 'presenter' ? 3 : 4;
    const roleDiff = roleOrder(a.role) - roleOrder(b.role);
    if (roleDiff !== 0) return roleDiff;
    return (a.displayName || '').localeCompare(b.displayName || '');
  });
}

function actionSuccess(action: string) {
  const labels: Record<string, string> = {
    admit: 'Join request approved', reject: 'Join request rejected', ban: 'Participant banned', mute: 'Participant muted', ask_unmute: 'Unmute request sent', disable_audio: 'Microphone disabled', enable_audio: 'Microphone enabled', disable_video: 'Camera disabled', enable_video: 'Camera enabled', grant_screen_share: 'Screen sharing granted', revoke_screen_share: 'Screen sharing revoked', grant_whiteboard: 'Whiteboard granted', revoke_whiteboard: 'Whiteboard revoked', promote_cohost: 'Participant promoted to co-host', demote_cohost: 'Co-host role removed', grant_cohost_controls: 'Co-host controls granted', revoke_cohost_controls: 'Co-host controls revoked', change_presenter: 'Presenter changed', clear_presenter: 'Presenter cleared', pin: 'Participant pinned', unpin: 'Participant unpinned', spotlight: 'Participant spotlighted', clear_spotlight: 'Spotlight cleared', rename: 'Participant renamed', remove: 'Participant removed', move_waiting: 'Participant moved to waiting room',
  };
  return labels[action] || 'Participant updated';
}
