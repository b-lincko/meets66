'use client';

import { Moon, Sun } from 'lucide-react';
import { useEffect, useState } from 'react';

export function ThemeToggle() {
  const [dark, setDark] = useState(false);
  useEffect(() => {
    const saved = localStorage.getItem('defensiq.theme');
    const enabled = saved ? saved === 'dark' : window.matchMedia('(prefers-color-scheme: dark)').matches;
    setDark(enabled);
    document.documentElement.classList.toggle('dark', enabled);
  }, []);
  function toggle() {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle('dark', next);
    localStorage.setItem('defensiq.theme', next ? 'dark' : 'light');
  }
  return <button onClick={toggle} aria-label="Toggle theme" className="rounded-2xl border border-slate-200 bg-white/80 p-3 dark:border-slate-700 dark:bg-slate-900">{dark ? <Sun size={18}/> : <Moon size={18}/>}</button>;
}
