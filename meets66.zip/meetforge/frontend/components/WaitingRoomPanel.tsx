'use client';

import { Crown, Lock, MicOff, PhoneOff, RefreshCcw, Shield, ShieldOff, UserCheck, UserMinus, UserX, VideoOff } from 'lucide-react';
import { useEffect, useState } from 'react';
import { toast } from 'sonner';
import { api, Meeting, Participant } from '@/lib/api';
import { getSocket } from '@/lib/socket';

export function WaitingRoomPanel({ meeting, onMeetingUpdate, visible = true }: { meeting: Meeting; onMeetingUpdate?: (meeting: Meeting) => void; visible?: boolean }) {
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [confirmEnd, setConfirmEnd] = useState(false);
  const meetingId = meeting.id;
  async function load() {
    const data = await api<{ items: Participant[]; total: number }>(`/meetings/${meetingId}/participants`);
    setParticipants(data.items);
  }
  useEffect(() => {
    load().catch(() => {});
    const socket = getSocket();
    socket.emit('meeting:watch', { meetingId });
    const participantHandler = (participant: Participant) => setParticipants((prev) => prev.some((p) => p.id === participant.id) ? prev.map((p) => p.id === participant.id ? participant : p) : [...prev, participant]);
    const meetingHandler = (updated: Meeting) => { if (updated.id === meetingId) onMeetingUpdate?.(updated); };
    socket.on('participant:updated', participantHandler);
    socket.on('meeting:updated', meetingHandler);
    return () => { socket.off('participant:updated', participantHandler); socket.off('meeting:updated', meetingHandler); };
  }, [meetingId]);
  async function decide(participant: Participant, action: 'admit' | 'reject') {
    try {
      const data = await api<{ participant: Participant }>(`/meetings/${meetingId}/participants/${participant.id}/${action}`, { method: 'POST' });
      setParticipants((prev) => prev.map((p) => p.id === participant.id ? data.participant : p));
      toast.success(action === 'admit' ? 'Participant admitted' : 'Participant rejected');
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Action failed'); }
  }
  async function control(patch: Partial<Meeting>) {
    try {
      const data = await api<{ meeting: Meeting }>(`/meetings/${meetingId}/controls`, { method: 'PATCH', body: JSON.stringify(patch) });
      onMeetingUpdate?.(data.meeting);
      toast.success('Meeting control updated');
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Control failed'); }
  }
  async function endMeeting() {
    try {
      const data = await api<{ meeting: Meeting }>(`/meetings/${meetingId}/end`, { method: 'POST' });
      onMeetingUpdate?.(data.meeting);
      setConfirmEnd(false);
      toast.success('Meeting ended');
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Could not end meeting'); }
  }
  async function participantAction(participant: Participant, action: string) {
    try {
      const data = await api<{ participant: Participant; meeting: Meeting }>(`/meetings/${meetingId}/participants/${participant.id}/action`, { method: 'POST', body: JSON.stringify({ action }) });
      setParticipants((prev) => prev.map((p) => p.id === participant.id ? data.participant : p));
      onMeetingUpdate?.(data.meeting);
      toast.success('Participant updated');
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Participant action failed'); }
  }
  if (!visible) return null;
  const waiting = participants.filter((p) => p.status === 'waiting');
  const admitted = participants.filter((p) => p.status === 'admitted');
  return (
    <aside className="flex h-full min-h-0 flex-col rounded-4xl border border-white/10 bg-slate-950/95 p-4 text-white shadow-2xl backdrop-blur-xl">
      <div className="mb-3 flex items-center justify-between"><div><h3 className="font-bold">Host controls</h3><p className="text-xs text-slate-400">{waiting.length} waiting · {admitted.length} admitted</p></div><button onClick={()=>load().catch(()=>{})} className="rounded-xl bg-white/10 p-2"><RefreshCcw size={16}/></button></div>
      <div className="mb-3 grid grid-cols-2 gap-2 text-xs font-bold">
        <button onClick={()=>control({ isLocked: !meeting.isLocked })} className={`rounded-xl px-3 py-2 ${meeting.isLocked ? 'bg-amber-600' : 'bg-white/10'}`}><Lock className="mr-1 inline" size={14}/>{meeting.isLocked ? 'Unlock' : 'Lock'}</button>
        <button onClick={()=>control({ allowParticipantAudio: !meeting.allowParticipantAudio })} className={`rounded-xl px-3 py-2 ${meeting.allowParticipantAudio ? 'bg-white/10' : 'bg-rose-600'}`}>Mics {meeting.allowParticipantAudio ? 'on' : 'off'}</button>
        <button onClick={()=>control({ allowParticipantVideo: !meeting.allowParticipantVideo })} className={`rounded-xl px-3 py-2 ${meeting.allowParticipantVideo ? 'bg-white/10' : 'bg-rose-600'}`}>Cameras {meeting.allowParticipantVideo ? 'on' : 'off'}</button>
        <button onClick={()=>control({ allowScreenShare: !meeting.allowScreenShare })} className={`rounded-xl px-3 py-2 ${meeting.allowScreenShare ? 'bg-white/10' : 'bg-rose-600'}`}>Share {meeting.allowScreenShare ? 'on' : 'off'}</button>
        <button onClick={()=>control({ allowChat: !meeting.allowChat })} className={`rounded-xl px-3 py-2 ${meeting.allowChat ? 'bg-white/10' : 'bg-rose-600'}`}>Chat {meeting.allowChat ? 'on' : 'off'}</button>
        <button onClick={()=>control({ allowWhiteboard: !meeting.allowWhiteboard })} className={`rounded-xl px-3 py-2 ${meeting.allowWhiteboard ? 'bg-white/10' : 'bg-rose-600'}`}>Board {meeting.allowWhiteboard ? 'on' : 'off'}</button>
        <select value={meeting.screenSharePolicy} onChange={(e)=>control({ screenSharePolicy: e.target.value as any })} className="rounded-xl border border-white/10 bg-slate-900 px-2 py-2"><option value="host">Host share</option><option value="cohosts">Host + co-hosts</option><option value="all">All share</option></select>
        <select value={meeting.presenterLayout} onChange={(e)=>control({ presenterLayout: e.target.value as any })} className="rounded-xl border border-white/10 bg-slate-900 px-2 py-2"><option value="presenter">Presenter</option><option value="side_by_side">Side by side</option><option value="gallery">Gallery</option></select>
        <button onClick={()=>setConfirmEnd(true)} className="col-span-2 rounded-xl bg-rose-700 px-3 py-2"><PhoneOff className="mr-1 inline" size={14}/>End</button>
      </div>
      <div className="min-h-0 flex-1 space-y-2 overflow-auto">
        {waiting.map((p)=><div key={p.id} className="rounded-2xl bg-amber-500/10 p-3"><p className="font-semibold">{p.displayName}</p><p className="text-xs text-amber-200">Waiting for approval</p><div className="mt-2 flex gap-2"><button onClick={()=>decide(p,'admit')} className="flex flex-1 items-center justify-center gap-1 rounded-xl bg-emerald-600 py-2 text-xs font-bold"><UserCheck size={14}/>Admit</button><button onClick={()=>decide(p,'reject')} className="flex flex-1 items-center justify-center gap-1 rounded-xl bg-rose-600 py-2 text-xs font-bold"><UserX size={14}/>Reject</button></div></div>)}
        {admitted.map((p)=><div key={p.id} className="rounded-2xl bg-white/10 p-3"><div className="flex items-start justify-between gap-2"><div><p className="font-semibold">{p.displayName}</p><p className="text-xs text-slate-400">{p.role} · {p.muted ? 'muted' : 'audio allowed'}{p.audioDisabled ? ' · mic disabled' : ''}{p.videoDisabled ? ' · camera disabled' : ''}</p></div>{p.role === 'host' && <Crown size={16} className="text-amber-300"/>}{p.role === 'cohost' && <Shield size={16} className="text-blue-300"/>}</div>{p.role !== 'host' && <div className="mt-2 grid grid-cols-2 gap-2 text-xs"><button onClick={()=>participantAction(p,'mute')} className="rounded-xl bg-white/10 py-2"><MicOff className="mr-1 inline" size={13}/>Mute</button><button onClick={()=>participantAction(p,'disable_audio')} className="rounded-xl bg-white/10 py-2"><MicOff className="mr-1 inline" size={13}/>Mic off</button><button onClick={()=>participantAction(p,'disable_video')} className="rounded-xl bg-white/10 py-2"><VideoOff className="mr-1 inline" size={13}/>Camera off</button>{p.screenSharing && <button onClick={()=>participantAction(p,'stop_screen_share')} className="rounded-xl bg-white/10 py-2">Stop share</button>}<button onClick={()=>participantAction(p, p.role === 'cohost' ? 'demote_cohost' : 'promote_cohost')} className="rounded-xl bg-white/10 py-2">{p.role === 'cohost' ? <ShieldOff className="mr-1 inline" size={13}/> : <Shield className="mr-1 inline" size={13}/>}{p.role === 'cohost' ? 'Demote' : 'Co-host'}</button><button onClick={()=>participantAction(p,'remove')} className="rounded-xl bg-rose-700 py-2"><UserMinus className="mr-1 inline" size={13}/>Remove</button></div>}</div>)}
        {!participants.length && <p className="py-8 text-center text-sm text-slate-500">No participants yet.</p>}
      </div>
      {confirmEnd && <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4"><div className="w-full max-w-md rounded-4xl border border-white/10 bg-slate-950 p-5 shadow-2xl"><h4 className="text-lg font-black text-rose-100">End meeting for everyone?</h4><p className="mt-2 text-sm text-slate-400">All admitted and waiting participants will be disconnected or marked left.</p><div className="mt-5 flex justify-end gap-2"><button onClick={()=>setConfirmEnd(false)} className="rounded-2xl bg-white/10 px-4 py-2 font-bold">Cancel</button><button onClick={endMeeting} className="rounded-2xl bg-rose-600 px-4 py-2 font-bold">End meeting</button></div></div></div>}
    </aside>
  );
}
