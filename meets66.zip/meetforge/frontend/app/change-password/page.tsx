'use client';

import { KeyRound } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { toast } from 'sonner';
import { Button } from '@/components/Button';
import { NotFoundScreen } from '@/components/AdminGuard';
import { ThemeToggle } from '@/components/ThemeToggle';
import { Admin, api, cachedAdmin, saveAuth } from '@/lib/api';

type ChangeResponse = { admin: Admin; accessToken: string; refreshToken: string; csrfToken?: string; forceChangePassword: boolean };

export default function ChangePasswordPage() {
  const router = useRouter();
  const [form, setForm] = useState({ currentPassword: '', newPassword: '', confirmPassword: '' });
  const [loading, setLoading] = useState(false);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    if (!cachedAdmin()) setNotFound(true);
  }, [router]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      const data = await api<ChangeResponse>('/auth/change-password', { method: 'POST', body: JSON.stringify(form) });
      saveAuth(data.accessToken, data.refreshToken, data.admin, data.csrfToken);
      toast.success('Password changed');
      router.push('/dashboard');
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Password change failed');
    } finally {
      setLoading(false);
    }
  }

  if (notFound) return <NotFoundScreen />;
  return (
    <main className="grid min-h-screen place-items-center bg-mesh p-4 dark:bg-slate-950">
      <div className="absolute right-4 top-4"><ThemeToggle /></div>
      <form onSubmit={submit} className="glass w-full max-w-md rounded-4xl p-8">
        <div className="mb-8 text-center">
          <span className="mx-auto grid h-14 w-14 place-items-center rounded-3xl bg-brand-600 text-white"><KeyRound /></span>
          <h1 className="mt-4 text-3xl font-black text-slate-950 dark:text-white">Change administrator password</h1>
          <p className="mt-2 text-slate-500 dark:text-slate-400">A strong password is required before console access is granted.</p>
        </div>
        <input type="password" required autoComplete="current-password" placeholder="Current password" value={form.currentPassword} onChange={(e)=>setForm({...form,currentPassword:e.target.value})} className="w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 outline-none focus:ring-2 focus:ring-brand-500 dark:border-slate-700 dark:bg-slate-900" />
        <input type="password" required autoComplete="new-password" placeholder="New password" value={form.newPassword} onChange={(e)=>setForm({...form,newPassword:e.target.value})} className="mt-4 w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 outline-none focus:ring-2 focus:ring-brand-500 dark:border-slate-700 dark:bg-slate-900" />
        <input type="password" required autoComplete="new-password" placeholder="Confirm new password" value={form.confirmPassword} onChange={(e)=>setForm({...form,confirmPassword:e.target.value})} className="mt-4 w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 outline-none focus:ring-2 focus:ring-brand-500 dark:border-slate-700 dark:bg-slate-900" />
        <Button className="mt-6 w-full" disabled={loading}>{loading ? 'Saving...' : 'Change password'}</Button>
      </form>
    </main>
  );
}
