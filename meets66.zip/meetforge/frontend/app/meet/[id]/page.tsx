import { HostMeetingClient } from './HostMeetingClient';

export default async function HostMeetingPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <HostMeetingClient id={id} />;
}
