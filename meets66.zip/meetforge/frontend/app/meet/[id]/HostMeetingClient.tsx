'use client';

import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { toast } from 'sonner';
import { NotFoundScreen } from '@/components/AdminGuard';
import { MediaRoom } from '@/components/MediaRoom';
import { DeviceChoice, PreJoin } from '@/components/PreJoin';
import { Meeting, Participant, api, cachedAdmin } from '@/lib/api';

type MeetingResponse = { meeting: Meeting };
type HostTokenResponse = { meeting: Meeting; participant: Participant; participantToken: string; livekit: { url: string; token: string; roomName: string } };

export function HostMeetingClient({ id }: { id: string }) {
  const router = useRouter();
  const [meeting, setMeeting] = useState<Meeting | null>(null);
  const [participant, setParticipant] = useState<Participant | null>(null);
  const [livekit, setLivekit] = useState<HostTokenResponse['livekit'] | null>(null);
  const [devices, setDevices] = useState<DeviceChoice | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [joining, setJoining] = useState(false);

  useEffect(() => {
    if (!cachedAdmin()) { setNotFound(true); setLoading(false); return; }
    api<MeetingResponse>(`/meetings/${id}`)
      .then((data) => setMeeting(data.meeting))
      .catch(() => { setNotFound(true); })
      .finally(() => setLoading(false));
  }, [id, router]);

  async function join(choice: DeviceChoice) {
    setJoining(true);
    try {
      const data = await api<HostTokenResponse>(`/meetings/${id}/host-token`, { method: 'POST', body: JSON.stringify({ deviceInfo: choice.deviceInfo, lowBandwidthMode: choice.lowBandwidthMode, audioOnlyMode: choice.audioOnlyMode, preferredLayout: choice.preferredLayout, mobileClient: choice.mobileClient, networkType: choice.networkType }) });
      setMeeting(data.meeting);
      setParticipant(data.participant);
      setDevices(choice);
      setLivekit(data.livekit);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Could not join as host');
    } finally { setJoining(false); }
  }

  if (notFound) return <NotFoundScreen />;
  if (loading || !meeting) return <main className="grid min-h-screen place-items-center bg-slate-950 text-white">Loading meeting...</main>;
  if (livekit && devices && participant) return <MediaRoom title={meeting.title} meeting={meeting} livekit={livekit} devices={devices} participant={participant} onLeave={()=>router.push('/dashboard')} onMeetingUpdate={setMeeting} />;
  return <main className="min-h-screen bg-mesh p-4 dark:bg-slate-950"><PreJoin displayName="Defensiq Administrator" setDisplayName={()=>{}} requireName={false} onJoin={join} loading={joining} /></main>;
}
