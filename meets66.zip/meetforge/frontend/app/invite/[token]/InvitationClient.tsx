'use client';

import { CalendarClock, KeyRound, Link as LinkIcon, ShieldCheck } from 'lucide-react';
import { useEffect, useState } from 'react';
import { toast } from 'sonner';
import { MediaRoom } from '@/components/MediaRoom';
import { DeviceChoice, PreJoin } from '@/components/PreJoin';
import { Button } from '@/components/Button';
import { ThemeToggle } from '@/components/ThemeToggle';
import { getSocket } from '@/lib/socket';
import { API_URL, Meeting, MeetingInvitation, Participant, api } from '@/lib/api';

type InvitationResponse = { meeting: Meeting; invitation: MeetingInvitation };
type JoinResponse = { meeting: Meeting; participant: Participant; participantToken: string; requiresAdmission: boolean; livekit?: { url: string; token: string; roomName: string } };

export function InvitationClient({ token }: { token: string }) {
  const [meeting, setMeeting] = useState<Meeting | null>(null);
  const [invitation, setInvitation] = useState<MeetingInvitation | null>(null);
  const [password, setPassword] = useState('');
  const [passwordVerified, setPasswordVerified] = useState(false);
  const [displayName, setDisplayName] = useState('');
  const [participant, setParticipant] = useState<Participant | null>(null);
  const [participantToken, setParticipantToken] = useState('');
  const [livekit, setLivekit] = useState<JoinResponse['livekit'] | null>(null);
  const [devices, setDevices] = useState<DeviceChoice | null>(null);
  const [loading, setLoading] = useState(true);
  const [joining, setJoining] = useState(false);

  useEffect(() => {
    api<InvitationResponse>(`/meetings/invitations/${token}`, { auth: false })
      .then((data) => { setMeeting(data.meeting); setInvitation(data.invitation); setPasswordVerified(!data.meeting.hasPassword); })
      .catch((err) => toast.error(err instanceof Error ? err.message : 'Invitation could not be loaded'))
      .finally(() => setLoading(false));
  }, [token]);

  useEffect(() => {
    if (!participantToken || !participant || participant.status !== 'waiting') return;
    const socket = getSocket(participantToken);
    socket.emit('meeting:watch', { meetingId: participant.meetingId });
    const admitted = () => refreshStatus();
    const rejected = () => refreshStatus();
    socket.on('participant:admitted', admitted);
    socket.on('participant:rejected', rejected);
    const interval = window.setInterval(refreshStatus, 2500);
    return () => { socket.off('participant:admitted', admitted); socket.off('participant:rejected', rejected); window.clearInterval(interval); };
  }, [participantToken, participant?.id, participant?.status]);

  async function refreshStatus() {
    if (!participantToken) return;
    try {
      const data = await api<JoinResponse>(`/meetings/invitations/${token}/status`, { auth: false, headers: { Authorization: `Bearer ${participantToken}` } });
      setMeeting(data.meeting);
      setParticipant(data.participant);
      if (data.livekit) { setLivekit(data.livekit); toast.success('You have been admitted'); }
      if (data.participant.status === 'rejected') toast.error('Your join request was rejected');
    } catch {}
  }

  async function verifyPassword(e: React.FormEvent) {
    e.preventDefault();
    try {
      await api<{ valid: boolean; meeting: Meeting }>(`/meetings/invitations/${token}/verify-password`, { method: 'POST', auth: false, body: JSON.stringify({ password }) });
      setPasswordVerified(true);
      toast.success('Meeting password verified');
    } catch (err) {
      setPasswordVerified(false);
      toast.error(err instanceof Error ? err.message : 'Password verification failed');
    }
  }


  async function downloadIcs() {
    const res = await fetch(`${API_URL}/meetings/invitations/${token}/calendar.ics`);
    if (!res.ok) return toast.error('Calendar download failed');
    const url = URL.createObjectURL(await res.blob());
    const a = document.createElement('a');
    a.href = url;
    a.download = `${meeting?.meetingId || 'meeting'}.ics`;
    a.click();
    URL.revokeObjectURL(url);
  }

  async function openCalendar(provider: 'google' | 'outlook') {
    try {
      const data = await api<{ links: Record<string, string> }>(`/meetings/invitations/${token}/calendar-links`, { auth: false });
      window.open(data.links[provider], '_blank', 'noopener,noreferrer');
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Calendar link failed');
    }
  }

  async function join(choice: DeviceChoice) {
    setJoining(true);
    try {
      const data = await api<JoinResponse>(`/meetings/invitations/${token}/join`, { method: 'POST', auth: false, body: JSON.stringify({ displayName, password, deviceInfo: choice.deviceInfo, cameraEnabled: choice.startVideo, microphoneEnabled: choice.startAudio, lowBandwidthMode: choice.lowBandwidthMode, audioOnlyMode: choice.audioOnlyMode, preferredLayout: choice.preferredLayout, mobileClient: choice.mobileClient, networkType: choice.networkType }) });
      setMeeting(data.meeting);
      setParticipant(data.participant);
      setParticipantToken(data.participantToken);
      setDevices(choice);
      if (data.livekit) setLivekit(data.livekit);
      else toast.info('Waiting for host approval');
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Join failed'); }
    finally { setJoining(false); }
  }

  if (loading) return <main className="grid min-h-screen place-items-center bg-slate-950 text-white">Loading invitation...</main>;
  if (!meeting) return <main className="grid min-h-screen place-items-center bg-mesh p-4 dark:bg-slate-950"><div className="glass max-w-md rounded-4xl p-8 text-center"><h1 className="text-2xl font-black">Invitation unavailable</h1><p className="mt-2 text-slate-500">The invitation token is invalid or expired.</p></div></main>;
  if (livekit && devices && participant) return <MediaRoom title={meeting.title} meeting={meeting} livekit={livekit} devices={devices} participant={participant} participantToken={participantToken} inviteToken={token} onLeave={()=>{ setLivekit(null); setParticipant(null); }} onMeetingUpdate={setMeeting} />;
  if (participant?.status === 'waiting') return <WaitingScreen name={participant.displayName} />;
  if (participant?.status === 'rejected') return <main className="grid min-h-screen place-items-center bg-mesh p-4 dark:bg-slate-950"><div className="glass max-w-md rounded-4xl p-8 text-center"><h1 className="text-2xl font-black">Request rejected</h1><p className="mt-2 text-slate-500">The host did not admit this participant.</p></div></main>;

  return (
    <main className="min-h-screen bg-mesh p-4 dark:bg-slate-950">
      <div className="absolute right-4 top-4"><ThemeToggle /></div>
      <section className="glass mx-auto mb-6 mt-4 w-full max-w-5xl rounded-4xl p-6">
        <div className="text-center"><span className="mx-auto grid h-14 w-14 place-items-center rounded-3xl bg-brand-600 text-white"><ShieldCheck /></span><p className="mt-4 text-sm font-bold uppercase tracking-widest text-brand-600">Verified Defensiq invitation</p><h1 className="mt-2 text-3xl font-black text-slate-950 dark:text-white">{meeting.title}</h1></div>
        <div className="mt-6 grid gap-3 rounded-3xl bg-white/60 p-5 text-sm dark:bg-slate-900/60 sm:grid-cols-3"><p className="flex items-center gap-2"><CalendarClock size={16}/><span>{new Date(meeting.scheduledStartAt).toLocaleString()}</span></p><p className="flex items-center gap-2"><CalendarClock size={16}/><span>{new Date(meeting.scheduledEndAt).toLocaleString()}</span></p><p className="flex items-center gap-2"><LinkIcon size={16}/><span className="font-mono">{meeting.meetingId}</span></p></div><div className="mt-4 flex flex-wrap justify-center gap-2"><Button type="button" variant="secondary" onClick={downloadIcs}>Download ICS</Button><Button type="button" variant="secondary" onClick={()=>openCalendar('google')}>Google Calendar</Button><Button type="button" variant="secondary" onClick={()=>openCalendar('outlook')}>Outlook</Button></div>
        {meeting.hasPassword && !passwordVerified && <form onSubmit={verifyPassword} className="mt-6 rounded-3xl border border-amber-400/30 bg-amber-400/10 p-5"><div className="mb-3 flex items-center gap-2 font-bold text-amber-700 dark:text-amber-200"><KeyRound size={18}/>Meeting password required</div><input type="password" required value={password} onChange={(e)=>setPassword(e.target.value)} className="w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 outline-none focus:ring-2 focus:ring-brand-500 dark:border-slate-700 dark:bg-slate-900" /><Button className="mt-3 w-full">Verify password</Button></form>}
      </section>
      {passwordVerified && <PreJoin displayName={displayName} setDisplayName={setDisplayName} requireName onJoin={join} loading={joining} />}
    </main>
  );
}

function WaitingScreen({ name }: { name: string }) {
  return <main className="grid min-h-screen place-items-center bg-mesh p-4 dark:bg-slate-950"><div className="glass max-w-md rounded-4xl p-8 text-center"><h1 className="text-3xl font-black text-slate-950 dark:text-white">Waiting for host approval</h1><p className="mt-3 text-slate-500">{name}, your request is visible to the host. This page will enter the meeting automatically when admitted.</p></div></main>;
}
