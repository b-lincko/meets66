'use client';

import { KeyRound, RefreshCcw, ShieldCheck, Trash2, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import { toast } from 'sonner';
import { Button } from '@/components/Button';
import { ThemeToggle } from '@/components/ThemeToggle';
import { AdminGuard } from '@/components/AdminGuard';
import { Admin, api, cachedAdmin } from '@/lib/api';

const roles = ['super_admin', 'admin', 'meeting_admin'] as const;
const permissions = ['admins.manage','settings.manage','meetings.manage','recordings.manage','security.manage','integrations.manage','analytics.view'];

export default function AdminsPage() {
  const [admins, setAdmins] = useState<Admin[]>([]);
  const [form, setForm] = useState({ email: '', displayName: '', password: '', role: 'admin', permissions: ['meetings.manage', 'analytics.view'] });
  const [resetTarget, setResetTarget] = useState<Admin | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Admin | null>(null);
  const [temporaryPassword, setTemporaryPassword] = useState('');
  const [busy, setBusy] = useState(false);

  async function load() {
    const data = await api<{ items: Admin[]; total: number }>('/admin/admins');
    setAdmins(data.items);
  }
  useEffect(() => { if (cachedAdmin()) load().catch((err) => toast.error(err.message)); }, []);

  function togglePerm(perm: string) { setForm((prev)=>({ ...prev, permissions: prev.permissions.includes(perm) ? prev.permissions.filter((p)=>p!==perm) : [...prev.permissions, perm] })); }
  async function create(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      await api('/admin/admins', { method:'POST', body: JSON.stringify(form) });
      setForm({ email:'', displayName:'', password:'', role:'admin', permissions:['meetings.manage','analytics.view'] });
      toast.success('Admin created');
      await load();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Admin creation failed'); }
    finally { setBusy(false); }
  }
  async function update(admin: Admin, patch: Record<string, unknown>) {
    try { await api(`/admin/admins/${admin.id}`, { method:'PATCH', body: JSON.stringify(patch) }); await load(); }
    catch (err) { toast.error(err instanceof Error ? err.message : 'Admin update failed'); }
  }
  function openReset(admin: Admin) { setResetTarget(admin); setTemporaryPassword(''); }
  async function resetPassword(e: React.FormEvent) {
    e.preventDefault();
    if (!resetTarget || temporaryPassword.length < 10) return;
    setBusy(true);
    try {
      await api(`/admin/admins/${resetTarget.id}/reset-password`, { method:'POST', body: JSON.stringify({ password: temporaryPassword }) });
      toast.success('Password reset');
      setResetTarget(null);
      setTemporaryPassword('');
      await load();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Password reset failed'); }
    finally { setBusy(false); }
  }
  async function removeConfirmed() {
    if (!deleteTarget) return;
    setBusy(true);
    try {
      await api(`/admin/admins/${deleteTarget.id}`, { method:'DELETE' });
      toast.success('Admin disabled');
      setDeleteTarget(null);
      await load();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Admin delete failed'); }
    finally { setBusy(false); }
  }

  return (
    <AdminGuard permission="admins.manage">
    <main className="min-h-screen bg-mesh p-4 dark:bg-slate-950 sm:p-8">
      <div className="mx-auto max-w-6xl">
        <header className="mb-8 flex items-center justify-between"><div><p className="text-sm font-bold uppercase tracking-widest text-brand-600">Enterprise administration</p><h1 className="text-4xl font-black">Admin Management</h1></div><div className="flex gap-2"><ThemeToggle/><Button variant="secondary" onClick={load}><RefreshCcw size={16}/>Refresh</Button></div></header>
        <section className="grid gap-6 lg:grid-cols-[.8fr_1.2fr]">
          <form onSubmit={create} className="glass rounded-4xl p-5"><h2 className="mb-4 flex items-center gap-2 text-xl font-bold"><ShieldCheck/>Create admin</h2><input required type="email" value={form.email} onChange={(e)=>setForm({...form,email:e.target.value})} placeholder="Email" className="mb-3 w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900"/><input required value={form.displayName} onChange={(e)=>setForm({...form,displayName:e.target.value})} placeholder="Name" className="mb-3 w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900"/><input required type="password" value={form.password} onChange={(e)=>setForm({...form,password:e.target.value})} placeholder="Temporary password" className="mb-3 w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900"/><select value={form.role} onChange={(e)=>setForm({...form,role:e.target.value})} className="mb-3 w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900">{roles.map((r)=><option key={r} value={r}>{r}</option>)}</select><div className="mb-4 flex flex-wrap gap-2">{permissions.map((p)=><label key={p} className="rounded-xl bg-white/60 px-3 py-2 text-sm dark:bg-slate-900/60"><input type="checkbox" checked={form.permissions.includes(p)} onChange={()=>togglePerm(p)} className="mr-2"/>{p}</label>)}</div><Button disabled={busy}>Create admin</Button></form>
          <div className="glass rounded-4xl p-5"><h2 className="mb-4 text-xl font-bold">Admins</h2><div className="space-y-3">{admins.map((admin)=><div key={admin.id} className="rounded-2xl bg-white/70 p-4 dark:bg-slate-900/70"><div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-center"><div><p className="font-semibold">{admin.displayName}</p><p className="text-sm text-slate-500">{admin.email} · {admin.role} · {admin.status}</p><p className="text-xs text-slate-500">{(admin.effectivePermissions || admin.permissions || []).join(', ')}</p></div><div className="flex flex-wrap gap-2"><Button variant="secondary" onClick={()=>update(admin,{ status: admin.status === 'active' ? 'disabled' : 'active' })}>{admin.status === 'active' ? 'Disable' : 'Enable'}</Button><Button variant="secondary" onClick={()=>openReset(admin)}><KeyRound size={15}/>Reset password</Button><select value={admin.role} onChange={(e)=>update(admin,{ role:e.target.value })} className="rounded-2xl border border-slate-200 bg-white/80 px-3 py-2 dark:border-slate-700 dark:bg-slate-900">{roles.map((r)=><option key={r} value={r}>{r}</option>)}</select><Button variant="danger" onClick={()=>setDeleteTarget(admin)}><Trash2 size={15}/>Delete</Button></div></div></div>)}</div></div>
        </section>
      </div>
      {resetTarget && <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/70 p-4 backdrop-blur"><form onSubmit={resetPassword} className="glass w-full max-w-md rounded-4xl p-6"><div className="flex items-start justify-between gap-4"><div><h2 className="text-xl font-black">Reset password</h2><p className="mt-1 text-sm text-slate-500">Set a new temporary password for {resetTarget.email}. The admin must change it after login.</p></div><button type="button" onClick={()=>setResetTarget(null)} className="rounded-xl bg-white/10 p-2"><X size={16}/></button></div><input autoFocus required minLength={10} type="password" value={temporaryPassword} onChange={(e)=>setTemporaryPassword(e.target.value)} className="mt-4 w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900"/><p className="mt-1 text-xs text-slate-500">Minimum 10 characters.</p><div className="mt-5 flex justify-end gap-2"><Button type="button" variant="secondary" onClick={()=>setResetTarget(null)}>Cancel</Button><Button disabled={busy || temporaryPassword.length < 10}>Reset password</Button></div></form></div>}
      {deleteTarget && <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/70 p-4 backdrop-blur"><div className="glass w-full max-w-md rounded-4xl p-6"><h2 className="text-xl font-black">Disable admin?</h2><p className="mt-2 text-sm text-slate-500">This will disable {deleteTarget.email} and prevent console access.</p><div className="mt-5 flex justify-end gap-2"><Button variant="secondary" onClick={()=>setDeleteTarget(null)}>Cancel</Button><Button variant="danger" disabled={busy} onClick={removeConfirmed}><Trash2 size={15}/>Disable admin</Button></div></div></div>}
    </main></AdminGuard>
  );
}
