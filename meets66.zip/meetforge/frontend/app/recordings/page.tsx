'use client';

import { Archive, Download, Edit3, Link as LinkIcon, Play, RefreshCcw, Share2, Trash2, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import { toast } from 'sonner';
import { Button } from '@/components/Button';
import { ThemeToggle } from '@/components/ThemeToggle';
import { AdminGuard } from '@/components/AdminGuard';
import { API_URL, Recording, RecordingShare, api, cachedAdmin, getAccessToken } from '@/lib/api';

type Modal =
  | { type: 'rename'; recording: Recording; title: string }
  | { type: 'metadata'; recording: Recording; category: string; summaryText: string; transcriptText: string }
  | { type: 'share'; recording: Recording; password: string; days: string; allowDownload: boolean; watermarkText: string; clipStartSeconds: string; clipEndSeconds: string }
  | { type: 'delete'; recording: Recording }
  | null;

export default function RecordingsPage() {
  const [items, setItems] = useState<Recording[]>([]);
  const [query, setQuery] = useState('');
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [previewTitle, setPreviewTitle] = useState('');
  const [modal, setModal] = useState<Modal>(null);
  const [busy, setBusy] = useState(false);

  async function load() {
    const data = await api<{ items: Recording[]; total: number }>(`/recordings?perPage=100&q=${encodeURIComponent(query)}`);
    setItems(data.items);
  }
  useEffect(() => { if (cachedAdmin()) load().catch((err) => toast.error(err.message)); }, []);

  async function blobUrl(recording: Recording, kind: 'download' | 'playback') {
    const res = await fetch(`${API_URL}/recordings/${recording.id}/${kind}`, { headers: { Authorization: `Bearer ${getAccessToken()}` } });
    if (!res.ok) throw new Error(`${kind} failed`);
    return URL.createObjectURL(await res.blob());
  }
  async function preview(recording: Recording) {
    try {
      const url = await blobUrl(recording, 'playback');
      if (previewUrl) URL.revokeObjectURL(previewUrl);
      setPreviewUrl(url);
      setPreviewTitle(recording.title);
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Preview failed'); }
  }
  async function download(recording: Recording) {
    try {
      const url = await blobUrl(recording, 'download');
      const a = document.createElement('a'); a.href = url; a.download = recording.filename || `${recording.title}.mp4`; a.click(); URL.revokeObjectURL(url);
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Download failed'); }
  }
  async function archive(recording: Recording) {
    try {
      const status = recording.status === 'archived' ? 'ready' : 'archived';
      const data = await api<{ recording: Recording }>(`/recordings/${recording.id}`, { method: 'PATCH', body: JSON.stringify({ status }) });
      setItems((prev) => prev.map((item) => item.id === recording.id ? data.recording : item));
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Archive action failed'); }
  }
  async function submitModal(e?: React.FormEvent) {
    e?.preventDefault();
    if (!modal) return;
    setBusy(true);
    try {
      if (modal.type === 'rename') {
        const title = modal.title.trim();
        if (!title) return toast.error('Title is required');
        const data = await api<{ recording: Recording }>(`/recordings/${modal.recording.id}`, { method: 'PATCH', body: JSON.stringify({ title }) });
        setItems((prev) => prev.map((item) => item.id === modal.recording.id ? data.recording : item));
        toast.success('Recording renamed');
      } else if (modal.type === 'metadata') {
        const data = await api<{ recording: Recording }>(`/recordings/${modal.recording.id}`, { method: 'PATCH', body: JSON.stringify({ category: modal.category, summaryText: modal.summaryText, transcriptText: modal.transcriptText }) });
        setItems((prev) => prev.map((item) => item.id === modal.recording.id ? data.recording : item));
        toast.success('Recording library metadata updated');
      } else if (modal.type === 'share') {
        const daysNumber = modal.days.trim() ? Number(modal.days) : 0;
        if (Number.isNaN(daysNumber) || daysNumber < 0) return toast.error('Expiration days must be a positive number');
        const expiresAt = daysNumber ? new Date(Date.now() + daysNumber * 24 * 60 * 60 * 1000).toISOString() : undefined;
        const clipStartSeconds = modal.clipStartSeconds.trim() ? Number(modal.clipStartSeconds) : undefined;
        const clipEndSeconds = modal.clipEndSeconds.trim() ? Number(modal.clipEndSeconds) : undefined;
        if ((clipStartSeconds !== undefined || clipEndSeconds !== undefined) && modal.allowDownload) return toast.error('Disable downloads for clip shares');
        const data = await api<{ share: RecordingShare; recording: Recording }>(`/recordings/${modal.recording.id}/shares`, { method: 'POST', body: JSON.stringify({ password: modal.password, expiresAt, allowDownload: modal.allowDownload, watermarkText: modal.watermarkText || 'Defensiq Security', clipStartSeconds, clipEndSeconds }) });
        if (data.share.url) { await navigator.clipboard.writeText(data.share.url); toast.success('Secure share link copied to clipboard'); }
        setItems((prev) => prev.map((item) => item.id === modal.recording.id ? data.recording : item));
      } else if (modal.type === 'delete') {
        await api(`/recordings/${modal.recording.id}`, { method: 'DELETE' });
        setItems((prev) => prev.filter((item) => item.id !== modal.recording.id));
        toast.success('Recording deleted');
      }
      setModal(null);
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Action failed'); }
    finally { setBusy(false); }
  }

  return (
    <AdminGuard permission="recordings.manage">
    <main className="min-h-screen bg-mesh p-4 dark:bg-slate-950 sm:p-8"><div className="mx-auto max-w-6xl"><header className="mb-8 flex flex-col justify-between gap-4 sm:flex-row sm:items-center"><div><p className="text-sm font-bold uppercase tracking-widest text-brand-600">Recording management</p><h1 className="text-4xl font-black text-slate-950 dark:text-white">Recording Center</h1><p className="mt-2 text-slate-500">Playback, download, rename, archive, share, and delete recorded MP4 files.</p></div><div className="flex gap-2"><ThemeToggle/><Button variant="secondary" onClick={load}><RefreshCcw size={16}/>Refresh</Button></div></header><div className="glass rounded-4xl p-5"><div className="mb-4 flex gap-2"><input value={query} onChange={(e)=>setQuery(e.target.value)} onKeyDown={(e)=>{ if(e.key==='Enter') load(); }} placeholder="Search recordings" className="flex-1 rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900"/><Button onClick={load}>Search</Button></div><div className="grid gap-3">{items.map((recording)=><div key={recording.id} className="rounded-3xl bg-white/70 p-4 dark:bg-slate-900/70"><div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-center"><div><h3 className="font-bold">{recording.title}</h3><p className="text-sm text-slate-500">{recording.status} · {recording.category || 'Uncategorized'} · {(recording.sizeBytes/1024/1024).toFixed(2)} MB · {recording.durationSeconds}s · {recording.startedAt ? new Date(recording.startedAt).toLocaleString() : ''}</p>{recording.summaryText && <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">{recording.summaryText}</p>}{recording.errorMessage && <p className="text-sm text-rose-500">{recording.errorMessage}</p>}</div><div className="flex flex-wrap gap-2"><Button variant="secondary" disabled={recording.status !== 'ready' && recording.status !== 'archived'} onClick={()=>preview(recording)}><Play size={15}/>Preview</Button><Button variant="secondary" disabled={recording.status !== 'ready' && recording.status !== 'archived'} onClick={()=>download(recording)}><Download size={15}/>Download</Button><Button variant="secondary" onClick={()=>setModal({ type:'rename', recording, title: recording.title })}><Edit3 size={15}/>Rename</Button><Button variant="secondary" onClick={()=>setModal({ type:'metadata', recording, category: recording.category || '', summaryText: recording.summaryText || '', transcriptText: recording.transcriptText || '' })}><LinkIcon size={15}/>Metadata</Button><Button variant="secondary" disabled={recording.status !== 'ready' && recording.status !== 'archived'} onClick={()=>setModal({ type:'share', recording, password:'', days:'7', allowDownload:false, watermarkText:'Defensiq Security', clipStartSeconds:'', clipEndSeconds:'' })}><Share2 size={15}/>Share</Button><Button variant="secondary" disabled={recording.status !== 'ready' && recording.status !== 'archived'} onClick={()=>archive(recording)}><Archive size={15}/>{recording.status === 'archived' ? 'Restore' : 'Archive'}</Button><Button variant="danger" onClick={()=>setModal({ type:'delete', recording })}><Trash2 size={15}/>Delete</Button></div></div></div>)}</div>{!items.length && <p className="py-10 text-center text-slate-500">No recordings found.</p>}</div>{previewUrl && <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/70 p-4 backdrop-blur"><div className="glass w-full max-w-4xl rounded-4xl p-5"><h2 className="mb-4 text-xl font-bold">{previewTitle}</h2><video src={previewUrl} controls className="aspect-video w-full rounded-3xl bg-black"/><Button className="mt-4" onClick={()=>{ URL.revokeObjectURL(previewUrl); setPreviewUrl(null); }}>Close</Button></div></div>}</div>
      {modal && <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/70 p-4 backdrop-blur"><form onSubmit={submitModal} className="glass w-full max-w-lg rounded-4xl p-6"><div className="flex items-start justify-between gap-4"><div><h2 className="text-xl font-black">{modal.type === 'rename' ? 'Rename recording' : modal.type === 'metadata' ? 'Edit recording metadata' : modal.type === 'share' ? 'Create secure share link' : 'Delete recording?'}</h2><p className="mt-1 text-sm text-slate-500">{modal.recording.title}</p></div><button type="button" onClick={()=>setModal(null)} className="rounded-xl bg-white/10 p-2"><X size={16}/></button></div>{modal.type === 'rename' && <input autoFocus value={modal.title} onChange={(e)=>setModal({ ...modal, title: e.target.value })} className="mt-4 w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900"/>}{modal.type === 'metadata' && <div className="mt-4 space-y-3"><input value={modal.category} onChange={(e)=>setModal({ ...modal, category: e.target.value })} placeholder="Category" className="w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900"/><textarea value={modal.summaryText} onChange={(e)=>setModal({ ...modal, summaryText: e.target.value })} placeholder="Summary" rows={3} className="w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900"/><textarea value={modal.transcriptText} onChange={(e)=>setModal({ ...modal, transcriptText: e.target.value })} placeholder="Transcript text for search" rows={4} className="w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900"/></div>}{modal.type === 'share' && <div className="mt-4 space-y-3"><input type="password" value={modal.password} onChange={(e)=>setModal({ ...modal, password: e.target.value })} placeholder="Optional share password" className="w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900"/><input type="number" min="0" value={modal.days} onChange={(e)=>setModal({ ...modal, days: e.target.value })} placeholder="Expire after days; 0 for no expiration" className="w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900"/><input value={modal.watermarkText} onChange={(e)=>setModal({ ...modal, watermarkText: e.target.value })} placeholder="Watermark text" className="w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900"/><div className="grid gap-2 sm:grid-cols-2"><input type="number" min="0" value={modal.clipStartSeconds} onChange={(e)=>setModal({ ...modal, clipStartSeconds: e.target.value, allowDownload: e.target.value || modal.clipEndSeconds ? false : modal.allowDownload })} placeholder="Clip start seconds" className="w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900"/><input type="number" min="0" value={modal.clipEndSeconds} onChange={(e)=>setModal({ ...modal, clipEndSeconds: e.target.value, allowDownload: e.target.value || modal.clipStartSeconds ? false : modal.allowDownload })} placeholder="Clip end seconds" className="w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900"/></div><p className="text-xs text-slate-500">Set start/end seconds to share a specific moment. Downloads are disabled for clip shares.</p><label className="flex items-center gap-2 rounded-2xl bg-white/60 p-3 dark:bg-slate-900/60"><input type="checkbox" checked={modal.allowDownload} disabled={Boolean(modal.clipStartSeconds || modal.clipEndSeconds)} onChange={(e)=>setModal({ ...modal, allowDownload: e.target.checked })}/>Allow viewers to download</label></div>}{modal.type === 'delete' && <p className="mt-4 rounded-2xl bg-rose-500/10 p-4 text-sm text-rose-700 dark:text-rose-200">This permanently deletes the recording file, metadata, shares, and analytics events.</p>}<div className="mt-5 flex justify-end gap-2"><Button type="button" variant="secondary" onClick={()=>setModal(null)}>Cancel</Button><Button disabled={busy} variant={modal.type === 'delete' ? 'danger' : 'primary'}>{modal.type === 'delete' ? 'Delete recording' : modal.type === 'share' ? 'Create share' : 'Save'}</Button></div></form></div>}
    </main></AdminGuard>
  );
}
