'use client';

import { Activity, BarChart3, CalendarPlus, Copy, Download, FileVideo, KeyRound, Link as LinkIcon, LogOut, RefreshCcw, Search, Server, ShieldCheck, Trash2, Users } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useEffect, useMemo, useState } from 'react';
import { toast } from 'sonner';
import { Button } from '@/components/Button';
import { NotFoundScreen } from '@/components/AdminGuard';
import { ThemeToggle } from '@/components/ThemeToggle';
import { Admin, AdminSession, AuditLog, API_URL, Meeting, MeetingInvitation, Recording, api, cachedAdmin, clearAuth, getAccessToken } from '@/lib/api';

type MeResponse = { admin: Admin; session: AdminSession; forceChangePassword: boolean };
type ListResponse<T> = { items: T[]; total: number };
type Overview = {
  meetings: { total: number; scheduled: number; running: number; completed: number; cancelled: number; averageDurationSeconds: number };
  participants: { total: number; active: number; waiting: number };
  adminSessions: { active: number };
  recordings: { total: number; byStatus: Record<string, number>; failedJobs: number };
  storage: { recordings: number; files: number; total: number };
  system: { cpuPercent: number; ram: { total: number; used: number; percent: number }; disk: { total: number; used: number; percent: number }; network: { bytesSent: number; bytesRecv: number } };
  services: Record<string, string>;
  recentMeetings: Meeting[];
  recentRecordings: Recording[];
  authEvents: AuditLog[];
};
type Analytics = { labels: string[]; series: Record<string, { meetings: number; participants: number; recordings: number; chatMessages: number }>; browsers: Record<string, number>; operatingSystems: Record<string, number>; devices: Record<string, number>; storage: { total: number; recordings: number; files: number } };
type CreateMeetingResponse = { meeting: Meeting; invitation: MeetingInvitation; occurrences?: Meeting[] };
type HistoryRow = Meeting & { durationSeconds: number; participantsJoined: number; recordingCount: number; chatMessageCount: number };

function localDatetime(offsetHours = 1) {
  const date = new Date(Date.now() + offsetHours * 60 * 60 * 1000);
  date.setMinutes(0, 0, 0);
  return date.toISOString().slice(0, 16);
}

function formatBytes(bytes = 0) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
  return `${(bytes / 1024 / 1024 / 1024).toFixed(2)} GB`;
}

function adminCan(admin: Admin, permission: string) {
  return admin.role === 'super_admin' || (admin.effectivePermissions || admin.permissions || []).includes(permission);
}

async function optionalApi<T>(path: string, fallback: T): Promise<T> {
  try { return await api<T>(path); } catch { return fallback; }
}

export default function DashboardPage() {
  const router = useRouter();
  const [admin, setAdmin] = useState<Admin | null>(null);
  const [currentSession, setCurrentSession] = useState<AdminSession | null>(null);
  const [sessions, setSessions] = useState<AdminSession[]>([]);
  const [overview, setOverview] = useState<Overview | null>(null);
  const [analytics, setAnalytics] = useState<Analytics | null>(null);
  const [meetings, setMeetings] = useState<Meeting[]>([]);
  const [history, setHistory] = useState<HistoryRow[]>([]);
  const [recordings, setRecordings] = useState<Recording[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [meetingQuery, setMeetingQuery] = useState('');
  const [recordingQuery, setRecordingQuery] = useState('');
  const [deleteMeetingTarget, setDeleteMeetingTarget] = useState<Meeting | HistoryRow | null>(null);
  const [createdInvitation, setCreatedInvitation] = useState<MeetingInvitation | null>(null);
  const [form, setForm] = useState({ title: '', description: '', scheduledStartAt: localDatetime(1), scheduledEndAt: localDatetime(2), timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC', password: '', linkExpiresAt: '', reminderMinutes: '10', recurrenceType: 'none', recurrenceCount: '1' });
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [creating, setCreating] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const me = await api<MeResponse>('/auth/me');
      if (me.forceChangePassword) { router.push('/change-password'); return; }
      setAdmin(me.admin);
      setCurrentSession(me.session);
      const canViewAnalytics = adminCan(me.admin, 'analytics.view');
      const canManageMeetings = adminCan(me.admin, 'meetings.manage');
      const canManageRecordings = adminCan(me.admin, 'recordings.manage');
      const [sessionData, overviewData, analyticsData, meetingData, historyData, recordingData, auditData] = await Promise.all([
        optionalApi<ListResponse<AdminSession>>('/auth/sessions', { items: [], total: 0 }),
        canViewAnalytics ? optionalApi<Overview>('/admin/overview', null as unknown as Overview) : Promise.resolve(null as unknown as Overview),
        canViewAnalytics ? optionalApi<Analytics>('/admin/analytics', null as unknown as Analytics) : Promise.resolve(null as unknown as Analytics),
        canManageMeetings ? optionalApi<ListResponse<Meeting>>('/admin/meetings?perPage=100', { items: [], total: 0 }) : Promise.resolve({ items: [], total: 0 }),
        canViewAnalytics ? optionalApi<ListResponse<HistoryRow>>('/admin/meeting-history?perPage=100', { items: [], total: 0 }) : Promise.resolve({ items: [], total: 0 }),
        canManageRecordings ? optionalApi<ListResponse<Recording>>('/admin/recordings?perPage=100', { items: [], total: 0 }) : Promise.resolve({ items: [], total: 0 }),
        canViewAnalytics ? optionalApi<ListResponse<AuditLog>>('/auth/audit-logs?perPage=30', { items: [], total: 0 }) : Promise.resolve({ items: [], total: 0 })
      ]);
      setSessions(sessionData.items);
      setOverview(overviewData);
      setAnalytics(analyticsData);
      setMeetings(meetingData.items);
      setHistory(historyData.items);
      setRecordings(recordingData.items);
      setAuditLogs(auditData.items);
    } catch {
      clearAuth();
      setNotFound(true);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (!cachedAdmin()) { setNotFound(true); setLoading(false); return; }
    load();
  }, []);

  async function logout() {
    try { await api('/auth/logout', { method: 'POST' }); } catch {}
    clearAuth();
    router.push('/');
  }

  async function revokeSession(id: string) {
    try {
      await api(`/auth/sessions/${id}`, { method: 'DELETE' });
      toast.success('Session revoked');
      await load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Could not revoke session');
    }
  }

  async function createMeeting(e: React.FormEvent) {
    e.preventDefault();
    setCreating(true);
    try {
      const payload = {
        title: form.title,
        description: form.description,
        scheduledStartAt: new Date(form.scheduledStartAt).toISOString(),
        scheduledEndAt: new Date(form.scheduledEndAt).toISOString(),
        timezone: form.timezone,
        password: form.password || undefined,
        linkExpiresAt: form.linkExpiresAt ? new Date(form.linkExpiresAt).toISOString() : undefined,
        reminderMinutes: Number(form.reminderMinutes || 10),
        recurrenceType: form.recurrenceType,
        recurrenceCount: Number(form.recurrenceCount || 1),
      };
      const data = await api<CreateMeetingResponse>('/meetings', { method: 'POST', body: JSON.stringify(payload) });
      setCreatedInvitation(data.invitation);
      setForm({ title: '', description: '', scheduledStartAt: localDatetime(1), scheduledEndAt: localDatetime(2), timezone: form.timezone, password: '', linkExpiresAt: '', reminderMinutes: '10', recurrenceType: 'none', recurrenceCount: '1' });
      toast.success(data.occurrences && data.occurrences.length > 1 ? `${data.occurrences.length} recurring meetings created` : 'Meeting created and secure link generated');
      await load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Meeting creation failed');
    } finally {
      setCreating(false);
    }
  }

  async function regenerateLink(meeting: Meeting) {
    try {
      const data = await api<CreateMeetingResponse>(`/meetings/${meeting.id}/regenerate-link`, { method: 'POST' });
      setCreatedInvitation(data.invitation);
      toast.success('Invitation link regenerated');
      await load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Could not regenerate link');
    }
  }

  async function deleteMeetingConfirmed() {
    if (!deleteMeetingTarget) return;
    try {
      await api(`/meetings/${deleteMeetingTarget.id}`, { method: 'DELETE' });
      toast.success('Meeting deleted');
      setDeleteMeetingTarget(null);
      await load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Could not delete meeting');
    }
  }


  async function downloadIcs(meeting: Meeting) {
    const res = await fetch(`${API_URL}/meetings/${meeting.id}/calendar.ics`, { headers: { Authorization: `Bearer ${getAccessToken()}` } });
    if (!res.ok) return toast.error('Calendar download failed');
    const url = URL.createObjectURL(await res.blob());
    const a = document.createElement('a');
    a.href = url;
    a.download = `${meeting.meetingId}.ics`;
    a.click();
    URL.revokeObjectURL(url);
  }

  async function openGoogleCalendar(meeting: Meeting) {
    try {
      const data = await api<{ links: { google: string } }>(`/meetings/${meeting.id}/calendar-links`);
      window.open(data.links.google, '_blank', 'noopener,noreferrer');
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Calendar link failed');
    }
  }

  async function copy(text?: string | null) {
    if (!text) return toast.error('No link available');
    await navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard');
  }

  async function downloadCsv(path: string, filename: string) {
    const res = await fetch(`${API_URL}${path}`, { headers: { Authorization: `Bearer ${getAccessToken()}` } });
    if (!res.ok) return toast.error('Export failed');
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }

  const filteredMeetings = useMemo(() => meetings.filter((meeting) => `${meeting.title} ${meeting.meetingId}`.toLowerCase().includes(meetingQuery.toLowerCase())), [meetings, meetingQuery]);

  const permissions = admin?.effectivePermissions || admin?.permissions || [];
  const can = (permission: string) => admin?.role === 'super_admin' || permissions.includes(permission);

  const filteredRecordings = useMemo(() => recordings.filter((recording) => `${recording.title} ${recording.status}`.toLowerCase().includes(recordingQuery.toLowerCase())), [recordings, recordingQuery]);

  if (notFound) return <NotFoundScreen />;
  if (loading) return <main className="grid min-h-screen place-items-center bg-slate-950 text-white">Loading admin console...</main>;

  return (
    <main className="min-h-screen bg-mesh p-4 dark:bg-slate-950 sm:p-8">
      <div className="mx-auto max-w-7xl">
        <header className="mb-8 flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
          <div>
            <p className="text-sm font-bold uppercase tracking-widest text-brand-600">Enterprise dashboard</p>
            <h1 className="text-4xl font-black text-slate-950 dark:text-white">Defensiq Meet Admin</h1>
            <p className="mt-2 text-slate-600 dark:text-slate-300">Live operational data, meeting management, recordings, health, analytics, and exports.</p>
          </div>
          <div className="flex flex-wrap gap-2"><ThemeToggle />{can('meetings.manage') && <Button onClick={()=>router.push('/meetings/new')}><CalendarPlus size={17}/>Create Meeting</Button>}{can('admins.manage') && <Button variant="secondary" onClick={()=>router.push('/admins')}>Admins</Button>}{can('settings.manage') && <Button variant="secondary" onClick={()=>router.push('/settings')}>Settings</Button>}{can('security.manage') && <Button variant="secondary" onClick={()=>router.push('/security')}>Security</Button>}{can('integrations.manage') && <Button variant="secondary" onClick={()=>router.push('/integrations')}>Integrations</Button>}{can('analytics.view') && <Button variant="secondary" onClick={()=>router.push('/performance')}>Performance</Button>}{can('recordings.manage') && <Button variant="secondary" onClick={()=>router.push('/recordings')}>Recording Center</Button>}<Button variant="secondary" onClick={load}><RefreshCcw size={17}/>Refresh</Button><Button variant="danger" onClick={logout}><LogOut size={17}/>Logout</Button></div>
        </header>

        <section className="grid gap-5 md:grid-cols-4">
          <Card title="Meetings" value={String(overview?.meetings.total || 0)} detail={`${overview?.meetings.running || 0} running · ${overview?.meetings.scheduled || 0} scheduled`} icon={<CalendarPlus/>}/>
          <Card title="Participants" value={String(overview?.participants.active || 0)} detail={`${overview?.participants.waiting || 0} waiting · ${overview?.participants.total || 0} total`} icon={<Users/>}/>
          <Card title="Recordings" value={String(overview?.recordings.total || 0)} detail={`${overview?.recordings.byStatus.ready || 0} ready · ${overview?.recordings.failedJobs || 0} failed`} icon={<FileVideo/>}/>
          <Card title="Storage" value={formatBytes(overview?.storage.total || 0)} detail={`${formatBytes(overview?.storage.recordings || 0)} recordings · ${formatBytes(overview?.storage.files || 0)} files`} icon={<HardDriveIcon/>}/>
        </section>

        <section className="mt-5 grid gap-5 md:grid-cols-4">
          <Card title="CPU" value={`${overview?.system.cpuPercent ?? 0}%`} detail="Live host metric" icon={<Activity/>}/>
          <Card title="RAM" value={`${overview?.system.ram.percent ?? 0}%`} detail={`${formatBytes(overview?.system.ram.used || 0)} used`} icon={<Server/>}/>
          <Card title="Disk" value={`${overview?.system.disk.percent ?? 0}%`} detail={`${formatBytes(overview?.system.disk.used || 0)} used`} icon={<Server/>}/>
          <Card title="Services" value={overview?.services.database || 'unknown'} detail={`LiveKit ${overview?.services.livekit || 'unknown'} · Redis ${overview?.services.redis || 'unknown'}`} icon={<ShieldCheck/>}/>
        </section>

        <section className="mt-8 grid gap-6 lg:grid-cols-[.9fr_1.1fr]">
          {can('meetings.manage') ? <form onSubmit={createMeeting} className="glass rounded-4xl p-5">
            <div className="mb-5 flex items-center gap-3"><span className="grid h-11 w-11 place-items-center rounded-2xl bg-brand-600 text-white"><CalendarPlus/></span><div><h2 className="text-xl font-bold">Create meeting</h2><p className="text-sm text-slate-500">Instant, scheduled, or recurring meeting with secure invitation link.</p></div></div>
            <label className="block"><span className="text-sm font-semibold">Title</span><input required value={form.title} onChange={(e)=>setForm({...form,title:e.target.value})} className="mt-2 w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 outline-none focus:ring-2 focus:ring-brand-500 dark:border-slate-700 dark:bg-slate-900" /></label>
            <label className="mt-4 block"><span className="text-sm font-semibold">Description</span><textarea rows={3} value={form.description} onChange={(e)=>setForm({...form,description:e.target.value})} className="mt-2 w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 outline-none focus:ring-2 focus:ring-brand-500 dark:border-slate-700 dark:bg-slate-900" /></label>
            <div className="mt-4 grid gap-4 sm:grid-cols-2"><label><span className="text-sm font-semibold">Start</span><input type="datetime-local" required value={form.scheduledStartAt} onChange={(e)=>setForm({...form,scheduledStartAt:e.target.value})} className="mt-2 w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900" /></label><label><span className="text-sm font-semibold">End</span><input type="datetime-local" required value={form.scheduledEndAt} onChange={(e)=>setForm({...form,scheduledEndAt:e.target.value})} className="mt-2 w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900" /></label></div>
            <label className="mt-4 block"><span className="text-sm font-semibold">Timezone</span><input required value={form.timezone} onChange={(e)=>setForm({...form,timezone:e.target.value})} className="mt-2 w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 outline-none focus:ring-2 focus:ring-brand-500 dark:border-slate-700 dark:bg-slate-900" /></label>
            <div className="mt-4 grid gap-4 sm:grid-cols-2"><label><span className="text-sm font-semibold">Meeting password optional</span><input type="password" value={form.password} onChange={(e)=>setForm({...form,password:e.target.value})} className="mt-2 w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900" /></label><label><span className="text-sm font-semibold">Link expiration optional</span><input type="datetime-local" value={form.linkExpiresAt} onChange={(e)=>setForm({...form,linkExpiresAt:e.target.value})} className="mt-2 w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900" /></label></div><label className="mt-4 block"><span className="text-sm font-semibold">Calendar reminder minutes</span><input type="number" min="0" max="10080" value={form.reminderMinutes} onChange={(e)=>setForm({...form,reminderMinutes:e.target.value})} className="mt-2 w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900" /></label>
            <div className="mt-4 grid gap-4 sm:grid-cols-2"><label><span className="text-sm font-semibold">Recurrence</span><select value={form.recurrenceType} onChange={(e)=>setForm({...form,recurrenceType:e.target.value})} className="mt-2 w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900"><option value="none">One time</option><option value="daily">Daily</option><option value="weekly">Weekly</option><option value="monthly">Monthly</option></select></label><label><span className="text-sm font-semibold">Occurrences</span><input type="number" min="1" max="52" value={form.recurrenceCount} onChange={(e)=>setForm({...form,recurrenceCount:e.target.value})} className="mt-2 w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900" /></label></div>
            <Button className="mt-6 w-full" disabled={creating}>{creating ? 'Creating...' : 'Create meeting and link'}</Button>
            {createdInvitation && <div className="mt-5 rounded-3xl bg-emerald-500/10 p-4 text-sm text-emerald-700 dark:text-emerald-200"><div className="mb-2 flex items-center gap-2 font-bold"><LinkIcon size={16}/>Latest invitation link</div><p className="break-all font-mono text-xs">{createdInvitation.url}</p><Button type="button" variant="secondary" className="mt-3" onClick={()=>copy(createdInvitation.url)}><Copy size={16}/>Copy link</Button></div>}
          </form> : <div className="glass rounded-4xl p-5"><h2 className="text-xl font-bold">Meeting creation unavailable</h2><p className="mt-2 text-sm text-slate-500">Your admin account does not have meeting management permission.</p></div>}

          <div className="glass rounded-4xl p-5">
            <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"><h2 className="text-xl font-bold">Meeting management</h2><div className="flex gap-2"><input value={meetingQuery} onChange={(e)=>setMeetingQuery(e.target.value)} placeholder="Search title or ID" className="rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 text-sm outline-none dark:border-slate-700 dark:bg-slate-900" /><Button variant="secondary" onClick={()=>downloadCsv('/admin/exports/meetings.csv','meetings.csv')}><Download size={15}/>CSV</Button></div></div>
            <div className="overflow-x-auto"><table className="w-full min-w-[900px] text-left text-sm"><thead className="text-xs uppercase tracking-wider text-slate-500"><tr><th className="px-3 py-3">Meeting</th><th>Schedule</th><th>Status</th><th>Invitation</th><th>Actions</th></tr></thead><tbody>{filteredMeetings.map((meeting)=><tr key={meeting.id} className="border-t border-slate-200/70 dark:border-slate-800"><td className="px-3 py-4"><p className="font-semibold">{meeting.title}</p><p className="font-mono text-xs text-slate-500">{meeting.meetingId}</p></td><td><p>{new Date(meeting.scheduledStartAt).toLocaleString()}</p><p className="text-xs text-slate-500">to {new Date(meeting.scheduledEndAt).toLocaleString()}</p></td><td>{meeting.status}</td><td><p className="max-w-xs truncate font-mono text-xs text-slate-500">{meeting.invitationUrl}</p>{meeting.hasPassword && <span className="mt-1 inline-flex items-center gap-1 rounded-full bg-amber-100 px-2 py-1 text-xs font-bold text-amber-700 dark:bg-amber-500/20 dark:text-amber-200"><KeyRound size={12}/>Password</span>}</td><td><div className="flex gap-2"><Button type="button" variant="secondary" className="px-3 py-2" onClick={()=>router.push(`/meet/${meeting.id}`)}>Host</Button><Button type="button" variant="secondary" className="px-3 py-2" onClick={()=>router.push(`/meetings/${meeting.id}/roles`)}>Roles</Button><Button type="button" variant="secondary" className="px-3 py-2" onClick={()=>copy(meeting.invitationUrl)}><Copy size={15}/>Copy</Button><Button type="button" variant="secondary" className="px-3 py-2" onClick={()=>downloadIcs(meeting)}><Download size={15}/>ICS</Button><Button type="button" variant="secondary" className="px-3 py-2" onClick={()=>openGoogleCalendar(meeting)}>Google</Button><Button type="button" variant="secondary" className="px-3 py-2" onClick={()=>regenerateLink(meeting)}>Regenerate</Button>{meeting.status !== 'running' && <Button type="button" variant="danger" className="px-3 py-2" onClick={()=>setDeleteMeetingTarget(meeting)}><Trash2 size={15}/>Delete</Button>}</div></td></tr>)}</tbody></table>{!filteredMeetings.length && <p className="py-10 text-center text-sm text-slate-500">No meetings match the current search.</p>}</div>
          </div>
        </section>

        <section className="mt-8 grid gap-6 lg:grid-cols-2">
          <Panel title="Meeting history" action={<Button variant="secondary" onClick={()=>downloadCsv('/admin/exports/meetings.csv','meeting-history.csv')}><Download size={15}/>CSV</Button>}><div className="overflow-x-auto"><table className="w-full min-w-[820px] text-left text-sm"><thead className="text-xs uppercase text-slate-500"><tr><th className="px-3 py-3">Meeting</th><th>Duration</th><th>Participants</th><th>Recordings</th><th>Chat</th><th>Action</th></tr></thead><tbody>{history.slice(0,10).map((row)=><tr key={row.id} className="border-t border-slate-200/70 dark:border-slate-800"><td className="px-3 py-3"><p className="font-semibold">{row.title}</p><p className="text-xs text-slate-500">{row.status}</p></td><td>{Math.round(row.durationSeconds/60)} min</td><td>{row.participantsJoined}</td><td>{row.recordingCount}</td><td>{row.chatMessageCount}</td><td>{can('meetings.manage') && row.status !== 'running' ? <Button variant="danger" className="px-3 py-2" onClick={()=>setDeleteMeetingTarget(row)}><Trash2 size={15}/>Delete</Button> : <span className="text-slate-400">—</span>}</td></tr>)}</tbody></table></div></Panel>
          <Panel title="Recording status" action={<Button variant="secondary" onClick={()=>downloadCsv('/admin/exports/recordings.csv','recordings.csv')}><Download size={15}/>CSV</Button>}><div className="mb-4 flex gap-2"><Search size={18} className="mt-3 text-slate-400"/><input value={recordingQuery} onChange={(e)=>setRecordingQuery(e.target.value)} placeholder="Filter recordings" className="flex-1 rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 text-sm outline-none dark:border-slate-700 dark:bg-slate-900"/></div><div className="space-y-3">{filteredRecordings.slice(0,10).map((recording)=><div key={recording.id} className="rounded-2xl bg-white/60 p-3 dark:bg-slate-900/60"><div className="flex justify-between gap-3"><p className="font-semibold">{recording.title}</p><span className="text-xs text-slate-500">{recording.status}</span></div><p className="text-xs text-slate-500">{formatBytes(recording.sizeBytes)} · {recording.durationSeconds}s</p></div>)}</div></Panel>
        </section>

        <section className="mt-8 grid gap-6 lg:grid-cols-2">
          <Panel title="Analytics"><div className="space-y-2 text-sm">{analytics?.labels.map((label)=><div key={label} className="grid grid-cols-[110px_1fr] items-center gap-3"><span className="text-xs text-slate-500">{label}</span><div className="h-2 rounded-full bg-slate-200 dark:bg-slate-800"><div className="h-2 rounded-full bg-brand-600" style={{width: `${Math.min(100, ((analytics.series[label]?.meetings || 0) + (analytics.series[label]?.participants || 0) + (analytics.series[label]?.recordings || 0)) * 12)}%`}} /></div></div>)}</div><div className="mt-4 grid gap-3 sm:grid-cols-2"><Metric label="Browsers" value={Object.entries(analytics?.browsers || {}).map(([k,v])=>`${k}: ${v}`).join(', ') || 'No data'} /><Metric label="Operating systems" value={Object.entries(analytics?.operatingSystems || {}).map(([k,v])=>`${k}: ${v}`).join(', ') || 'No data'} /></div></Panel>
          <Panel title="Audit log" action={<Button variant="secondary" onClick={()=>downloadCsv('/admin/exports/audit.csv','audit.csv')}><Download size={15}/>CSV</Button>}><div className="space-y-3">{auditLogs.map((log)=><div key={log.id} className="rounded-2xl bg-white/60 p-3 dark:bg-slate-900/60"><div className="flex items-center justify-between gap-3"><p className="font-semibold">{log.action}</p><span className="text-xs text-slate-500">{new Date(log.createdAt).toLocaleString()}</span></div><p className="mt-1 text-xs text-slate-500">{log.ipAddress || 'No IP'} · {log.entityType || 'system'}</p></div>)}</div></Panel>
        </section>

        <section className="mt-8"><Panel title="Admin sessions"><div className="overflow-x-auto"><table className="w-full min-w-[760px] text-left text-sm"><thead className="text-xs uppercase tracking-wider text-slate-500"><tr><th className="px-3 py-3">Session</th><th>IP</th><th>Last seen</th><th>Status</th><th>Action</th></tr></thead><tbody>{sessions.map((session)=><tr key={session.id} className="border-t border-slate-200/70 dark:border-slate-800"><td className="px-3 py-4 font-mono text-xs">{session.id}</td><td>{session.ipAddress || '—'}</td><td>{session.lastSeenAt ? new Date(session.lastSeenAt).toLocaleString() : '—'}</td><td><span className={`rounded-full px-3 py-1 text-xs font-bold ${session.active ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-200' : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300'}`}>{session.active ? 'Active' : session.revokedReason || 'Inactive'}</span></td><td>{session.id !== currentSession?.id && session.active ? <button onClick={()=>revokeSession(session.id)} className="rounded-xl bg-rose-600 p-2 text-white"><Trash2 size={15}/></button> : <span className="text-slate-400">—</span>}</td></tr>)}</tbody></table></div></Panel></section>
        {deleteMeetingTarget && <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/70 p-4 backdrop-blur"><div className="glass w-full max-w-md rounded-4xl p-6"><h2 className="text-xl font-black text-slate-950 dark:text-white">Delete meeting?</h2><p className="mt-2 text-sm text-slate-600 dark:text-slate-300">This will permanently delete “{deleteMeetingTarget.title}” and its participants, chat, whiteboard, breakout, poll, and recording records. Running meetings must be ended before deletion.</p><div className="mt-5 flex justify-end gap-2"><Button variant="secondary" onClick={()=>setDeleteMeetingTarget(null)}>Cancel</Button><Button variant="danger" onClick={deleteMeetingConfirmed}><Trash2 size={15}/>Delete meeting</Button></div></div></div>}
      </div>
    </main>
  );
}

function Card({ title, value, detail, icon }: { title: string; value: string; detail: string; icon: React.ReactNode }) {
  return <div className="glass rounded-4xl p-5"><div className="flex items-start justify-between"><div><p className="text-sm text-slate-500">{title}</p><p className="mt-2 break-all text-2xl font-black text-slate-950 dark:text-white">{value}</p><p className="mt-2 text-sm text-slate-500">{detail}</p></div><span className="grid h-12 w-12 place-items-center rounded-2xl bg-brand-600 text-white">{icon}</span></div></div>;
}

function Panel({ title, action, children }: { title: string; action?: React.ReactNode; children: React.ReactNode }) {
  return <div className="glass rounded-4xl p-5"><div className="mb-4 flex items-center justify-between gap-3"><h2 className="text-xl font-bold">{title}</h2>{action}</div>{children}</div>;
}

function Metric({ label, value }: { label: string; value: string }) {
  return <div className="rounded-2xl bg-white/60 p-3 dark:bg-slate-900/60"><p className="text-xs uppercase tracking-wider text-slate-500">{label}</p><p className="mt-1 text-sm font-semibold">{value}</p></div>;
}

function HardDriveIcon() { return <Server />; }
