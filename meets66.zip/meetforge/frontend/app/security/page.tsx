'use client';

import { Ban, KeyRound, RefreshCcw, ShieldCheck, Smartphone, Trash2 } from 'lucide-react';
import { useEffect, useState } from 'react';
import { toast } from 'sonner';
import { Button } from '@/components/Button';
import { ThemeToggle } from '@/components/ThemeToggle';
import { AdminGuard } from '@/components/AdminGuard';
import { AdminDevice, E2EESetting, IPBlock, api, cachedAdmin } from '@/lib/api';

type List<T> = { items: T[]; total: number };

export default function SecurityPage() {
  const [devices, setDevices] = useState<AdminDevice[]>([]);
  const [blocks, setBlocks] = useState<IPBlock[]>([]);
  const [e2ee, setE2ee] = useState<E2EESetting>({ enabled: false, requirePassphrase: false, mode: 'off' });
  const [ipAddress, setIpAddress] = useState('');
  const [reason, setReason] = useState('');

  async function load() {
    const [deviceData, blockData, e2eeData] = await Promise.all([
      api<List<AdminDevice>>('/security/devices'),
      api<List<IPBlock>>('/security/ip-blocks'),
      api<{ e2ee: E2EESetting }>('/security/e2ee')
    ]);
    setDevices(deviceData.items);
    setBlocks(blockData.items);
    setE2ee(e2eeData.e2ee);
  }

  useEffect(() => { if (cachedAdmin()) load().catch((err) => toast.error(err.message)); }, []);

  async function blockIp(e: React.FormEvent) {
    e.preventDefault();
    try {
      await api('/security/ip-blocks', { method: 'POST', body: JSON.stringify({ ipAddress, reason }) });
      setIpAddress(''); setReason(''); toast.success('IP blocked'); await load();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed to block IP'); }
  }
  async function unblock(id: string) { await api(`/security/ip-blocks/${id}`, { method: 'DELETE' }); toast.success('IP block revoked'); await load(); }
  async function trust(id: string) { await api(`/security/devices/${id}/trust`, { method: 'POST' }); toast.success('Device trusted'); await load(); }
  async function revokeDevice(id: string) { await api(`/security/devices/${id}/revoke`, { method: 'POST' }); toast.success('Device revoked'); await load(); }
  async function saveE2ee(next: E2EESetting) { const data = await api<{e2ee:E2EESetting}>('/security/e2ee', { method:'PATCH', body: JSON.stringify(next) }); setE2ee(data.e2ee); toast.success('E2EE settings saved'); }

  return <AdminGuard permission="security.manage"><main className="min-h-screen bg-mesh p-4 dark:bg-slate-950 sm:p-8"><div className="mx-auto max-w-6xl"><header className="mb-8 flex items-center justify-between"><div><p className="text-sm font-bold uppercase tracking-widest text-brand-600">Security hardening</p><h1 className="text-4xl font-black">Security Center</h1></div><div className="flex gap-2"><ThemeToggle/><Button variant="secondary" onClick={load}><RefreshCcw size={16}/>Refresh</Button></div></header><section className="grid gap-6 lg:grid-cols-2"><div className="glass rounded-4xl p-5"><h2 className="mb-4 flex items-center gap-2 text-xl font-bold"><Ban/>IP blocking</h2><form onSubmit={blockIp} className="mb-4 grid gap-2 sm:grid-cols-[1fr_1fr_auto]"><input required value={ipAddress} onChange={(e)=>setIpAddress(e.target.value)} placeholder="IP address" className="rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900"/><input value={reason} onChange={(e)=>setReason(e.target.value)} placeholder="Reason" className="rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900"/><Button>Block</Button></form><div className="space-y-2">{blocks.map((block)=><div key={block.id} className="flex items-center justify-between rounded-2xl bg-white/60 p-3 dark:bg-slate-900/60"><div><p className="font-semibold">{block.ipAddress}</p><p className="text-xs text-slate-500">{block.active ? 'Active' : 'Revoked'} · {block.reason || 'No reason'}</p></div>{block.active && <button onClick={()=>unblock(block.id)} className="rounded-xl bg-rose-600 p-2 text-white"><Trash2 size={15}/></button>}</div>)}</div></div><div className="glass rounded-4xl p-5"><h2 className="mb-4 flex items-center gap-2 text-xl font-bold"><Smartphone/>Device management</h2><div className="space-y-2">{devices.map((device)=><div key={device.id} className="rounded-2xl bg-white/60 p-3 dark:bg-slate-900/60"><div className="flex items-center justify-between gap-3"><div><p className="font-semibold">{device.label || device.lastIp || 'Admin device'}</p><p className="text-xs text-slate-500">{device.active ? 'Active' : 'Revoked'} · trusted: {device.trusted ? 'yes' : 'no'} · {device.lastSeenAt ? new Date(device.lastSeenAt).toLocaleString() : ''}</p></div><div className="flex gap-2">{device.active && !device.trusted && <Button variant="secondary" onClick={()=>trust(device.id)}>Trust</Button>}{device.active && <Button variant="danger" onClick={()=>revokeDevice(device.id)}>Revoke</Button>}</div></div><p className="mt-2 truncate text-xs text-slate-500">{device.userAgent}</p></div>)}</div></div><div className="glass rounded-4xl p-5 lg:col-span-2"><h2 className="mb-4 flex items-center gap-2 text-xl font-bold"><KeyRound/>Optional E2EE configuration</h2><div className="grid gap-3 sm:grid-cols-3"><label className="rounded-2xl bg-white/60 p-3 dark:bg-slate-900/60"><input type="checkbox" checked={e2ee.enabled} onChange={(event)=>saveE2ee({...e2ee, enabled:event.target.checked, mode:event.target.checked ? 'optional' : 'off'})} className="mr-2"/>Enabled</label><label className="rounded-2xl bg-white/60 p-3 dark:bg-slate-900/60"><input type="checkbox" checked={e2ee.requirePassphrase} onChange={(event)=>saveE2ee({...e2ee, requirePassphrase:event.target.checked})} className="mr-2"/>Require passphrase</label><select value={e2ee.mode} onChange={(event)=>saveE2ee({...e2ee, mode:event.target.value as E2EESetting['mode']})} className="rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900"><option value="off">Off</option><option value="optional">Optional</option><option value="required">Required</option></select></div><p className="mt-3 text-sm text-slate-500">This controls the server-side E2EE policy exposed to clients. Media encryption in transit remains handled by WebRTC SRTP.</p></div></section></div></main></AdminGuard>;
}
