import { RecordingShareClient } from './share-client';

export default async function RecordingSharePage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  return <RecordingShareClient token={token} />;
}
