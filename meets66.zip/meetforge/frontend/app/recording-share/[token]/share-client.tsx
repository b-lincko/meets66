'use client';

import { Download, KeyRound, Play, Search } from 'lucide-react';
import { useEffect, useMemo, useRef, useState } from 'react';
import { toast } from 'sonner';
import { Button } from '@/components/Button';
import { API_URL, Recording, RecordingShare, api } from '@/lib/api';

type PublicShareResponse = { share: RecordingShare; recording: Partial<Recording> };
type TimedText = { time: number; text: string; title?: string; type?: string };

export function RecordingShareClient({ token }: { token: string }) {
  const [share, setShare] = useState<RecordingShare | null>(null);
  const [recording, setRecording] = useState<Partial<Recording> | null>(null);
  const [password, setPassword] = useState('');
  const [accessToken, setAccessToken] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const [search, setSearch] = useState('');
  const videoRef = useRef<HTMLVideoElement | null>(null);

  useEffect(() => {
    api<PublicShareResponse>(`/recording-shares/${token}`, { auth: false })
      .then((data) => { setShare(data.share); setRecording(data.recording); if (!data.share.passwordRequired) requestAccess(''); })
      .catch((err) => toast.error(err instanceof Error ? err.message : 'Share unavailable'));
  }, [token]);

  const metadata = (recording?.metadata || {}) as any;
  const chapters = (metadata.chapters || []) as TimedText[];
  const timeline = (metadata.timelineEvents || []) as TimedText[];
  const transcript = ((metadata.transcriptSegments || []) as TimedText[]).filter((item) => `${item.text || item.title || ''}`.toLowerCase().includes(search.toLowerCase()));
  const clipStart = share?.clipStartSeconds ?? 0;
  const clipEnd = share?.clipEndSeconds || recording?.durationSeconds || 0;
  const isClip = Boolean(share && (share.clipStartSeconds !== null && share.clipStartSeconds !== undefined || share.clipEndSeconds !== null && share.clipEndSeconds !== undefined));

  async function requestAccess(pass = password) {
    try {
      const data = await api<{ accessToken: string; share: RecordingShare; recording: Partial<Recording> }>(`/recording-shares/${token}/access`, { method: 'POST', auth: false, body: JSON.stringify({ password: pass }) });
      setAccessToken(data.accessToken);
      setShare(data.share);
      setRecording(data.recording);
      const res = await fetch(`${API_URL}/recording-shares/${token}/playback?accessToken=${encodeURIComponent(data.accessToken)}`);
      if (!res.ok) throw new Error('Playback request failed');
      const url = URL.createObjectURL(await res.blob());
      if (videoUrl) URL.revokeObjectURL(videoUrl);
      setVideoUrl(url);
      window.setTimeout(() => { if (videoRef.current && data.share.clipStartSeconds !== null && data.share.clipStartSeconds !== undefined) videoRef.current.currentTime = data.share.clipStartSeconds; }, 100);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Access failed');
    }
  }

  function seek(seconds: number) {
    if (!videoRef.current) return;
    videoRef.current.currentTime = Math.max(clipStart, seconds);
    videoRef.current.play().catch(() => undefined);
  }

  function enforceClip() {
    if (!videoRef.current || !isClip) return;
    if (videoRef.current.currentTime < clipStart) videoRef.current.currentTime = clipStart;
    if (clipEnd && videoRef.current.currentTime >= clipEnd) videoRef.current.pause();
  }

  async function download() {
    if (!accessToken || !share?.allowDownload) return;
    const res = await fetch(`${API_URL}/recording-shares/${token}/download?accessToken=${encodeURIComponent(accessToken)}`);
    if (!res.ok) return toast.error('Download failed');
    const url = URL.createObjectURL(await res.blob());
    const a = document.createElement('a');
    a.href = url;
    a.download = `${recording?.title || 'recording'}.mp4`;
    a.click();
    URL.revokeObjectURL(url);
  }

  if (!share || !recording) return <main className="grid min-h-screen place-items-center bg-slate-950 text-white">Loading recording share...</main>;

  return <main className="min-h-screen bg-slate-950 p-4 text-white"><section className="mx-auto grid w-full max-w-7xl gap-5 lg:grid-cols-[1fr_360px]"><div className="rounded-4xl border border-white/10 bg-white/10 p-6 shadow-2xl backdrop-blur-xl"><div className="mb-5"><p className="text-sm font-bold uppercase tracking-widest text-brand-300">Secure recording share</p><h1 className="mt-2 text-3xl font-black">{recording.title}</h1><p className="mt-2 text-sm text-slate-300">{recording.durationSeconds || 0}s · {recording.category || 'Uncategorized'}{share.expiresAt ? ` · expires ${new Date(share.expiresAt).toLocaleString()}` : ''}{isClip ? ` · clip ${clipStart}s-${clipEnd}s` : ''}</p>{recording.summaryText && <p className="mt-3 rounded-2xl bg-white/10 p-3 text-sm text-slate-200">{recording.summaryText}</p>}</div>{share.passwordRequired && !accessToken && <form onSubmit={(e)=>{e.preventDefault(); requestAccess();}} className="mb-5 rounded-3xl bg-amber-500/10 p-4"><div className="mb-3 flex items-center gap-2 font-bold text-amber-200"><KeyRound size={18}/>Password required</div><div className="flex gap-2"><input type="password" value={password} onChange={(e)=>setPassword(e.target.value)} className="flex-1 rounded-2xl border border-white/10 bg-white px-4 py-3 text-slate-950"/><Button>Unlock</Button></div></form>}{videoUrl && <div className="relative overflow-hidden rounded-3xl bg-black"><video ref={videoRef} src={videoUrl} controls onTimeUpdate={enforceClip} onLoadedMetadata={()=>{ if (videoRef.current && isClip) videoRef.current.currentTime = clipStart; }} className="aspect-video w-full"/><div className="pointer-events-none absolute inset-0 grid place-items-center text-4xl font-black uppercase tracking-widest text-white/15 -rotate-12">{share.watermarkText || 'Defensiq Security'}</div></div>}<div className="mt-5 flex flex-wrap gap-2"><Button onClick={()=>requestAccess(password)} variant="secondary"><Play size={16}/>Reload playback</Button>{share.allowDownload && <Button onClick={download} variant="secondary"><Download size={16}/>Download</Button>}</div></div><aside className="rounded-4xl border border-white/10 bg-white/10 p-5 shadow-2xl backdrop-blur-xl"><h2 className="text-xl font-black">Timeline</h2>{metadata.thumbnailDataUrl && <img src={metadata.thumbnailDataUrl} alt="Recording thumbnail" className="mt-3 aspect-video rounded-2xl object-cover"/>}<div className="mt-4 space-y-2"><h3 className="font-bold">Chapters</h3>{chapters.length ? chapters.map((chapter, i)=><button key={`${chapter.time}-${i}`} onClick={()=>seek(chapter.time)} className="block w-full rounded-xl bg-white/10 px-3 py-2 text-left text-sm hover:bg-white/15">{formatTime(chapter.time)} · {chapter.title || chapter.text}</button>) : <p className="text-sm text-slate-400">No chapters available.</p>}</div><div className="mt-4 space-y-2"><h3 className="font-bold">Events</h3>{timeline.slice(0,8).map((event,i)=><button key={`${event.time}-${i}`} onClick={()=>seek(event.time)} className="block w-full rounded-xl bg-white/10 px-3 py-2 text-left text-xs hover:bg-white/15">{formatTime(event.time)} · {event.title || event.text}</button>)}</div><label className="mt-4 flex items-center gap-2 rounded-2xl bg-white/10 px-3 py-2"><Search size={16}/><input value={search} onChange={(e)=>setSearch(e.target.value)} placeholder="Search transcript" className="min-w-0 flex-1 bg-transparent text-sm outline-none"/></label><div className="mt-3 max-h-80 space-y-2 overflow-auto">{transcript.length ? transcript.map((line,i)=><button key={`${line.time}-${i}`} onClick={()=>seek(line.time)} className="block w-full rounded-xl bg-white/10 px-3 py-2 text-left text-xs hover:bg-white/15"><span className="font-bold text-brand-200">{formatTime(line.time)}</span> {line.text}</button>) : <p className="text-sm text-slate-400">No transcript matches.</p>}</div></aside></section></main>;
}

function formatTime(seconds = 0) { const s = Math.max(0, Math.floor(seconds)); const m = Math.floor(s/60); return `${m}:${String(s%60).padStart(2,'0')}`; }
