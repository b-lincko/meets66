'use client';

import { Database, Gauge, RefreshCcw, Server } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { toast } from 'sonner';
import { AdminGuard } from '@/components/AdminGuard';
import { Button } from '@/components/Button';
import { ThemeToggle } from '@/components/ThemeToggle';
import { api, cachedAdmin } from '@/lib/api';

type TablePerf = { rows: number; indexes: { name: string; columns: string[] }[]; error?: string };
type PerformanceReport = {
  database: { dialect: string; tables: Record<string, TablePerf> };
  pagination: { defaultPerPage: number; maxPerPage: number; adminMaxPerPage: number };
  system: { cpuPercent: number; ram: { total: number; used: number; percent: number }; disk: { total: number; used: number; percent: number }; network: { bytesSent: number; bytesRecv: number } };
  cachePolicy: Record<string, string>;
};

function bytes(value = 0) {
  if (value < 1024) return `${value} B`;
  if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`;
  if (value < 1024 * 1024 * 1024) return `${(value / 1024 / 1024).toFixed(1)} MB`;
  return `${(value / 1024 / 1024 / 1024).toFixed(2)} GB`;
}

export default function PerformancePage() {
  const [report, setReport] = useState<PerformanceReport | null>(null);
  const [filter, setFilter] = useState('');
  async function load() {
    if (!cachedAdmin()) return;
    try { setReport(await api<PerformanceReport>('/admin/performance')); }
    catch (err) { toast.error(err instanceof Error ? err.message : 'Could not load performance report'); }
  }
  useEffect(() => { load(); }, []);
  const tables = useMemo(() => Object.entries(report?.database.tables || {}).filter(([name]) => name.toLowerCase().includes(filter.toLowerCase())), [report, filter]);
  return (
    <AdminGuard permission="analytics.view">
      {!report ? <main className="grid min-h-screen place-items-center bg-slate-950 text-white">Loading performance report...</main> : <main className="min-h-screen bg-mesh p-4 dark:bg-slate-950 sm:p-8">
        <div className="mx-auto max-w-7xl">
          <header className="mb-8 flex flex-col justify-between gap-4 sm:flex-row sm:items-center"><div><p className="text-sm font-bold uppercase tracking-widest text-brand-600">Performance optimization</p><h1 className="text-4xl font-black">Performance Center</h1><p className="mt-2 text-slate-500">Database indexes, table sizes, pagination policy, cache policy, and system metrics.</p></div><div className="flex gap-2"><ThemeToggle/><Button variant="secondary" onClick={load}><RefreshCcw size={16}/>Refresh</Button></div></header>
          <section className="grid gap-5 md:grid-cols-4"><Card title="Database" value={report.database.dialect} detail="SQLAlchemy dialect" icon={<Database/>}/><Card title="CPU" value={`${report.system.cpuPercent}%`} detail="Current process host" icon={<Gauge/>}/><Card title="RAM" value={`${report.system.ram.percent}%`} detail={`${bytes(report.system.ram.used)} used`} icon={<Server/>}/><Card title="Disk" value={`${report.system.disk.percent}%`} detail={`${bytes(report.system.disk.used)} used`} icon={<Server/>}/></section>
          <section className="mt-8 grid gap-6 lg:grid-cols-[1fr_.7fr]"><div className="glass rounded-4xl p-5"><div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"><h2 className="text-xl font-bold">Database tables and indexes</h2><input value={filter} onChange={(e)=>setFilter(e.target.value)} placeholder="Filter tables" className="rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900"/></div><div className="overflow-x-auto"><table className="w-full min-w-[760px] text-left text-sm"><thead className="text-xs uppercase text-slate-500"><tr><th className="px-3 py-3">Table</th><th>Rows</th><th>Indexes</th></tr></thead><tbody>{tables.map(([name, table])=><tr key={name} className="border-t border-slate-200/70 dark:border-slate-800"><td className="px-3 py-3 font-mono">{name}</td><td>{table.rows}</td><td><div className="space-y-1">{table.indexes.map((idx)=><p key={idx.name} className="font-mono text-xs text-slate-500">{idx.name}: {idx.columns.join(', ')}</p>)}{!table.indexes.length && <span className="text-slate-500">No indexes reported</span>}</div></td></tr>)}</tbody></table></div></div><div className="space-y-6"><Panel title="Pagination policy"><p>Default: {report.pagination.defaultPerPage}</p><p>Max: {report.pagination.maxPerPage}</p><p>Admin max: {report.pagination.adminMaxPerPage}</p></Panel><Panel title="Cache policy">{Object.entries(report.cachePolicy).map(([k,v])=><p key={k} className="text-sm"><b>{k}:</b> {v}</p>)}</Panel><Panel title="Network counters"><p>Sent: {bytes(report.system.network.bytesSent)}</p><p>Received: {bytes(report.system.network.bytesRecv)}</p></Panel></div></section>
        </div>
      </main>}
    </AdminGuard>
  );
}

function Card({ title, value, detail, icon }: { title: string; value: string; detail: string; icon: React.ReactNode }) { return <div className="glass rounded-4xl p-5"><div className="flex justify-between gap-3"><div><p className="text-sm text-slate-500">{title}</p><p className="mt-2 text-2xl font-black">{value}</p><p className="mt-2 text-sm text-slate-500">{detail}</p></div><span className="grid h-12 w-12 place-items-center rounded-2xl bg-brand-600 text-white">{icon}</span></div></div>; }
function Panel({ title, children }: { title: string; children: React.ReactNode }) { return <div className="glass rounded-4xl p-5"><h2 className="mb-3 text-xl font-bold">{title}</h2><div className="space-y-2 text-sm text-slate-600 dark:text-slate-300">{children}</div></div>; }
