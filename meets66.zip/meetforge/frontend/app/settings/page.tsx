'use client';

import { RefreshCcw, Save } from 'lucide-react';
import { useEffect, useState } from 'react';
import { toast } from 'sonner';
import { Button } from '@/components/Button';
import { ThemeToggle } from '@/components/ThemeToggle';
import { AdminGuard } from '@/components/AdminGuard';
import { api, cachedAdmin } from '@/lib/api';

type SettingsMap = Record<string, Record<string, any>>;

export default function SettingsPage() {
  const [settings, setSettings] = useState<SettingsMap>({});
  async function load() { setSettings((await api<{settings: SettingsMap}>('/admin/settings')).settings); }
  useEffect(() => { if (cachedAdmin()) load().catch((err)=>toast.error(err.message)); }, []);
  function setValue(section: string, key: string, value: any) { setSettings((prev)=>({ ...prev, [section]: { ...(prev[section] || {}), [key]: value } })); }
  async function save(section: string) { const data = await api<{value: Record<string, any>}>(`/admin/settings/${section}`, { method:'PATCH', body: JSON.stringify(settings[section]) }); setSettings((prev)=>({ ...prev, [section]: data.value })); toast.success(`${section} saved`); }
  return <AdminGuard permission="settings.manage"><main className="min-h-screen bg-mesh p-4 dark:bg-slate-950 sm:p-8"><div className="mx-auto max-w-6xl"><header className="mb-8 flex items-center justify-between"><div><p className="text-sm font-bold uppercase tracking-widest text-brand-600">Enterprise settings</p><h1 className="text-4xl font-black">Settings</h1></div><div className="flex gap-2"><ThemeToggle/><Button variant="secondary" onClick={load}><RefreshCcw size={16}/>Refresh</Button></div></header><div className="grid gap-6 lg:grid-cols-2">{Object.entries(settings).map(([section, values])=><section key={section} className="glass rounded-4xl p-5"><div className="mb-4 flex items-center justify-between"><h2 className="text-xl font-bold">{section.replaceAll('_',' ')}</h2><Button onClick={()=>save(section)}><Save size={15}/>Save</Button></div><div className="space-y-3">{Object.entries(values).map(([key,value])=><label key={key} className="block"><span className="text-sm font-semibold">{key}</span>{typeof value === 'boolean' ? <select value={String(value)} onChange={(e)=>setValue(section,key,e.target.value === 'true')} className="mt-1 w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900"><option value="true">Enabled</option><option value="false">Disabled</option></select> : typeof value === 'number' ? <input type="number" value={value} onChange={(e)=>setValue(section,key,Number(e.target.value))} className="mt-1 w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900"/> : <input value={value ?? ''} onChange={(e)=>setValue(section,key,e.target.value)} className="mt-1 w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900"/>}</label>)}</div></section>)}</div></div></main></AdminGuard>;
}
