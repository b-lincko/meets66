import { MeetingRolesClient } from './roles-client';

export default async function MeetingRolesPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <MeetingRolesClient id={id} />;
}
