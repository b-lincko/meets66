'use client';

import { ArrowLeft, BarChart3, Download, RefreshCcw, Search, ShieldCheck, Trash2, UserPlus, Users } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { toast } from 'sonner';
import { Button } from '@/components/Button';
import { ThemeToggle } from '@/components/ThemeToggle';
import { AdminGuard } from '@/components/AdminGuard';
import { API_URL, Meeting, api, cachedAdmin, getAccessToken } from '@/lib/api';

type Assignment = { id: string; meetingId: string; adminId?: string | null; participantId?: string | null; email?: string | null; displayName: string; role: string; permissions: string[]; active: boolean; createdAt?: string | null };
type Candidate = { subjectType: 'admin' | 'participant'; id: string; displayName: string; email?: string | null; role: string; department?: string; organization?: string };
type Dashboard = { meeting: Meeting; durationSeconds: number; participants: { total: number; admitted: number; waiting: number }; recording: { active: boolean; total: number }; screenSharing: { active: boolean }; whiteboard: { enabled: boolean; elements: number }; chat: { enabled: boolean; messages: number }; polls: { active: number }; breakouts: { activeAssignments: number } };

const roleOptions = [['meeting_admin','Meeting Admin'], ['cohost','Co-host'], ['moderator','Moderator'], ['presenter','Presenter']];
const categories: Record<string, string[]> = {
  'Meeting Controls': ['meeting.start','meeting.end','meeting.lock'],
  'Participant Management': ['waiting.admit','waiting.reject','waiting.ban','participants.remove','participants.mute','participants.mute_all','participants.camera.disable','participants.pin','presenter.change'],
  'Recording': ['recording.start','recording.pause','recording.stop','recordings.download'],
  'Screen Sharing': ['sharing.grant','sharing.revoke'],
  'Whiteboard': ['whiteboard.grant','whiteboard.revoke'],
  'Breakout Rooms': ['breakouts.manage'],
  'Polls & Q&A': ['polls.manage','qna.manage'],
  'Chat & Files': ['chat.manage','files.manage'],
  'Reports & Analytics': ['attendance.view','analytics.view'],
  'Captions & AI': ['captions.manage','ai_transcription.manage'],
  'Role Management': ['cohosts.manage'],
};

export function MeetingRolesClient({ id }: { id: string }) {
  const router = useRouter();
  const [meeting, setMeeting] = useState<Meeting | null>(null);
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [permissions, setPermissions] = useState<string[]>([]);
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [query, setQuery] = useState('');
  const [selectedCandidate, setSelectedCandidate] = useState<Candidate | null>(null);
  const [selectedRole, setSelectedRole] = useState('cohost');
  const [selectedPermissions, setSelectedPermissions] = useState<string[]>([]);
  const [dashboard, setDashboard] = useState<Dashboard | null>(null);
  const [busy, setBusy] = useState(false);

  async function load() {
    const [meetingData, rolesData, dash] = await Promise.all([
      api<{ meeting: Meeting }>(`/meetings/${id}`),
      api<{ items: Assignment[]; permissions: string[]; total: number }>(`/meetings/${id}/roles`),
      api<Dashboard>(`/meetings/${id}/admin-dashboard`).catch(() => null),
    ]);
    setMeeting(meetingData.meeting);
    setAssignments(rolesData.items);
    setPermissions(rolesData.permissions);
    setDashboard(dash);
  }
  useEffect(() => { if (cachedAdmin()) load().catch((err) => toast.error(err.message)); }, [id]);
  useEffect(() => { const t = window.setTimeout(() => search(), 350); return () => window.clearTimeout(t); }, [query]);

  async function search() {
    const data = await api<{ items: Candidate[]; total: number }>(`/meetings/${id}/role-candidates?q=${encodeURIComponent(query)}`);
    setCandidates(data.items);
  }
  function togglePermission(permission: string) { setSelectedPermissions((prev) => prev.includes(permission) ? prev.filter((item) => item !== permission) : [...prev, permission]); }
  function roleDefaults(role: string) {
    if (role === 'meeting_admin') return permissions;
    if (role === 'cohost') return ['waiting.admit','waiting.reject','participants.mute','sharing.grant','whiteboard.grant','recording.start','breakouts.manage','polls.manage','qna.manage','chat.manage','presenter.change','participants.pin'];
    if (role === 'moderator') return ['waiting.admit','waiting.reject','participants.mute','chat.manage','polls.manage','qna.manage'];
    return ['sharing.grant','whiteboard.grant','presenter.change'];
  }
  function chooseRole(role: string) { setSelectedRole(role); setSelectedPermissions(roleDefaults(role)); }
  async function assign() {
    if (!selectedCandidate) return toast.error('Select a user or participant');
    setBusy(true);
    try {
      const body = selectedCandidate.subjectType === 'admin'
        ? { subjectType: 'admin', adminId: selectedCandidate.id, role: selectedRole, permissions: selectedPermissions }
        : { subjectType: 'participant', participantId: selectedCandidate.id, role: selectedRole, permissions: selectedPermissions };
      await api(`/meetings/${id}/roles`, { method: 'POST', body: JSON.stringify(body) });
      setSelectedCandidate(null); setSelectedPermissions([]); toast.success('Meeting role assigned'); await load();
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Assignment failed'); }
    finally { setBusy(false); }
  }
  async function updateAssignment(assignment: Assignment, nextPermissions: string[]) {
    const data = await api<{ assignment: Assignment }>(`/meetings/${id}/roles/${assignment.id}`, { method: 'PATCH', body: JSON.stringify({ permissions: nextPermissions }) });
    setAssignments((prev) => prev.map((item) => item.id === assignment.id ? data.assignment : item));
    toast.success('Permissions updated');
  }
  async function revoke(assignment: Assignment) {
    await api(`/meetings/${id}/roles/${assignment.id}`, { method: 'DELETE' });
    toast.success('Role revoked'); await load();
  }
  async function downloadAttendance() {
    const res = await fetch(`${API_URL}/meetings/${id}/attendance.csv`, { headers: { Authorization: `Bearer ${getAccessToken()}` } });
    if (!res.ok) return toast.error('Attendance export failed');
    const url = URL.createObjectURL(await res.blob()); const a = document.createElement('a'); a.href = url; a.download = `${meeting?.meetingId || 'meeting'}-attendance.csv`; a.click(); URL.revokeObjectURL(url);
  }

  return <AdminGuard permission="meetings.manage"><main className="min-h-screen bg-mesh p-4 dark:bg-slate-950 sm:p-8"><div className="mx-auto max-w-7xl"><header className="mb-8 flex flex-col justify-between gap-4 sm:flex-row sm:items-center"><div className="flex items-start gap-3"><button onClick={()=>router.push('/dashboard')} className="rounded-2xl bg-white/80 p-3 dark:bg-slate-900"><ArrowLeft/></button><div><p className="text-sm font-bold uppercase tracking-widest text-brand-600">Meeting administration</p><h1 className="text-4xl font-black">Roles & Permissions</h1><p className="mt-2 text-slate-500">{meeting?.title || 'Loading meeting...'}</p></div></div><div className="flex gap-2"><ThemeToggle/><Button variant="secondary" onClick={load}><RefreshCcw size={16}/>Refresh</Button><Button variant="secondary" onClick={downloadAttendance}><Download size={16}/>Attendance CSV</Button></div></header>{dashboard && <section className="mb-6 grid gap-3 md:grid-cols-4"><Metric icon={<Users/>} label="Participants" value={`${dashboard.participants.admitted}/${dashboard.participants.total}`} /><Metric icon={<UserPlus/>} label="Waiting" value={String(dashboard.participants.waiting)} /><Metric icon={<BarChart3/>} label="Chat" value={`${dashboard.chat.messages} messages`} /><Metric icon={<ShieldCheck/>} label="Recording" value={dashboard.recording.active ? 'Active' : 'Stopped'} /></section>}<section className="grid gap-6 lg:grid-cols-[.9fr_1.1fr]"><div className="glass rounded-4xl p-5"><h2 className="mb-4 text-xl font-black">Assign meeting role</h2><label className="mb-3 flex items-center gap-2 rounded-2xl border border-slate-200 bg-white/80 px-3 py-2 dark:border-slate-700 dark:bg-slate-900"><Search size={16}/><input value={query} onChange={(e)=>setQuery(e.target.value)} placeholder="Search name, email, department, organization" className="min-w-0 flex-1 bg-transparent outline-none"/></label><div className="mb-4 max-h-56 space-y-2 overflow-auto">{candidates.map((candidate)=><button key={`${candidate.subjectType}-${candidate.id}`} onClick={()=>setSelectedCandidate(candidate)} className={`w-full rounded-2xl p-3 text-left text-sm ${selectedCandidate?.id===candidate.id && selectedCandidate.subjectType===candidate.subjectType ? 'bg-brand-600 text-white' : 'bg-white/70 dark:bg-slate-900/70'}`}><p className="font-bold">{candidate.displayName}</p><p className="text-xs opacity-80">{candidate.subjectType} · {candidate.email || 'No email'} · {candidate.department || 'No department'} · {candidate.organization || 'No organization'}</p></button>)}</div><label className="mb-3 block"><span className="text-sm font-bold">Role</span><select value={selectedRole} onChange={(e)=>chooseRole(e.target.value)} className="mt-2 w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900">{roleOptions.map(([id,label])=><option key={id} value={id}>{label}</option>)}</select></label><PermissionEditor value={selectedPermissions} onChange={togglePermission}/><Button className="mt-4 w-full" disabled={busy || !selectedCandidate} onClick={assign}>Assign Role</Button></div><div className="glass rounded-4xl p-5"><h2 className="mb-4 text-xl font-black">Current administrators and co-hosts</h2><div className="space-y-3">{assignments.map((assignment)=><div key={assignment.id} className="rounded-3xl bg-white/70 p-4 dark:bg-slate-900/70"><div className="mb-3 flex items-start justify-between gap-3"><div><p className="font-black">{assignment.displayName}</p><p className="text-sm text-slate-500">{assignment.role} · {assignment.email || assignment.participantId || assignment.adminId} · {assignment.active ? 'active' : 'revoked'}</p></div><Button variant="danger" className="px-3 py-2" onClick={()=>revoke(assignment)}><Trash2 size={15}/>Revoke</Button></div><AssignmentPermissions assignment={assignment} onChange={(next)=>updateAssignment(assignment,next)} /></div>)}{!assignments.length && <p className="rounded-3xl border border-dashed border-slate-300 p-8 text-center text-slate-500 dark:border-slate-700">No meeting roles assigned yet.</p>}</div></div></section></div></main></AdminGuard>;
}
function PermissionEditor({ value, onChange }: { value: string[]; onChange: (permission: string)=>void }) { return <div className="max-h-80 space-y-3 overflow-auto rounded-3xl bg-white/60 p-3 dark:bg-slate-900/60">{Object.entries(categories).map(([category, perms])=><div key={category}><p className="mb-1 text-xs font-black uppercase tracking-wider text-slate-500">{category}</p><div className="flex flex-wrap gap-2">{perms.map((perm)=><label key={perm} className="rounded-xl bg-white/80 px-2 py-1 text-xs dark:bg-slate-950"><input type="checkbox" checked={value.includes(perm)} onChange={()=>onChange(perm)} className="mr-1"/>{perm}</label>)}</div></div>)}</div>; }
function AssignmentPermissions({ assignment, onChange }: { assignment: Assignment; onChange: (next: string[])=>void }) { const [value,setValue]=useState(assignment.permissions); useEffect(()=>setValue(assignment.permissions),[assignment.permissions]); function toggle(p:string){ setValue((prev)=>prev.includes(p)?prev.filter((x)=>x!==p):[...prev,p]); } return <div><PermissionEditor value={value} onChange={toggle}/><Button variant="secondary" className="mt-3" onClick={()=>onChange(value)}>Save permissions</Button></div>; }
function Metric({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) { return <div className="glass rounded-3xl p-4"><div className="flex items-center gap-3"><span className="grid h-10 w-10 place-items-center rounded-2xl bg-brand-600 text-white">{icon}</span><div><p className="text-xs uppercase text-slate-500">{label}</p><p className="font-black">{value}</p></div></div></div>; }
