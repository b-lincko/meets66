'use client';

import { ArrowLeft, CalendarDays, CheckCircle2, Clock, Copy, FileText, Info, KeyRound, Link as LinkIcon, Loader2, Palette, RotateCcw, Save, Search, ShieldCheck, Sparkles, Trash2, Users, Video } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { toast } from 'sonner';
import { Button } from '@/components/Button';
import { ThemeToggle } from '@/components/ThemeToggle';
import { AdminGuard } from '@/components/AdminGuard';
import { Meeting, MeetingInvitation, api, cachedAdmin } from '@/lib/api';

type DraftResponse = { draft: { id: string; title: string; payload: MeetingForm } };
type Template = { id: string; name: string; title: string; description?: string | null; durationMinutes: number; timezone: string; waitingRoomEnabled: boolean; allowChat: boolean; allowScreenShare: boolean };
type ConflictResponse = { items: Meeting[]; total: number; hasConflicts: boolean };
type CreateMeetingResponse = { meeting: Meeting; invitation: MeetingInvitation; occurrences?: Meeting[]; invitations?: MeetingInvitation[] };

type MeetingForm = {
  title: string;
  description: string;
  meetingType: 'general' | 'webinar' | 'training' | 'interview' | 'support' | 'custom';
  customType: string;
  templateId: string;
  category: string;
  tags: string;
  color: string;
  startDate: string;
  startTime: string;
  endTime: string;
  timezone: string;
  recurring: boolean;
  recurrenceType: 'daily' | 'weekly' | 'monthly' | 'yearly' | 'custom';
  recurrenceInterval: number;
  recurrenceEndDate: string;
  recurrenceCount: number;
  meetingIdMode: 'auto' | 'personal' | 'custom';
  customMeetingId: string;
  passwordEnabled: boolean;
  passwordMode: 'auto' | 'manual';
  password: string;
  waitingRoomEnabled: boolean;
  joinBeforeHost: boolean;
  hostOnlyStart: boolean;
  maxParticipants: number;
  recordingPermission: 'disabled' | 'host' | 'host_cohost' | 'everyone';
  recordingMode: 'presentation' | 'screen_only' | 'camera_only' | 'gallery';
  autoRecord: boolean;
  recordingStorage: 'local' | 'server' | 'cloud' | 'hybrid';
  retentionDays: number;
  recordingWatermark: boolean;
  whoCanShare: 'host' | 'cohosts' | 'approved' | 'all';
  participantShareRequests: boolean;
  shareApprovalRequired: boolean;
  multiplePresenters: boolean;
  shareSystemAudio: boolean;
  whiteboardEnabled: boolean;
  whiteboardWho: 'host' | 'cohosts' | 'approved' | 'all';
  collaborativeEditing: boolean;
  autoSaveWhiteboard: boolean;
  chatPolicy: 'disabled' | 'host' | 'everyone';
  privateChat: boolean;
  fileSharing: boolean;
  maxUploadMb: number;
  allowedFileTypes: string;
  messageHistory: boolean;
  chatModeration: boolean;
  defaultCamera: string;
  defaultMicrophone: string;
  noiseSuppression: boolean;
  echoCancellation: boolean;
  backgroundBlur: boolean;
  virtualBackground: boolean;
  hdVideo: boolean;
  bandwidthOptimization: boolean;
  requireAuthentication: boolean;
  watermark: boolean;
  e2ee: boolean;
  muteOnJoin: boolean;
  disableRename: boolean;
  disableUnmute: boolean;
  disableCamera: boolean;
  lockAfterStart: boolean;
  preventAnonymous: boolean;
  ipRestrictions: string;
  deviceRestrictions: string;
  sessionTimeoutMinutes: number;
  breakoutEnabled: boolean;
  breakoutAssignment: 'automatic' | 'manual';
  maxRooms: number;
  allowChooseRooms: boolean;
  pollsEnabled: boolean;
  qnaEnabled: boolean;
  anonymousQuestions: boolean;
  qnaModeration: boolean;
  pollTemplate: string;
  emailInvitations: boolean;
  calendarInvitations: boolean;
  reminderEmails: boolean;
  smsReminders: boolean;
  pushNotifications: boolean;
  inviteEmails: string;
  inviteByLink: boolean;
};

function datePart(offsetHours = 1) { const d = new Date(Date.now() + offsetHours * 3600000); d.setMinutes(0, 0, 0); return d.toISOString().slice(0, 10); }
function timePart(offsetHours = 1) { const d = new Date(Date.now() + offsetHours * 3600000); d.setMinutes(0, 0, 0); return d.toTimeString().slice(0, 5); }
function defaultPassword() { return `Dq-${Math.random().toString(36).slice(2, 6)}-${Math.random().toString(36).slice(2, 6)}`; }
function initialForm(): MeetingForm {
  const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
  return {
    title: '', description: '', meetingType: 'general', customType: '', templateId: '', category: '', tags: '', color: '#2563eb',
    startDate: datePart(1), startTime: timePart(1), endTime: timePart(2), timezone, recurring: false, recurrenceType: 'weekly', recurrenceInterval: 1, recurrenceEndDate: '', recurrenceCount: 1,
    meetingIdMode: 'auto', customMeetingId: '', passwordEnabled: true, passwordMode: 'auto', password: defaultPassword(), waitingRoomEnabled: true, joinBeforeHost: false, hostOnlyStart: false, maxParticipants: 100,
    recordingPermission: 'host_cohost', recordingMode: 'presentation', autoRecord: false, recordingStorage: 'server', retentionDays: 30, recordingWatermark: false,
    whoCanShare: 'cohosts', participantShareRequests: true, shareApprovalRequired: true, multiplePresenters: false, shareSystemAudio: true,
    whiteboardEnabled: true, whiteboardWho: 'cohosts', collaborativeEditing: true, autoSaveWhiteboard: true,
    chatPolicy: 'everyone', privateChat: true, fileSharing: true, maxUploadMb: 25, allowedFileTypes: 'pdf,docx,xlsx,png,jpg,txt', messageHistory: true, chatModeration: false,
    defaultCamera: 'system', defaultMicrophone: 'system', noiseSuppression: true, echoCancellation: true, backgroundBlur: false, virtualBackground: false, hdVideo: true, bandwidthOptimization: true,
    requireAuthentication: false, watermark: false, e2ee: false, muteOnJoin: false, disableRename: false, disableUnmute: false, disableCamera: false, lockAfterStart: false, preventAnonymous: false, ipRestrictions: '', deviceRestrictions: '', sessionTimeoutMinutes: 120,
    breakoutEnabled: false, breakoutAssignment: 'automatic', maxRooms: 4, allowChooseRooms: false,
    pollsEnabled: true, qnaEnabled: true, anonymousQuestions: false, qnaModeration: true, pollTemplate: 'none',
    emailInvitations: false, calendarInvitations: true, reminderEmails: false, smsReminders: false, pushNotifications: false,
    inviteEmails: '', inviteByLink: true,
  };
}

function combineLocal(date: string, time: string) { return new Date(`${date}T${time}:00`); }
function durationMinutes(form: MeetingForm) { return Math.max(0, Math.round((combineLocal(form.startDate, form.endTime).getTime() - combineLocal(form.startDate, form.startTime).getTime()) / 60000)); }
function parseEmails(value: string) { return value.replace(/;/g, ',').split(/[\n,]+/).map((item) => item.trim()).filter(Boolean); }

function payloadFromForm(form: MeetingForm) {
  const start = combineLocal(form.startDate, form.startTime);
  const end = combineLocal(form.startDate, form.endTime);
  const screenPolicy = form.whoCanShare === 'host' ? 'host' : form.whoCanShare === 'cohosts' || form.whoCanShare === 'approved' ? 'cohosts' : 'all';
  return {
    title: form.title.trim(),
    description: form.description.trim() || undefined,
    scheduledStartAt: start.toISOString(),
    scheduledEndAt: end.toISOString(),
    timezone: form.timezone,
    reminderMinutes: 10,
    recurrenceType: form.recurring ? form.recurrenceType : 'none',
    recurrenceCount: form.recurring ? form.recurrenceCount : 1,
    recurrenceInterval: form.recurring ? form.recurrenceInterval : 1,
    meetingIdMode: form.meetingIdMode,
    customMeetingId: form.meetingIdMode === 'custom' ? form.customMeetingId.trim().toLowerCase() : undefined,
    password: form.passwordEnabled ? form.password : '',
    waitingRoomEnabled: form.waitingRoomEnabled,
    joinBeforeHost: form.joinBeforeHost,
    hostOnlyStart: form.hostOnlyStart,
    maxParticipants: form.maxParticipants,
    allowParticipantAudio: !form.muteOnJoin,
    allowParticipantVideo: !form.disableCamera,
    allowChat: form.chatPolicy !== 'disabled',
    allowScreenShare: form.whoCanShare !== 'host' || true,
    allowWhiteboard: form.whiteboardEnabled,
    screenSharePolicy: screenPolicy,
    advancedSettings: {
      basic: { meetingType: form.meetingType, customType: form.customType, category: form.category, tags: form.tags, color: form.color },
      dateTime: { recurrenceInterval: form.recurrenceInterval, recurrenceEndDate: form.recurrenceEndDate },
      recording: { permission: form.recordingPermission, mode: form.recordingMode, autoRecord: form.autoRecord, storage: form.recordingStorage, retentionDays: form.retentionDays, watermark: form.recordingWatermark },
      screenSharing: { whoCanShare: form.whoCanShare, participantRequests: form.participantShareRequests, hostApprovalRequired: form.shareApprovalRequired, multiplePresenters: form.multiplePresenters, systemAudio: form.shareSystemAudio },
      whiteboard: { enabled: form.whiteboardEnabled, whoCanUse: form.whiteboardWho, collaborativeEditing: form.collaborativeEditing, autoSave: form.autoSaveWhiteboard },
      chat: { whoCanChat: form.chatPolicy, privateChat: form.privateChat, fileSharing: form.fileSharing, maxUploadMb: form.maxUploadMb, allowedFileTypes: form.allowedFileTypes, messageHistory: form.messageHistory, moderation: form.chatModeration },
      audioVideo: { defaultCamera: form.defaultCamera, defaultMicrophone: form.defaultMicrophone, noiseSuppression: form.noiseSuppression, echoCancellation: form.echoCancellation, backgroundBlur: form.backgroundBlur, virtualBackground: form.virtualBackground, hdVideo: form.hdVideo, bandwidthOptimization: form.bandwidthOptimization },
      security: { requireAuthentication: form.requireAuthentication, watermark: form.watermark, e2ee: form.e2ee, muteOnJoin: form.muteOnJoin, disableRename: form.disableRename, disableUnmute: form.disableUnmute, disableCamera: form.disableCamera, lockAfterStart: form.lockAfterStart, preventAnonymous: form.preventAnonymous, ipRestrictions: form.ipRestrictions, deviceRestrictions: form.deviceRestrictions, sessionTimeoutMinutes: form.sessionTimeoutMinutes },
      breakout: { enabled: form.breakoutEnabled, assignment: form.breakoutAssignment, maxRooms: form.maxRooms, allowChooseRooms: form.allowChooseRooms },
      pollsQna: { pollsEnabled: form.pollsEnabled, qnaEnabled: form.qnaEnabled, anonymousQuestions: form.anonymousQuestions, moderation: form.qnaModeration, pollTemplate: form.pollTemplate },
      notifications: { emailInvitations: form.emailInvitations, calendarInvitations: form.calendarInvitations, reminderEmails: form.reminderEmails, smsReminders: form.smsReminders, pushNotifications: form.pushNotifications },
      invitees: { emails: parseEmails(form.inviteEmails), inviteByLink: form.inviteByLink },
    },
  };
}

export default function NewMeetingPage() {
  const router = useRouter();
  const [form, setForm] = useState<MeetingForm>(() => initialForm());
  const [templates, setTemplates] = useState<Template[]>([]);
  const [draftId, setDraftId] = useState<string | null>(null);
  const [draftSavedAt, setDraftSavedAt] = useState<string>('Not saved yet');
  const [dirty, setDirty] = useState(false);
  const [savingDraft, setSavingDraft] = useState(false);
  const [creating, setCreating] = useState(false);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [created, setCreated] = useState<CreateMeetingResponse | null>(null);
  const [conflicts, setConflicts] = useState<Meeting[]>([]);
  const [meetingIdStatus, setMeetingIdStatus] = useState<{valid: boolean; available: boolean} | null>(null);

  useEffect(() => {
    if (!cachedAdmin()) return;
    api<{items: Template[]; total: number}>('/meetings/templates').then((data) => setTemplates(data.items)).catch(() => {});
  }, [router]);

  const setValue = useCallback(<K extends keyof MeetingForm>(key: K, value: MeetingForm[K]) => { setForm((prev) => ({ ...prev, [key]: value })); setDirty(true); }, []);
  const duration = durationMinutes(form);
  const validation = useMemo(() => {
    const errors: string[] = [];
    if (form.title.trim().length < 3) errors.push('Meeting title must be at least 3 characters.');
    if (form.title.length > 200) errors.push('Meeting title must be 200 characters or fewer.');
    if (form.description.length > 5000) errors.push('Description must be 5000 characters or fewer.');
    if (duration <= 0) errors.push('End time must be after start time.');
    if (form.passwordEnabled && form.password.length < 6) errors.push('Password must be at least 6 characters.');
    if (form.meetingIdMode === 'custom' && (!meetingIdStatus || !meetingIdStatus.valid || !meetingIdStatus.available)) errors.push('Custom meeting ID must be valid and available.');
    if (form.maxParticipants < 1 || form.maxParticipants > 10000) errors.push('Maximum participants must be between 1 and 10000.');
    return errors;
  }, [form, duration, meetingIdStatus]);

  useEffect(() => {
    const handler = (event: BeforeUnloadEvent) => { if (dirty) { event.preventDefault(); event.returnValue = ''; } };
    window.addEventListener('beforeunload', handler);
    return () => window.removeEventListener('beforeunload', handler);
  }, [dirty]);

  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 's') { event.preventDefault(); saveDraft(); }
      if ((event.ctrlKey || event.metaKey) && event.key === 'Enter') { event.preventDefault(); createMeeting(); }
      if (event.key === 'Escape') setPreviewOpen(false);
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  });

  useEffect(() => {
    if (!dirty) return;
    const id = window.setTimeout(() => saveDraft(true), 1300);
    return () => window.clearTimeout(id);
  }, [form, dirty]);

  useEffect(() => {
    if (form.meetingIdMode !== 'custom' || form.customMeetingId.trim().length < 3) { setMeetingIdStatus(null); return; }
    const id = window.setTimeout(() => {
      api<{valid: boolean; available: boolean}>(`/meetings/check-id/${encodeURIComponent(form.customMeetingId.trim().toLowerCase())}`).then(setMeetingIdStatus).catch(() => setMeetingIdStatus({ valid: false, available: false }));
    }, 350);
    return () => window.clearTimeout(id);
  }, [form.meetingIdMode, form.customMeetingId]);

  useEffect(() => {
    if (duration <= 0) { setConflicts([]); return; }
    const id = window.setTimeout(() => {
      const payload = payloadFromForm(form);
      api<ConflictResponse>('/meetings/conflicts', { method: 'POST', body: JSON.stringify({ scheduledStartAt: payload.scheduledStartAt, scheduledEndAt: payload.scheduledEndAt }) }).then((data) => setConflicts(data.items)).catch(() => setConflicts([]));
    }, 500);
    return () => window.clearTimeout(id);
  }, [form.startDate, form.startTime, form.endTime]);

  async function saveDraft(silent = false) {
    if (savingDraft) return;
    setSavingDraft(true);
    try {
      const body = JSON.stringify({ title: form.title || 'Untitled meeting draft', payload: form });
      const data = draftId ? await api<DraftResponse>(`/meetings/drafts/${draftId}`, { method: 'PATCH', body }) : await api<DraftResponse>('/meetings/drafts', { method: 'POST', body });
      setDraftId(data.draft.id);
      setDraftSavedAt(new Date().toLocaleTimeString());
      setDirty(false);
      if (!silent) toast.success('Draft saved');
    } catch (err) { if (!silent) toast.error(err instanceof Error ? err.message : 'Draft save failed'); }
    finally { setSavingDraft(false); }
  }

  function applyTemplate(templateId: string) {
    setValue('templateId', templateId);
    const template = templates.find((item) => item.id === templateId);
    if (!template) return;
    setForm((prev) => ({ ...prev, title: prev.title || template.title, description: prev.description || template.description || '', timezone: template.timezone || prev.timezone, waitingRoomEnabled: template.waitingRoomEnabled, chatPolicy: template.allowChat ? 'everyone' : 'disabled', whoCanShare: template.allowScreenShare ? prev.whoCanShare : 'host' }));
    setDirty(true);
  }

  function duplicateForm() { setDraftId(null); setForm((prev) => ({ ...prev, title: `${prev.title || 'Meeting'} Copy` })); setDirty(true); toast.info('Duplicated form. Save it as a new draft or create a meeting.'); }
  function resetForm() { setForm(initialForm()); setDraftId(null); setDirty(false); setCreated(null); toast.info('Form reset'); }
  async function copyText(value?: string | null) { if (!value) return toast.error('Nothing to copy'); await navigator.clipboard.writeText(value); toast.success('Copied'); }

  async function createMeeting() {
    if (validation.length) { toast.error(validation[0]); return; }
    setCreating(true);
    try {
      const payload = payloadFromForm(form);
      const data = await api<CreateMeetingResponse>('/meetings', { method: 'POST', body: JSON.stringify(payload) });
      if (form.emailInvitations && parseEmails(form.inviteEmails).length) {
        const inviteResult = await api<{sent: string[]; failed: {email: string; error: string}[]}>(`/meetings/${data.meeting.id}/email-invitations`, { method: 'POST', body: JSON.stringify({ recipients: parseEmails(form.inviteEmails), message: form.description }) });
        if (inviteResult.failed.length) toast.error(`${inviteResult.failed.length} invitations failed`); else toast.success(`${inviteResult.sent.length} invitations sent`);
      }
      if (draftId) await api(`/meetings/drafts/${draftId}`, { method: 'DELETE' }).catch(() => undefined);
      setCreated(data); setDirty(false); toast.success('Meeting created');
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Meeting creation failed'); }
    finally { setCreating(false); }
  }

  const estimatedStorage = Math.max(1, Math.round(duration * (form.recordingMode === 'gallery' ? 9 : form.recordingMode === 'camera_only' ? 3 : 6)));
  const estimatedBandwidth = Math.max(1, Math.round(form.maxParticipants * (form.hdVideo ? 2.5 : 1.2)));

  return (
    <AdminGuard permission="meetings.manage">
    <main className="min-h-screen bg-slate-50 text-slate-950 dark:bg-slate-950 dark:text-white">
      <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/90 px-4 py-4 backdrop-blur dark:border-slate-800 dark:bg-slate-950/90 sm:px-6">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4"><div className="flex items-center gap-3"><button onClick={()=>router.push('/dashboard')} className="rounded-2xl p-2 hover:bg-slate-100 dark:hover:bg-slate-900" aria-label="Back to dashboard"><ArrowLeft/></button><div><h1 className="text-2xl font-black">Create New Meeting</h1><p className="text-sm text-slate-500">Auto-saved draft: {draftSavedAt}{dirty ? ' · unsaved changes' : ''}</p></div></div><div className="flex items-center gap-2"><ThemeToggle/><Button variant="secondary" onClick={()=>saveDraft()} disabled={savingDraft}>{savingDraft ? <Loader2 className="animate-spin" size={16}/> : <Save size={16}/>}Save Draft</Button><Button onClick={createMeeting} disabled={creating || validation.length > 0}>{creating ? <Loader2 className="animate-spin" size={16}/> : <CalendarDays size={16}/>}Create Meeting</Button></div></div>
      </header>
      <div className="mx-auto grid max-w-7xl gap-5 p-4 sm:p-6 xl:grid-cols-[minmax(0,1fr)_360px]">
        <section className="space-y-5">
          <Section number="1" title="Basic Information" icon={<Info/>}><div className="grid gap-4 lg:grid-cols-2"><Field label="Meeting Title" required counter={`${form.title.length}/200`} error={form.title && form.title.trim().length < 3 ? 'Minimum 3 characters' : ''}><input required value={form.title} onChange={(e)=>setValue('title', e.target.value)} maxLength={200} className="input" /></Field><Field label="Meeting Description" counter={`${form.description.length}/5000`}><textarea value={form.description} onChange={(e)=>setValue('description', e.target.value)} maxLength={5000} rows={3} className="input" /></Field><Field label="Meeting Type"><Select value={form.meetingType} onChange={(v)=>setValue('meetingType', v as MeetingForm['meetingType'])} options={[['general','General Meeting'],['webinar','Webinar'],['training','Training'],['interview','Interview'],['support','Support Session'],['custom','Custom']]} /></Field><Field label="Meeting Template"><Select value={form.templateId} onChange={applyTemplate} options={[['','Select a template'], ...templates.map((t)=>[t.id,t.name] as [string,string])]} /></Field>{form.meetingType === 'custom' && <Field label="Custom Meeting Type"><input value={form.customType} onChange={(e)=>setValue('customType', e.target.value)} maxLength={80} className="input" /></Field>}<Field label="Meeting Category"><input value={form.category} onChange={(e)=>setValue('category', e.target.value)} maxLength={80} className="input" /></Field><Field label="Tags"><input value={form.tags} onChange={(e)=>setValue('tags', e.target.value)} placeholder="quarterly, board, security" className="input" /></Field><Field label="Meeting Color"><input type="color" value={form.color} onChange={(e)=>setValue('color', e.target.value)} className="h-12 w-full rounded-2xl border border-slate-200 bg-white p-2 dark:border-slate-800 dark:bg-slate-900" /></Field></div></Section>
          <Section number="2" title="Date & Time" icon={<Clock/>}><div className="grid gap-4 md:grid-cols-3"><Field label="Start Date" required><input type="date" value={form.startDate} onChange={(e)=>setValue('startDate', e.target.value)} className="input" /></Field><Field label="Start Time" required><input type="time" value={form.startTime} onChange={(e)=>setValue('startTime', e.target.value)} className="input" /></Field><Field label="End Time" required error={duration <= 0 ? 'Must be after start' : ''}><input type="time" value={form.endTime} onChange={(e)=>setValue('endTime', e.target.value)} className="input" /></Field><Field label="Duration"><input readOnly value={`${Math.floor(duration/60)}h ${duration%60}m`} className="input bg-slate-100 dark:bg-slate-800" /></Field><Field label="Time Zone"><input value={form.timezone} onChange={(e)=>setValue('timezone', e.target.value)} className="input" /></Field><Toggle label="Recurring Meeting" enabled={form.recurring} onChange={(v)=>setValue('recurring', v)} /></div>{form.recurring && <div className="mt-4 grid gap-4 md:grid-cols-4"><Field label="Repeat"><Select value={form.recurrenceType} onChange={(v)=>setValue('recurrenceType', v as MeetingForm['recurrenceType'])} options={[['daily','Daily'],['weekly','Weekly'],['monthly','Monthly'],['yearly','Yearly'],['custom','Custom days']]} /></Field><Field label="Interval"><input type="number" min={1} max={365} value={form.recurrenceInterval} onChange={(e)=>setValue('recurrenceInterval', Number(e.target.value))} className="input" /></Field><Field label="End Date"><input type="date" value={form.recurrenceEndDate} onChange={(e)=>setValue('recurrenceEndDate', e.target.value)} className="input" /></Field><Field label="Occurrences"><input type="number" min={1} max={52} value={form.recurrenceCount} onChange={(e)=>setValue('recurrenceCount', Number(e.target.value))} className="input" /></Field></div>}</Section>
          <Section number="3" title="Meeting Access" icon={<KeyRound/>}><div className="grid gap-4 md:grid-cols-2"><Field label="Meeting ID"><RadioGroup value={form.meetingIdMode} onChange={(v)=>setValue('meetingIdMode', v as MeetingForm['meetingIdMode'])} options={[['auto','Generate automatically'],['personal','Personal Meeting ID'],['custom','Custom Meeting ID']]} /></Field>{form.meetingIdMode === 'custom' && <Field label="Custom Meeting ID" error={meetingIdStatus && (!meetingIdStatus.valid || !meetingIdStatus.available) ? 'Unavailable or invalid' : meetingIdStatus?.available ? 'Available' : ''}><input value={form.customMeetingId} onChange={(e)=>setValue('customMeetingId', e.target.value.toLowerCase())} className="input" /></Field>}{form.meetingIdMode === 'personal' && <div className="rounded-2xl bg-brand-600/10 p-4 text-sm text-brand-700 dark:text-brand-200"><p className="font-bold">Personal Meeting ID</p><p className="mt-1">This will schedule/update your dedicated personal meeting room and keep the same reusable invite link.</p></div>}<Toggle label="Password Protection" enabled={form.passwordEnabled} onChange={(v)=>setValue('passwordEnabled', v)} />{form.passwordEnabled && <Field label="Meeting Password"><div className="flex gap-2"><input value={form.password} onChange={(e)=>{ setValue('password', e.target.value); setValue('passwordMode','manual'); }} className="input" /><button type="button" className="iconbtn" onClick={()=>copyText(form.password)}><Copy size={16}/></button><button type="button" className="iconbtn" onClick={()=>setValue('password', defaultPassword())}><RotateCcw size={16}/></button></div></Field>}<Toggle label="Waiting Room" enabled={form.waitingRoomEnabled} onChange={(v)=>setValue('waitingRoomEnabled', v)} /><Toggle label="Join Before Host" enabled={form.joinBeforeHost} onChange={(v)=>setValue('joinBeforeHost', v)} /><Toggle label="Host Only Start" enabled={form.hostOnlyStart} onChange={(v)=>setValue('hostOnlyStart', v)} /><Field label="Maximum Participants"><input type="number" min={1} max={10000} value={form.maxParticipants} onChange={(e)=>setValue('maxParticipants', Number(e.target.value))} className="input" /></Field></div></Section>
          <Section number="4" title="Recording Settings" icon={<Video/>}><div className="grid gap-4 md:grid-cols-3"><Field label="Recording"><Select value={form.recordingPermission} onChange={(v)=>setValue('recordingPermission', v as MeetingForm['recordingPermission'])} options={[['disabled','Disabled'],['host','Host Only'],['host_cohost','Host + Co-host'],['everyone','Everyone']]} /></Field><Field label="Recording Mode"><Select value={form.recordingMode} onChange={(v)=>setValue('recordingMode', v as MeetingForm['recordingMode'])} options={[['presentation','Presenter & Screen'],['screen_only','Screen Only'],['camera_only','Presenter Only'],['gallery','Gallery View']]} /></Field><Field label="Save Recordings To"><Select value={form.recordingStorage} onChange={(v)=>setValue('recordingStorage', v as MeetingForm['recordingStorage'])} options={[['local','Local Storage'],['server','Server'],['cloud','Cloud Storage'],['hybrid','Hybrid']]} /></Field><Toggle label="Automatically Record" enabled={form.autoRecord} onChange={(v)=>setValue('autoRecord', v)} /><Toggle label="Watermark Recording" enabled={form.recordingWatermark} onChange={(v)=>setValue('recordingWatermark', v)} /><Field label="Retention Days"><input type="number" min={1} max={3650} value={form.retentionDays} onChange={(e)=>setValue('retentionDays', Number(e.target.value))} className="input" /></Field></div></Section>
          <Section number="5" title="Screen Sharing" icon={<Sparkles/>}><div className="grid gap-4 md:grid-cols-3"><Field label="Who Can Share"><Select value={form.whoCanShare} onChange={(v)=>setValue('whoCanShare', v as MeetingForm['whoCanShare'])} options={[['host','Host Only'],['cohosts','Host + Co-host'],['approved','Approved Participants'],['all','Everyone']]} /></Field><Toggle label="Participant Requests" enabled={form.participantShareRequests} onChange={(v)=>setValue('participantShareRequests', v)} /><Toggle label="Host Approval Required" enabled={form.shareApprovalRequired} onChange={(v)=>setValue('shareApprovalRequired', v)} /><Toggle label="Allow Multiple Presenters" enabled={form.multiplePresenters} onChange={(v)=>setValue('multiplePresenters', v)} /><Toggle label="Share System Audio" enabled={form.shareSystemAudio} onChange={(v)=>setValue('shareSystemAudio', v)} /></div></Section>
          <Section number="6" title="Whiteboard" icon={<Palette/>}><div className="grid gap-4 md:grid-cols-3"><Toggle label="Whiteboard Enabled" enabled={form.whiteboardEnabled} onChange={(v)=>setValue('whiteboardEnabled', v)} /><Field label="Who Can Use"><Select value={form.whiteboardWho} onChange={(v)=>setValue('whiteboardWho', v as MeetingForm['whiteboardWho'])} options={[['host','Host'],['cohosts','Host + Co-host'],['approved','Approved Participants'],['all','Everyone']]} /></Field><Toggle label="Collaborative Editing" enabled={form.collaborativeEditing} onChange={(v)=>setValue('collaborativeEditing', v)} /><Toggle label="Save Automatically" enabled={form.autoSaveWhiteboard} onChange={(v)=>setValue('autoSaveWhiteboard', v)} /></div></Section>
          <Section number="7" title="Chat" icon={<FileText/>}><div className="grid gap-4 md:grid-cols-3"><Field label="Who Can Chat"><Select value={form.chatPolicy} onChange={(v)=>setValue('chatPolicy', v as MeetingForm['chatPolicy'])} options={[['disabled','Disabled'],['host','Host Only'],['everyone','Everyone']]} /></Field><Toggle label="Private Chat" enabled={form.privateChat} onChange={(v)=>setValue('privateChat', v)} /><Toggle label="File Sharing" enabled={form.fileSharing} onChange={(v)=>setValue('fileSharing', v)} /><Field label="Max Upload MB"><input type="number" min={1} max={200} value={form.maxUploadMb} onChange={(e)=>setValue('maxUploadMb', Number(e.target.value))} className="input" /></Field><Field label="Allowed File Types"><input value={form.allowedFileTypes} onChange={(e)=>setValue('allowedFileTypes', e.target.value)} className="input" /></Field><Toggle label="Message History" enabled={form.messageHistory} onChange={(v)=>setValue('messageHistory', v)} /><Toggle label="Chat Moderation" enabled={form.chatModeration} onChange={(v)=>setValue('chatModeration', v)} /></div></Section>
          <Section number="8" title="Audio & Video" icon={<Video/>}><div className="grid gap-4 md:grid-cols-3"><Field label="Default Camera"><input value={form.defaultCamera} onChange={(e)=>setValue('defaultCamera', e.target.value)} className="input" /></Field><Field label="Default Microphone"><input value={form.defaultMicrophone} onChange={(e)=>setValue('defaultMicrophone', e.target.value)} className="input" /></Field><Toggle label="Noise Suppression" enabled={form.noiseSuppression} onChange={(v)=>setValue('noiseSuppression', v)} /><Toggle label="Echo Cancellation" enabled={form.echoCancellation} onChange={(v)=>setValue('echoCancellation', v)} /><Toggle label="Background Blur" enabled={form.backgroundBlur} onChange={(v)=>setValue('backgroundBlur', v)} /><Toggle label="Virtual Background" enabled={form.virtualBackground} onChange={(v)=>setValue('virtualBackground', v)} /><Toggle label="HD Video" enabled={form.hdVideo} onChange={(v)=>setValue('hdVideo', v)} /><Toggle label="Bandwidth Optimization" enabled={form.bandwidthOptimization} onChange={(v)=>setValue('bandwidthOptimization', v)} /></div></Section>
          <Section number="9" title="Security" icon={<ShieldCheck/>}><div className="grid gap-4 md:grid-cols-3"><Toggle label="Require Authentication" enabled={form.requireAuthentication} onChange={(v)=>setValue('requireAuthentication', v)} /><Toggle label="Watermark" enabled={form.watermark} onChange={(v)=>setValue('watermark', v)} /><Toggle label="E2EE Policy" enabled={form.e2ee} onChange={(v)=>setValue('e2ee', v)} /><Toggle label="Mute Participants on Join" enabled={form.muteOnJoin} onChange={(v)=>setValue('muteOnJoin', v)} /><Toggle label="Disable Rename" enabled={form.disableRename} onChange={(v)=>setValue('disableRename', v)} /><Toggle label="Disable Unmute" enabled={form.disableUnmute} onChange={(v)=>setValue('disableUnmute', v)} /><Toggle label="Disable Camera" enabled={form.disableCamera} onChange={(v)=>setValue('disableCamera', v)} /><Toggle label="Lock After Start" enabled={form.lockAfterStart} onChange={(v)=>setValue('lockAfterStart', v)} /><Toggle label="Prevent Anonymous Users" enabled={form.preventAnonymous} onChange={(v)=>setValue('preventAnonymous', v)} /><Field label="IP Restrictions"><input value={form.ipRestrictions} onChange={(e)=>setValue('ipRestrictions', e.target.value)} className="input" /></Field><Field label="Device Restrictions"><input value={form.deviceRestrictions} onChange={(e)=>setValue('deviceRestrictions', e.target.value)} className="input" /></Field><Field label="Session Timeout Minutes"><input type="number" min={5} max={1440} value={form.sessionTimeoutMinutes} onChange={(e)=>setValue('sessionTimeoutMinutes', Number(e.target.value))} className="input" /></Field></div></Section>
          <Section number="10" title="Breakout Rooms" icon={<Users/>}><div className="grid gap-4 md:grid-cols-3"><Toggle label="Enable Breakout Rooms" enabled={form.breakoutEnabled} onChange={(v)=>setValue('breakoutEnabled', v)} /><Field label="Assignment"><Select value={form.breakoutAssignment} onChange={(v)=>setValue('breakoutAssignment', v as MeetingForm['breakoutAssignment'])} options={[['automatic','Automatic'],['manual','Manual']]} /></Field><Field label="Maximum Rooms"><input type="number" min={1} max={100} value={form.maxRooms} onChange={(e)=>setValue('maxRooms', Number(e.target.value))} className="input" /></Field><Toggle label="Participants Choose Rooms" enabled={form.allowChooseRooms} onChange={(v)=>setValue('allowChooseRooms', v)} /></div></Section>
          <Section number="11" title="Polls & Q&A" icon={<CheckCircle2/>}><div className="grid gap-4 md:grid-cols-3"><Toggle label="Enable Polls" enabled={form.pollsEnabled} onChange={(v)=>setValue('pollsEnabled', v)} /><Toggle label="Enable Q&A" enabled={form.qnaEnabled} onChange={(v)=>setValue('qnaEnabled', v)} /><Toggle label="Anonymous Questions" enabled={form.anonymousQuestions} onChange={(v)=>setValue('anonymousQuestions', v)} /><Toggle label="Moderation" enabled={form.qnaModeration} onChange={(v)=>setValue('qnaModeration', v)} /><Field label="Poll Template"><input value={form.pollTemplate} onChange={(e)=>setValue('pollTemplate', e.target.value)} className="input" /></Field></div></Section>
          <Section number="12" title="Notifications & Invites" icon={<Users/>}><div className="grid gap-4 md:grid-cols-2"><Toggle label="Email Invitations" enabled={form.emailInvitations} onChange={(v)=>setValue('emailInvitations', v)} /><Toggle label="Calendar Invitations" enabled={form.calendarInvitations} onChange={(v)=>setValue('calendarInvitations', v)} /><Toggle label="Reminder Emails" enabled={form.reminderEmails} onChange={(v)=>setValue('reminderEmails', v)} /><Toggle label="SMS Reminders" enabled={form.smsReminders} onChange={(v)=>setValue('smsReminders', v)} /><Toggle label="Push Notifications" enabled={form.pushNotifications} onChange={(v)=>setValue('pushNotifications', v)} /><Toggle label="Invite by Link" enabled={form.inviteByLink} onChange={(v)=>setValue('inviteByLink', v)} /><Field label="Paste Email Addresses" hint="Comma, semicolon, or line separated. Emails are sent after meeting creation if Email Invitations is enabled."><textarea value={form.inviteEmails} onChange={(e)=>setValue('inviteEmails', e.target.value)} rows={5} className="input" /></Field><div className="rounded-3xl bg-brand-600/10 p-4 text-sm text-brand-700 dark:text-brand-200"><Search className="mb-2"/><p className="font-bold">Invite link and calendar files are generated automatically when the meeting is created.</p><p className="mt-2">Invitees: {parseEmails(form.inviteEmails).length}</p></div></div></Section>
        </section>
        <aside className="xl:sticky xl:top-24 xl:h-[calc(100dvh-7rem)]"><Summary form={form} duration={duration} conflicts={conflicts} estimatedStorage={estimatedStorage} estimatedBandwidth={estimatedBandwidth} validation={validation} onPreview={()=>setPreviewOpen(true)} onCreate={createMeeting} onSaveDraft={()=>saveDraft()} onDuplicate={duplicateForm} onReset={resetForm} onCancel={()=>router.push('/dashboard')} creating={creating} savingDraft={savingDraft}/></aside>
      </div>
      <footer className="sticky bottom-0 z-20 border-t border-slate-200 bg-white/90 p-3 backdrop-blur dark:border-slate-800 dark:bg-slate-950/90"><div className="mx-auto flex max-w-7xl flex-wrap justify-end gap-2"><Button variant="secondary" onClick={()=>saveDraft()}><Save size={15}/>Save Draft</Button><Button variant="secondary" onClick={()=>setPreviewOpen(true)}>Preview Meeting</Button><Button variant="secondary" onClick={duplicateForm}>Duplicate</Button><Button variant="secondary" onClick={resetForm}>Reset Form</Button><Button variant="secondary" onClick={()=>router.push('/dashboard')}>Cancel</Button><Button onClick={createMeeting} disabled={creating || validation.length > 0}>{creating ? <Loader2 className="animate-spin" size={15}/> : <CalendarDays size={15}/>}Create Meeting</Button></div></footer>
      {previewOpen && <PreviewModal form={form} duration={duration} onClose={()=>setPreviewOpen(false)} />}
      {created && <CreatedModal data={created} onClose={()=>{ setCreated(null); router.push('/dashboard'); }} onCopy={copyText} />}
    </main></AdminGuard>
  );
}

function Section({ number, title, icon, children }: { number: string; title: string; icon: React.ReactNode; children: React.ReactNode }) { return <section className="rounded-4xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900/80"><div className="mb-5 flex items-center gap-3"><span className="grid h-8 w-8 place-items-center rounded-xl bg-brand-600/10 text-sm font-black text-brand-700 dark:text-brand-200">{number}</span><span className="text-brand-600">{icon}</span><h2 className="text-lg font-black">{title}</h2></div>{children}</section>; }
function Field({ label, required, counter, error, hint, children }: { label: string; required?: boolean; counter?: string; error?: string; hint?: string; children: React.ReactNode }) { return <label className="block"><span className="mb-2 flex justify-between gap-2 text-sm font-bold"><span>{label}{required && <span className="text-rose-500"> *</span>}</span>{counter && <span className="text-xs text-slate-400">{counter}</span>}</span>{children}{hint && <p className="mt-1 text-xs text-slate-500">{hint}</p>}{error && <p className={`mt-1 text-xs ${error === 'Available' ? 'text-emerald-600' : 'text-rose-500'}`}>{error}</p>}</label>; }
function Select({ value, onChange, options }: { value: string; onChange: (value: string)=>void; options: [string,string][] }) { return <select value={value} onChange={(e)=>onChange(e.target.value)} className="input">{options.map(([id,label])=><option key={id} value={id}>{label}</option>)}</select>; }
function Toggle({ label, enabled, onChange }: { label: string; enabled: boolean; onChange: (value: boolean)=>void }) { return <button type="button" onClick={()=>onChange(!enabled)} className="flex min-h-12 items-center justify-between rounded-2xl border border-slate-200 bg-white px-4 py-3 text-left text-sm font-bold dark:border-slate-800 dark:bg-slate-950"><span>{label}</span><span className={`relative h-7 w-12 rounded-full transition ${enabled ? 'bg-brand-600' : 'bg-slate-300 dark:bg-slate-700'}`}><span className={`absolute top-1 h-5 w-5 rounded-full bg-white shadow transition ${enabled ? 'left-6' : 'left-1'}`}/></span></button>; }
function RadioGroup({ value, onChange, options }: { value: string; onChange: (value:string)=>void; options: [string,string][] }) { return <div className="grid gap-2">{options.map(([id,label])=><button type="button" key={id} onClick={()=>onChange(id)} className={`rounded-2xl border px-4 py-3 text-left text-sm font-bold ${value===id?'border-brand-500 bg-brand-600/10 text-brand-700 dark:text-brand-200':'border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-950'}`}>{value===id?'●':'○'} {label}</button>)}</div>; }
function Summary({ form, duration, conflicts, estimatedStorage, estimatedBandwidth, validation, onPreview, onCreate, onSaveDraft, onDuplicate, onReset, onCancel, creating, savingDraft }: { form: MeetingForm; duration: number; conflicts: Meeting[]; estimatedStorage: number; estimatedBandwidth: number; validation: string[]; onPreview:()=>void; onCreate:()=>void; onSaveDraft:()=>void; onDuplicate:()=>void; onReset:()=>void; onCancel:()=>void; creating:boolean; savingDraft:boolean }) { const inviteCount=parseEmails(form.inviteEmails).length; return <div className="flex h-full flex-col rounded-4xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900/80"><h2 className="mb-4 flex items-center gap-2 text-lg font-black"><CalendarDays className="text-brand-600"/>Meeting Summary</h2><div className="min-h-0 flex-1 space-y-3 overflow-auto text-sm"><h3 className="text-xl font-black">{form.title || 'Untitled meeting'}</h3><SummaryRow label="Date" value={form.startDate}/><SummaryRow label="Time" value={`${form.startTime} - ${form.endTime}`}/><SummaryRow label="Duration" value={`${Math.floor(duration/60)}h ${duration%60}m`}/><SummaryRow label="Time Zone" value={form.timezone}/><SummaryRow label="Type" value={form.meetingType}/><SummaryRow label="Maximum Participants" value={String(form.maxParticipants)}/><SummaryRow label="Password Protected" value={form.passwordEnabled?'Yes':'No'}/><SummaryRow label="Waiting Room" value={form.waitingRoomEnabled?'Enabled':'Disabled'}/><SummaryRow label="Recording Mode" value={form.recordingMode}/><SummaryRow label="Screen Sharing" value={form.whoCanShare}/><SummaryRow label="Whiteboard" value={form.whiteboardEnabled ? form.whiteboardWho : 'Disabled'}/><SummaryRow label="Chat" value={form.chatPolicy}/><SummaryRow label="Breakout Rooms" value={form.breakoutEnabled?'Enabled':'Disabled'}/><SummaryRow label="Polls" value={form.pollsEnabled?'Enabled':'Disabled'}/><SummaryRow label="Q&A" value={form.qnaEnabled?'Enabled':'Disabled'}/><SummaryRow label="Recording Location" value={form.recordingStorage}/><SummaryRow label="Invitees" value={String(inviteCount)}/><SummaryRow label="Estimated Storage" value={`${estimatedStorage} MB/hour`}/><SummaryRow label="Estimated Bandwidth" value={`${estimatedBandwidth} Mbps aggregate`}/>{conflicts.length ? <div className="rounded-2xl bg-amber-500/10 p-3 text-amber-700 dark:text-amber-200"><p className="font-bold">Potential conflicts</p>{conflicts.slice(0,3).map((m)=><p key={m.id} className="text-xs">{m.title} · {new Date(m.scheduledStartAt).toLocaleString()}</p>)}</div> : <div className="rounded-2xl bg-emerald-500/10 p-3 text-emerald-700 dark:text-emerald-200">No scheduling conflicts detected.</div>}{validation.length>0 && <div className="rounded-2xl bg-rose-500/10 p-3 text-rose-700 dark:text-rose-200"><p className="font-bold">Validation</p>{validation.map((e)=><p key={e} className="text-xs">{e}</p>)}</div>}</div><div className="mt-4 grid gap-2"><Button onClick={onCreate} disabled={creating || validation.length>0}>{creating?<Loader2 className="animate-spin" size={15}/>:<CalendarDays size={15}/>}Create Meeting</Button><Button variant="secondary" onClick={onPreview}>Preview Meeting</Button><Button variant="secondary" onClick={onSaveDraft}>{savingDraft?<Loader2 className="animate-spin" size={15}/>:<Save size={15}/>}Save Draft</Button><div className="grid grid-cols-3 gap-2"><Button variant="secondary" onClick={onDuplicate}>Duplicate</Button><Button variant="secondary" onClick={onReset}>Reset</Button><Button variant="secondary" onClick={onCancel}>Cancel</Button></div></div></div>; }
function SummaryRow({ label, value }: { label: string; value: string }) { return <div className="flex justify-between gap-4 rounded-2xl bg-slate-50 px-3 py-2 dark:bg-slate-950"><span className="text-slate-500">{label}</span><span className="text-right font-bold">{value}</span></div>; }
function PreviewModal({ form, duration, onClose }: { form: MeetingForm; duration: number; onClose:()=>void }) { return <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/70 p-4 backdrop-blur"><div className="w-full max-w-3xl rounded-4xl bg-white p-6 shadow-2xl dark:bg-slate-900"><h2 className="text-2xl font-black">Participant Preview</h2><div className="mt-5 rounded-4xl border border-slate-200 bg-slate-950 p-8 text-center text-white dark:border-slate-800"><span className="mx-auto grid h-16 w-16 place-items-center rounded-3xl" style={{backgroundColor:form.color}}><Video/></span><h3 className="mt-4 text-3xl font-black">{form.title || 'Untitled meeting'}</h3><p className="mx-auto mt-2 max-w-xl text-slate-300">{form.description || 'No description provided.'}</p><div className="mt-5 grid gap-3 text-sm sm:grid-cols-3"><SummaryCard label="When" value={`${form.startDate} ${form.startTime}`}/><SummaryCard label="Duration" value={`${Math.floor(duration/60)}h ${duration%60}m`}/><SummaryCard label="Access" value={form.waitingRoomEnabled?'Waiting room':'Direct join'}/></div><Button className="mt-6">Join meeting</Button></div><div className="mt-5 flex justify-end"><Button variant="secondary" onClick={onClose}>Close Preview</Button></div></div></div>; }
function SummaryCard({label,value}:{label:string;value:string}) { return <div className="rounded-2xl bg-white/10 p-3"><p className="text-xs uppercase text-slate-400">{label}</p><p className="font-bold">{value}</p></div>; }
function CreatedModal({ data, onClose, onCopy }: { data: CreateMeetingResponse; onClose:()=>void; onCopy:(value?:string|null)=>void }) { return <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/70 p-4 backdrop-blur"><div className="w-full max-w-xl rounded-4xl bg-white p-6 shadow-2xl dark:bg-slate-900"><h2 className="text-2xl font-black">Meeting Created</h2><p className="mt-2 text-slate-500">{data.meeting.title}</p><div className="mt-4 rounded-2xl bg-slate-50 p-4 dark:bg-slate-950"><p className="text-xs uppercase text-slate-500">Invitation Link</p><p className="mt-1 break-all font-mono text-sm">{data.invitation.url}</p><div className="mt-3 flex gap-2"><Button variant="secondary" onClick={()=>onCopy(data.invitation.url)}><Copy size={15}/>Copy Invitation</Button><Button variant="secondary" onClick={()=>onCopy(data.meeting.meetingId)}><LinkIcon size={15}/>Copy ID</Button></div></div><div className="mt-5 flex justify-end"><Button onClick={onClose}>Done</Button></div></div></div>; }
