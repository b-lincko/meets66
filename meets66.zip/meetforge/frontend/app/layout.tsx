import type { Metadata, Viewport } from 'next';
import { Toaster } from 'sonner';
import '@livekit/components-styles';
import './globals.css';

export const metadata: Metadata = {
  title: 'Defensiq Meet Admin',
  description: 'Private Defensiq Meet administration console.'
};

export const viewport: Viewport = { width: 'device-width', initialScale: 1, themeColor: '#1f68eb' };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body>
        {children}
        <Toaster richColors position="top-right" />
      </body>
    </html>
  );
}
