'use client';

import { Copy, KeyRound, RefreshCcw, RotateCcw, Trash2, Webhook } from 'lucide-react';
import { useEffect, useState } from 'react';
import { toast } from 'sonner';
import { Button } from '@/components/Button';
import { ThemeToggle } from '@/components/ThemeToggle';
import { AdminGuard } from '@/components/AdminGuard';
import { API_URL, ApiKey, WebhookDelivery, WebhookSubscription, api, cachedAdmin } from '@/lib/api';

type List<T> = { items: T[]; total: number };

const scopes = ['meetings:read', 'recordings:read', 'webhooks:read'];

export default function IntegrationsPage() {
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([]);
  const [webhooks, setWebhooks] = useState<WebhookSubscription[]>([]);
  const [deliveries, setDeliveries] = useState<WebhookDelivery[]>([]);
  const [events, setEvents] = useState<string[]>([]);
  const [newSecret, setNewSecret] = useState('');
  const [keyForm, setKeyForm] = useState({ name: '', scopes: ['meetings:read'] });
  const [hookForm, setHookForm] = useState({ targetUrl: '', events: ['meeting.created'], description: '' });

  async function load() {
    const [keyData, hookData, deliveryData, eventData] = await Promise.all([
      api<List<ApiKey>>('/admin/api-keys'),
      api<List<WebhookSubscription>>('/admin/webhooks'),
      api<List<WebhookDelivery>>('/admin/webhook-deliveries?perPage=50'),
      api<{ items: string[] }>('/admin/webhooks/events')
    ]);
    setApiKeys(keyData.items);
    setWebhooks(hookData.items);
    setDeliveries(deliveryData.items);
    setEvents(eventData.items);
  }
  useEffect(() => { if (cachedAdmin()) load().catch((err) => toast.error(err.message)); }, []);

  async function createKey(e: React.FormEvent) {
    e.preventDefault();
    const data = await api<{ apiKey: ApiKey; secret: string }>('/admin/api-keys', { method: 'POST', body: JSON.stringify(keyForm) });
    setNewSecret(data.secret);
    setKeyForm({ name: '', scopes: ['meetings:read'] });
    await load();
  }
  async function revokeKey(key: ApiKey) { await api(`/admin/api-keys/${key.id}`, { method: 'DELETE' }); await load(); }
  async function createWebhook(e: React.FormEvent) {
    e.preventDefault();
    const data = await api<{ webhook: WebhookSubscription }>('/admin/webhooks', { method: 'POST', body: JSON.stringify(hookForm) });
    if (data.webhook.signingSecret) { await navigator.clipboard.writeText(data.webhook.signingSecret); toast.success('Signing secret copied'); }
    setHookForm({ targetUrl: '', events: ['meeting.created'], description: '' });
    await load();
  }
  async function toggleWebhook(hook: WebhookSubscription) { await api(`/admin/webhooks/${hook.id}`, { method: 'PATCH', body: JSON.stringify({ enabled: !hook.enabled }) }); await load(); }
  async function deleteWebhook(hook: WebhookSubscription) { await api(`/admin/webhooks/${hook.id}`, { method: 'DELETE' }); await load(); }
  async function retry(delivery: WebhookDelivery) { await api(`/admin/webhook-deliveries/${delivery.id}/retry`, { method: 'POST' }); await load(); }
  function toggleScope(scope: string) { setKeyForm((prev) => ({ ...prev, scopes: prev.scopes.includes(scope) ? prev.scopes.filter((s) => s !== scope) : [...prev.scopes, scope] })); }
  function toggleEvent(event: string) { setHookForm((prev) => ({ ...prev, events: prev.events.includes(event) ? prev.events.filter((s) => s !== event) : [...prev.events, event] })); }

  return <AdminGuard permission="integrations.manage"><main className="min-h-screen bg-mesh p-4 dark:bg-slate-950 sm:p-8"><div className="mx-auto max-w-6xl"><header className="mb-8 flex items-center justify-between"><div><p className="text-sm font-bold uppercase tracking-widest text-brand-600">REST APIs & Webhooks</p><h1 className="text-4xl font-black">Integrations</h1><p className="mt-2 text-slate-500">API keys, OpenAPI docs, signed webhooks, delivery logs, and retry controls.</p></div><div className="flex gap-2"><ThemeToggle/><Button variant="secondary" onClick={load}><RefreshCcw size={16}/>Refresh</Button></div></header><section className="grid gap-6 lg:grid-cols-2"><div className="glass rounded-4xl p-5"><h2 className="mb-4 flex items-center gap-2 text-xl font-bold"><KeyRound/>API keys</h2><form onSubmit={createKey} className="mb-4 space-y-3"><input required value={keyForm.name} onChange={(e)=>setKeyForm({...keyForm,name:e.target.value})} placeholder="Key name" className="w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900"/><div className="flex flex-wrap gap-2">{scopes.map((scope)=><label key={scope} className="rounded-xl bg-white/60 px-3 py-2 text-sm dark:bg-slate-900/60"><input type="checkbox" checked={keyForm.scopes.includes(scope)} onChange={()=>toggleScope(scope)} className="mr-2"/>{scope}</label>)}</div><Button>Create API key</Button></form>{newSecret && <div className="mb-4 rounded-2xl bg-amber-500/10 p-3 text-sm text-amber-700 dark:text-amber-200"><p className="font-bold">Copy this key now. It will not be shown again.</p><p className="break-all font-mono text-xs">{newSecret}</p><Button className="mt-2" variant="secondary" onClick={()=>navigator.clipboard.writeText(newSecret)}><Copy size={14}/>Copy</Button></div>}<div className="space-y-2">{apiKeys.map((key)=><div key={key.id} className="flex items-center justify-between rounded-2xl bg-white/60 p-3 dark:bg-slate-900/60"><div><p className="font-semibold">{key.name}</p><p className="text-xs text-slate-500">{key.keyPrefix} · {key.scopes.join(', ')} · {key.active ? 'active' : 'revoked'}</p></div>{key.active && <button onClick={()=>revokeKey(key)} className="rounded-xl bg-rose-600 p-2 text-white"><Trash2 size={15}/></button>}</div>)}</div></div><div className="glass rounded-4xl p-5"><h2 className="mb-4 flex items-center gap-2 text-xl font-bold"><Webhook/>Webhooks</h2><form onSubmit={createWebhook} className="mb-4 space-y-3"><input required value={hookForm.targetUrl} onChange={(e)=>setHookForm({...hookForm,targetUrl:e.target.value})} placeholder="https://example.com/webhook" className="w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900"/><input value={hookForm.description} onChange={(e)=>setHookForm({...hookForm,description:e.target.value})} placeholder="Description" className="w-full rounded-2xl border border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900"/><div className="max-h-36 overflow-auto rounded-2xl bg-white/60 p-2 dark:bg-slate-900/60">{events.map((event)=><label key={event} className="mr-3 inline-block py-1 text-sm"><input type="checkbox" checked={hookForm.events.includes(event)} onChange={()=>toggleEvent(event)} className="mr-1"/>{event}</label>)}</div><Button>Create webhook</Button></form><div className="space-y-2">{webhooks.map((hook)=><div key={hook.id} className="rounded-2xl bg-white/60 p-3 dark:bg-slate-900/60"><div className="flex items-center justify-between gap-3"><div><p className="break-all font-semibold">{hook.targetUrl}</p><p className="text-xs text-slate-500">{hook.enabled ? 'enabled' : 'disabled'} · {hook.events.join(', ')}</p></div><div className="flex gap-2"><Button variant="secondary" onClick={()=>toggleWebhook(hook)}>{hook.enabled?'Disable':'Enable'}</Button><Button variant="danger" onClick={()=>deleteWebhook(hook)}>Delete</Button></div></div></div>)}</div></div></section><section className="mt-8 glass rounded-4xl p-5"><h2 className="mb-4 text-xl font-bold">Webhook deliveries</h2><div className="overflow-x-auto"><table className="w-full min-w-[900px] text-left text-sm"><thead className="text-xs uppercase text-slate-500"><tr><th className="px-3 py-3">Event</th><th>Status</th><th>Attempts</th><th>Response</th><th>Created</th><th>Action</th></tr></thead><tbody>{deliveries.map((delivery)=><tr key={delivery.id} className="border-t border-slate-200/70 dark:border-slate-800"><td className="px-3 py-3">{delivery.eventType}</td><td>{delivery.status}</td><td>{delivery.attempts}</td><td>{delivery.responseStatus || delivery.errorMessage || '—'}</td><td>{delivery.createdAt ? new Date(delivery.createdAt).toLocaleString() : '—'}</td><td>{delivery.status === 'failed' && <Button variant="secondary" onClick={()=>retry(delivery)}><RotateCcw size={14}/>Retry</Button>}</td></tr>)}</tbody></table></div></section><section className="mt-8 glass rounded-4xl p-5"><h2 className="text-xl font-bold">OpenAPI documentation</h2><p className="mt-2 text-sm text-slate-500">OpenAPI JSON and local docs are available from the running API.</p><div className="mt-3 flex gap-2"><a className="rounded-2xl bg-brand-600 px-5 py-3 text-sm font-semibold text-white" href={`${API_URL}/openapi.json`} target="_blank">OpenAPI JSON</a><a className="rounded-2xl bg-slate-900 px-5 py-3 text-sm font-semibold text-white" href={`${API_URL}/docs`} target="_blank">Docs</a></div></section></div></main></AdminGuard>;
}
