import { Suspense } from 'react';
import { AdminLogin } from '@/components/AdminLogin';

export default function AdminLoginPage() {
  return (
    <Suspense fallback={<div className="grid min-h-screen place-items-center bg-slate-950 text-white">Loading...</div>}>
      <AdminLogin />
    </Suspense>
  );
}
