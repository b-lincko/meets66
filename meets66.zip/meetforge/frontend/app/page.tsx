'use client';

import { LogIn } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { toast } from 'sonner';
import { Button } from '@/components/Button';
import { api, Meeting, MeetingInvitation } from '@/lib/api';

type CodeLookup = { meeting: Meeting; invitation: MeetingInvitation };

const MEETING_CODE_RE = /^[a-z0-9]{3}-[a-z0-9]{3}-[a-z0-9]{3}$/i;
const INVITE_TOKEN_RE = /^[A-Za-z0-9_-]{32,160}$/;

function normalizeJoinValue(input: string) {
  const value = input.trim().replace(/[\u0000-\u001f\u007f]/g, '');
  if (!value || value.length > 700) return { type: 'invalid' as const, value: '' };
  if (MEETING_CODE_RE.test(value)) return { type: 'code' as const, value: value.toLowerCase() };
  if (INVITE_TOKEN_RE.test(value)) return { type: 'token' as const, value };
  try {
    const url = new URL(value);
    const parts = url.pathname.split('/').filter(Boolean);
    if (parts.length === 2 && parts[0] === 'invite' && INVITE_TOKEN_RE.test(parts[1])) return { type: 'token' as const, value: parts[1] };
    return { type: 'invalid' as const, value: '' };
  } catch {
    return { type: 'invalid' as const, value: '' };
  }
}

export default function HomePage() {
  const router = useRouter();
  const [value, setValue] = useState('');
  const [loading, setLoading] = useState(false);

  async function join(e: React.FormEvent) {
    e.preventDefault();
    const parsed = normalizeJoinValue(value);
    if (parsed.type === 'invalid') return toast.error('Enter a valid meeting code or Defensiq invitation link');
    setLoading(true);
    try {
      if (parsed.type === 'code') {
        const data = await api<CodeLookup>(`/meetings/code/${encodeURIComponent(parsed.value)}`, { auth: false });
        const token = normalizeJoinValue(data.invitation.url);
        if (token.type !== 'token') throw new Error('Invitation link is invalid');
        router.push(`/invite/${token.value}`);
      } else {
        router.push(`/invite/${encodeURIComponent(parsed.value)}`);
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Meeting not found');
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="grid min-h-screen place-items-center bg-slate-950 p-4 text-white">
      <form onSubmit={join} className="w-full max-w-xl rounded-4xl border border-white/10 bg-white/10 p-6 shadow-2xl backdrop-blur-xl">
        <h1 className="text-center text-3xl font-black">Join Meeting</h1>
        <p className="mt-2 text-center text-sm text-slate-300">Enter your meeting code or paste a Defensiq invitation link.</p>
        <div className="mt-6 flex flex-col gap-3 sm:flex-row">
          <input
            value={value}
            onChange={(e) => setValue(e.target.value.slice(0, 700))}
            inputMode="text"
            autoCapitalize="none"
            autoComplete="off"
            spellCheck={false}
            pattern="([A-Za-z0-9]{3}-[A-Za-z0-9]{3}-[A-Za-z0-9]{3}|[A-Za-z0-9_-]{32,160}|https?://.+/invite/[A-Za-z0-9_-]{32,160})"
            placeholder="abc-123-xyz or /invite link"
            className="min-w-0 flex-1 rounded-2xl border border-white/10 bg-white px-4 py-3 text-slate-950 outline-none focus:ring-2 focus:ring-brand-500"
          />
          <Button disabled={loading} className="shrink-0"><LogIn size={18}/>{loading ? 'Opening...' : 'Join'}</Button>
        </div>
      </form>
    </main>
  );
}
