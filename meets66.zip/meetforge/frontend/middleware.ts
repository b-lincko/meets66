import { NextRequest, NextResponse } from 'next/server';

const protectedPrefixes = [
  '/dashboard',
  '/change-password',
  '/meet/',
  '/meetings',
  '/recordings',
  '/admins',
  '/settings',
  '/security',
  '/integrations',
  '/performance',
];

function isProtectedPath(pathname: string) {
  return protectedPrefixes.some((prefix) => pathname === prefix || pathname.startsWith(`${prefix}/`) || pathname.startsWith(prefix));
}

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  if (!isProtectedPath(pathname)) return NextResponse.next();
  const marker = request.cookies.get('defensiq_admin_present')?.value;
  if (marker === '1') return NextResponse.next();
  const url = request.nextUrl.clone();
  url.pathname = '/not-found';
  url.search = '';
  return NextResponse.rewrite(url);
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico|.*\\.(?:png|jpg|jpeg|gif|svg|webp|ico)$).*)'],
};
