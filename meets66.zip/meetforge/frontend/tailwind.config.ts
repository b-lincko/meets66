import type { Config } from 'tailwindcss';

const config: Config = {
  darkMode: 'class',
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}', './lib/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: { 50: '#eef7ff', 100: '#d9ecff', 500: '#3287f6', 600: '#1f68eb', 700: '#1a53d8' }
      },
      borderRadius: { '4xl': '2rem' },
      boxShadow: { glass: '0 24px 80px rgba(15,23,42,.16)' },
      backgroundImage: { mesh: 'radial-gradient(circle at top left, rgba(37,99,235,.22), transparent 35%), radial-gradient(circle at bottom right, rgba(20,184,166,.16), transparent 35%)' }
    }
  },
  plugins: []
};
export default config;
