@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo [Defensiq Meet] Checking Docker...
where docker >nul 2>nul
if errorlevel 1 (
  echo [Defensiq Meet] Docker not found. Attempting Docker Desktop install.
  where winget >nul 2>nul
  if not errorlevel 1 (
    winget install --id Docker.DockerDesktop -e --accept-package-agreements --accept-source-agreements
  ) else (
    echo [Defensiq Meet] Install Docker Desktop from https://www.docker.com/products/docker-desktop/ and rerun.
    pause
    exit /b 1
  )
)

docker info >nul 2>nul
if errorlevel 1 (
  if exist "%ProgramFiles%\Docker\Docker\Docker Desktop.exe" start "" "%ProgramFiles%\Docker\Docker\Docker Desktop.exe"
  echo [Defensiq Meet] Waiting for Docker daemon...
  for /L %%I in (1,1,90) do (
    docker info >nul 2>nul
    if not errorlevel 1 goto DockerReady
    timeout /t 2 /nobreak >nul
  )
  echo [Defensiq Meet] Docker daemon did not become ready.
  pause
  exit /b 1
)
:DockerReady

docker compose version >nul 2>nul
if not errorlevel 1 (
  set "COMPOSE=docker compose"
) else (
  where docker-compose >nul 2>nul
  if errorlevel 1 (
    echo [Defensiq Meet] Docker Compose is required.
    pause
    exit /b 1
  )
  set "COMPOSE=docker-compose"
)

if not exist ".env" (
  echo [Defensiq Meet] Creating .env
  copy ".env.example" ".env" >nul
)

for %%L in ("SOCKETIO_MESSAGE_QUEUE=redis://redis:6379/2" "LIVEKIT_URL=ws://localhost:7880" "LIVEKIT_INTERNAL_URL=ws://livekit:7880" "LIVEKIT_API_KEY=devkey" "LIVEKIT_API_SECRET=secret" "LIVEKIT_ROOM_PREFIX=defensiq" "NEXT_PUBLIC_SOCKET_URL=http://localhost:5000" "NEXT_PUBLIC_LIVEKIT_URL=ws://localhost:7880") do (
  for /f "tokens=1 delims==" %%K in ("%%~L") do (
    findstr /B /C:"%%K=" ".env" >nul 2>nul
    if errorlevel 1 echo %%~L>> ".env"
  )
)

echo [Defensiq Meet] Validating Compose configuration...
%COMPOSE% config >nul
if errorlevel 1 (
  echo [Defensiq Meet] Docker Compose configuration is invalid.
  pause
  exit /b 1
)

echo [Defensiq Meet] Building and starting Phase 1 application...
%COMPOSE% up --build -d
if errorlevel 1 (
  echo [Defensiq Meet] Failed to start containers.
  pause
  exit /b 1
)

echo.
echo Frontend:    http://localhost:3000
echo API health:  http://localhost:5000/api/v1/health
echo Gateway:     http://localhost:8080
echo.
echo [Defensiq Meet] Following logs. Press Ctrl+C to stop watching; containers keep running.
%COMPOSE% logs -f backend frontend
