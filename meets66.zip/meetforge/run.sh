#!/usr/bin/env sh
set -eu
PROJECT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$PROJECT_DIR"

log() { printf '\033[1;34m[Defensiq Meet]\033[0m %s\n' "$*"; }
fail() { printf '\033[1;31m[Defensiq Meet]\033[0m %s\n' "$*" >&2; exit 1; }

as_root() {
  if [ "$(id -u)" = "0" ]; then "$@"; elif command -v sudo >/dev/null 2>&1; then sudo "$@"; else fail "Root privileges are required to install/start Docker."; fi
}

if ! command -v docker >/dev/null 2>&1; then
  log "Docker not found. Attempting installation."
  if command -v apt-get >/dev/null 2>&1; then as_root apt-get update && as_root apt-get install -y docker.io docker-compose-plugin;
  elif command -v dnf >/dev/null 2>&1; then as_root dnf install -y docker docker-compose-plugin;
  elif command -v yum >/dev/null 2>&1; then as_root yum install -y docker docker-compose;
  elif command -v brew >/dev/null 2>&1; then brew install --cask docker;
  else fail "Install Docker Engine/Desktop and Docker Compose, then rerun."; fi
fi

if ! docker info >/dev/null 2>&1; then
  log "Starting Docker daemon."
  if command -v systemctl >/dev/null 2>&1; then as_root systemctl start docker || true; fi
  if command -v open >/dev/null 2>&1; then open -a Docker || true; fi
fi

i=0
while ! docker info >/dev/null 2>&1; do
  i=$((i+1)); [ "$i" -gt 90 ] && fail "Docker daemon did not become ready."; sleep 2
done

if docker compose version >/dev/null 2>&1; then COMPOSE="docker compose"; elif command -v docker-compose >/dev/null 2>&1; then COMPOSE="docker-compose"; else fail "Docker Compose is required."; fi

[ -f .env ] || { log "Creating .env"; cp .env.example .env; }
for line in \
  "SOCKETIO_MESSAGE_QUEUE=redis://redis:6379/2" \
  "LIVEKIT_URL=ws://localhost:7880" \
  "LIVEKIT_INTERNAL_URL=ws://livekit:7880" \
  "LIVEKIT_API_KEY=devkey" \
  "LIVEKIT_API_SECRET=secret" \
  "LIVEKIT_ROOM_PREFIX=defensiq" \
  "NEXT_PUBLIC_SOCKET_URL=http://localhost:5000" \
  "NEXT_PUBLIC_LIVEKIT_URL=ws://localhost:7880"; do
  key="${line%%=*}"
  grep -q "^$key=" .env || printf '\n%s\n' "$line" >> .env
done
log "Validating Compose configuration."
$COMPOSE config >/dev/null
log "Building and starting Phase 1 application."
$COMPOSE up --build -d

printf '\nFrontend:    http://localhost:3000\nAPI health:  http://localhost:5000/api/v1/health\nGateway:     http://localhost:8080\n\n'
log "Following logs. Press Ctrl+C to stop watching; containers keep running."
$COMPOSE logs -f backend frontend
