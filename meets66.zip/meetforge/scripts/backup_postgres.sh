#!/usr/bin/env sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
cd "$ROOT"
COMPOSE="docker compose"
if ! docker compose version >/dev/null 2>&1; then COMPOSE="docker-compose"; fi
mkdir -p backups
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT="backups/meetforge-${STAMP}.sql"
$COMPOSE exec -T postgres pg_dump -U meetforge -d meetforge --clean --if-exists > "$OUT"
sha256sum "$OUT" > "${OUT}.sha256"
printf 'Backup written to %s\n' "$OUT"
