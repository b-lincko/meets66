@echo off
setlocal EnableExtensions
cd /d "%~dp0\.."
if not exist backups mkdir backups
for /f %%I in ('powershell -NoProfile -Command "Get-Date -AsUTC -Format yyyyMMddTHHmmssZ"') do set STAMP=%%I
set OUT=backups\meetforge-%STAMP%.sql
docker compose version >nul 2>nul
if not errorlevel 1 (
  set "COMPOSE=docker compose"
) else (
  set "COMPOSE=docker-compose"
)
%COMPOSE% exec -T postgres pg_dump -U meetforge -d meetforge --clean --if-exists > "%OUT%"
if errorlevel 1 exit /b 1
powershell -NoProfile -Command "Get-FileHash '%OUT%' -Algorithm SHA256 | ForEach-Object { $_.Hash + '  %OUT%' }" > "%OUT%.sha256"
echo Backup written to %OUT%
