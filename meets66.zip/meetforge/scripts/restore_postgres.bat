@echo off
setlocal EnableExtensions
if "%~1"=="" (
  echo Usage: scripts\restore_postgres.bat backups\file.sql
  exit /b 2
)
cd /d "%~dp0\.."
if not exist "%~1" (
  echo Backup file not found: %~1
  exit /b 2
)
docker compose version >nul 2>nul
if not errorlevel 1 (
  set "COMPOSE=docker compose"
) else (
  set "COMPOSE=docker-compose"
)
%COMPOSE% exec -T postgres psql -U meetforge -d meetforge < "%~1"
if errorlevel 1 exit /b 1
echo Restore completed from %~1
