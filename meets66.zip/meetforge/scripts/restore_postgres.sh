#!/usr/bin/env sh
set -eu
if [ "$#" -ne 1 ]; then
  echo "Usage: scripts/restore_postgres.sh backups/file.sql" >&2
  exit 2
fi
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
cd "$ROOT"
FILE="$1"
[ -f "$FILE" ] || { echo "Backup file not found: $FILE" >&2; exit 2; }
COMPOSE="docker compose"
if ! docker compose version >/dev/null 2>&1; then COMPOSE="docker-compose"; fi
$COMPOSE exec -T postgres psql -U meetforge -d meetforge < "$FILE"
printf 'Restore completed from %s\n' "$FILE"
